#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'harryberlin'

KODI_ACTIONS = {'Playlist': 'Action(Playlist)',
                'Screenshot': 'Action(Screenshot)',
                'Mute': 'Action(Mute)',
                'Info': 'Action(Info)',
                'Fullscreen': 'Action(FullScreen)',
                'Stepforward': 'Action(StepForward)',
                'Stepback': 'Action(StepBack)',
                'OSD': 'Action(OSD)',
                'Volume +': 'Action(VolumeUp)',
                'Volume -': 'Action(VolumeDown)',
                'Show Subtitles': 'Action(ShowSubtitles)',
                'Show Video Menu': 'Action(ShowVideoMenu)',
                'Home': 'ActivateWindow(Home)',
                'Music': 'ActivateWindow(Music)',
                'Player': 'ActivateWindow(1135)',
                'Repeat': 'PlayerControl(Repeat)',
                'Random': 'PlayerControl(Random)',
                'IBusCommunicator: On-Board': 'RunAddon(plugin.script.ibuscommunicator,obc)',
                'IBusCommunicator: Toggle DRL Light': 'RunAddon(plugin.script.ibuscommunicator,toggle_drl_light)',
                'IBusCommunicator: Mirros fold': 'RunAddon(plugin.script.ibuscommunicator,mirrors_fold)',
                'IBusCommunicator: Mirros unfold': 'RunAddon(plugin.script.ibuscommunicator,mirrors_unfold)',
                'IBusCommunicator: Settings': 'RunAddon(plugin.script.ibuscommunicator)',
                'SimplePlaylists: Add Current URL': 'RunPlugin(plugin://script.simpleplaylists/?mode=addCurrentUrl)',
                'SimplePlaylists: Show Playlists': 'RunPlugin(plugin://script.simpleplaylists/?mode=showPlaylists)'}