#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
import xbmc, xbmcgui, xbmcaddon
from resources.lib.log import *

__author__ = 'harryberlin'

KODI_ACTIONS = ['Action(Playlist)',
                'Action(Screenshot)',
                'Action(Mute)',
                'Action(Info)',
                'Action(FullScreen)',
                'Action(StepForward)',
                'Action(StepBack)',
                'Action(OSD)',
                'Action(ShowSubtitles)',
                'Action(ShowVideoMenu)',
                'ActivateWindow(Home)',
                'ActivateWindow(Music)',
                'ActivateWindow(1150)',
                'ActivateWindow(1135)',
                'PlayerControl(Repeat)',
                'PlayerControl(Random)',
                'RunAddon(plugin.script.ibuscommunicator)'
                ]
'''
KODI_ACTIONS = {'Playlist':'Action(Playlist)',
                'Screenshot':'Action(Screenshot)',
                'Mute':'Action(Mute)',
                'Info':'Action(Info)',
                'Fullscreen':'Action(FullScreen)',
                'StepForward':'Action(StepForward)',
                'StepBack':'Action(StepBack)',
                'OSD':'Action(OSD)',
                'Show Subtitles':'Action(ShowSubtitles)',
                'ShowVideoMenu':'Action(ShowVideoMenu)',
                'Home':'ActivateWindow(Home)',
                'Music':'ActivateWindow(Music)',
                'ON-BOARD':'ActivateWindow(1150)',
                'Player':'ActivateWindow(1135)',
                'Repeat':'PlayerControl(Repeat)',
                'Random':'PlayerControl(Random)',
                'IBusCommunicator Settings':'RunAddon(plugin.script.ibuscommunicator)'
                }
'''
def open_obcgui():
    xbmcaddon.Addon().openSettings()
    pass


def open_settings():
    xbmcaddon.Addon().openSettings()
    pass


def connect_ibus():
    pass


def disconnect_ibus():
    pass

def bm_set_button_event(button_nbr):
    log('Set Event for BM Button: %s' % button_nbr)
    favmusicpath = 'Favorite Music Path'
    custom = '-- CUSTOM --'
    reset  = '---- RESET ---'

    #temp = KODI_ACTIONS.keys()
    #temp.extend([favmusicpath,custom,reset])
    KODI_ACTIONS.extend([favmusicpath,custom,reset])

    ### Select and Set
    selected =  xbmcgui.Dialog().select("Choose Kodi Function",  KODI_ACTIONS)
    if selected != -1:
        if KODI_ACTIONS[selected] == reset:
            xbmcaddon.Addon().setSetting('bm_btn_%s' % button_nbr,'')

        elif KODI_ACTIONS[selected] == custom:
            response = xbmcgui.Dialog().input("Custom Kodi Function eingeben")
            if response == '': return
            xbmcaddon.Addon().setSetting('bm_btn_%s' % button_nbr,response)

        elif KODI_ACTIONS[selected] == favmusicpath:
            #response = xbmcgui.Dialog().browse(0, 'Custom Kodi Function eingeben', 'special://home')
            response = xbmcgui.Dialog().browseSingle(0, favmusicpath, 'files', '', False, False, '')
            if response == '': return
            xbmcaddon.Addon().setSetting('bm_btn_%s' % button_nbr,'ActivateWindow(Music,%s)' % response)

        else:
            xbmcaddon.Addon().setSetting('bm_btn_%s' % button_nbr,KODI_ACTIONS[selected])
    xbmc.sleep(1000)
    #open_settings()

def test():
    win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    current_control = win.getControl(win.getFocusId())
    #listitem = current_control......getLabel()

    #log("TEST: %s" % listitem)


def music_tag():
    log('MUSIC TAG START')
    from resources.lib.log import dlgInfoOk
    #mObject = xbmc.Player().getMusicInfoTag()
    vObject = xbmc.Player().getVideoInfoTag()
    log(dir(vObject))  # introspect'e das Objekt mal
    #sArtist = xbmc.Player().getMusicInfoTag().getArtist()
    #sTitle = xbmc.Player().getMusicInfoTag().getTitle()
    #print ('Artist: %s, Title: %s' % (sArtist,sTitle))
    log('MUSIC TAG ENDE')


# Start Script
count = len(sys.argv) - 1
if count > 0:
    given_args = sys.argv[1].split(';')
    if str(given_args[0]) == "obc":
        open_obcgui()
    elif str(given_args[0]) == "settings":
        open_settings()
    elif str(given_args[0]) == "connect_ibus":
        connect_ibus()
    elif str(given_args[0]) == "disconnect_ibus":
        disconnect_ibus()
    elif str(given_args[0]) == "test":
        test()
    elif str(given_args[0]) == "music_tag":
        music_tag()
    elif str(given_args[0]) == "disconnect_ibus":
        try:
            # add_iptv_item(str(given_args[1]))
            pass
        except:
            # add_iptv_item()
            pass
    elif str(given_args[0]) == "bm_btn":
        bm_set_button_event(given_args[1])
    else:
        # set_url_list(urlname=str(given_args[0]))
        pass

else:
    open_settings()
    # xbmcgui.Dialog().ok('IBusCommunictor','IBusCommunictor')

pass
