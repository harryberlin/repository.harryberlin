#! /bin/sh
echo "1" > /sys/class/gpio/gpio7/value
exit 0