#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'harryberlin'
import os
import sys
import xbmc, xbmcaddon
ADDON = xbmcaddon.Addon()
ADDONID = ADDON.getAddonInfo('id')
ADDONPATH = ADDON.getAddonInfo('path')
ADDONUSERPATH = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data', ADDONID)
ADDON_PDC_BG_PATH = os.path.join(ADDONPATH, 'resources', 'skins', 'Default', 'media', 'pdc', 'bgs', 'default.png')
ICON = os.path.join(ADDONPATH, 'icon.png')
KODILOGFILE = '/home/osmc/.kodi/temp/kodi.log'
BACKUPLOGFILEPATH = '/boot/ibuscommunicator'
EXTLOGFILEPATH = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data', ADDONID, 'logfiles', 'info.log')
EXTERNIBUSLOGFILEFULLPATH = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data', ADDONID, 'logfiles', 'data.log')
KODI_ACTIONS = ['Action(Playlist)',
 'Action(Screenshot)',
 'Action(Mute)',
 'Action(Info)',
 'Action(FullScreen)',
 'Action(StepForward)',
 'Action(StepBack)',
 'Action(OSD)',
 'Action(VolumeUp)',
 'Action(VolumeDown)',
 'Action(ShowSubtitles)',
 'Action(ShowVideoMenu)',
 'ActivateWindow(Home)',
 'ActivateWindow(Music)',
 'RunAddon(plugin.script.ibuscommunicator,obc)',
 'ActivateWindow(1135)',
 'PlayerControl(Repeat)',
 'PlayerControl(Random)',
 'RunAddon(plugin.script.ibuscommunicator)',
 'RunPlugin(plugin://script.simpleplaylists/?mode=addCurrentUrl)',
 'RunPlugin(plugin://script.simpleplaylists/?mode=showPlaylists)']
ACTION_PARENT_DIR = 9
ACTION_PREVIOUS_MENU = 10
ACTION_CLOSE_DIALOG = 51
ACTION_SELECT_ITEM = 7
ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4
ACTION_NAV_BACK = 92
ACTION_BACKSPACE = 110

def log(string):
    return xbmc.log('IBUSCOMMUNICATOR: %s' % string, xbmc.LOGNOTICE)


def note(heading, message = None, time = 5000):
    import xbmcgui
    xbmcgui.Dialog().notification(heading='%s' % heading, message='%s' % message if message else '', icon=ICON, time=time)
    log('NOTIFICATION: "%s%s"' % (heading, ' - %s' % message if message else ''))


def dialog_ok(label1, label2 = '', label3 = ''):
    import xbmcgui
    return xbmcgui.Dialog().ok('IBusCommunicator', label1, label2, label3)


def get_addon_setting(id):
    setting = xbmcaddon.Addon().getSetting(id)
    if setting.upper() == 'TRUE':
        return True
    if setting.upper() == 'FALSE':
        return False
    return '%s' % setting


def set_addon_setting(id, value):
    if type(value) == 'bool':
        xbmcaddon.Addon().setSetting(id, 'true' if value else 'false')
    else:
        xbmcaddon.Addon().setSetting(id, '%s' % value)


def get_property(property, id = 10000):
    import xbmcgui
    return xbmcgui.Window(id).getProperty(property)


def set_property(property, value, id = 10000):
    import xbmcgui
    xbmcgui.Window(id).setProperty(property, value)


def copy_log_file(show_dialog = False):
    import zipfile
    from datetime import datetime
    log('LOGFILE: COPY LOG FILE TO "/boot/ibuscommunicator"')
    if not os.path.exists(BACKUPLOGFILEPATH):
        os.popen('sudo -s mkdir %s' % BACKUPLOGFILEPATH)
    log('LOGFILE: Create Zip File')
    filename = datetime.now().strftime('%Y%m%d_%H%M%S_ibuscommunicator.zip')
    dest_logfile = os.path.join(BACKUPLOGFILEPATH, filename)
    zip = zipfile.ZipFile(os.path.join(ADDONUSERPATH, filename), 'w', zipfile.ZIP_DEFLATED)
    zip.write(KODILOGFILE, os.path.split(KODILOGFILE)[1])
    if not get_addon_setting('log_to_kodi'):
        zip.write(EXTLOGFILEPATH, os.path.split(EXTLOGFILEPATH)[1])
        zip.write(EXTERNIBUSLOGFILEFULLPATH, os.path.split(EXTERNIBUSLOGFILEFULLPATH)[1])
    zip.close()
    log('LOGFILE: Move Zip File')
    os.popen('sudo -s mv %s %s' % (os.path.join(ADDONUSERPATH, filename), dest_logfile))
    if show_dialog:
        dialog_ok('LOGFILE: <%s>' % filename, 'created on:', BACKUPLOGFILEPATH)


def copy_extra_addon_files():
    import xbmcgui
    if not xbmcgui.Dialog().yesno('IBusCommunicator', 'Are your sure to copy / replace skin files?', '', '[COLOR FFFF0000]NO BACKUP FUNCTION INCLUDED[/COLOR]'):
        return
    if xbmc.getSkinDir() != 'skin.confluence-vertical':
        dialog_ok('Current skin in not "skin.confluence-vertical"')
        return
    addon_path = os.path.join(ADDONPATH, 'resources', 'replace_skin_files', '*.*')
    skin_path = os.path.join(xbmcaddon.Addon(xbmc.getSkinDir()).getAddonInfo('path'), '720p')
    os.popen('sudo -s cp %s %s' % (addon_path, skin_path))
    if not xbmcgui.Dialog().yesno('IBusCommunicator', 'Extra addon skin files were', 'copied / replaced.', yeslabel='Restart Kodi', nolabel='Reload Skin'):
        xbmc.executebuiltin('ReloadSkin()')
    else:
        os.popen('sudo systemctl restart mediacenter')


def send_command(message):
    import socket
    clientsocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    port = int(get_addon_setting('tcp_port'))
    try:
        clientsocket.connect(('localhost', port))
    except:
        return False

    log('# TCP %s: SEND >%s<' % (port, message.upper()))
    clientsocket.send(message)
    answer = clientsocket.recv(100).replace('\n', '')
    if answer == 'OK':
        return True
    else:
        return False


def open_obcgui():
    if not send_command('obc'):
        note('error by opening OBC GUI')


def open_settings():
    import xbmcgui
    if xbmcgui.getCurrentWindowDialogId() == 10140:
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Back", "id": 1 }')
    else:
        xbmcaddon.Addon().openSettings()


def connect_ibus():
    pass


def disconnect_ibus():
    pass


def bm_set_button_event(button_nbr):
    import xbmcgui
    log('Set Event for BM Button: %s' % button_nbr)
    favmusicpath = 'Favorite Music Path'
    custom = '-- CUSTOM --'
    reset = '---- RESET ---'
    KODI_ACTIONS.extend([favmusicpath, custom, reset])
    selected = xbmcgui.Dialog().select('Choose Kodi Function', KODI_ACTIONS)
    if selected != -1:
        if KODI_ACTIONS[selected] == reset:
            xbmcaddon.Addon().setSetting('bm_btn_%s' % button_nbr, '')
        elif KODI_ACTIONS[selected] == custom:
            response = xbmcgui.Dialog().input('Custom Kodi Function eingeben')
            if response == '':
                return
            xbmcaddon.Addon().setSetting('bm_btn_%s' % button_nbr, response)
        elif KODI_ACTIONS[selected] == favmusicpath:
            response = xbmcgui.Dialog().browseSingle(0, favmusicpath, 'files', '', False, False, '')
            if response == '':
                return
            xbmcaddon.Addon().setSetting('bm_btn_%s' % button_nbr, 'ActivateWindow(Music,%s)' % response)
        else:
            xbmcaddon.Addon().setSetting('bm_btn_%s' % button_nbr, KODI_ACTIONS[selected])
    xbmc.sleep(1000)


def pdc_bg():
    import xbmcgui
    log('PDC: Set Model Type')
    default = xbmcaddon.Addon().getSetting('pdc_bg')
    selected = xbmcgui.Dialog().browse(2, 'Choose Kodi Function', 'files', '.png', True, False, default)
    if selected != default:
        xbmcaddon.Addon().setSetting('pdc_bg', selected)
        xbmcgui.Window(10000).setProperty('pdc_bg', os.path.splitext(os.path.basename(selected))[0])
    xbmc.sleep(1000)


def set_serialport():
    import xbmcgui
    from serial.tools import list_ports
    log('#'.join(list_ports.main()))


def test():
    import xbmcgui
    win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    current_control = win.getControl(win.getFocusId())


def music_tag():
    log('MUSIC TAG START')
    vObject = xbmc.Player().getVideoInfoTag()
    log(dir(vObject))
    log('MUSIC TAG ENDE')


def main():
    count = len(sys.argv) - 1
    if count > 0:
        given_args = sys.argv[1].split(';')
        if str(given_args[0]) == 'obc':
            open_obcgui()
        elif str(given_args[0]) == 'settings':
            open_settings()
        elif str(given_args[0]) == 'connect_ibus':
            connect_ibus()
        elif str(given_args[0]) == 'disconnect_ibus':
            disconnect_ibus()
        elif str(given_args[0]) == 'test':
            test()
        elif str(given_args[0]) == 'copy_logfile':
            copy_log_file(True)
        elif str(given_args[0]) == 'pdc_bg':
            pdc_bg()
        elif str(given_args[0]) == 'setup':
            copy_extra_addon_files()
        elif str(given_args[0]) == 'music_tag':
            music_tag()
        elif str(given_args[0]) == 'disconnect_ibus':
            try:
                pass
            except:
                pass

        elif str(given_args[0]) == 'bm_btn':
            bm_set_button_event(given_args[1])
        else:
            note('Unknown Arguments given!')
    else:
        open_settings()


if __name__ == '__main__':
    main()
