#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'harryberlin'
import sys
import os
import xbmc, xbmcgui, xbmcaddon, xbmcvfs
ADDON = xbmcaddon.Addon()
ADDONNAME = ADDON.getAddonInfo('name')
ADDONID = ADDON.getAddonInfo('id')
ADDONPATH = ADDON.getAddonInfo('path')
ADDONUSERPATH = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data', ADDONID)
ADDONVERSION = ADDON.getAddonInfo('version')
ADDONMEDIAPATH = os.path.join(ADDONPATH, 'resources', 'skins', 'Default', 'media')
ADDONPDCPATH = os.path.join(ADDONPATH, 'resources', 'skins', 'Default', 'media', 'pdc')
ADDONGAUGEPATH = os.path.join(ADDONPATH, 'resources', 'skins', 'Default', 'media', 'gauges')
ICON = os.path.join(ADDONPATH, 'icon.png')
BASE_RESOURCE_PATH = os.path.join(ADDONPATH, 'resources')
BASE_LIB_PATH = os.path.join(ADDONPATH, 'resources', 'lib')
sys.path.append(BASE_RESOURCE_PATH)
sys.path.append(BASE_LIB_PATH)
from re import findall
import time
import serial
import socket
import logging
import zipfile
import subprocess
from re import findall
from datetime import datetime
from functools import partial
from threading import Thread, Lock, Event, activeCount
from Queue import PriorityQueue, Empty, Queue
KODILOGFILE = '/home/osmc/.kodi/temp/kodi.log'
BACKUPLOGFILEPATH = '/boot/ibuscommunicator'
EXTLOGFILEPATH = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data', ADDONID, 'logfiles', 'info.log')
EXTERNIBUSLOGFILEFULLPATH = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data', ADDONID, 'logfiles', 'data.log')
BIT = [7,
 6,
 5,
 4,
 3,
 2,
 1,
 0]

class RepeatTimer(Thread):

    def __init__(self, interval, function, iterations = 0, args = [], kwargs = {}):
        Thread.__init__(self)
        self.interval = interval
        self.function = function
        self.iterations = iterations
        self.args = args
        self.kwargs = kwargs
        self.finished = Event()

    def run(self):
        count = 0
        while not self.finished.isSet() and (self.iterations <= 0 or count < self.iterations):
            self.finished.wait(self.interval)
            if not self.finished.isSet():
                self.function(*self.args, **self.kwargs)
                count += 1

    def cancel(self):
        self.finished.set()


class TimerClass(Thread):

    def __init__(self, interval, function, args = [], kwargs = {}, loop = False):
        Thread.__init__(self)
        self.interval = interval
        self.counter = interval
        self.function = function
        self.args = args
        self.kwargs = kwargs
        self.loop = loop
        self.cancelTimer = False
        self.pauseTimer = False
        self.finished = Event()

    def run(self):
        while not self.cancelTimer:
            if self.cancelTimer:
                break
            if not self.finished.isSet():
                if self.counter <= 0:
                    self.function(*self.args, **self.kwargs)
                    if self.loop:
                        self.counter = self.interval
                    else:
                        break
                elif not self.pauseTimer:
                    self.counter -= 1

        self.finished.set()
        self.cancelTimer = False
        self.finished.set()

    def cancel(self):
        self.cancelTimer = True

    def restart(self):
        self.counter = self.interval

    def pause(self):
        self.pauseTimer = True

    def resume(self):
        self.pauseTimer = False

    def isPause(self):
        return self.pauseTimer


class Logger(object):

    def __init__(self, filefullpath):
        logger_name = '%s' % time.time()
        self.logger = logging.getLogger(logger_name)
        directoryname, filename = os.path.split(filefullpath)
        print directoryname
        print filename
        if not os.path.exists(directoryname):
            os.makedirs(directoryname)
        with open(filefullpath, 'wb') as f:
            f.write(bytearray([239, 187, 191]))
        self.logger = logging.getLogger(logger_name)
        fileHandler = logging.FileHandler(filefullpath, mode='a', encoding='utf-8')
        formatter = logging.Formatter('%(asctime)-15s: %(message)s')
        fileHandler.setFormatter(formatter)
        self.logger.setLevel(logging.INFO)
        self.logger.addHandler(fileHandler)

    def log(self, string):
        self.logger.info('%s' % string.decode('utf-8'))


class ObcGuiClass(xbmcgui.WindowXML):
    obc_screen = 0
    MAINLABEL = {}
    BUTTON1 = {}
    BUTTON2 = {}
    BUTTON3 = {}
    BUTTON4 = {}
    BUTTON5 = {}
    BUTTON6 = {}
    BUTTON7 = {}
    BUTTON8 = {}
    LABEL1 = {}
    LABEL2 = {}
    LABEL3 = {}
    LABEL4 = {}
    LABEL5 = {}
    LABEL6 = {}
    LABEL7 = {}
    LABEL8 = {}
    IMAGE1 = {}
    IMAGE2 = {}
    IMAGE3 = {}
    IMAGE4 = {}
    IMAGE5 = {}
    IMAGE6 = {}
    IMAGE7 = {}
    IMAGE8 = {}
    GAUGE_L = [None, None]
    GAUGE_M = [None, None]
    GAUGE_R = [None, None]
    isActive = False
    ACTION_PARENT_DIR = 9
    ACTION_PREVIOUS_MENU = 10
    ACTION_CLOSE_DIALOG = 51
    ACTION_SELECT_ITEM = 7
    ACTION_MOVE_LEFT = 1
    ACTION_MOVE_RIGHT = 2
    ACTION_MOVE_UP = 3
    ACTION_MOVE_DOWN = 4
    ACTION_NAV_BACK = 92
    ACTION_BACKSPACE = 110

    def __init__(self, xmlFilename, scriptPath, defaultSkin, defaultRes):
        log('Initializing OBC Gui...')
        self.pause_submenu_counter = False
        self.obc_set_value = ObcSetValueClass('OBC_SETVALUE.xml', ADDONPATH, 'Default', '720p')

    def isVisible(self):
        if self.isActive and xbmcgui.getCurrentWindowId() == 13000:
            return True
        else:
            return False

    def onInit(self):
        self.COOLANT = [['- K\xc3\xbchlwassertemperatur', True, False], [partial(EVENT.obc_coolant_get),
          True,
          True,
          [],
          []], []]
        self.CONS1 = [['Verbrauch 1', True, True], [partial(EVENT.obc_cons1_get),
          True,
          True,
          ['RESET'],
          [partial(EVENT.obc_cons1_reset)]], []]
        self.CONS2 = [['Verbrauch 2', True, True], [partial(EVENT.obc_cons2_get),
          True,
          True,
          ['RESET'],
          [partial(EVENT.obc_cons2_reset)]], []]
        self.RANGE = [['- Reichweite', True, False], [partial(EVENT.obc_range_get),
          True,
          True,
          [],
          []], []]
        self.FUELLEVEL = [['- Tankinhalt', True, False], [partial(EVENT.obc_fuellevel_get),
          True,
          True,
          [],
          []], []]
        self.DIST = [['Distanz', True, True], [partial(EVENT.obc_dist_get),
          True,
          True,
          ['SET', 'RESET'],
          [partial(self.set_distance), partial(EVENT.obc_dist_reset)]], []]
        self.ARR = [['- Ankunft', True, False], [partial(EVENT.obc_arr_get),
          True,
          True,
          [],
          []], []]
        self.RPM = [['- Drehzahl', True, False], [partial(EVENT.obc_rpm_get),
          True,
          True,
          [],
          []], []]
        self.SPEED = [['- Akt. Geschwindigkeit', True, False], [partial(EVENT.obc_speed_get),
          True,
          True,
          [],
          []], []]
        self.AVG = [['Geschwindigkeit', True, True], [partial(EVENT.obc_avg_get),
          True,
          True,
          ['RESET'],
          [partial(EVENT.obc_avg_reset)]], []]
        self.LIMIT = [['Limit', True, True], [partial(EVENT.obc_limit_get),
          True,
          True,
          ['SET',
           'SPEED',
           'RESET',
           'ACTIVATE',
           'DEACTIVATE'],
          [partial(self.set_limit),
           partial(EVENT.obc_limit_set),
           partial(EVENT.obc_limit_reset),
           partial(EVENT.obc_limit_enable, True),
           partial(EVENT.obc_limit_enable, False)]], [EVENT.obc_limit_get_ind]]
        self.MEMO = [['Memo', True, True], [' ',
          True,
          True,
          ['ACTIVATE', 'DEACTIVATE'],
          [partial(EVENT.obc_memo_enable, True), partial(EVENT.obc_memo_enable, False)]], [EVENT.obc_memo_get_ind]]
        self.TMR1 = [['Timer 1', True, True], [partial(EVENT.obc_tmr1_get),
          True,
          True,
          ['SET',
           'RESET',
           'ACTIVATE',
           'DEACTIVATE'],
          [partial(note, 'Under Construction'),
           partial(EVENT.obc_tmr1_reset),
           partial(EVENT.obc_tmr1_enable, True),
           partial(EVENT.obc_tmr1_enable, False)]], [EVENT.obc_tmr1_get_ind]]
        self.TMR2 = [['Timer 2', True, True], [partial(EVENT.obc_tmr2_get),
          True,
          True,
          ['SET',
           'RESET',
           'ACTIVATE',
           'DEACTIVATE'],
          [partial(note, 'Under Construction'),
           partial(EVENT.obc_tmr2_reset),
           partial(EVENT.obc_tmr2_enable, True),
           partial(EVENT.obc_tmr2_enable, False)]], [EVENT.obc_tmr2_get_ind]]
        self.STPWTCH = [['- Stopuhr', True, False], [partial(EVENT.obc_stpwtch_get),
          True,
          True,
          [],
          []], []]
        self.VOLTAGE = [['- Bordspannung', True, False], [partial(EVENT.obc_voltage_get),
          True,
          True,
          [],
          []], []]
        self.KEYS = [['- Fahrzeugschl\xc3\xbcssel', True, False], [partial(EVENT.obc_key_get),
          True,
          True,
          [],
          []], []]
        self.VIN = [['- VIN', True, False], [partial(EVENT.obc_vin_get),
          True,
          True,
          [],
          []], []]
        self.ODOMETER = [['- Kilometerstand', True, False], [partial(EVENT.obc_odometer_get),
          True,
          True,
          [],
          []], []]
        self.AUXLBL = [[' ', True, False], [partial(EVENT.obc_auxventheat_label),
          True,
          True,
          [],
          []], []]
        self.AUXVENT = [['Standl\xc3\xbcftung', True, True], [' ',
          True,
          True,
          ['ACTIVATE', 'DEACTIVATE'],
          [partial(EVENT.obc_auxvent_enable, True), partial(EVENT.obc_auxvent_enable, False)]], [EVENT.obc_auxvent_get_ind]]
        self.AUXHEAT = [['Standheizung', True, True], [' ',
          True,
          True,
          ['ACTIVATE', 'DEACTIVATE'],
          [partial(EVENT.obc_auxheat_enable, True), partial(EVENT.obc_auxheat_enable, False)]], [EVENT.obc_auxheat_get_ind]]
        self.GPSFIX = [['- GPS FIX', True, False], [partial(EVENT.nav_time_get),
          True,
          True,
          [],
          []], [EVENT.nav_gpsfix_get]]
        self.GPSTOWN = [['- Ort', True, False], [partial(EVENT.nav_town_get),
          True,
          True,
          [],
          []], []]
        self.GPSSTREET = [['- Stra\xc3\x9fe', True, False], [partial(EVENT.nav_street_get),
          True,
          True,
          [],
          []], []]
        self.GPSLAT = [['- Latitude', True, False], [partial(EVENT.nav_latitude_get),
          True,
          True,
          [],
          []], []]
        self.GPSLON = [['- Longitude', True, False], [partial(EVENT.nav_longitude_get),
          True,
          True,
          [],
          []], []]
        self.GPSALT = [['- Altitude', True, False], [partial(EVENT.nav_altitude_get),
          True,
          True,
          [],
          []], []]
        self.EMPTY = [[' ', False, False], [' ',
          False,
          False,
          [],
          []], []]
        self.obc_screen_min = 0
        self.obc_screen_max = 4
        self.MAINLABEL[0] = ['ON-BOARD', True, True]
        self.BUTTON1[0], self.LABEL1[0], self.IMAGE1[0] = self.CONS1
        self.BUTTON2[0], self.LABEL2[0], self.IMAGE2[0] = self.CONS2
        self.BUTTON3[0], self.LABEL3[0], self.IMAGE3[0] = self.RANGE
        self.BUTTON4[0], self.LABEL4[0], self.IMAGE4[0] = self.FUELLEVEL
        self.BUTTON5[0], self.LABEL5[0], self.IMAGE5[0] = self.DIST
        self.BUTTON6[0], self.LABEL6[0], self.IMAGE6[0] = self.ARR
        self.BUTTON7[0], self.LABEL7[0], self.IMAGE7[0] = self.LIMIT
        self.BUTTON8[0], self.LABEL8[0], self.IMAGE8[0] = self.SPEED
        self.MAINLABEL[1] = ['ON-BOARD', True, True]
        self.BUTTON1[1], self.LABEL1[1], self.IMAGE1[1] = self.AVG
        self.BUTTON2[1], self.LABEL2[1], self.IMAGE2[1] = self.MEMO
        self.BUTTON3[1], self.LABEL3[1], self.IMAGE3[1] = self.STPWTCH
        self.BUTTON4[1], self.LABEL4[1], self.IMAGE4[1] = self.EMPTY
        self.BUTTON5[1], self.LABEL5[1], self.IMAGE5[1] = self.TMR1
        self.BUTTON6[1], self.LABEL6[1], self.IMAGE6[1] = self.TMR2
        self.BUTTON7[1], self.LABEL7[1], self.IMAGE7[1] = self.AUXVENT
        self.BUTTON8[1], self.LABEL8[1], self.IMAGE8[1] = self.AUXHEAT
        self.MAINLABEL[2] = ['INFORMATION', True, True]
        self.BUTTON1[2], self.LABEL1[2], self.IMAGE1[2] = self.KEYS
        self.BUTTON2[2], self.LABEL2[2], self.IMAGE2[2] = self.ODOMETER
        self.BUTTON3[2], self.LABEL3[2], self.IMAGE3[2] = self.VIN
        self.BUTTON4[2], self.LABEL4[2], self.IMAGE4[2] = self.RPM
        self.BUTTON5[2], self.LABEL5[2], self.IMAGE5[2] = self.COOLANT
        self.BUTTON6[2], self.LABEL6[2], self.IMAGE6[2] = self.VOLTAGE
        self.BUTTON7[2], self.LABEL7[2], self.IMAGE7[2] = self.EMPTY
        self.BUTTON8[2], self.LABEL8[2], self.IMAGE8[2] = self.EMPTY
        self.MAINLABEL[3] = ['GPS', True, True]
        self.BUTTON1[3], self.LABEL1[3], self.IMAGE1[3] = self.GPSFIX
        self.BUTTON2[3], self.LABEL2[3], self.IMAGE2[3] = self.GPSTOWN
        self.BUTTON3[3], self.LABEL3[3], self.IMAGE3[3] = self.GPSSTREET
        self.BUTTON4[3], self.LABEL4[3], self.IMAGE4[3] = self.GPSLAT
        self.BUTTON5[3], self.LABEL5[3], self.IMAGE5[3] = self.GPSLON
        self.BUTTON6[3], self.LABEL6[3], self.IMAGE6[3] = self.GPSALT
        self.BUTTON7[3], self.LABEL7[3], self.IMAGE7[3] = self.EMPTY
        self.BUTTON8[3], self.LABEL8[3], self.IMAGE8[3] = self.EMPTY
        self.MAINLABEL[self.obc_screen_max] = ['INSTRUMENTS', True, True]
        self.BUTTON1[self.obc_screen_max], self.LABEL1[self.obc_screen_max], self.IMAGE1[self.obc_screen_max] = self.EMPTY
        self.BUTTON2[self.obc_screen_max], self.LABEL2[self.obc_screen_max], self.IMAGE2[self.obc_screen_max] = self.EMPTY
        self.BUTTON3[self.obc_screen_max], self.LABEL3[self.obc_screen_max], self.IMAGE3[self.obc_screen_max] = self.EMPTY
        self.BUTTON4[self.obc_screen_max], self.LABEL4[self.obc_screen_max], self.IMAGE4[self.obc_screen_max] = self.EMPTY
        self.BUTTON5[self.obc_screen_max], self.LABEL5[self.obc_screen_max], self.IMAGE5[self.obc_screen_max] = self.EMPTY
        self.BUTTON6[self.obc_screen_max], self.LABEL6[self.obc_screen_max], self.IMAGE6[self.obc_screen_max] = self.EMPTY
        self.BUTTON7[self.obc_screen_max], self.LABEL7[self.obc_screen_max], self.IMAGE7[self.obc_screen_max] = self.EMPTY
        self.BUTTON8[self.obc_screen_max], self.LABEL8[self.obc_screen_max], self.IMAGE8[self.obc_screen_max] = self.EMPTY
        log('OBC: GUI Opening')
        self.selectedButton = -1
        self.selectedSubButton = -1
        self.timeoutSubMenu = 2000
        self.obc_screen_next = False
        self.isActive = True
        self.MAINLABEL[-1] = self.getControl(200)
        self.mainleft = self.getControl(201)
        self.mainright = self.getControl(202)
        self.IMAGE1[-1] = self.getControl(101)
        self.IMAGE2[-1] = self.getControl(102)
        self.IMAGE3[-1] = self.getControl(103)
        self.IMAGE4[-1] = self.getControl(104)
        self.IMAGE5[-1] = self.getControl(105)
        self.IMAGE6[-1] = self.getControl(106)
        self.IMAGE7[-1] = self.getControl(107)
        self.IMAGE8[-1] = self.getControl(108)
        self.BUTTON1[-1] = self.getControl(111)
        self.BUTTON2[-1] = self.getControl(112)
        self.BUTTON3[-1] = self.getControl(113)
        self.BUTTON4[-1] = self.getControl(114)
        self.BUTTON5[-1] = self.getControl(115)
        self.BUTTON6[-1] = self.getControl(116)
        self.BUTTON7[-1] = self.getControl(117)
        self.BUTTON8[-1] = self.getControl(118)
        self.LABEL1[-1] = self.getControl(121)
        self.LABEL2[-1] = self.getControl(122)
        self.LABEL3[-1] = self.getControl(123)
        self.LABEL4[-1] = self.getControl(124)
        self.LABEL5[-1] = self.getControl(125)
        self.LABEL6[-1] = self.getControl(126)
        self.LABEL7[-1] = self.getControl(127)
        self.LABEL8[-1] = self.getControl(128)
        self.GAUGE_L = [self.getControl(203), self.getControl(213)]
        self.GAUGE_M = [self.getControl(204), self.getControl(214)]
        self.GAUGE_R = [self.getControl(205), self.getControl(215)]
        self.LABEL211 = self.getControl(211)
        self.update(startup=True)
        self.set_default_navigation()
        self.updateTimer = RepeatTimer(0.333, self.update)
        self.updateTimer.start()
        self.some_obc_req()
        self.updateObc = RepeatTimer(1, self.some_obc_req)
        self.updateObc.start()
        EVENT.obc_req(True)

    def onClick(self, controlId):
        log('ONCLICK: %s' % controlId, 3)
        if controlId == 201:
            self.obcPrev()
        elif controlId == 202:
            self.obcNext()

    def onAction(self, Action):
        if Action in [self.ACTION_PREVIOUS_MENU,
         self.ACTION_CLOSE_DIALOG,
         self.ACTION_NAV_BACK,
         self.ACTION_BACKSPACE]:
            self.onStop()
        log('OBCGUI ACTION ID: %s' % Action.getId(), 1)
        log('OBCGUI FOCUS ID: %s' % self.getFocusId(), 3)
        if Action == self.ACTION_MOVE_LEFT and self.obc_screen > self.obc_screen_min:
            self.obcPrev()
        elif Action == self.ACTION_MOVE_RIGHT and self.obc_screen < self.obc_screen_max:
            self.obcNext()
        elif Action == self.ACTION_SELECT_ITEM:
            if self.selectedButton < 0:
                if self.set_submenu(0):
                    self.counter_submenu()
            else:
                log('submenu selected')
                log('obc screen %s' % self.obc_screen)
                log('Button %s' % self.selectedButton)
                log('SubButton %s' % self.selectedSubButton)
                self.onSubmenuSelected(self.obc_screen, self.selectedButton, self.selectedSubButton)
                self.timeoutSubMenu = 0
        elif Action == self.ACTION_MOVE_UP:
            if self.selectedButton > 0:
                self.set_submenu(self.selectedSubButton - 1)
                self.timeoutSubMenu = 2000
        elif Action == self.ACTION_MOVE_DOWN:
            if self.selectedButton > 0:
                self.set_submenu(self.selectedSubButton + 1)
                self.timeoutSubMenu = 2000
        log('OBCGUI FOCUSED ID: %s' % self.getFocusId(), 3)

    def onFocus(self, controlId):
        pass

    def onStop(self):
        log('OBC: GUI Closing')
        self.close()
        self.isActive = False
        self.updateObc.cancel()
        self.updateTimer.cancel()

    def set_default_navigation(self):
        self.BUTTON1[-1].setNavigation(self.BUTTON1[-1], self.BUTTON2[-1], self.BUTTON1[-1], self.BUTTON1[-1])
        self.BUTTON2[-1].setNavigation(self.BUTTON1[-1], self.BUTTON3[-1], self.BUTTON2[-1], self.BUTTON2[-1])
        self.BUTTON3[-1].setNavigation(self.BUTTON2[-1], self.BUTTON4[-1], self.BUTTON3[-1], self.BUTTON3[-1])
        self.BUTTON4[-1].setNavigation(self.BUTTON3[-1], self.BUTTON5[-1], self.BUTTON4[-1], self.BUTTON4[-1])
        self.BUTTON5[-1].setNavigation(self.BUTTON4[-1], self.BUTTON6[-1], self.BUTTON5[-1], self.BUTTON5[-1])
        self.BUTTON6[-1].setNavigation(self.BUTTON5[-1], self.BUTTON7[-1], self.BUTTON6[-1], self.BUTTON6[-1])
        self.BUTTON7[-1].setNavigation(self.BUTTON6[-1], self.BUTTON8[-1], self.BUTTON7[-1], self.BUTTON7[-1])
        self.BUTTON8[-1].setNavigation(self.BUTTON7[-1], self.BUTTON8[-1], self.BUTTON8[-1], self.BUTTON8[-1])

    def set_submenu(self, menu_pos):
        if self.getFocusId() == 111:
            label_textlist = self.LABEL1
            label_control = self.LABEL1[-1]
            self.selectedButton = 1
            button_control = self.BUTTON1[-1]
        elif self.getFocusId() == 112:
            label_textlist = self.LABEL2
            label_control = self.LABEL2[-1]
            self.selectedButton = 2
            button_control = self.BUTTON2[-1]
        elif self.getFocusId() == 113:
            label_textlist = self.LABEL3
            label_control = self.LABEL3[-1]
            self.selectedButton = 3
            button_control = self.BUTTON3[-1]
        elif self.getFocusId() == 114:
            label_textlist = self.LABEL4
            label_control = self.LABEL4[-1]
            self.selectedButton = 4
            button_control = self.BUTTON4[-1]
        elif self.getFocusId() == 115:
            label_textlist = self.LABEL5
            label_control = self.LABEL5[-1]
            self.selectedButton = 5
            button_control = self.BUTTON5[-1]
        elif self.getFocusId() == 116:
            label_textlist = self.LABEL6
            label_control = self.LABEL6[-1]
            self.selectedButton = 6
            button_control = self.BUTTON6[-1]
        elif self.getFocusId() == 117:
            label_textlist = self.LABEL7
            label_control = self.LABEL7[-1]
            self.selectedButton = 7
            button_control = self.BUTTON7[-1]
        elif self.getFocusId() == 118:
            label_textlist = self.LABEL8
            label_control = self.LABEL8[-1]
            self.selectedButton = 8
            button_control = self.BUTTON8[-1]
        else:
            return False
        if not len(label_textlist[self.obc_screen][3]) > 0:
            self.selectedButton = -1
            self.selectedSubButton = -1
            return False
        else:
            if menu_pos < 0:
                menu_pos = len(label_textlist[self.obc_screen][3]) - 1
            elif menu_pos > len(label_textlist[self.obc_screen][3]) - 1:
                menu_pos = 0
            if label_textlist[self.obc_screen][3][menu_pos]:
                label_control.setLabel(' ')
                time.sleep(0.1)
                color = 'FFFF7E00'
                label_control.setLabel('[COLOR %s]- %s -[/COLOR]' % (color, label_textlist[self.obc_screen][3][menu_pos]))
                self.selectedSubButton = menu_pos
                button_control.setNavigation(button_control, button_control, button_control, button_control)
                return True
            self.selectedButton = -1
            self.selectedSubButton = -1
            return False

    def reset_submenu(self):
        self.selectedButton = -1
        self.selectedSubButton = -1
        self.update()
        self.set_default_navigation()

    def onSubmenuSelected(self, obc_screen, button, sub_button):
        if button == 1:
            obc_event = self.LABEL1[obc_screen][4]
        elif button == 2:
            obc_event = self.LABEL2[obc_screen][4]
        elif button == 3:
            obc_event = self.LABEL3[obc_screen][4]
        elif button == 4:
            obc_event = self.LABEL4[obc_screen][4]
        elif button == 5:
            obc_event = self.LABEL5[obc_screen][4]
        elif button == 6:
            obc_event = self.LABEL6[obc_screen][4]
        elif button == 7:
            obc_event = self.LABEL7[obc_screen][4]
        elif button == 8:
            obc_event = self.LABEL8[obc_screen][4]
        else:
            return
        obc_event[sub_button]()

    def counter_submenu(self):
        self.timeoutSubMenu = 2000
        thread = Thread(target=self._counter_submenu)
        thread.setDaemon(True)
        thread.start()

    def _counter_submenu(self):
        while self.timeoutSubMenu > 0:
            if not self.pause_submenu_counter:
                self.timeoutSubMenu -= 1
            time.sleep(0.001)

        self.reset_submenu()

    def some_obc_req(self):
        if self.obc_screen_next or self.obc_screen == self.obc_screen_max:
            return
        log('OBCGUI: SOME REQUEST TICK', 3)
        if self.obc_screen == 2:
            EVENT.obc_voltage_req()
        elif self.obc_screen == 0:
            EVENT.ike_get_state()
        elif self.obc_screen == 3:
            EVENT.nav_position_req()
            EVENT.nav_location_req()

    def obcNext(self):
        self.obc_screen_next = True
        if self.obc_screen == self.obc_screen_max:
            KODI.set_property('IBUSCOMMUNICATOR_OBC_Gauges', '0')
        else:
            KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', 'left_out')
        self.obc_screen += 1
        if self.obc_screen > self.obc_screen_max:
            inv_slide_direction = True
            self.obc_screen = self.obc_screen_min
        else:
            inv_slide_direction = False
        time.sleep(0.5)
        self.obc_screen_next = False
        self.reset_submenu()
        if self.obc_screen == self.obc_screen_max and self.MAINLABEL[self.obc_screen_max][2]:
            KODI.set_property('IBUSCOMMUNICATOR_OBC_Gauges', '1')
        else:
            if inv_slide_direction:
                KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', 'left_in')
            else:
                KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', 'right_in')
            self.setFocus(self.BUTTON1[-1])

    def obcPrev(self):
        self.obc_screen_next = True
        if self.obc_screen == self.obc_screen_max and self.MAINLABEL[self.obc_screen_max][2]:
            KODI.set_property('IBUSCOMMUNICATOR_OBC_Gauges', '0')
        else:
            KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', 'right_out')
        self.obc_screen -= 1
        if self.obc_screen < self.obc_screen_min:
            inv_slide_direction = True
            self.obc_screen = self.obc_screen_max
        else:
            inv_slide_direction = False
        time.sleep(0.5)
        self.obc_screen_next = False
        self.reset_submenu()
        if self.obc_screen == self.obc_screen_max:
            KODI.set_property('IBUSCOMMUNICATOR_OBC_Gauges', '1')
        else:
            if inv_slide_direction:
                KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', 'right_in')
            else:
                KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', 'left_in')
            self.setFocus(self.BUTTON1[-1])

    def update(self, startup = False):

        def set_button_control(button, obc_screen):
            button[-1].setLabel(button[obc_screen][0])
            button[-1].setVisible(button[obc_screen][1])
            button[-1].setEnabled(button[obc_screen][2])

        def set_label_control(label, obc_screen):
            if label[obc_screen][0] != ' ':
                label[-1].setLabel(label[obc_screen][0]())
            else:
                label[-1].setLabel(' ')
                label[-1].setVisible(label[obc_screen][1])
            label[-1].setEnabled(label[obc_screen][2])

        def set_img_control(image, obc_screen):
            if len(image[obc_screen]) > 0:
                image[-1].setVisible(image[obc_screen][0]())
            else:
                image[-1].setVisible(False)

        def set_gauges():
            self.GAUGE_L[0].setImage(EVENT.obc_speed_get_gauge(), False)
            self.GAUGE_M[0].setImage(EVENT.obc_coolant_get_gauge(), False)
            self.GAUGE_R[0].setImage(EVENT.obc_rpm_get_gauge(), False)
            rpm = EVENT.obc_rpm
            if rpm < 1:
                rpm = '---'
                speed = '---'
            else:
                speed = EVENT.obc_speed_kmh
            self.GAUGE_L[1].setLabel('%s' % speed)
            self.GAUGE_M[1].setLabel('%s' % EVENT.obc_coolant)
            self.GAUGE_R[1].setLabel('%s' % rpm)

        set_button_control(self.MAINLABEL, self.obc_screen)
        if self.obc_screen == self.obc_screen_max:
            self.mainright.setVisible(False)
        else:
            self.mainright.setVisible(True)
        if self.obc_screen == self.obc_screen_min:
            self.mainleft.setVisible(False)
        else:
            self.mainleft.setVisible(True)
        if not startup:
            if self.obc_screen_next:
                return
            if self.obc_screen == self.obc_screen_max:
                set_gauges()
                return
        if self.selectedButton != 1:
            set_button_control(self.BUTTON1, self.obc_screen)
            set_label_control(self.LABEL1, self.obc_screen)
            set_img_control(self.IMAGE1, self.obc_screen)
        if self.selectedButton != 2:
            set_button_control(self.BUTTON2, self.obc_screen)
            set_label_control(self.LABEL2, self.obc_screen)
            set_img_control(self.IMAGE2, self.obc_screen)
        if self.selectedButton != 3:
            set_button_control(self.BUTTON3, self.obc_screen)
            set_label_control(self.LABEL3, self.obc_screen)
            set_img_control(self.IMAGE3, self.obc_screen)
        if self.selectedButton != 4:
            set_button_control(self.BUTTON4, self.obc_screen)
            set_label_control(self.LABEL4, self.obc_screen)
            set_img_control(self.IMAGE4, self.obc_screen)
        if self.selectedButton != 5:
            set_button_control(self.BUTTON5, self.obc_screen)
            set_label_control(self.LABEL5, self.obc_screen)
            set_img_control(self.IMAGE5, self.obc_screen)
        if self.selectedButton != 6:
            set_button_control(self.BUTTON6, self.obc_screen)
            set_label_control(self.LABEL6, self.obc_screen)
            set_img_control(self.IMAGE6, self.obc_screen)
        if self.selectedButton != 7:
            set_button_control(self.BUTTON7, self.obc_screen)
            set_label_control(self.LABEL7, self.obc_screen)
            set_img_control(self.IMAGE7, self.obc_screen)
        if self.selectedButton != 8:
            set_button_control(self.BUTTON8, self.obc_screen)
            set_label_control(self.LABEL8, self.obc_screen)
            set_img_control(self.IMAGE8, self.obc_screen)
        self.LABEL211.setLabel('%s' % EVENT.obc_outtemp_get())

    def set_distance(self):
        self.pause_submenu_counter = True
        result = self.obc_set_value.get_value(EVENT.obc_dist, 1, 9999)
        log('Value set %s' % result)
        if result != -1:
            EVENT.obc_dist_set(result)
        self.pause_submenu_counter = False

    def set_limit(self):
        self.pause_submenu_counter = True
        result = self.obc_set_value.get_value(EVENT.obc_limit, 6, 299)
        log('Value set %s' % result)
        if result != -1:
            EVENT.obc_limit_set(result)
        self.pause_submenu_counter = False

    def __del__(self):
        del self.obc_set_value


class ObcSetValueClass(xbmcgui.WindowXMLDialog):
    isActive = False
    ACTION_PARENT_DIR = 9
    ACTION_PREVIOUS_MENU = 10
    ACTION_CLOSE_DIALOG = 51
    ACTION_SELECT_ITEM = 7
    ACTION_MOVE_LEFT = 1
    ACTION_MOVE_RIGHT = 2
    ACTION_MOVE_UP = 3
    ACTION_MOVE_DOWN = 4
    ACTION_NAV_BACK = 92
    ACTION_BACKSPACE = 110

    def __init__(self, xmlFilename, scriptPath, defaultSkin, defaultRes):
        log('Initializing OBC Set-Value Gui...')
        self.input_value_start = -1
        self.input_value_min = 0
        self.input_value_max = 0

    def onInit(self):
        log('OBC: Set-Value GUI Opening')
        self.input_value = self.input_value_start
        self.ENTER = self.getControl(201)
        self.BUTTON2 = self.getControl(203)
        self.CANCEL = self.getControl(205)
        self.selectedButton = -1
        self.isActive = True
        self.setFocus(self.BUTTON2)
        self.BUTTON2.setLabel('%s' % self.input_value)
        self.set_default_navigation()
        time.sleep(0.05)
        self.submenu_set()

    def onAction(self, Action):
        if Action in [self.ACTION_PREVIOUS_MENU,
         self.ACTION_CLOSE_DIALOG,
         self.ACTION_NAV_BACK,
         self.ACTION_BACKSPACE]:
            self.input_value = -1
            self.onStop()
        if Action == self.ACTION_MOVE_LEFT:
            pass
        elif Action == self.ACTION_MOVE_RIGHT:
            pass
        elif Action == self.ACTION_SELECT_ITEM:
            if self.getFocus() == self.ENTER:
                self.onStop()
                return
            if self.getFocus() == self.CANCEL:
                self.input_value = -1
                self.onStop()
                return
            if self.selectedButton < 0:
                self.submenu_set()
            else:
                log('submenu selected')
                self.submenu_reset()
        elif Action == self.ACTION_MOVE_UP:
            if self.selectedButton == 203:
                self.input_value += 1
                if self.input_value > self.input_value_max:
                    self.input_value = self.input_value_max
                self.BUTTON2.setLabel('%s' % self.input_value)
        elif Action == self.ACTION_MOVE_DOWN:
            if self.selectedButton == 203:
                self.input_value -= 1
                if self.input_value < self.input_value_min:
                    self.input_value = self.input_value_min
                self.BUTTON2.setLabel('%s' % self.input_value)
        log('OBCGUI FOCUSED ID: %s' % self.getFocusId(), 3)

    def onFocus(self, controlId):
        pass

    def onStop(self):
        log('OBC: GUI Closing')
        self.submenu_reset()
        self.close()
        self.isActive = False

    def get_value(self, value_start = 0, value_min = 0, value_max = 500):
        if value_start < value_min or value_start > value_max:
            self.input_value_start = value_min
        else:
            self.input_value_start = value_start
        self.input_value_min = value_min
        self.input_value_max = value_max
        self.doModal()
        return self.input_value

    def set_default_navigation(self):
        self.ENTER.setNavigation(self.BUTTON2, self.ENTER, self.ENTER, self.BUTTON2)
        self.BUTTON2.setNavigation(self.CANCEL, self.ENTER, self.ENTER, self.CANCEL)
        self.CANCEL.setNavigation(self.CANCEL, self.BUTTON2, self.BUTTON2, self.CANCEL)

    def submenu_set(self):
        if self.getFocusId() == 203:
            self.selectedButton = 203
            self.BUTTON2.setLabel('%s' % self.input_value, textColor='0xFF000000')
            self.BUTTON2.setNavigation(self.BUTTON2, self.BUTTON2, self.BUTTON2, self.BUTTON2)

    def submenu_reset(self):
        self.BUTTON2.setLabel('%s' % self.input_value, textColor='0xFFEEEEFF')
        self.selectedButton = -1
        self.set_default_navigation()


class Kodi(object):
    log_to_kodi = True
    log_level = 1
    kodi_play = -1
    ibuslogger = None
    ibusdatalogger = None
    volume_backup = -1
    volume_reset_active = False
    volume_delay_counter = 0

    def __init__(self):
        self.circle = ['\\', '/', '-']
        self.circle_counter = 0

    def up(self, steps = '01'):
        steps = int(steps, 16)
        while steps > 0:
            xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Up", "id": 1 }')
            steps -= 1
            time.sleep(0.02)

    def down(self, steps = '01'):
        steps = int(steps, 16)
        while steps > 0:
            xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Down", "id": 1 }')
            steps -= 1
            time.sleep(0.02)

    def left(self):
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Left", "id": 1 }')

    def right(self):
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Right", "id": 1 }')

    def back(self):
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Back", "id": 1 }')

    def select(self):
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Select", "id": 1 }')

    def home(self):
        if xbmcgui.getCurrentWindowDialogId() != 9999:
            xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Home", "id": 1 }')

    def track_play(self):
        if self.kodi_play == 1:
            return
        self.kodi_play = 1
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Player.SetSpeed","params":{"playerid":%s,"speed":1 },"id":1}' % self.player_id())
        log('KODI: PLAY')

    def track_pause(self):
        if self.kodi_play == 0:
            return
        self.kodi_play = 0
        time.sleep(1)
        if self.kodi_play == 1:
            return
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Player.SetSpeed","params":{"playerid":%s,"speed":0 },"id":1}' % self.player_id())
        log('KODI: PAUSE')

    def track_seek(self, SPEED):
        self.kodi_play = 2
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Player.SetSpeed","params":{"playerid":%s,"speed":%s },"id":1}' % (self.player_id(), SPEED))

    def track_next(self):
        xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.GoTo", "params": { "playerid": %s, "to": "next" }, "id": 1}' % self.player_id())

    def track_prev(self):
        xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.GoTo", "params": { "playerid": %s, "to": "previous" }, "id": 1}' % self.player_id())

    def track_pos(self, milliseconds):
        xbmc.Player().seekTime(milliseconds)

    def volume_up(self, steps = '01'):
        steps = int(steps, 16)
        while steps > 0:
            xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Application.SetVolume", "params": { "volume": "increment" }, "id": 1 }')
            steps -= 1
            time.sleep(0.08)

    def volume_down(self, steps = '01'):
        steps = int(steps, 16)
        while steps > 0:
            xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Application.SetVolume", "params": { "volume": "decrement" }, "id": 1 }')
            steps -= 1
            time.sleep(0.08)

    def volume_get(self):
        volume = eval(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Application.GetProperties", "params": { "properties": [ "volume" ] }, "id": 1}'))['result']['volume']
        log('KODI: VOLUME: Get %s' % volume)
        return volume

    def volume_set(self, volume):
        if self.volume_reset_active:
            self.volume_reset_active = False
        if self.volume_backup < 0:
            self.volume_backup = self.volume_get()
            if EVENT.volume_sink_r_ibus:
                EVENT.radio_volume_set(EVENT.volume_sink_r_value_ibus * -1)
            else:
                xbmc.executebuiltin('SetVolume(%s, False)' % volume)
            log('KODI: VOLUME: Set = %s' % volume)

    def volume_reset(self, delay = 0):
        if self.volume_backup == -1:
            log('KODI: VOLUME: Reset not available', 2)
            self.volume_reset_active = False
            return
        if self.volume_reset_active:
            self.volume_delay_counter = delay
            log('KODI: VOLUME: Reset Change to %ss' % self.volume_delay_counter, 2)
            return
        thread = Thread(target=self._volume_reset)
        thread.setDaemon(True)
        self.volume_reset_active = True
        self.volume_delay_counter = delay
        thread.start()

    def _volume_reset(self):
        log('KODI: VOLUME: Reset Start with %ss' % self.volume_delay_counter, 2)
        while self.volume_delay_counter > 0:
            time.sleep(0.1)
            log('KODI: VOLUME: Countdown %s' % self.volume_delay_counter, 3)
            self.volume_delay_counter -= 0.1
            if not self.volume_reset_active:
                return
            if EVENT.obc_speed_kmh > EVENT.volume_sink_r_speed:
                break
            if self.volume_backup < 0:
                self.volume_reset_active = False
                return

        if EVENT.volume_sink_r_ibus:
            EVENT.radio_volume_set(EVENT.volume_sink_r_value_ibus)
        else:
            xbmc.executebuiltin('SetVolume(%s, False)' % self.volume_backup)
        log('KODI: Volume Reset = %s' % self.volume_backup)
        self.volume_backup = -1
        self.volume_reset_active = False

    def track_title(self):
        log('get song', 3)
        if xbmc.Player().isPlayingAudio():
            log('music', 3)
            artist = xbmc.getInfoLabel('MusicPlayer.Artist')
            title = xbmc.getInfoLabel('MusicPlayer.Title')
            log('SONG MUSIC: "%s" - "%s"' % (artist, title), 2)
            if artist == title:
                return '%s' % artist
            if artist == '':
                return '%s' % title
            if title == '':
                return '%s' % artist
            return '%s - %s' % (artist, title)
        if xbmc.Player().isPlayingVideo():
            log('video', 3)
            title = xbmc.getInfoLabel('VideoPlayer.Title')
            file = xbmc.Player().getVideoInfoTag().getFile()
            log('SONG VIDEO: "%s"' % title, 2)
            if title != '':
                return '%s' % title
            else:
                return '%s' % file
        else:
            log('SONG: empty')
            return ''

    def action(self, action_event):
        if EVENT.modeaux:
            return note(heading='No Function in AUX-Mode', message='Key 1-6 sets Volumelevel', time=2000)
        if action_event == '':
            return note('No Function for this Button set', time=2000)
        log('KODI ACTION EVENT: %s' % action_event)
        xbmc.executebuiltin('%s' % action_event)

    def player_id(self):
        response = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.GetActivePlayers","id": 1}')
        log('JSONREPLY: ' + response, 3)
        try:
            playerID_tmp = findall('"playerid":(.*?),"', response)
            log('PLAYERID: %s' % playerID_tmp[0], 3)
            return playerID_tmp[0]
        except:
            log('PLAYERID: -1', 3)
            return '-1'

    def get_current_listlabel(self, old_label = ''):
        wait = 5
        while old_label == xbmc.getInfoLabel('ListItem.Label') and wait > 0:
            time.sleep(0.1)
            wait += -1

        new_label = xbmc.getInfoLabel('ListItem.Label')
        if new_label != '':
            return new_label
        return 'Kodi Control'

    def copy_log_fileOLD(self):
        log('COPY LOG FILE TO "/boot/ibuscommunicator"')
        if not xbmcvfs.exists(BACKUPLOGFILEPATH):
            os.popen('sudo -s mkdir %s' % BACKUPLOGFILEPATH)
        if self.log_to_kodi:
            file_name = datetime.now().strftime('%Y%m%d_%H%M%S_kodi.txt')
            dest_logfile = os.path.join(BACKUPLOGFILEPATH, file_name)
            os.popen('sudo -s cp %s %s' % (KODILOGFILE, dest_logfile))
        else:
            file_name1 = datetime.now().strftime('%Y%m%d_%H%M%S_info.txt')
            file_name2 = datetime.now().strftime('%Y%m%d_%H%M%S_data.txt')
            dest_logfile = os.path.join(BACKUPLOGFILEPATH, file_name1)
            os.popen('sudo -s cp %s %s' % (EXTLOGFILEPATH, dest_logfile))
            dest_logfile = os.path.join(BACKUPLOGFILEPATH, file_name2)
            os.popen('sudo -s cp %s %s' % (EXTERNIBUSLOGFILEFULLPATH, dest_logfile))

    def copy_log_file(self):
        if not xbmcvfs.exists(BACKUPLOGFILEPATH):
            os.popen('sudo -s mkdir %s' % BACKUPLOGFILEPATH)
        log('LOGFILE: COPY LOG FILE TO "/boot/ibuscommunicator"')
        if not xbmcvfs.exists(BACKUPLOGFILEPATH):
            os.popen('sudo -s mkdir %s' % BACKUPLOGFILEPATH)
        log('LOGFILE: Create Zip File')
        filename = datetime.now().strftime('%Y%m%d_%H%M%S_ibuscommunicator.zip')
        dest_logfile = os.path.join(BACKUPLOGFILEPATH, filename)
        zip = zipfile.ZipFile(os.path.join(ADDONUSERPATH, filename), 'w', zipfile.ZIP_DEFLATED)
        zip.write(KODILOGFILE, os.path.split(KODILOGFILE)[1])
        if not self.log_to_kodi:
            zip.write(EXTLOGFILEPATH, os.path.split(EXTLOGFILEPATH)[1])
            zip.write(EXTERNIBUSLOGFILEFULLPATH, os.path.split(EXTERNIBUSLOGFILEFULLPATH)[1])
        zip.close()
        log('LOGFILE: Move Zip File')
        os.popen('sudo -s mv %s %s' % (os.path.join(ADDONUSERPATH, filename), dest_logfile))

    @staticmethod
    def get_addon_setting(id):
        setting = ADDON.getSetting(id)
        if setting.upper() == 'TRUE':
            return True
        if setting.upper() == 'FALSE':
            return False
        return '%s' % setting

    @staticmethod
    def set_addon_setting(id, value):
        if type(value) == 'bool':
            ADDON.setSetting(id, 'true' if value else 'false')
        else:
            ADDON.setSetting(id, '%s' % value)

    @staticmethod
    def get_property(property, id = 10000):
        value = xbmcgui.Window(id).getProperty(property)
        return value

    @staticmethod
    def set_property(property, value, id = 10000):
        xbmcgui.Window(id).setProperty(property, value)

    @staticmethod
    def clear_property(property, id = 10000):
        value = xbmcgui.Window(id).clearProperty(property)

    def get_addon_string(id, replacements = None):
        string = ADDON.getLocalizedString(id)
        if replacements is not None:
            return string % replacements
        else:
            return string

    def set_log_level(self, level):
        self.log_level = level

    def log(self, string, lvl = 1):
        if self.log_level < 1 and lvl > 0:
            return
        if lvl <= self.log_level <= 3 or self.log_level == 5 and lvl == 5:
            if self.log_to_kodi:
                try:
                    xbmc.log('IBUSCOMMUNICATOR: %s %s' % (self.circle[self.circle_counter], string), xbmc.LOGNOTICE)
                except:
                    self.circle_counter = 0
                    xbmc.log('IBUSCOMMUNICATOR: %s %s' % (self.circle[self.circle_counter], string), xbmc.LOGNOTICE)

                if self.circle_counter + 1 > 2:
                    self.circle_counter = 0
                else:
                    self.circle_counter += 1
            elif self.log_level < 5:
                self.ibuslogger.log('%s' % string)
        if self.log_level >= 1 and lvl == 5 and not self.log_to_kodi:
            self.ibusdatalogger.log('%s' % string)

    def note(self, heading, message = None, time = 5000):
        xbmcgui.Dialog().notification(heading='%s' % heading, message='%s' % message if message else '', icon=ICON, time=time)
        log('NOTIFICATION: "%s%s"' % (heading, ' - %s' % message if message else ''))

    def dialog_ok(self, label1, label2 = None, label3 = None):
        log('DIALOG_OK: "%s%s%s"' % (label1, ' - %s' % label2 if label2 else '', ' - %s' % label3 if label3 else ''))
        xbmcgui.Dialog().ok('IBusCommunicator', label1, label2, label3)

    def dialog_yesno(self, label1, label2 = None, label3 = None, nolabel = '', yeslabel = '', autoclose = 0):
        return xbmcgui.Dialog().yesno('IBusCommunicator', line1=label1, line2=label2, line3=label3, nolabel=nolabel, yeslabel=yeslabel, autoclose=autoclose)


class Clicker():

    def __init__(self, double_click_interval, single_func, double_func, single_args = (), double_args = ()):
        self._queue = Queue()
        latch = Event()

        def handle_clicks():
            latch.set()
            while not EVENT.cancel_read_thread:
                self._queue.get()
                if EVENT.cancel_read_thread:
                    break
                try:
                    self._queue.get(True, double_click_interval)
                except Empty:
                    single_func(*single_args)
                else:
                    double_func(*double_args)

        thread = Thread(target=handle_clicks)
        thread.daemon = True
        thread.start()
        latch.wait()

    def click(self):
        self._queue.put(None)


class RemoteKeyClass(object):
    remote_state = -1
    remote_accept_cmd = True
    remote_press = False
    hold_time = 700 / 50

    def __init__(self, hold_time_seconds, lock_pres = None, lock_hold = None, lock_rel = None, unlock_pres = None, unlock_hold = None, unlock_rel = None, boot_pres = None, boot_hold = None, boot_rel = None):
        self.hold_time = hold_time_seconds * 1000 / 50
        self.lock_pres = lock_pres
        self.lock_hold = lock_hold
        self.lock_rel = lock_rel
        self.unlock_pres = unlock_pres
        self.unlock_hold = unlock_hold
        self.unlock_rel = unlock_rel
        self.boot_pres = boot_pres
        self.boot_hold = boot_hold
        self.boot_rel = boot_rel

    def _hold_loop(self):
        counter = self.hold_time
        while self.remote_press and counter > 0:
            time.sleep(0.05)
            counter -= 1

    def key_event(self, dat):
        dat = ('%02X' % dat[1])[0]
        if dat == '1':
            if self.remote_press:
                return
            self.remote_state = 1
            self.remote_press = True
            if self.lock_pres:
                thread = Thread(target=self.lock_pres)
                thread.setDaemon(True)
                thread.start()
            if self.lock_hold:
                self._hold_loop()
                if self.remote_press:
                    self.lock_hold()
        elif dat == '2':
            if self.remote_press:
                return
            self.remote_state = 2
            self.remote_press = True
            if self.unlock_pres:
                thread = Thread(target=self.unlock_pres)
                thread.setDaemon(True)
                thread.start()
            if self.unlock_hold:
                self._hold_loop()
                if self.remote_press:
                    self.unlock_hold()
        elif dat == '4':
            if self.remote_press:
                return
            self.remote_state = 4
            self.remote_press = True
            if self.boot_pres:
                thread = Thread(target=self.boot_pres)
                thread.setDaemon(True)
                thread.start()
            if self.boot_hold:
                self._hold_loop()
                if self.remote_press:
                    self.boot_hold()
        elif dat == '0':
            self.remote_press = False
            if self.remote_state == 1:
                if self.lock_rel:
                    self.lock_rel()
            elif self.remote_state == 2:
                if self.unlock_rel:
                    self.unlock_rel()
            elif self.remote_state == 4:
                if self.boot_rel:
                    self.boot_rel()
            self.remote_state = 0


class PlayerClass(xbmc.Player):

    def __init__(self):
        self.RESUMEONCE = False
        xbmc.Player.__init__(self)

    def onQueueNextItem(self):
        pass

    def onPlayBackStarted(self):
        if not EVENT.new_song:
            EVENT.new_song = True
            EVENT.send_song_to_ike()
        EVENT.kodi_said_play()

    def onPlayBackEnded(self):
        pass

    def onPlayBackStopped(self):
        pass

    def onPlayBackPaused(self):
        pass

    def onPlayBackResumed(self):
        EVENT.kodi_said_play()

    def onPlayBackSeek(self, time, seekOffset):
        pass


class MonitorClass(xbmc.Monitor):

    def __init__(self):
        xbmc.Monitor.__init__(self)

    def onSettingsChanged(self):
        time.sleep(0.6)
        note('Settings changed')
        load_settings(True)


class GPIOClass(object):
    isOpen = False

    def _call(self, command):
        try:
            try:
                output = subprocess.check_output(command, stderr=subprocess.STDOUT)
            except subprocess.CalledProcessError as error:
                output = error.output
                return error.returncode

            return output
        finally:
            pass

    def open(self, pinnumber, mode = 'out', level = False, off_level = False):
        if pinnumber not in (4, 5, 6, 7, 12, 13, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27):
            raise ValueError('%s is not a valid GPIO' % pinnumber)
        self.pinnumber = pinnumber
        self.invert_signal = off_level
        os.popen('sudo chmod 222 /sys/class/gpio/export /sys/class/gpio/unexport')
        os.popen('sudo echo %s >/sys/class/gpio/export' % self.pinnumber)
        os.popen('sudo chmod 222 /sys/class/gpio/gpio%s/direction' % self.pinnumber)
        os.popen('sudo chmod 222 /sys/class/gpio/gpio%s/value' % self.pinnumber)
        os.popen('sudo echo %s >/sys/class/gpio/gpio%s/direction' % ('high' if self.invert_signal else 'low', self.pinnumber))
        if mode == 'out':
            if level:
                self.set()
            else:
                self.reset()
        elif mode == 'in':
            pass
        self.isOpen = True

    def change(self, pinnumber, mode = 'out', level = False, off_level = False):
        self.close()
        self.open(pinnumber, mode, level, off_level)

    def close(self, other_pinnumber = -1):
        if other_pinnumber >= 0:
            os.popen('sudo echo %s > /sys/class/gpio/unexport' % other_pinnumber)
        elif self.isOpen:
            os.popen('sudo echo %s > /sys/class/gpio/unexport' % self.pinnumber)
            self.isOpen = False

    def set(self):
        if self.isOpen:
            if self.invert_signal:
                os.popen('sudo echo "0" > /sys/class/gpio/gpio%s/value' % self.pinnumber)
            else:
                os.popen('sudo echo "1" > /sys/class/gpio/gpio%s/value' % self.pinnumber)

    def reset(self):
        if self.isOpen:
            if self.invert_signal:
                os.popen('sudo echo "1" > /sys/class/gpio/gpio%s/value' % self.pinnumber)
            else:
                os.popen('sudo echo "0" > /sys/class/gpio/gpio%s/value' % self.pinnumber)

    def toggle(self):
        if self.isOpen:
            pin_level = bool(os.popen('sudo cat /sys/class/gpio/gpio%s/value' % self.pinnumber))
            if pin_level:
                self.reset()
            else:
                self.set()

    def trigger(self, holdtime = 0.2):
        if self.isOpen:
            self.set()
            while holdtime > 0:
                holdtime -= 0.001
                time.sleep(0.001)

            self.reset()

    def get(self):
        if self.isOpen:
            value = bool(os.popen('sudo cat /sys/class/gpio/gpio%s/value' % self.pinnumber))
            return value


class IBusFace(object):

    def __init__(self):
        log('SERIAL_VERSION: %s' % serial.VERSION)
        self.serial_port = serial.Serial()
        self.serial_port.baudrate = 9600
        self.serial_port.parity = serial.PARITY_EVEN
        self.serial_port.stopbits = serial.STOPBITS_ONE
        self.serial_port.timeout = 0.001
        self.rts_state = False
        self.read_buffer = []
        self.read_lock = Lock()
        self.read_error_counter = 0
        self.read_error_container = []
        KODI.set_property('msgerr_cnt', '0')
        self.cancel_read_thread = False
        self.read_thread = Thread(target=self._reading)
        self.read_thread.setDaemon(True)
        self.read_bus_packet_thread = Thread(target=self._reading_bus_packet)
        self.read_bus_packet_thread.setDaemon(True)
        self.cts_counter = 0.0
        self.cts_thread = Thread(target=self._cts_watcher)
        self.cts_thread.setDaemon(True)
        self.packet_buffer = Queue()
        self.write_buffer = PriorityQueue()
        self.write_counter = 0
        self.write_in_progress = False
        self.cancel_write_thread = False
        self.write_thread = Thread(target=self._writing)
        self.write_thread.setDaemon(True)

    @staticmethod
    def _calculate_checksum(packet):
        result = 0
        for value in packet:
            result ^= value

        return result

    def _cut_read_buffer(self, offset = 1):
        with self.read_lock:
            self.read_buffer = self.read_buffer[offset:]

    def _wait_free_bus(self, waiting = 17, timeout = 1000):
        if waiting >= timeout:
            log('IBUS: ERROR: Waiting Time (%sms) is bigger than Timeout Time (%sms)' % (waiting, timeout), 3)
            return False
        while timeout > 0:
            if self.cts_counter >= waiting:
                return True
            timeout -= 1
            time.sleep(0.001)

        return False

    def _reading(self):
        while not self.cancel_read_thread:
            input = self.serial_port.read(999)
            if len(input) > 0:
                input = [ ord(x) for x in input ]
                with self.read_lock:
                    self.read_buffer.extend(input)
            self._read_bus_packet()

        log('IBUS: READ Thread finished', 2)

    def _reading_bus_packet(self):
        while not self.cancel_read_thread:
            self._read_bus_packet()
            time.sleep(0.001)

    def _writing(self):
        while not self.cancel_read_thread:
            try:
                prio, write_counter, data = self.write_buffer.get(timeout=1)
                try:
                    while self.cts_counter < 7.0:
                        time.sleep(0.001)

                    self.serial_port.write(data)
                    self.cts_counter = 0.0
                    self.serial_port.flush()
                    self.cts_counter = 0.0
                except serial.SerialException:
                    self.write_buffer.put((prio, write_counter, data))

            except Empty:
                pass

        log('IBUS: WRITE Thread finished', 2)

    def _cts_watcher(self):
        while not self.cancel_read_thread:
            if self.serial_port.getCTS():
                self.cts_counter += 0.1
                time.sleep(0.0001)
            else:
                self.cts_counter = 0.0

        log('IBUS: CTS-WATCHER Thread finished', 2)

    def set_port(self, device_path):
        if not os.path.exists(device_path):
            log('IBUS: ERROR: Serial Port does not exist >%s<' % device_path)
            raise Exception('IBUS: ERROR: Serial Port does not exist >%s<')
        self.serial_port.port = device_path

    def connect(self):
        try:
            self.serial_port.open()
        except serial.SerialException:
            log('IBUS: ERROR: Can not open Serial Port >%s<' % self.serial_port.port)
            raise

        self.serial_port.setDTR(1)
        self.serial_port.setRTS(0)
        self.cts_thread.start()
        if not self._wait_free_bus(120, 3000):
            log('IBUS: ERROR: Can not locate free Bus')
            raise
        self.serial_port.flushInput()
        self.read_thread.start()
        self.write_thread.start()

    def disconnect(self):
        self.cancel_write_thread = True
        self.cancel_read_thread = True
        self.ntsc = False
        time.sleep(0.6)
        self.serial_port.close()

    @property
    def ntsc(self):
        return self.rts_state

    @ntsc.setter
    def ntsc(self, value):
        if self.rts_state == value:
            return
        self.serial_port.setRTS(value)
        self.rts_state = value

    def read_bus_packet(self):
        try:
            return self.packet_buffer.get(timeout=1)
        except:
            return None

    def _read_bus_packet(self):
        if self.cancel_read_thread:
            return None
        try:
            data_length = self.read_buffer[1]
        except:
            return None

        if data_length < 3 or data_length > 37:
            self.read_error_container.append(self.read_buffer[0])
            self._cut_read_buffer()
            return None
        buffer_len = len(self.read_buffer)
        if buffer_len < 5 or buffer_len < data_length + 2:
            return None
        message = self.read_buffer[:data_length + 2]
        if self._calculate_checksum(message) == 0:
            if len(self.read_error_container) > 0:
                error_hex_string = ' '.join([ '%02X' % i for i in self.read_error_container ])
                if self.read_error_container in [[4,
                  4,
                  191,
                  255], [128, 4, 239], [128,
                  4,
                  191,
                  255]]:
                    log('# IBUS: READ-ERR: %s (no counter increase)' % error_hex_string, 5)
                else:
                    log('# IBUS: READ-ERR: %s' % error_hex_string, 5)
                    self.read_error_counter += len(self.read_error_container)
                    KODI.set_property('msgerr_cnt', '%s' % self.read_error_counter)
                self.read_error_container = []
            self._cut_read_buffer(data_length + 2)
            self.packet_buffer.put_nowait({'src': message[0],
             'len': data_length,
             'dst': message[2],
             'data': message[3:data_length + 1],
             'xor': message[-1]})
            log('IBUS-READ: %s' % ' '.join([ '%02X' % i for i in message ]), 5)
        else:
            self.read_error_container.append(self.read_buffer[0])
            self._cut_read_buffer()
            return None

    def write_bus_packet(self, src, dst, data, highprio = False, veryhighprio = False, repeat = 1):
        try:
            packet = [src, len(data) + 2, dst]
            packet.extend(data)
        except:
            packet = [int(src, 16), len(data) + 2, int(dst, 16)]
            packet.extend([ int(s, 16) for s in data ])

        packet.append(self._calculate_checksum(packet))
        bytepacket = bytearray(packet)
        while repeat > 0:
            repeat -= 1
            if veryhighprio:
                self.write_buffer.put_nowait((0, 0, bytepacket))
            else:
                self.write_buffer.put_nowait((0 if highprio else 1, self.write_counter, bytepacket))
            self.write_counter += 1

    def write_hex_message(self, hexstring):
        hexstring_tmp = hexstring.upper().split(' ')
        src = int(hexstring_tmp[0], 16)
        dst = int(hexstring_tmp[2], 16)
        data = [ int(s, 16) for s in hexstring_tmp[3:-1] ]
        self.write_bus_packet(src, dst, data)


class EventClass(object):
    TUNER_MODES = [[165,
      98,
      1,
      1,
      32,
      70,
      77,
      68],
     [165,
      98,
      1,
      1,
      32,
      32,
      70,
      77],
     [165,
      98,
      1,
      1,
      32,
      32,
      77,
      87],
     [165,
      98,
      1,
      1,
      32,
      77,
      87,
      65],
     [165,
      98,
      1,
      1,
      32,
      32,
      76,
      87],
     [165,
      98,
      1,
      1,
      32,
      76,
      87,
      65],
     [165,
      98,
      1,
      1,
      32,
      32,
      83,
      87],
     [165,
      98,
      1,
      1,
      32,
      83,
      87,
      65],
     [165,
      98,
      1,
      65,
      32,
      32,
      70,
      77,
      32],
     [165,
      98,
      1,
      65,
      32,
      70,
      77,
      68,
      32],
     [165,
      98,
      1,
      65,
      32,
      77,
      87,
      32,
      32],
     [165,
      98,
      1,
      65,
      32,
      77,
      87,
      65,
      32],
     [165,
      98,
      1,
      65,
      32,
      76,
      87,
      32,
      32],
     [165,
      98,
      1,
      65,
      32,
      76,
      87,
      65,
      32],
     [165,
      98,
      1,
      65,
      32,
      83,
      87,
      32,
      32],
     [165,
      98,
      1,
      65,
      32,
      83,
      87,
      65,
      32],
     [165,
      98,
      1,
      65,
      70,
      77,
      32],
     [165,
      98,
      1,
      65,
      70,
      77,
      68],
     [165,
      98,
      1,
      65,
      77,
      87,
      32],
     [165,
      98,
      1,
      65,
      77,
      87,
      65],
     [165,
      98,
      1,
      65,
      76,
      87,
      32],
     [165,
      98,
      1,
      65,
      76,
      87,
      65],
     [165,
      98,
      1,
      65,
      83,
      87,
      32],
     [165,
      98,
      1,
      65,
      83,
      87,
      65]]
    TP_MESSAGES = [[165,
      98,
      1,
      68,
      32,
      32,
      84,
      80,
      32]]
    cancel_ike_thread = False
    cancel_pdc_thread = False
    cancel_read_thread = False
    ike_states = {'run_once': False,
     'ign_mode': -1,
     'handbrake': False,
     'motor_running': False,
     'vehicle_driving': False,
     'gear_pos': 'X',
     'aux_heat': False,
     'aux_vent': False}
    gm_states = {'run_once': False,
     'driverdoor': False,
     'passangerdoor': False,
     'driverreardoor': False,
     'passangerreardoor': False,
     'doorsopen': False,
     'zvunlocked': False,
     'zvlocked': False,
     'zvlockstate': False,
     'zvhardlocked': False,
     'zvprocessed': False,
     'indoorlights': False,
     'driverwindow': False,
     'passengerwindow': False,
     'driverrearwindow': False,
     'passangerrearwindow': False,
     'sunroof': False,
     'trunk': False,
     'bonnet': False,
     'trunkbuttonpress': False}
    lcm_states = {'run_once': False,
     'park': False,
     'low_beam': False,
     'high_beam': False,
     'fog_front': False,
     'fog_rear': False,
     'turn_left': False,
     'turn_right': False,
     'turn_fast_blink': False,
     'tail': False,
     'reverse': False,
     'hazard': False,
     'dim_level': 0,
     'diag_dim_level': 120}
    nav_states = {'gpsfix': False,
     'latitude': ' ',
     'longitude': ' ',
     'altitude': ' ',
     'time': ' ',
     'town': ' ',
     'street': ' '}
    reverse_hold = False
    clock_hold = False
    bm_next_hold = False
    bm_prev_hold = False
    nav_hold = False
    select_hold = False
    always_hold = False
    stw_up_hold = False
    stw_dn_hold = False
    stw_rt_hold = False
    stw_vol_up_active = False
    stw_vol_down_active = False
    stw_speak_hold = False
    stw_nav = False
    btn_bcpres = False
    btnx_hold = {1: False,
     2: False,
     3: False,
     4: False,
     5: False,
     6: False}
    ign_mode = -1
    lcm_on = 0
    lcm_delay = -1
    remote_state = 2
    remote_accept_cmd = True
    navmenu = False
    tonemenu = False
    selectmenu = False
    tpmenu = False
    piaktiv = False
    pass_bm_buttons = False
    cancel_ike_text = False
    cdc_play = True
    cdc_pause = False
    cdc_scan = False
    cdc_seek = False
    cdc_rnd = False
    cdc_skip_counter = 0
    track_change_counter = 0
    cdc_disc = 7
    cdc_track = 151
    cdc_track_prev = 148
    cdc_track_next = 153
    cdc_loaded = 64
    phone_mute = False
    got_audiomode = False
    modefm = False
    modecd = False
    modetape = False
    modeaux = False
    modecis = False
    modealways = False
    device_path = None
    car_model = None
    tcp_port = 8089
    tcp_send_ibus = False
    cdc_emu = False
    gpio_ntsc = False
    dsp_cd = False
    dsp_tuner = False
    ike_display = False
    ike_track = False
    wel_ike = False
    wel_iketxt = None
    wel_iketxt_hold = False
    text_scrollspeed = 220
    welcome_on_boot = True
    wel_light = False
    wel_light_time = 10
    wel_light_park = False
    wel_light_low = False
    wel_light_fog = False
    wel_light_nbrplate = False
    wel_light_turn_front = False
    wel_light_turn_back = False
    lev_light = False
    lev_light_time = 10
    keyin_off = False
    doors_off = False
    lev_light_ign_off = False
    day_time = False
    day_time_start = '00:00'
    day_time_end = '00:00'
    mir_unfold = False
    mir_unfolded = False
    mir_unfold_mov = False
    mir_fold = False
    mir_folded = False
    mir_fold_mov = False
    seek_sec = 3000
    seek_max = 32
    use_stw_nav = False
    navhold_event = False
    inv_navturnbtn = False
    traffic = False
    gpio_gear_shift = -1
    gpio_gear_shift_trigger_time = 500
    gpio_gear_shift_up = 4
    gpio_gear_shift_down = 8
    rearcam_active = False
    gpio_rearcam = False
    gpio_rearcam_on = 5
    gpio_rearcam_off = 0
    gpio_rearcam_timeout = 15
    gpio_rearcam_speed = 30
    comfort_blink = False
    comfort_blink_time = 1500
    turn_light = False
    turn_light_time = 7000
    turn_light_max_speed = 50
    obc_time = [None, None]
    obc_date = [None, None]
    obc_cons1 = '---'
    obc_cons2 = '---'
    obc_range = '---'
    obc_dist = -1
    obc_arr = '--:--'
    obc_limit = -1
    obc_avg = '---'
    obc_stpwtch = '----'
    obc_tmr1 = '--:--'
    obc_tmr1ind = False
    obc_tmr2 = '--:--'
    obc_tmr2ind = False
    obc_limitind = False
    obc_memoind = False
    obc_outtemp = '--.-'
    obc_fuellevel = '--'
    obc_fuellevel_low = True
    obc_speed_kmh = -1
    obc_speed_mph = -1
    obc_rpm = 0
    obc_coolant = 0
    obc_auxventind = False
    obc_auxheatind = False
    obc_voltage = None
    obc_inserted_key = -1
    obc_vin = ''
    obc_odometer = -1
    obc_position = None
    obc_req_runs = False
    obc_settime = 0
    obc_req_runonce = False
    pdc_on = False
    pdc_type = 0
    pdc_timeout = 30
    pdc_timeout_off = False
    pdc_interval = 0.25
    pdc_bg = os.path.join(ADDONPDCPATH, 'bgs', 'default.png')
    zv_auto_lock = False
    zv_auto_lock_speed = 6
    zv_auto_unlock_handbrake = False
    zv_auto_unlock_ign1 = False
    zv_auto_unlock_gear_p = False
    zv_auto_unlock_door_open = False
    map_auto_zoom = False
    map_auto_zoom_100 = 10
    map_auto_zoom_200 = 30
    map_auto_zoom_500 = 55
    map_auto_zoom_1000 = 80
    map_auto_zoom_2000 = 120
    map_auto_zoom_5000 = 145
    map_states = {'zoom_level': -1,
     'speed_old': -1,
     100: (176, 127, [170, 16, 1]),
     200: (176, 127, [170, 16, 2]),
     500: (176, 127, [170, 16, 4]),
     1000: (176, 127, [170, 16, 16]),
     2000: (176, 127, [170, 16, 17]),
     5000: (176, 127, [170, 16, 18])}
    nav_toggle_map = False
    flash_to_pass = False
    flash_to_pass_low_beam = False
    flash_to_pass_fog = False
    bm_sensor = False
    bm_sensor_level = 50
    volume_sink_r = False
    volume_sink_r_ibus = False
    volume_sink_r_value = 50
    volume_sink_r_value_ibus = 15
    volume_sink_r_delay = 0
    volume_sink_r_speed = 6
    volume_store = 100
    lcd_brightness = False
    lcd_brightness_value_on = 0
    lcd_brightness_value_off = 0
    mid_ignore_radio_text = False
    new_song = False

    def __init__(self):
        self.remote = RemoteKeyClass(2, lock_pres=self.remote_key_lock_pres, lock_hold=self.remote_key_lock_hold, lock_rel=self.remote_key_lock_rel, unlock_pres=self.remote_key_unlock_pres, unlock_hold=self.remote_key_unlock_hold, unlock_rel=self.remote_key_unlock_rel, boot_pres=self.remote_key_boot_pres, boot_hold=self.remote_key_boot_hold, boot_rel=self.remote_key_boot_rel)
        self.ike_text_scrolling = False
        self.ike_text_scroll_thread = Thread()
        self.cancel_turn_left = False
        self.turning_left = False
        self.turning_fog_left = False
        self.cancel_turn_right = False
        self.turning_right = False
        self.turning_fog_right = False
        self.gpio_rearcam_counter = 0
        self.pdc_req_cancel = False
        self.pdc_req_running = False
        self.pdc_counter = 30
        self.bm_sensor_brightness = None
        self.obc_speed_unit = ''
        self.obc_distance_unit = ''
        self.obc_consumption_unit = ''
        self.obc_volume_unit = ''
        self.pdc_unit = ''

    def read_ibus_packages(self):
        while not self.cancel_read_thread:
            packet = IBUS.read_bus_packet()
            if packet:
                thread = Thread(target=self.manage, args=(packet['src'], packet['dst'], packet['data']))
                thread.setDaemon(True)
                thread.start()

        log('MANAGE: READ PACKAGES CLOSED')

    def simulate_ibus_packages(self, hex_message):
        hexstring_tmp = hex_message.upper().split(' ')
        src = int(hexstring_tmp[0], 16)
        dst = int(hexstring_tmp[2], 16)
        data = [ int(s, 16) for s in hexstring_tmp[3:-1] ]
        thread = Thread(target=self.manage, args=(src, dst, data))
        thread.setDaemon(True)
        thread.start()

    def manage(self, src, dst, dat):
        if src == 208:
            if dat[0] == 91:
                self.lcm_state(dat)
                log('MANAGE: LCM STATE: %s' % ' '.join([ '%02X' % i for i in dat[1:] ]))
                return
            if dat[0] == 92:
                log('MANAGE: LCM DIM STATE')
                self.lcm_dim_level(dat)
                return
            if dst == 63 and dat[0] == 160:
                self.lcm_diag_state(dat)
                return
        if dst == 24:
            if dat == [1]:
                self.cdch_alive()
                log('MANAGE: RAD ASKED FOR CDC ALIVE')
                return
            if dat == [56, 0, 0]:
                self.cdch_state()
                log('MANAGE: RAD ASKED FOR CDC STATE')
                return
            if dat == [56, 3, 0]:
                self.cdch_play()
                log('MANAGE: RAD SAID PLAY')
                return
            if dat == [56, 2, 0]:
                self.cdch_pause()
                log('MANAGE: RAD SAID PAUSE')
                return
            if dat == [56, 7, 0]:
                self.cdch_scan(False)
                log('MANAGE: RAD SAID SCAN OFF')
                return
            if dat == [56, 7, 1]:
                self.cdch_scan(True)
                log('MANAGE: RAD SAID SCAN ON')
                return
            if dat == [56, 1, 0]:
                self.cdch_stop()
                log('MANAGE: RAD SAID STOP')
                return
            if dat == [56, 4, 1]:
                self.cdch_ffwd()
                log('MANAGE: RAD SAID FFWD')
                return
            if dat == [56, 4, 0]:
                self.cdch_frwd()
                log('MANAGE: RAD SAID FRWD')
                return
            if dat == [56, 10, 0]:
                self.cdch_next()
                log('MANAGE: RAD SAID NEXT')
                return
            if dat == [56, 10, 1]:
                self.cdch_prev()
                log('MANAGE: RAD SAID PREV')
                return
            if dat == [56, 8, 0]:
                self.cdch_rnd(False)
                log('MANAGE: RAD SAID RANDOM OFF')
                return
            if dat == [56, 8, 1]:
                self.cdch_rnd(True)
                log('MANAGE: RAD SAID RANDOM ON')
                return
        if dst in (191, 104):
            if dat == [2, 0, 3]:
                self.cdch_state()
                log("MANAGE: RAD SAID I'M READY")
                return
            if dat == [78, 1, 0]:
                self.gt_tv_on()
                log('MANAGE: GT TV ON')
                return
            if dat == [78, 0, 0]:
                self.gt_tv_off()
                log('MANAGE: GT TV OFF')
                return
            if dat[0] == 17:
                if dat[1] == 0:
                    log('MANAGE: IGN_OFF')
                    self.ign_off()
                    return
                if dat[1] == 1:
                    log('MANAGE: IGN_RAD')
                    self.ign_acc()
                    return
                if dat[1] == 3:
                    log('MANAGE: IGN_ON')
                    self.ign_on()
                    return
                if dat[1] == 7:
                    log('MANAGE: IGN_START')
                    self.ign_start()
                    return
            if dat[0] == 114:
                log('MANAGE: REMOTE KEY', 2)
                self.remote.key_event(dat)
                return
            if dat[0] == 25:
                self.obc_coolant_put(dat)
                return
            if dat[0] == 24:
                self.obc_speed_rpm_put(dat)
                return
            if dat[0] == 19:
                log('MANAGE: IKE STATE', 2)
                self.ike_state(dat)
                return
            if dat[0] == 23:
                log('MANAGE: IKE ODOMETER', 2)
                self.obc_odometer_put(dat)
                return
        if src == 96:
            if dat[0] == 90:
                log('MANAGE: PDC TURNED ON', 1)
                self.pdc_req_start()
            if dat[0] == 160:
                log('MANAGE: PDC VALUE REPLY', 2)
                self.pdc_put_state(dat)
        if src == 0:
            if dat[0] == 122:
                log('MANAGE: GM STATE', 2)
                self.gm_state(dat)
        if dst == 104:
            if dat == [72, 64]:
                log('MANAGE: BM_NEXT_HOLD')
                self.btn_bm_next_hold()
                return
            if dat == [72, 128]:
                log('MANAGE: BM_NEXT_REL')
                self.btn_bm_next_rel()
                return
            if dat == [72, 80]:
                log('MANAGE: BM_PREV_HOLD')
                self.btn_bm_prev_hold()
                return
            if dat == [72, 144]:
                log('MANAGE: BM_PREV_REL')
                self.btn_bm_prev_rel()
                return
            if dat == [72, 84]:
                log('MANAGE: BM_REVERSE_HOLD')
                self.btn_bm_reverse_hold()
                return
            if dat == [72, 148]:
                log('MANAGE: BM_REVERSE_REL')
                self.btn_bm_reverse_rel()
                return
            if dat == [72, 132]:
                log('MANAGE: BM_TONE_REL')
                self.btn_bm_tone_rel()
                return
            if dat == [72, 81]:
                log('MANAGE: BM_BTN1_HOLD')
                self.btn_bm_x_hold(7)
                return
            if dat == [72, 145]:
                log('MANAGE: BM_BTN1_REL')
                self.btn_bm_x_rel(1)
                return
            if dat == [72, 65]:
                log('MANAGE: BM_BTN2_HOLD')
                self.btn_bm_x_hold(8)
                return
            if dat == [72, 129]:
                log('MANAGE: BM_BTN2_REL')
                self.btn_bm_x_rel(2)
                return
            if dat == [72, 82]:
                log('MANAGE: BM_BTN3_HOLD')
                self.btn_bm_x_hold(9)
                return
            if dat == [72, 146]:
                log('MANAGE: BM_BTN3_REL')
                self.btn_bm_x_rel(3)
                return
            if dat == [72, 66]:
                log('MANAGE: BM_BTN4_HOLD')
                self.btn_bm_x_hold(10)
                return
            if dat == [72, 130]:
                log('MANAGE: BM_BTN4_REL')
                self.btn_bm_x_rel(4)
                return
            if dat == [72, 83]:
                log('MANAGE: BM_BTN5_HOLD')
                self.btn_bm_x_hold(11)
                return
            if dat == [72, 147]:
                log('MANAGE: BM_BTN5_REL')
                self.btn_bm_x_rel(5)
                return
            if dat == [72, 67]:
                log('MANAGE: BM_BTN6_HOLD')
                self.btn_bm_x_hold(12)
                return
            if dat == [72, 131]:
                log('MANAGE: BM_BTN6_REL')
                self.btn_bm_x_rel(6)
                return
            if src == 240 and dat[0] == 50 and ('%02X' % dat[1])[1] == '1':
                steps = ('%02X' % dat[1])[0]
                log('MANAGE: BM_VOL_KNOB_RIGHT -steps: %s' % int(steps, 16))
                self.btn_bm_vol_right(steps)
                return
            if src == 240 and dat[0] == 50 and ('%02X' % dat[1])[1] == '0':
                steps = ('%02X' % dat[1])[0]
                log('MANAGE: BM_VOL_KNOB_LEFT -steps: %s' % int(steps, 16))
                self.btn_bm_vol_left(steps)
                return
            if src == 240 and dat == [72, 134]:
                log('MANAGE: BM_VOL_KNOB_REL')
                self.btn_bm_vol_rel()
                return
            if src == 240 and dat == [72, 70]:
                log('MANAGE: BM_VOL_KNOB_HOLD')
                self.btn_bm_vol_hold()
                return
            if dat == [72, 99]:
                log('MANAGE: BM_MODE_HOLD')
                self.btn_bm_always_hold('mode')
                return
            if dat == [72, 163]:
                log('MANAGE: BM_MODE_REL')
                self.btn_bm_always_rel('mode')
                return
            if dat == [72, 113]:
                log('MANAGE: BM_FM_HOLD')
                self.btn_bm_always_hold('fm')
                return
            if dat == [72, 177]:
                log('MANAGE: BM_FM_REL')
                self.btn_bm_always_rel('fm')
                return
            if dat == [72, 97]:
                log('MANAGE: BM_AM_HOLD')
                self.btn_bm_always_hold('am')
                return
            if dat == [72, 161]:
                log('MANAGE: BM_AM_REL')
                self.btn_bm_always_rel('am')
                return
        if src == 80:
            if dat == [50, 17]:
                log('MANAGE: STW_VOL_UP')
                self.btn_stw_vol_up()
                return
            if dat == [50, 16]:
                log('MANAGE: STW_VOL_DOWN')
                self.btn_stw_vol_down()
                return
            if dat == [59, 1]:
                log('MANAGE: STW_UP_PRES')
                self.btn_stw_up_pres()
                return
            if dat == [59, 17]:
                log('MANAGE: STW_UP_HOLD')
                self.btn_stw_up_hold()
                return
            if dat == [59, 33]:
                log('MANAGE: STW_UP_REL')
                self.btn_stw_up_rel()
                return
            if dat == [59, 8]:
                log('MANAGE: STW_DN_PRES')
                self.btn_stw_down_pres()
                return
            if dat == [59, 24]:
                log('MANAGE: STW_DN_HOLD')
                self.btn_stw_down_hold()
                return
            if dat == [59, 40]:
                log('MANAGE: STW_DN_REL')
                self.btn_stw_down_rel()
                return
            if dat == [59, 18]:
                log('MANAGE: STW_R/T_HOLD')
                self.btn_stw_rt_hold()
                return
            if dat in [[59, 34], [1]]:
                log('MANAGE: STW_R/T_REL')
                self.btn_stw_rt_rel()
                return
            if dat == [59, 64]:
                log('MANAGE: STW_R/T_ON with Phone')
                self.btn_stw_rt_on()
                return
            if dat == [59, 0]:
                log('MANAGE: STW_R/T_OFF with Phone')
                self.btn_stw_rt_off()
                return
            if dat == [59, 128]:
                log('MANAGE: STW_SPEAK_PRES')
                return
            if dat == [59, 144]:
                log('MANAGE: STW_SPEAK_HOLD')
                self.btn_stw_speak_hold()
                return
            if dat == [59, 160]:
                log('MANAGE: STW_SPEAK_REL')
                self.btn_stw_speak_rel()
                return
        if dst == 128:
            if dat[:11] == [35,
             65,
             48,
             32,
             32,
             32,
             84,
             82,
             3,
             32,
             57]:
                if not self.ike_text_scrolling:
                    time.sleep(0.1)
                self.ike_clear_display(0)
                log('MANAGE: Clear IKE Track Message in IKE', 2)
                return
            if dat[:16] == [35,
             65,
             48,
             32,
             32,
             32,
             32,
             32,
             3,
             67,
             68,
             67,
             32,
             55,
             45,
             57]:
                if not self.ike_text_scrolling:
                    time.sleep(0.1)
                    self.ike_clear_display(0)
                log('MANAGE: Clear IKE Track Message in IKE', 2)
                return
            if dat[:16] == [35,
             98,
             48,
             7,
             32,
             32,
             32,
             32,
             32,
             8,
             67,
             68,
             32,
             55,
             45,
             57]:
                if not self.ike_text_scrolling:
                    time.sleep(0.1)
                    self.ike_clear_display(0)
                log('MANAGE: Clear IKE Track Message in IKE', 2)
                return
            if dat[0] == 84:
                log('MANAGE: VIN', 2)
                self.obc_vin_put(dat)
        if dst == 59:
            if dat == [165,
             98,
             1,
             65,
             67,
             68,
             55]:
                self.gt_mode_cd()
                log('MANAGE: BMBT TEXT: CD7')
                return
            if dat[:7] == [165,
             98,
             1,
             65,
             67,
             68,
             55]:
                self.gt_mode_cd()
                log('MANAGE: BMBT TEXT: CD7')
                return
            if dat[:7] == [165,
             98,
             1,
             65,
             67,
             68,
             54]:
                self.gt_mode_cis()
                log('MANAGE: BMBT TEXT: CD6 CIS')
                return
            if dat == [165,
             98,
             1,
             65,
             67,
             68]:
                self.gt_mode_tape()
                log('MANAGE: BMBT TEXT: CD E46 BM-CD')
                return
            if dat[:3] == [35, 98, 16]:
                if dat[3:7] == [84,
                 82,
                 32,
                 32]:
                    self.gt_mode_cd()
                    self.cdch_play()
                    log('MANAGE: BMBT TEXT: "TR  "')
                    return
                if dat[3:6] == [67, 68, 67]:
                    self.gt_mode_cd()
                    log('MANAGE: BMBT TEXT: CDC...')
                    return
                if dat[3:10] == [78,
                 79,
                 32,
                 68,
                 73,
                 83,
                 67] or dat[3:10] == [78,
                 111,
                 32,
                 68,
                 105,
                 115,
                 99]:
                    log('MANAGE: BMBT TEXT: NO DISC')
                    return
                if dat[3:7] == [84,
                 65,
                 80,
                 69]:
                    self.gt_mode_tape()
                    log('MANAGE: BMBT TEXT: TAPE...')
                    return
                if dat[3:10] == [78,
                 79,
                 32,
                 84,
                 65,
                 80,
                 69]:
                    self.gt_mode_tape()
                    log('MANAGE: BMBT TEXT: NO TAPE')
                    return
                if dat[3:6] == [67, 68, 32]:
                    self.gt_mode_tape()
                    log('MANAGE: BMBT TEXT: CD / E46 CD Screen')
                    return
                if dat[3:6] == [65, 85, 88]:
                    self.gt_mode_aux()
                    log('MANAGE: BMBT TEXT: AUX ')
                    return
            if dat[:9] == [35,
             196,
             32,
             67,
             68,
             32,
             55,
             45,
             57]:
                self.gt_mode_cd()
                log('MANAGE: BMBT TEXT: CD 7-9...')
                return
            if dat[:7] == [35,
             80,
             32,
             84,
             65,
             80,
             69]:
                self.gt_mode_tape()
                log('MANAGE: BMBT TEXT: TAPE')
                return
            if dat[:10] == [35,
             80,
             32,
             78,
             79,
             32,
             84,
             65,
             80,
             69]:
                self.gt_mode_tape()
                log('MANAGE: BMBT TEXT: NO TAPE')
                return
            if dat[:3] == [35, 64, 32] or dat[:3] == [35, 80, 32]:
                self.gt_mode_radio()
                self.cdch_state()
                log('MANAGE: BMBT TEXT: what ever')
                return
            if dat[:18] == [35,
             98,
             48,
             32,
             32,
             7,
             32,
             32,
             32,
             32,
             32,
             8,
             67,
             68,
             32,
             55,
             45,
             57]:
                self.gt_mode_cd()
                log('MANAGE: BMBT TEXT: CD 7-9...')
                return
            if dat[:16] == [35,
             98,
             48,
             32,
             32,
             7,
             32,
             32,
             32,
             32,
             32,
             8,
             84,
             65,
             80,
             69]:
                self.gt_mode_tape()
                log('MANAGE: BMBT TEXT: TAPE')
                return
            if dat[:19] == [35,
             98,
             48,
             32,
             32,
             7,
             32,
             32,
             32,
             32,
             32,
             8,
             78,
             79,
             32,
             84,
             65,
             80,
             69]:
                self.gt_mode_tape()
                log('MANAGE: BMBT TEXT: NO TAPE')
                return
            if dat in self.TUNER_MODES:
                self.gt_mode_radio()
                self.cdch_state()
                log('MANAGE: BMBT TEXT: FMD')
                return
            if dat in self.TP_MESSAGES:
                self.gt_tp_message()
                log('MANAGE: TRAFFIC')
                return
            if dat == [70, 1]:
                self.gt_nav_menu_on()
                log('MANAGE: NAV MENU ON')
                return
            if dat == [70, 2]:
                self.gt_radio_menu_off()
                log('MANAGE: RADIO MENU OFF')
                return
            if dat == [70, 4]:
                log('MANAGE: SELECT MENU OFF')
                return
            if dat == [70, 8]:
                self.gt_tone_menu_off()
                log('MANAGE: TONE MENU OFF')
                return
            if dat == [70, 12]:
                self.gt_select_tone_menu_off()
                log('MANAGE: TONE + SELECT MENU OFF')
                return
            if dat == [55, 12]:
                log('MANAGE: SELECT MENU ON')
                return
            if dat[:8] == [33,
             96,
             0,
             64,
             84,
             80,
             32,
             32]:
                log('MANAGE: TP MENU ON')
                return
            if dat[:4] == [165,
             98,
             1,
             65]:
                return
            if dat == [33,
             96,
             0,
             7,
             80,
             54,
             58,
             32,
             78,
             79,
             32,
             68,
             73,
             83,
             67,
             32,
             32,
             32,
             6,
             6,
             6]:
                self.gt_select_tone_menu_off()
                log('MANAGE: BMBT Bottom Right " P6: NO DISC   "')
                return
            if dat[0] == 73 and ('%02X' % dat[1])[0] == '8':
                steps = ('%02X' % dat[1])[1]
                log('MANAGE: BM_NAV_KNOB_RIGHT -steps: %s' % int(steps, 16))
                self.btn_bm_nav_right(steps)
                return
            if dat[0] == 73 and ('%02X' % dat[1])[0] == '0':
                steps = ('%02X' % dat[1])[1]
                log('MANAGE: BM_NAV_KNOB_LEFT -steps: %s' % int(steps, 16))
                self.btn_bm_nav_left(steps)
                return
            if dat == [72, 133]:
                log('MANAGE: BM_NAV_KNOB_REL')
                self.btn_bm_nav_rel()
                return
            if dat == [72, 69]:
                log('MANAGE: BM_NAV_KNOB_HOLD')
                self.btn_bm_nav_hold()
                return
        if dst == 192:
            if dat[:9] == [35,
             196,
             48,
             67,
             68,
             32,
             55,
             45,
             57]:
                self.mid_mode_cd()
                log('MANAGE: MID TEXT: CD 7-9...')
                return
            if src == 104 and dat == [35,
             146,
             48,
             82,
             97,
             115,
             112,
             98,
             101,
             114,
             114,
             121,
             80,
             105]:
                log('MANAGE: MID TEXT: RaspberryPi')
                return
            if dat[:7] == [35,
             146,
             48,
             84,
             65,
             80,
             69] or dat[:7] == [35,
             130,
             48,
             84,
             65,
             80,
             69]:
                self.mid_mode_tape()
                log('MANAGE: MID TEXT: TAPE')
                return
            if dat[:11] == [35,
             196,
             48,
             32,
             78,
             79,
             32,
             84,
             65,
             80,
             69]:
                self.mid_mode_tape()
                log('MANAGE: MID TEXT: NO TAPE')
                return
            if dat[:2] == [35, 98]:
                self.mid_mode_tape()
                log('MANAGE: MID AUDIO MENU')
                return
            if dat[:1] == [35]:
                self.mid_mode_radio()
                log('MANAGE: MID TEXT: RADIO')
                return
        if src == 192 and dst == 255:
            if dat == [32,
             1,
             176,
             0]:
                self.btn_mid_audio()
                log('MANAGE: MID BTN AUDIO')
                return
            if dat == [32,
             32,
             142,
             0]:
                self.btn_mid_onoff()
                log('MANAGE: MID BTN ON/OFF')
                return
        if dst == 200:
            if dat == [59, 144]:
                log('MANAGE: STW_SPEAK_HOLD')
                self.btn_stw_speak_hold()
                return
            if dat == [59, 160]:
                log('MANAGE: STW_SPEAK_REL')
                self.btn_stw_speak_rel()
                return
            if dat[0] == 162:
                log('MANAGE: NAV POSITION', 2)
                self.nav_position_put(dat)
                return
            if dat[0] == 164:
                log('MANAGE: NAV LOCATION', 2)
                self.nav_location_put(dat)
                return
        if dst == 240:
            if dat == [74, 255]:
                self.radio_led_on()
                log('MANAGE: RADIO LED TURNED ON')
                return
            if dat == [74, 0]:
                self.radio_led_off()
                log('MANAGE: RADIO LED TURNED OFF')
                return
        if dst in (231, 255):
            if dat[:2] == [36, 1]:
                log('OBC: TIME', 2)
                self.obc_time_put(dat)
                return
            if dat[:2] == [36, 2]:
                log('OBC: DATE', 2)
                self.obc_date_put(dat)
                return
            if dat[:2] == [36, 3]:
                log('OBC: OUTTEMP', 2)
                self.obc_outtemp_put(dat)
                return
            if dat[:2] == [36, 4]:
                log('OBC: CONS1', 2)
                self.obc_cons1_put(dat)
                return
            if dat[:2] == [36, 5]:
                log('OBC: CONS2', 2)
                self.obc_cons2_put(dat)
                return
            if dat[:2] == [36, 6]:
                log('OBC: RANGE', 2)
                self.obc_range_put(dat)
                return
            if dat[:2] == [36, 7]:
                log('OBC: DIST', 2)
                self.obc_dist_put(dat)
                return
            if dat[:2] == [36, 8]:
                log('OBC: ARR', 2)
                self.obc_arr_put(dat)
                return
            if dat[:2] == [36, 9]:
                log('OBC: LIMIT', 2)
                self.obc_limit_put(dat)
                return
            if dat[:2] == [36, 10]:
                log('OBC: AVG', 2)
                self.obc_avg_put(dat)
                return
            if dat[:2] == [36, 14]:
                log('OBC: STPWTCH', 2)
                self.obc_stpwtch_put(dat)
                return
            if dat[:2] == [36, 15]:
                log('OBC: TMR1', 2)
                self.obc_tmr1_put(dat)
                return
            if dat[:2] == [36, 16]:
                log('OBC: TMR2', 2)
                self.obc_tmr2_put(dat)
                return
            if dat[0] == 42:
                log('OBC: IND', 2)
                self.obc_ind_put(dat)
            if src == 200 and dat[:1] == [43]:
                log('PHONE: STATE')
                self.phone_state(dat)
                return
            if dat == [71, 0, 79]:
                log('MANAGE: BM_SEL_HOLD')
                self.btn_bm_select_hold()
                return
            if dat == [71, 0, 143]:
                log('MANAGE: BM_SEL_REL')
                self.btn_bm_select_rel()
                return
            if dat == [71, 0, 56]:
                log('MANAGE: BM_INFO_PRES')
                self.btn_bm_info_pres()
                return
            if dat == [71, 0, 184]:
                log('MANAGE: BM_INFO_REL')
                return
            if dat == [72, 71]:
                log('MANAGE: BM_CLK_HOLD')
                self.btn_bm_clock_hold()
                return
            if dat == [72, 135]:
                log('MANAGE: BM_CLK_REL')
                self.btn_bm_clock_rel()
                return
            if dat == [72, 176]:
                log('MANAGE: BM_SCREEN_REL')
                self.btn_bm_screen_rel()
                return
            if dat == [72, 116]:
                log('MANAGE: BM_MENU_HOLD')
                self.btn_bm_always_hold('menu')
                return
            if dat == [72, 180]:
                log('MANAGE: BM_MENU_REL')
                self.btn_bm_always_rel('menu')
                return
            if dat == [72, 72]:
                log('MANAGE: BM_PHONE_HOLD')
                self.btn_bm_always_hold('phone')
                return
            if dat == [72, 136]:
                log('MANAGE: BM_PHONE_REL')
                self.btn_bm_always_rel('phone')
                return
            if dat == [87, 2]:
                log('MANAGE: IKE_BC_PRES')
                self.btn_bc_pres()
                return
        if src == 68:
            if dat[0] == 116:
                log('MANAGE: EWS_KEY')
                self.ews_key_put(dat)
                return
        if dst == 106:
            if dat == [54, 160]:
                if self.dsp_tuner:
                    self.dsp_set_tuner()
        if dst == 63:
            if src == 240 and dat[0] == 160:
                self.bm_set_state(dat)
                return
            if src == 127 and dat[0] == 160:
                self.obc_voltage_put(dat)
                return

    def cdch_init(self):
        if not self.cdc_emu:
            return
        IBUS.write_bus_packet(24, 255, [2, 1], True)
        time.sleep(0.05)
        IBUS.write_bus_packet(24, 255, [2, 0], True)
        time.sleep(0.1)
        IBUS.write_bus_packet(24, 104, [57,
         2,
         9,
         0,
         self.cdc_loaded,
         0,
         self.cdc_disc,
         self.cdc_track], True)

    def cdch_alive(self):
        if not self.cdc_emu:
            return
        IBUS.write_bus_packet(24, 255, [2, 0], True)

    def cdch_state(self):
        if self.modecis:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             9,
             0,
             32,
             0,
             6,
             153], True)
        if not self.cdc_emu:
            return
        if self.track_change_counter < 20:
            self.cdc_track = 151
        if self.track_change_counter >= 20:
            self.cdc_track = 150
        if self.track_change_counter > 40:
            self.track_change_counter = 0
        self.track_change_counter += 1
        if self.cdc_scan:
            IBUS.write_bus_packet(24, 104, [57,
             7,
             153,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
            return
        if self.cdc_seek:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             137,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
            return
        if self.cdc_rnd:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             169,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
            return
        if self.cdc_play:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             0,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
        elif self.cdc_pause:
            IBUS.write_bus_packet(24, 104, [57,
             1,
             0,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
        else:
            IBUS.write_bus_packet(24, 104, [57,
             0,
             140,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)

    def cdch_play(self):
        if not self.cdc_emu:
            return
        if self.cdc_seek:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             137,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
            self.cdc_seek = False
        if self.cdc_rnd:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             169,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
            self.cdc_rnd = False
        if self.cdc_scan:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             153,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
        else:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             2,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
        self.cdc_play = True
        self.cdc_pause = False
        if self.modecd:
            KODI.track_play()

    def cdch_pause(self):
        if not self.cdc_emu:
            return
        IBUS.write_bus_packet(24, 104, [57,
         1,
         0,
         0,
         self.cdc_loaded,
         0,
         self.cdc_disc,
         self.cdc_track], True)
        self.cdc_play = False
        if self.modecd:
            KODI.track_pause()

    def cdch_stop(self):
        if not self.cdc_emu:
            return
        IBUS.write_bus_packet(24, 104, [57,
         0,
         140,
         0,
         self.cdc_loaded,
         0,
         self.cdc_disc,
         self.cdc_track], True)
        self.cdc_play = False
        self.cdc_scan = False
        self.cdc_seek = False
        self.cdc_rnd = False
        self.cdc_pause = True

    def cdch_scan(self, enabled):
        if not self.cdc_emu:
            return
        time.sleep(0.25)
        if enabled:
            self.cdc_scan = True
            IBUS.write_bus_packet(24, 104, [57,
             7,
             153,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
        else:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             137,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
            self.cdc_scan = False

    def cdch_rnd(self, enabled):
        if not self.cdc_emu:
            return
        time.sleep(0.25)
        if enabled:
            self.cdc_rnd = True
            IBUS.write_bus_packet(24, 104, [57,
             2,
             169,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
        else:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             137,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
            self.cdc_rnd = False

    def cdch_ffwd(self):
        if not self.cdc_emu:
            return
        time.sleep(0.25)
        self.cdc_seek = True
        IBUS.write_bus_packet(24, 104, [57,
         3,
         137,
         0,
         self.cdc_loaded,
         0,
         self.cdc_disc,
         self.cdc_track], True)

    def cdch_frwd(self):
        if not self.cdc_emu:
            return
        time.sleep(0.25)
        self.cdc_seek = True
        IBUS.write_bus_packet(24, 104, [57,
         4,
         137,
         0,
         self.cdc_loaded,
         0,
         self.cdc_disc,
         self.cdc_track], True)

    def cdch_next(self):
        if not self.cdc_emu:
            return
        if self.cdc_skip_counter > 0:
            self.cdc_skip_counter += 350
            return
        self.cdc_skip_counter = 350
        while self.cdc_skip_counter > 0:
            self.cdc_skip_counter -= 10
            time.sleep(0.01)

        if self.cdc_track_next == 153:
            self.cdc_track_next = 152
        else:
            self.cdc_track_next = 153
        log('CDC: NEXT TRACK %02X' % self.cdc_track_next)
        IBUS.write_bus_packet(24, 104, [57,
         2,
         9,
         0,
         self.cdc_loaded,
         0,
         self.cdc_disc,
         self.cdc_track_next], True)

    def cdch_prev(self):
        if not self.cdc_emu:
            return
        if self.cdc_skip_counter > 0:
            self.cdc_skip_counter += 350
            return
        self.cdc_skip_counter = 350
        while self.cdc_skip_counter > 0:
            self.cdc_skip_counter -= 10
            time.sleep(0.01)

        if self.cdc_track_prev == 148:
            self.cdc_track_prev = 149
        else:
            self.cdc_track_prev = 148
        log('CDC: PREV TRACK %02X' % self.cdc_track_prev)
        IBUS.write_bus_packet(24, 104, [57,
         2,
         9,
         0,
         self.cdc_loaded,
         0,
         self.cdc_disc,
         self.cdc_track_prev], True)

    def btn_bm_vol_right(self, steps = '1'):
        if self.pass_bm_buttons and self.modealways:
            KODI.volume_up(steps)
        if self.volume_sink_r_ibus:
            KODI.volume_backup = -1

    def btn_bm_vol_left(self, steps = '1'):
        if self.pass_bm_buttons and self.modealways:
            KODI.volume_down(steps)
        if self.volume_sink_r_ibus:
            KODI.volume_backup = -1

    def btn_bm_vol_hold(self):
        return
        if self.pass_bm_buttons and self.modealways:
            self.nav_hold = True
            if self.navhold_event != ' ':
                xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.%s", "id": 1 }' % self.navhold_event)

    def btn_bm_vol_rel(self):
        return
        if self.pass_bm_buttons and self.modealways:
            if self.nav_hold:
                if self.navhold_event == ' ':
                    KODI.select()
            else:
                KODI.select()
            self.nav_hold = False

    def btn_bm_nav_right(self, steps = '1'):
        if self.pass_bm_buttons:
            KODI.down(steps) if self.inv_navturnbtn else KODI.up(steps)

    def btn_bm_nav_left(self, steps = '1'):
        if self.pass_bm_buttons:
            KODI.up(steps) if self.inv_navturnbtn else KODI.down(steps)

    def btn_bm_nav_hold(self):
        if self.pass_bm_buttons:
            self.nav_hold = True
            if self.navhold_event != ' ':
                xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.%s", "id": 1 }' % self.navhold_event)

    def btn_bm_nav_rel(self):
        if self.pass_bm_buttons:
            if self.nav_hold:
                if self.navhold_event == ' ':
                    KODI.select()
            else:
                KODI.select()
            self.nav_hold = False

    def btn_bm_next_hold(self):
        if not self.pass_bm_buttons:
            return
        log('state next hold: %s' % self.bm_next_hold)
        if self.bm_next_hold:
            return
        self.bm_next_hold = True
        speed = 4
        ticker = self.seek_sec
        while self.bm_next_hold:
            if ticker >= self.seek_sec:
                KODI.track_seek(speed)
                speed *= 2
                if speed > self.seek_max:
                    speed = self.seek_max
                ticker = 0
            time.sleep(0.001)
            ticker += 1

    def btn_bm_next_rel(self):
        self.bm_prev_hold = False
        if not self.pass_bm_buttons:
            return
        if self.bm_next_hold:
            self.bm_next_hold = False
            KODI.track_play()
        else:
            DBL_NEXT.click()

    def btn_bm_prev_hold(self):
        if not self.pass_bm_buttons:
            return
        if self.bm_prev_hold:
            return
        self.bm_prev_hold = True
        speed = -4
        ticker = self.seek_sec
        while self.bm_prev_hold:
            if ticker >= self.seek_sec:
                KODI.track_seek(speed)
                speed *= 2
                if speed > self.seek_max:
                    speed = self.seek_max
                ticker = 0
            time.sleep(0.001)
            ticker += 1

    def btn_bm_prev_rel(self):
        self.bm_next_hold = False
        if not self.pass_bm_buttons:
            return
        if self.bm_prev_hold:
            self.bm_prev_hold = False
            KODI.track_play()
        else:
            DBL_PREV.click()

    def btn_bm_reverse_hold(self):
        if self.pass_bm_buttons:
            self.reverse_hold = True
            KODI.home()

    def btn_bm_reverse_rel(self):
        if self.pass_bm_buttons:
            if self.reverse_hold:
                pass
            else:
                KODI.back()
            self.reverse_hold = False

    def btn_bm_x_hold(self, button_number):
        if not self.pass_bm_buttons:
            return
        if not self.modecd and not self.modecis and not self.modealways:
            return
        self.btnx_hold[button_number - 6] = True
        KODI.action(KODI.get_addon_setting('bm_btn_%s' % button_number))

    def btn_bm_x_rel(self, button_number):
        if not self.pass_bm_buttons:
            return
        if not self.modecd and not self.modecis and not self.modealways:
            return
        if self.btnx_hold[button_number]:
            pass
        else:
            KODI.action(KODI.get_addon_setting('bm_btn_%s' % button_number))
        self.btnx_hold[button_number] = False

    def btn_bm_tone_rel(self):
        self.gt_tone_menu()

    def btn_bm_select_hold(self):
        if self.pass_bm_buttons:
            self.select_hold = True

    def btn_bm_select_rel(self):
        if self.pass_bm_buttons:
            if self.select_hold:
                pass
            else:
                xbmc.executebuiltin('Action(ContextMenu)')
            self.select_hold = False
        else:
            self.gt_select_menu()

    def btn_bm_info_pres(self):
        self.tpmenu = True
        self.pi_hide()

    def btn_bm_info_hold(self):
        pass

    def btn_bm_info_rel(self):
        pass

    def btn_bm_clock_hold(self):
        self.clock_hold = True
        self.gt_av_r_on(False)
        ticker = 0
        while self.clock_hold:
            if ticker >= 3000:
                self.bm_led('green')
                time.sleep(0.5)
                self.bm_led('red')
                time.sleep(0.5)
                self.bm_led('yellow')
                time.sleep(0.5)
                self.bm_led('off')
                os.popen('sudo systemctl restart mediacenter')
                self.clock_hold = False
            time.sleep(0.001)
            ticker += 1

    def btn_bm_clock_rel(self):
        if self.clock_hold:
            pass
        else:
            self.gt_av_r_on(True)
        self.clock_hold = False

    def btn_bm_screen_rel(self):
        if self.piaktiv:
            self.pi_show()

    def btn_bm_always_hold(self, action):
        if self.modealways:
            self.always_hold = True
            event_hold = None
            if action == 'menu':
                event_hold = None
            elif action == 'mode':
                event_hold = None
            elif action == 'fm':
                event_hold = None
            elif action == 'am':
                event_hold = None
            elif action == 'phone':
                event_hold = None
            event_hold

    def btn_bm_always_rel(self, action):
        if self.modealways:
            event_hold_rel = None
            event_rel = None
            if action == 'menu':
                event_hold_rel = None
                event_rel = None
            elif action == 'mode':
                event_hold_rel = None
                event_rel = None
            elif action == 'fm':
                event_hold_rel = None
                event_rel = None
            elif action == 'am':
                event_hold_rel = None
                event_rel = None
            elif action == 'phone':
                event_hold_rel = None
                event_rel = None
            if self.always_hold:
                event_hold_rel
            else:
                event_rel
        self.always_hold = False

    def btn_stw_vol_up(self):
        if self.gpio_gear_shift == 1:
            if not self.stw_vol_up_active:
                self.stw_vol_up_active = True
                log('GEAR SHIFT: UP - GPIO%s' % GPIO_GEAR_SHIFT_UP.pinnumber)
                GPIO_GEAR_SHIFT_UP.trigger(self.gpio_gear_shift_trigger_time)
                self.stw_vol_up_active = False
        elif self.modealways:
            KODI.volume_up()
        if self.volume_sink_r_ibus:
            KODI.volume_backup = -1

    def btn_stw_vol_down(self):
        if self.gpio_gear_shift == 1:
            if not self.stw_vol_down_active:
                self.stw_vol_down_active = True
                log('GEAR SHIFT: DOWN - GPIO%s' % GPIO_GEAR_SHIFT_DOWN.pinnumber)
                GPIO_GEAR_SHIFT_DOWN.trigger(self.gpio_gear_shift_trigger_time)
                self.stw_vol_down_active = False
        elif self.modealways:
            KODI.volume_down()
        if self.volume_sink_r_ibus:
            KODI.volume_backup = -1

    def btn_stw_up_pres(self):
        if self.gpio_gear_shift == 2:
            log('GEAR SHIFT: UP - GPIO%s' % GPIO_GEAR_SHIFT_UP.pinnumber)
            GPIO_GEAR_SHIFT_UP.trigger(self.gpio_gear_shift_trigger_time)

    def btn_stw_up_hold(self):
        if self.stw_up_hold or self.gpio_gear_shift == 2:
            return
        self.stw_up_hold = True
        if self.ike_text_scrolling:
            self.ike_text_scrolling = False
        if self.stw_nav:
            KODI.select()
        else:
            speed = 4
            ticker = self.seek_sec
            while self.stw_up_hold:
                if ticker >= self.seek_sec:
                    KODI.track_seek(speed)
                    speed = speed * 2
                    if speed > self.seek_max:
                        speed = self.seek_max
                    ticker = 0
                time.sleep(0.001)
                ticker += 1

    def btn_stw_up_rel(self):
        if self.gpio_gear_shift == 2:
            return
        if self.stw_nav:
            if self.stw_up_hold:
                self.stw_up_hold = False
            else:
                KODI.up()
        else:
            self.stw_dn_hold = False
            if self.stw_up_hold:
                self.stw_up_hold = False
                KODI.track_play()
            else:
                KODI.track_next()

    def btn_stw_down_pres(self):
        if self.gpio_gear_shift == 2:
            log('GEAR SHIFT: DOWN - GPIO%s' % GPIO_GEAR_SHIFT_DOWN.pinnumber)
            GPIO_GEAR_SHIFT_DOWN.trigger(self.gpio_gear_shift_trigger_time)

    def btn_stw_down_hold(self):
        if self.stw_dn_hold or self.gpio_gear_shift == 2:
            return
        self.stw_dn_hold = True
        if self.ike_text_scrolling:
            self.ike_text_scrolling = False
        if self.stw_nav:
            KODI.back()
        else:
            speed = -4
            ticker = self.seek_sec
            while self.stw_dn_hold:
                if ticker >= self.seek_sec:
                    KODI.track_seek(speed)
                    speed = speed * 2
                    if speed > self.seek_max:
                        speed = self.seek_max
                    ticker = 0
                time.sleep(0.001)
                ticker += 1

    def btn_stw_down_rel(self):
        if self.gpio_gear_shift == 2:
            return
        if self.stw_nav:
            if self.stw_dn_hold:
                self.stw_dn_hold = False
            else:
                KODI.down()
        else:
            self.stw_up_hold = False
            if self.stw_dn_hold:
                self.stw_dn_hold = False
                KODI.track_play()
            else:
                try:
                    if xbmc.Player().getTime() <= 3:
                        KODI.track_prev()
                    else:
                        KODI.track_pos(0)
                except:
                    pass

    def btn_stw_rt_hold(self):
        if self.stw_rt_hold:
            return
        self.stw_rt_hold = True

    def btn_stw_rt_rel(self):
        self.stw_rt_hold = False
        self.btn_stw_rt_on()

    def btn_stw_rt_on(self):
        if self.ike_text_scrolling:
            self.ike_text_scrolling = False
        if self.stw_rt_hold:
            pass
        elif self.use_stw_nav:
            if self.stw_nav:
                self.stw_nav = False
                KODI.set_property('IBUSCOMMUNICATOR_MFL_SHOW', '0')
                self.ike_clear_display(0, True)
                log('Disable MFL Control for Kodi')
            elif self.pass_bm_buttons:
                KODI.set_property('IBUSCOMMUNICATOR_MFL_SHOW', '1')
                IBUS.write_bus_packet(200, 128, [26,
                 55,
                 0,
                 32,
                 32,
                 32,
                 32,
                 75,
                 79,
                 68,
                 73,
                 32,
                 67,
                 79,
                 78,
                 84,
                 82,
                 79,
                 76,
                 32,
                 32,
                 32,
                 32])
                self.stw_nav = True
                log('Enable MFL Control for Kodi')
        elif self.nav_toggle_map:
            if self.navmenu:
                self.radio_mode_get()
            else:
                self.nav_show_map()
        self.stw_rt_hold = False

    def btn_stw_rt_off(self):
        if self.stw_rt_hold:
            pass
        elif self.use_stw_nav:
            self.stw_nav = False
            KODI.set_property('IBUSCOMMUNICATOR_MFL_SHOW', '0')
            self.ike_clear_display(0, True)
            log('Disable MFL Control for Kodi')
        elif self.nav_toggle_map:
            if self.navmenu:
                self.radio_mode_get()
            else:
                self.nav_show_map()
        self.stw_rt_hold = False

    def btn_stw_speak_hold(self):
        if self.stw_speak_hold:
            return
        self.stw_speak_hold = True
        if self.stw_nav:
            KODI.back()

    def btn_stw_speak_rel(self):
        if self.stw_speak_hold:
            pass
        elif self.stw_nav:
            DBL_STW_SPEAK.click()
        self.stw_speak_hold = False

    def btn_mid_onoff(self):
        self.radio_mode_get()

    def btn_mid_audio(self):
        if self.piaktiv:
            self.mid_ignore_radio_text = True

    def btn_bc_pres(self):
        if OBCGUI.isVisible() and self.stw_nav and self.pass_bm_buttons:
            OBCGUI.obcNext()
        elif self.ike_text_scrolling:
            self.ike_text_scrolling = False
        elif not self.stw_nav:
            self.ike_clear_display(delay=0, when_ign_off=True)

    def radio_led_on(self):
        self.radio_mode_get()
        self.cdch_stop()

    def radio_led_off(self):
        self.pi_off()

    def radio_bm_led_on(self):
        IBUS.write_bus_packet(104, 240, [74, 255])
        log('Set Radio Led ON')

    def radio_bm_led_off(self):
        IBUS.write_bus_packet(104, 240, [74, 0])
        log('Set Radio Led OFF')

    def radio_diag_state_get(self):
        IBUS.write_bus_packet(63, 104, [11])

    def radio_diag_state_put(self, dat):
        pass

    def ign_get_state(self):
        IBUS.write_bus_packet(91, 128, [16])

    def ign_off(self):
        self.ike_states['ign_mode'] = 1
        self.got_audiomode = False
        self.stw_nav = False
        KODI.set_property('IBUSCOMMUNICATOR_MFL_SHOW', '0')
        self.pi_off()
        if self.modealways:
            self.radio_bm_led_off()
        if self.ign_mode > 0 and self.zv_auto_lock and self.zv_auto_unlock_ign1 and self.gm_states['zvlockstate']:
            self.gm_zv_unlock()
        if self.ign_mode > 0:
            self.ign_mode = 0
            if self.lev_light and self.lev_light_ign_off:
                self.lcm_lights_on(self.lev_light_time)
            KODI.copy_log_file()
            KODI.home()
            if KODI.volume_backup - self.volume_sink_r_value == KODI.volume_get():
                KODI.volume_reset()
            if OBCGUI.isActive:
                OBCGUI.onStop()
        self.obc_req_runonce = False
        self.ign_mode = 0
        log('IGN == 0')

    def ign_acc(self):
        self.ike_states['ign_mode'] = 1
        time.sleep(0.25)
        if not self.got_audiomode:
            self.radio_mode_get()
        if self.modealways:
            self.radio_bm_led_on()
        if self.cdc_emu:
            self.cdch_play()
        if self.ign_mode > 1 and self.zv_auto_lock and self.zv_auto_unlock_ign1 and self.gm_states['zvlockstate']:
            self.gm_zv_unlock()
        if self.ign_mode < 1:
            self.lcm_lights_off()
            while self.lcm_on:
                time.sleep(0.5)

            self.obc_req(True)
        self.ign_mode = 1
        log('IGN == 1')

    def ign_on(self):
        self.ike_states['ign_mode'] = 1
        time.sleep(0.25)
        if self.ign_mode < 2:
            self.obc_req(True)
        self.ign_mode = 2
        log('IGN == 2')

    def ign_start(self):
        self.ike_states['ign_mode'] = 1
        time.sleep(0.25)
        self.ign_mode = 3
        log('IGN == 3')

    def radio_mode_get(self):
        if self.ign_mode < 1:
            return
        IBUS.write_bus_packet(59, 104, [69, 0])
        IBUS.write_bus_packet(192, 104, [32,
         0,
         179,
         0])

    def radio_volume_set(self, steps):
        if steps > 0:
            steps = hex(steps)
            value = int('%s1' % steps, 16)
            IBUS.write_bus_packet(59, 104, [50, value])
        elif steps < 0:
            steps = hex(steps * -1)
            value = int('%s0' % steps, 16)
            IBUS.write_bus_packet(59, 104, [50, value])

    def gt_mode_radio(self):
        self.got_audiomode = True
        self.navmenu = False
        self.pi_off()

    def gt_mode_cd(self):
        self.got_audiomode = True
        self.navmenu = False
        if not self.cdc_play:
            self.cdch_play()
        if self.modecd:
            if self.piaktiv:
                self.pi_show()
            else:
                self.pi_on()
        else:
            self.pi_off()

    def gt_mode_tape(self):
        self.got_audiomode = True
        self.navmenu = False
        if self.modetape:
            if self.piaktiv:
                self.pi_show()
            else:
                self.pi_on()
        else:
            self.pi_off()

    def gt_mode_aux(self):
        self.got_audiomode = True
        self.navmenu = False
        if self.modeaux:
            if self.piaktiv:
                self.pi_show()
            else:
                self.pi_on()
        else:
            self.pi_off()

    def gt_mode_cis(self):
        self.got_audiomode = True
        self.navmenu = False
        if self.modecis:
            if self.piaktiv:
                self.pi_show()
            else:
                self.pi_on()
        else:
            self.pi_off()

    def gt_clear_cd_list(self):
        if self.modecd:
            IBUS.write_bus_packet(104, 59, [70, 12])

    def gt_nav_menu_on(self):
        self.navmenu = True
        self.tonemenu = False
        self.tpmenu = False
        self.pi_hide()

    def gt_radio_menu_off(self):
        self.tpmenu = False
        self.tonemenu = False
        self.navmenu = True
        self.pi_hide()

    def gt_tp_menu(self):
        self.tpmenu = True
        self.tonemenu = False
        self.pi_hide()

    def gt_tone_menu(self):
        self.tonemenu = True
        self.tpmenu = False
        self.navmenu = False
        self.pi_hide()

    def gt_select_menu(self):
        self.tonemenu = False
        self.tpmenu = False
        self.navmenu = False
        self.pi_show()

    def gt_tone_menu_off(self):
        self.tonemenu = False
        self.pi_show()

    def gt_select_tone_menu_off(self):
        self.tpmenu = False
        self.pi_show()

    def gt_tv_on(self):
        self.pi_hide()
        KODI.track_pause()

    def gt_tv_off(self):
        if self.piaktiv:
            KODI.track_play()

    def gt_tp_message(self):
        self.pi_off()

    def gt_new_field1(self):
        self.pi_show()

    def mid_mode_radio(self):
        if not self.mid_ignore_radio_text:
            self.gt_mode_radio()

    def mid_mode_cd(self):
        if self.modecd:
            self.mid_send_text('RaspberryPi')
            self.mid_ignore_radio_text = False
        self.gt_mode_cd()

    def mid_mode_tape(self):
        if self.modetape:
            self.mid_send_text('RaspberryPi')
            self.mid_ignore_radio_text = False
        self.gt_mode_tape()

    def phone_state(self, dat):
        dat = dat[1]
        if get_bit_from_hex(dat, BIT[4]) == 1:
            if self.piaktiv:
                KODI.track_pause()
            self.phone_mute = True
        elif get_bit_from_hex(dat, BIT[4]) == 0:
            self.phone_mute = False
            if self.piaktiv:
                KODI.track_play()

    def remote_key_lock_pres(self):
        log('REMOTE LOCK PRES')
        if self.mir_fold:
            self.gm_mirror_fold()
        if self.lev_light:
            if self.lcm_on:
                if self.remote_state == 1:
                    self.lcm_lights_off()
                else:
                    self.lcm_delay = self.lev_light_time
            else:
                self.lcm_lights_on(self.lev_light_time)
        elif self.lcm_on:
            self.lcm_lights_off()
        self.remote_state = 1

    def remote_key_lock_hold(self):
        log('REMOTE LOCK HOLD')

    def remote_key_lock_rel(self):
        log('REMOTE LOCK REL')

    def remote_key_unlock_pres(self):
        log('REMOTE UNLOCK PRES')
        if self.mir_unfold:
            self.gm_mirror_unfold()
        if self.wel_light:
            if self.lcm_on:
                if self.remote_state == 2:
                    self.lcm_lights_off()
                else:
                    self.lcm_delay = self.wel_light_time
            else:
                self.lcm_lights_on(self.wel_light_time)
        elif self.lcm_on:
            self.lcm_lights_off()
        if self.remote_state == 1:
            if self.wel_ike:
                self.ike_send_text(self.wel_iketxt, True, self.wel_iketxt_hold)
        self.remote_state = 2

    def remote_key_unlock_hold(self):
        log('REMOTE UNLOCK HOLD')

    def remote_key_unlock_rel(self):
        log('REMOTE UNLOCK REL')

    def remote_key_boot_pres(self):
        log('REMOTE TRUNK PRES')

    def remote_key_boot_hold(self):
        log('REMOTE TRUNK HOLD')

    def remote_key_boot_rel(self):
        log('REMOTE TRUNK REL')

    def ews_key_req(self):
        IBUS.write_bus_packet(48, 68, [115,
         0,
         0,
         128])

    def ews_key_put(self, dat):
        if dat[1] == 0:
            self.obc_inserted_key = -1
            log('EWS: KEY_OUT')
        elif dat[1] != 0 and dat[2] == 255:
            self.obc_inserted_key = -1
            log('EWS: KEY_OUT')
        elif dat[1] != 0 and dat[2] != 255:
            self.obc_inserted_key = dat[2]
            log('EWS: KEY_IN: %s' % dat[2])
            if self.keyin_off:
                self.lcm_lights_off()
                while self.lcm_on:
                    time.sleep(0.5)

    def ike_get_state(self, timer = False):
        if timer:
            counter = 10000
            while not MONITOR.abortRequested():
                if counter == 10000:
                    IBUS.write_bus_packet(59, 128, [18])
                elif counter <= 0:
                    counter = 10000
                counter -= 1
                time.sleep(0.001)

        else:
            IBUS.write_bus_packet(59, 128, [18])

    def ike_get_state_timer(self):
        thread = Thread(target=self.ike_get_state, args=True)
        thread.setDaemon(True)
        thread.start()

    def ike_state(self, dat):
        aa = dat[1]
        bb = dat[2]
        cc = dat[3]
        try:
            gg = dat[7]
        except IndexError:
            gg = 0

        handbrake = get_bit_from_hex(aa, BIT[0])
        motor_running = get_bit_from_hex(bb, BIT[0])
        vehicle_driving = get_bit_from_hex(bb, BIT[1])
        if ('%02X' % bb)[0] == '1':
            gear_pos = 'R'
        elif ('%02X' % bb)[0] == '2':
            gear_pos = '1'
        elif ('%02X' % bb)[0] == '4':
            gear_pos = '2'
        elif ('%02X' % bb)[0] == '6':
            gear_pos = 'N'
        elif ('%02X' % bb)[0] == '8':
            gear_pos = 'D'
        elif ('%02X' % bb)[0] == 'B':
            gear_pos = 'P'
        elif ('%02X' % bb)[0] == 'C':
            gear_pos = '4'
        elif ('%02X' % bb)[0] == 'D':
            gear_pos = '3'
        elif ('%02X' % bb)[0] == 'E':
            gear_pos = '5'
        else:
            gear_pos = 'X'
        aux_heat = get_bit_from_hex(cc, BIT[2])
        aux_vent = get_bit_from_hex(cc, BIT[3])
        if ('%02X' % gg)[0] == '8':
            obc_fuellevel_low = True
            obc_fuellevel = int(('%02X' % gg)[1])
        else:
            obc_fuellevel_low = False
            obc_fuellevel = gg
        if self.ike_states['run_once']:
            if handbrake and self.zv_auto_lock and self.zv_auto_unlock_handbrake and self.gm_states['zvlockstate']:
                self.gm_zv_unlock()
            if handbrake != self.ike_states['handbrake']:
                self.ike_states['handbrake'] = handbrake
            log('GM: HANDBRAKE=%s' % handbrake, 2)
            if gear_pos == 'P' and self.zv_auto_lock and self.zv_auto_unlock_gear_p and self.gm_states['zvlockstate']:
                self.gm_zv_unlock()
            if gear_pos != self.ike_states['gear_pos']:
                if gear_pos == 'R':
                    if self.volume_sink_r:
                        KODI.volume_set(KODI.volume_get() - self.volume_sink_r_value)
                    if self.gpio_rearcam:
                        self.rearcam_on()
                elif gear_pos != 'R' and self.ike_states['gear_pos'] == 'R':
                    if self.volume_sink_r:
                        KODI.volume_reset(self.volume_sink_r_delay)
                    if self.gpio_rearcam:
                        self.rearcam_off()
                self.ike_states['gear_pos'] = gear_pos
            if aux_vent != self.ike_states['aux_vent']:
                self.ike_states['aux_vent'] = aux_vent
            if aux_heat != self.ike_states['aux_heat']:
                self.ike_states['aux_heat'] = aux_heat
            if obc_fuellevel != self.obc_fuellevel:
                self.obc_fuellevel = obc_fuellevel
                self.obc_fuellevel_low = obc_fuellevel_low
                KODI.set_property('IBUSCOMMUNICATOR_OBC_FUELLEVEL', '%s%s L' % ('R ' if obc_fuellevel_low else '', obc_fuellevel))
            log('OBC: SET FUELLEVEL: %s' % obc_fuellevel)
        self.ike_states['run_once'] = True

    def gm_get_state(self):
        IBUS.write_bus_packet(191, 0, [121])

    def gm_state(self, dat):
        aa = dat[1]
        bb = dat[2]
        driverdoor = get_bit_from_hex(aa, BIT[0])
        passangerdoor = get_bit_from_hex(aa, BIT[1])
        driverreardoor = get_bit_from_hex(aa, BIT[2])
        passangerreardoor = get_bit_from_hex(aa, BIT[3])
        if driverdoor or passangerdoor or driverreardoor or passangerreardoor:
            doorsopen = True
        else:
            doorsopen = False
        zvunlocked = get_bit_from_hex(aa, BIT[4])
        zvlocked = get_bit_from_hex(aa, BIT[5])
        zvhardlocked = True if zvunlocked and zvlocked else False
        zvlockstate = zvlocked
        indoorlights = get_bit_from_hex(aa, BIT[6])
        driverwindow = get_bit_from_hex(bb, BIT[0])
        passengerwindow = get_bit_from_hex(bb, BIT[1])
        driverrearwindow = get_bit_from_hex(bb, BIT[2])
        passangerrearwindow = get_bit_from_hex(bb, BIT[3])
        sunroof = get_bit_from_hex(bb, BIT[4])
        trunk = get_bit_from_hex(bb, BIT[5])
        bonnet = get_bit_from_hex(bb, BIT[6])
        trunkbuttonpress = get_bit_from_hex(bb, BIT[7])
        if self.gm_states['zvprocessed']:
            self.gm_states['zvprocessed'] = False
            self.gm_diag_off()
        notemsg = [None, None]
        notetime = 50
        if self.gm_states['run_once']:
            if self.gm_states['driverdoor'] != driverdoor:
                notemsg[0] = 'Driver Door'
                notemsg[1] = 'opened' if driverdoor else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['passangerdoor'] != passangerdoor:
                notemsg[0] = 'Passanger Door'
                notemsg[1] = 'opened' if passangerdoor else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['driverreardoor'] != driverreardoor:
                notemsg[0] = 'Driver Rear Door'
                notemsg[1] = 'opened' if driverreardoor else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['passangerreardoor'] != passangerreardoor:
                notemsg[0] = 'Passanger Rear Door'
                notemsg[1] = 'opened' if passangerreardoor else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['doorsopen'] != doorsopen:
                if doorsopen and self.doors_off:
                    self.lcm_lights_off()
            if self.gm_states['zvlockstate'] != zvlockstate:
                notemsg[0] = 'Central Locksystem'
                notemsg[1] = 'locked' if zvlockstate else 'unlocked'
                if zvhardlocked:
                    notemsg[1] = 'hard locked'
                else:
                    notemsg[1] = 'locked' if zvlockstate else 'unlocked'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['indoorlights'] != indoorlights:
                notemsg[0] = 'Indoor Lights turned'
                notemsg[1] = 'ON' if indoorlights else 'OFF'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['driverwindow'] != driverwindow:
                notemsg[0] = 'Driver Window'
                notemsg[1] = 'opened' if driverwindow else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['passengerwindow'] != passengerwindow:
                notemsg[0] = 'Passenger Window'
                notemsg[1] = 'opened' if passengerwindow else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['driverrearwindow'] != driverrearwindow:
                notemsg[0] = 'Driver Rear Window'
                notemsg[1] = 'opened' if driverrearwindow else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['passangerrearwindow'] != passangerrearwindow:
                notemsg[0] = 'Passanger Rear Window'
                notemsg[1] = 'opened' if passangerrearwindow else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['sunroof'] != sunroof:
                notemsg[0] = 'Sunroof'
                notemsg[1] = 'opened' if sunroof else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['trunk'] != trunk:
                notemsg[0] = 'Trunk'
                notemsg[1] = 'opened' if trunk else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['bonnet'] != bonnet:
                notemsg[0] = 'Bonnet'
                notemsg[1] = 'opened' if bonnet else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['trunkbuttonpress'] != trunkbuttonpress:
                notemsg[0] = 'Trunk Button'
                notemsg[1] = 'pressed' if trunkbuttonpress else 'released'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if doorsopen and self.zv_auto_lock and self.zv_auto_unlock_door_open and zvlockstate:
                self.gm_zv_unlock()
        self.gm_states['driverdoor'] = driverdoor
        self.gm_states['passangerdoor'] = passangerdoor
        self.gm_states['driverreardoor'] = driverreardoor
        self.gm_states['passangerreardoor'] = passangerreardoor
        self.gm_states['doorsopen'] = doorsopen
        self.gm_states['zvunlocked'] = zvunlocked
        self.gm_states['zvlocked'] = zvlocked
        self.gm_states['zvlockstate'] = zvlockstate
        self.gm_states['zvhardlocked'] = zvhardlocked
        self.gm_states['indoorlights'] = indoorlights
        self.gm_states['driverwindow'] = driverwindow
        self.gm_states['passengerwindow'] = passengerwindow
        self.gm_states['driverrearwindow'] = driverrearwindow
        self.gm_states['passangerrearwindow'] = passangerrearwindow
        self.gm_states['sunroof'] = sunroof
        self.gm_states['trunk'] = trunk
        self.gm_states['bonnet'] = bonnet
        self.gm_states['trunkbuttonpress'] = trunkbuttonpress
        self.gm_states['run_once'] = True

    def gm_zv_lock(self):
        thread = Thread(target=self._gm_zv_lock())
        thread.setDaemon(True)
        thread.start()

    def gm_zv_unlock(self):
        thread = Thread(target=self._gm_zv_unlock())
        thread.setDaemon(True)
        thread.start()

    def _gm_zv_lock(self):
        if self.car_model == 'E39':
            IBUS.write_bus_packet(63, 0, [12, 0, 11])
        elif self.car_model == 'E46':
            IBUS.write_bus_packet(63, 0, [12, 52, 1])
        self.gm_states['zvprocessed'] = True
        log('CENTRAL-LOCK-SYSTEM: LOCK')

    def _gm_zv_unlock(self):
        if self.car_model == 'E39':
            IBUS.write_bus_packet(63, 0, [12, 1, 0])
        elif self.car_model == 'E46':
            IBUS.write_bus_packet(63, 0, [12, 3, 1])
        self.gm_states['zvprocessed'] = True
        log('CENTRAL-LOCK-SYSTEM: UNLOCK')

    def gm_mirror_unfold(self):
        thread = Thread(target=self._gm_mirror_unfold)
        thread.setDaemon(True)
        thread.start()

    def gm_mirror_fold(self):
        thread = Thread(target=self._gm_mirror_fold)
        thread.setDaemon(True)
        thread.start()

    def _gm_mirror_unfold(self):
        if self.mir_unfolded:
            return
        if self.mir_fold_mov:
            self.mir_fold_mov = False
            self.mir_folded = False
            self.mir_unfolded = False
            self.gm_diag_off()
            time.sleep(1)
        log('GM: UNFOLD MIRROS')
        self.mir_unfold_mov = True
        IBUS.write_bus_packet(63, 0, [12, 1, 48])
        time.sleep(0.2)
        IBUS.write_bus_packet(63, 0, [12, 2, 48])
        self.mir_folded = False
        time.sleep(6)
        if self.mir_unfold_mov:
            self.mir_unfolded = True
        self.mir_unfold_mov = False

    def _gm_mirror_fold(self):
        if self.mir_folded:
            return
        if self.mir_unfold_mov:
            self.mir_unfold_mov = False
            self.mir_folded = False
            self.mir_unfolded = False
            self.gm_diag_off()
            time.sleep(1)
        log('GM: FOLD MIRROS')
        self.mir_fold_mov = True
        IBUS.write_bus_packet(63, 0, [12, 1, 49])
        time.sleep(0.2)
        IBUS.write_bus_packet(63, 0, [12, 2, 49])
        self.mir_unfolded = False
        time.sleep(6)
        if self.mir_fold_mov:
            self.mir_folded = True
        self.mir_fold_mov = False

    def gm_diag_off(self):
        IBUS.write_bus_packet(63, 0, [159])
        log('GM: DIAG OFF')

    def pi_on(self):
        self.piaktiv = True
        log('RASPBERRY: ACTIVATE PI')
        self.pi_show()
        if self.dsp_cd:
            self.dsp_set_cd()
        KODI.track_play()
        if self.modealways:
            self.radio_bm_led_on()

    def pi_off(self):
        if self.modealways:
            return
        self.piaktiv = False
        log('RASPBERRY: DEACTIVATE PI')
        self.pi_hide()
        if self.dsp_cd:
            self.dsp_set_tuner()
        KODI.track_pause()

    def pi_show(self):
        if self.navmenu or self.tpmenu or self.tonemenu or not self.piaktiv:
            return
        self.pass_bm_buttons = True
        log('RASPBERRY: SHOW PI')
        self.gt_av_r_on(True)

    def pi_hide(self):
        self.pass_bm_buttons = False
        if self.gpio_rearcam_counter > 0 or self.pdc_req_running:
            return
        log('RASPBERRY: HIDE PI')
        self.gt_av_r_on(False)

    def gt_av_r_on(self, ntscstate):
        if self.gpio_ntsc:
            if ntscstate:
                GPIO_NTSC.set()
            else:
                GPIO_NTSC.reset()
        else:
            IBUS.ntsc = 1 if ntscstate else 0

    def dsp_set_tuner(self):
        IBUS.write_bus_packet(104, 106, [54, 161])
        log('RASPBERRY: DSP SOURCE TUNER')

    def dsp_set_cd(self):
        IBUS.write_bus_packet(104, 106, [54, 160])
        log('RASPBERRY: DSP SOURCE CD')

    def kodi_said_play(self):
        if not self.piaktiv or self.phone_mute:
            KODI.track_pause()

    def lcm_get_state(self):
        IBUS.write_bus_packet(191, 208, [90])
        time.sleep(0.2)
        IBUS.write_bus_packet(191, 208, [93])

    def lcm_state(self, dat):
        aa = dat[1]
        cc = dat[3]
        park = get_bit_from_hex(aa, BIT[0])
        low_beam = get_bit_from_hex(aa, BIT[1])
        high_beam = get_bit_from_hex(aa, BIT[2])
        fog_front = get_bit_from_hex(aa, BIT[3])
        fog_rear = get_bit_from_hex(aa, BIT[4])
        turn_left = get_bit_from_hex(aa, BIT[5])
        turn_right = get_bit_from_hex(aa, BIT[6])
        turn_fast_blink = get_bit_from_hex(aa, BIT[7])
        tail = get_bit_from_hex(cc, BIT[3])
        reverse = get_bit_from_hex(cc, BIT[5])
        hazard = get_bit_from_hex(cc, BIT[7])
        if self.lcm_states['run_once']:
            if turn_left != self.lcm_states['turn_left'] and not turn_right:
                if turn_left:
                    self.lcm_turn_left()
            if turn_right != self.lcm_states['turn_right'] and not turn_left:
                if turn_right:
                    self.lcm_turn_right()
            if high_beam != self.lcm_states['high_beam']:
                self.lcm_flash_to_pass(high_beam)
            if park != self.lcm_states['park']:
                if park:
                    if self.lcd_brightness:
                        self.bm_set_brightness(self.lcd_brightness_value_on)
                elif self.lcd_brightness:
                    self.bm_set_brightness(self.lcd_brightness_value_off)
        self.lcm_states['park'] = park
        self.lcm_states['low_beam'] = low_beam
        self.lcm_states['high_beam'] = high_beam
        self.lcm_states['fog_front'] = fog_front
        self.lcm_states['fog_rear'] = fog_rear
        self.lcm_states['turn_left'] = turn_left
        self.lcm_states['turn_right'] = turn_right
        self.lcm_states['turn_fast_blink'] = turn_fast_blink
        self.lcm_states['tail'] = tail
        self.lcm_states['reverse'] = reverse
        self.lcm_states['hazard'] = hazard
        self.lcm_states['run_once'] = True

    def lcm_diag_state(self, dat):
        if len(dat) < 2:
            return
        self.lcm_states['diag_dim_level'] = dat[16]
        log('LCM: Dim Diag Value = %s' % self.lcm_states['diag_dim_level'])

    def lcm_dim_level(self, dat):
        if self.lcm_states['dim_level'] != dat[1]:
            log('LCM: Dim Value = %s' % dat[1])
            self.lcm_states['dim_level'] = dat[1]
            IBUS.write_bus_packet(63, 208, [11])

    def lcm_lights_on(self, timedelay = 10):
        thread = Thread(target=self._lcm_lights_on, args=(timedelay,))
        thread.setDaemon(True)
        thread.start()

    def _lcm_lights_on(self, timedelay = 10):
        if self.day_time and time_now_in_range(self.day_time_start, self.day_time_end):
            return
        self.lcm_delay = timedelay
        if self.ign_mode > 0:
            log('LCM: Skip Welcomelight, IGN is turned ON')
            return
        sendcount = 10
        self.lcm_on = True
        while self.lcm_delay > 0 and self.lcm_on:
            if self.ign_mode > 0:
                break
            if sendcount >= 10:
                sendcount = 0
                if self.bm_sensor and not self.bm_sensor_brightness:
                    wait_counter = 5
                    while wait_counter > 0:
                        wait_counter -= 1
                        if self.bm_sensor_brightness:
                            break
                        self.bm_get_state()
                        time.sleep(0.2)

                    if self.bm_sensor_brightness:
                        if self.bm_sensor_brightness > self.bm_sensor_level:
                            break
                if self.car_model == 'E39':
                    AA = 0
                    BB = 0
                    CC = 0
                    DD = 0
                    EE = 0
                    FF = 0
                    GG = 0
                    HH = 0
                    II = 0
                    if self.wel_light_park:
                        FF = set_bit_in_hex(FF, BIT[0], True)
                        FF = set_bit_in_hex(FF, BIT[1], True)
                        GG = set_bit_in_hex(GG, BIT[3], True)
                        GG = set_bit_in_hex(GG, BIT[5], True)
                        HH = set_bit_in_hex(HH, BIT[3], True)
                        HH = set_bit_in_hex(HH, BIT[4], True)
                    if self.wel_light_low:
                        FF = set_bit_in_hex(FF, BIT[4], True)
                        FF = set_bit_in_hex(FF, BIT[5], True)
                    if self.wel_light_fog:
                        FF = set_bit_in_hex(FF, BIT[2], True)
                        FF = set_bit_in_hex(FF, BIT[6], True)
                    if self.wel_light_nbrplate:
                        GG = set_bit_in_hex(GG, BIT[2], True)
                    if self.wel_light_turn_front:
                        GG = set_bit_in_hex(GG, BIT[6], True)
                        HH = set_bit_in_hex(HH, BIT[6], True)
                    if self.wel_light_turn_back:
                        GG = set_bit_in_hex(GG, BIT[7], True)
                        HH = set_bit_in_hex(HH, BIT[1], True)
                    IBUS.write_bus_packet(63, 208, [12,
                     AA,
                     BB,
                     CC,
                     DD,
                     EE,
                     FF,
                     GG,
                     HH,
                     II,
                     self.lcm_states['diag_dim_level'],
                     1,
                     0], True)
                elif self.car_model == 'E46':
                    AA = 0
                    BB = 0
                    CC = 255
                    DD = 0
                    EE = 0
                    FF = 0
                    GG = 0
                    HH = 0
                    if self.wel_light_park:
                        EE = set_bit_in_hex(EE, BIT[1], True)
                        FF = set_bit_in_hex(FF, BIT[3], True)
                        FF = set_bit_in_hex(FF, BIT[6], True)
                        GG = set_bit_in_hex(GG, BIT[3], True)
                    if self.wel_light_low:
                        FF = set_bit_in_hex(FF, BIT[1], True)
                        FF = set_bit_in_hex(FF, BIT[2], True)
                    if self.wel_light_fog:
                        GG = set_bit_in_hex(GG, BIT[0], True)
                    if self.wel_light_nbrplate:
                        GG = set_bit_in_hex(GG, BIT[1], True)
                    if self.wel_light_turn_front:
                        EE = set_bit_in_hex(EE, BIT[5], True)
                        EE = set_bit_in_hex(EE, BIT[6], True)
                    if self.wel_light_turn_back:
                        GG = set_bit_in_hex(GG, BIT[5], True)
                        GG = set_bit_in_hex(GG, BIT[7], True)
                    IBUS.write_bus_packet(63, 208, [12,
                     AA,
                     BB,
                     CC,
                     DD,
                     EE,
                     FF,
                     GG,
                     HH,
                     0,
                     self.lcm_states['diag_dim_level'],
                     0,
                     0,
                     0,
                     0,
                     0], True)
                log('LCM: LIGHTS ON - Turn OFF in %ss - %s' % (self.lcm_delay, self.car_model))
            sendcount += 1
            self.lcm_delay += -1
            if self.ign_mode < 0:
                self.ign_get_state()
            time.sleep(1)

        if self.lcm_on:
            self.lcm_lights_off()

    def lcm_lights_off(self):
        self.lcm_delay = -1
        if self.lcm_on:
            IBUS.write_bus_packet(63, 208, [159], True, repeat=2)
            log('LCM: LIGHTS OFF')
        self.lcm_on = False
        self.bm_sensor_brightness = None

    def lcm_flash_to_pass(self, state):
        if True in [self.turning_left,
         self.turning_fog_left,
         self.turning_right,
         self.turning_fog_right]:
            return
        if self.lcm_states['low_beam'] and self.flash_to_pass_low_beam:
            return
        if self.lcm_states['fog_front'] and self.flash_to_pass_fog:
            return
        if state:
            if self.flash_to_pass and (self.flash_to_pass_low_beam or self.flash_to_pass_fog):
                if self.car_model == 'E39':
                    ff = 0
                    if self.flash_to_pass_low_beam and self.flash_to_pass_fog:
                        ff = 116
                    elif self.flash_to_pass_low_beam:
                        ff = 48
                    elif self.flash_to_pass_fog:
                        ff = 68
                    log('LCM: FLASH TO PASS: FOG=%s; LOWBEAM=%s' % (self.flash_to_pass_fog, self.flash_to_pass_low_beam))
                    IBUS.write_bus_packet(63, 208, [12,
                     0,
                     0,
                     0,
                     0,
                     0,
                     ff,
                     0,
                     0,
                     0,
                     self.lcm_states['diag_dim_level'],
                     1,
                     0], veryhighprio=True)
                elif self.car_model == 'E46':
                    ff = 0
                    gg = 0
                    if self.flash_to_pass_low_beam and self.flash_to_pass_fog:
                        ff = 6
                        gg = 1
                    elif self.flash_to_pass_low_beam:
                        ff = 6
                        gg = 0
                    elif self.flash_to_pass_fog:
                        ff = 0
                        gg = 1
                    log('LCM: FLASH TO PASS: FOG=%s; LOWBEAM=%s' % (self.flash_to_pass_fog, self.flash_to_pass_low_beam))
                    IBUS.write_bus_packet(63, 208, [12,
                     0,
                     0,
                     255,
                     0,
                     0,
                     ff,
                     gg,
                     0,
                     0,
                     self.lcm_states['diag_dim_level'],
                     0,
                     0,
                     0,
                     0,
                     0], veryhighprio=True)
        else:
            time.sleep(0.3)
            self._lcm_turn_off()

    def lcm_turn_left(self):
        if not self.turning_left:
            if self.comfort_blink or self.turn_light:
                if not self.turning_right and self.turning_fog_right:
                    self.cancel_turn_right = True
                elif self.turning_right:
                    self.cancel_turn_right = True
                    self._lcm_turn_off()
                    return
                while self.cancel_turn_right:
                    time.sleep(0.001)

                if self.turning_fog_left:
                    self.cancel_turn_left = True
                    while self.cancel_turn_left:
                        time.sleep(0.001)

            thread = Thread(target=self._lcm_turn_left_on)
            thread.setDaemon(True)
            thread.start()
        else:
            self.cancel_turn_left = True
            self._lcm_turn_off()

    def lcm_turn_right(self):
        if not self.turning_right:
            if self.comfort_blink or self.turn_light:
                if not self.turning_left and self.turning_fog_left:
                    self.cancel_turn_left = True
                elif self.turning_left:
                    self.cancel_turn_left = True
                    self._lcm_turn_off()
                    return
                while self.cancel_turn_left:
                    time.sleep(0.001)

                if self.turning_fog_right:
                    self.cancel_turn_right = True
                    while self.cancel_turn_right:
                        time.sleep(0.001)

            thread = Thread(target=self._lcm_turn_right_on)
            thread.setDaemon(True)
            thread.start()
        else:
            self.cancel_turn_left = True
            self._lcm_turn_off()

    def _lcm_turn_left_on(self):
        log('LCM: LIGHTS TURN LEFT')
        if self.comfort_blink:
            log('LCM: LIGHTS TURN LEFT FLASH')
            self.turning_left = True
            if self.car_model == 'E39':
                IBUS.write_bus_packet(63, 208, [12,
                 0,
                 0,
                 128,
                 0,
                 0,
                 4 if self.turn_light and self.lcm_states['park'] else 0,
                 0,
                 0,
                 0,
                 self.lcm_states['diag_dim_level'],
                 1,
                 0], veryhighprio=True)
            elif self.car_model == 'E46':
                IBUS.write_bus_packet(63, 208, [12,
                 0,
                 0,
                 255,
                 64,
                 0,
                 0,
                 0,
                 0,
                 0,
                 self.lcm_states['diag_dim_level'],
                 0,
                 0,
                 0,
                 0,
                 0], veryhighprio=True)
            counter = self.comfort_blink_time
            while counter > 0:
                if self.cancel_turn_left:
                    break
                counter -= 1
                time.sleep(0.001)

        if self.turn_light and self.lcm_states['park'] and self.car_model == 'E39' and not self.cancel_turn_left and self.obc_speed_kmh <= self.turn_light_max_speed:
            log('LCM: LIGHTS TURN LEFT FOG')
            self.turning_fog_left = True
            IBUS.write_bus_packet(63, 208, [12,
             0,
             0,
             0,
             0,
             0,
             4,
             0,
             0,
             0,
             self.lcm_states['diag_dim_level'],
             1,
             0], veryhighprio=True, repeat=2)
            self.turning_left = False
            counter = self.turn_light_time - (self.comfort_blink_time if self.comfort_blink else 0)
            light_counter = 10000
            while counter > 0:
                if self.cancel_turn_left or self.obc_speed_kmh > self.turn_light_max_speed or not self.lcm_states['park']:
                    break
                if self.lcm_states['turn_left']:
                    counter = self.turn_light_time / 2
                else:
                    counter -= 1
                light_counter -= 1
                if light_counter == 0:
                    light_counter = 10000
                    IBUS.write_bus_packet(63, 208, [12,
                     0,
                     0,
                     0,
                     0,
                     0,
                     4,
                     0,
                     0,
                     0,
                     self.lcm_states['diag_dim_level'],
                     1,
                     0], veryhighprio=True)
                time.sleep(0.001)

        if not self.cancel_turn_left:
            self._lcm_turn_off()
        self.turning_left = False
        self.turning_fog_left = False
        self.cancel_turn_left = False

    def _lcm_turn_right_on(self):
        log('LCM: LIGHTS TURN RIGHT')
        if self.comfort_blink:
            self.turning_right = True
            if self.car_model == 'E39':
                IBUS.write_bus_packet(63, 208, [12,
                 0,
                 0,
                 64 if self.comfort_blink else 0,
                 0,
                 0,
                 64 if self.turn_light and self.lcm_states['park'] else 0,
                 0,
                 0,
                 0,
                 self.lcm_states['diag_dim_level'],
                 1,
                 0], veryhighprio=True)
            elif self.car_model == 'E46':
                IBUS.write_bus_packet(63, 208, [12,
                 0,
                 0,
                 255,
                 128,
                 0,
                 0,
                 0,
                 0,
                 0,
                 self.lcm_states['diag_dim_level'],
                 0,
                 0,
                 0,
                 0,
                 0], veryhighprio=True)
            counter = self.comfort_blink_time
            while counter > 0:
                if self.cancel_turn_right:
                    break
                counter -= 1
                time.sleep(0.001)

        if self.turn_light and self.lcm_states['park'] and self.car_model == 'E39' and not self.cancel_turn_right and self.obc_speed_kmh <= self.turn_light_max_speed:
            log('LCM: LIGHTS TURN RIGHT FOG')
            self.turning_fog_right = True
            IBUS.write_bus_packet(63, 208, [12,
             0,
             0,
             0,
             0,
             0,
             64,
             0,
             0,
             0,
             self.lcm_states['diag_dim_level'],
             1,
             0], veryhighprio=True, repeat=2)
            self.turning_right = False
            counter = self.turn_light_time - (self.comfort_blink_time if self.comfort_blink else 0)
            light_counter = 10000
            while counter > 0:
                if self.cancel_turn_right or self.obc_speed_kmh > self.turn_light_max_speed or not self.lcm_states['park']:
                    break
                if self.lcm_states['turn_right']:
                    counter = self.turn_light_time / 2
                else:
                    counter -= 1
                light_counter -= 1
                if light_counter == 0:
                    light_counter = 10000
                    IBUS.write_bus_packet(63, 208, [12,
                     0,
                     0,
                     0,
                     0,
                     0,
                     64,
                     0,
                     0,
                     0,
                     self.lcm_states['diag_dim_level'],
                     1,
                     0], veryhighprio=True)
                time.sleep(0.001)

        if not self.cancel_turn_right:
            self._lcm_turn_off()
        self.cancel_turn_right = False
        self.turning_right = False
        self.turning_fog_right = False

    def _lcm_turn_off(self):
        """
        if self.car_model == 'E39':
            #IBUS.write_bus_packet('3F', 'D0', ['0C', '00', '00', '00', '00', '00', '00', '00', '00', '00'], veryhighprio=True)
            #IBUS.write_bus_packet('3F', 'D0', ['0C', '00', '00', '00', '00', '00', '00', '00', '00', '00'], veryhighprio=True)
            IBUS.write_bus_packet('3F', 'D0', ['0C', '00', '00', '00', '00', '00', '00', '00', '00', '00', self.lcm_states['diag_dim_level'], '01', '00'], veryhighprio=True)
            IBUS.write_bus_packet('3F', 'D0', ['0C', '00', '00', '00', '00', '00', '00', '00', '00', '00', self.lcm_states['diag_dim_level'], '01', '00'], veryhighprio=True)
        
            #IBUS.write_bus_packet('3F', 'D0', ['0C', '00', '00', '00', '00', '00', '00', '00', '00', '00', 'C2', '04', '00'], True)
            #time.sleep(0.4)
            #IBUS.write_bus_packet('3F', 'D0', ['00'], True)
        elif self.car_model == 'E46':
            IBUS.write_bus_packet('3F', 'D0', ['0C', '00', '00', '00', '00', '00', '00', '00', '00'], veryhighprio=True)
            IBUS.write_bus_packet('3F', 'D0', ['0C', '00', '00', '00', '00', '00', '00', '00', '00'], veryhighprio=True)
        """
        IBUS.write_bus_packet(63, 208, [159], veryhighprio=True)
        IBUS.write_bus_packet(63, 208, [159], veryhighprio=True)

    def send_song_to_ike(self):
        if not self.ike_display or not self.ike_track:
            self.new_song = False
            return
        thread = Thread(target=self._send_song_to_ike_thread)
        thread.setDaemon(True)
        thread.start()

    def _send_song_to_ike_thread(self):
        try:
            while int(xbmc.Player().getTime()) > 0.2:
                time.sleep(0.01)

            while not xbmc.Player().isPlaying():
                time.sleep(0.01)

            while int(xbmc.Player().getTime()) < 0.5:
                time.sleep(0.01)

            Song = KODI.track_title()
            if Song == '':
                return
            log('SEND SONG: "%s" to IKE Display' % Song, 2)
            self.ike_send_text(Song)
        except:
            log('Kodi has an error with playing or -> not playing <- media.')

        self.new_song = False

    def ike_send_text(self, Text, when_pi_is_inactiv = False, when_ign_off = False):
        if not self.ike_display or self.stw_nav:
            return
        time.sleep(0.05)
        while self.ike_text_scroll_thread.isAlive():
            self.ike_text_scrolling = False if self.ike_text_scrolling else True
            time.sleep(0.001)

        self.ike_text_scroll_thread = Thread(target=self._ike_send_text_thread, args=(Text, when_pi_is_inactiv, when_ign_off))
        self.ike_text_scroll_thread.setDaemon(True)
        self.ike_text_scrolling = True
        self.ike_text_scroll_thread.start()

    def _ike_send_text_thread(self, text, when_pi_is_inactiv = False, when_ign_off = False):
        if not self.piaktiv and not when_pi_is_inactiv:
            return
        scrollspeed = self.text_scrollspeed
        displaylength = 20
        text = _encode_ibus_chars(text)
        if len(text) <= displaylength:
            self.ike_text_to_ibus(text.center(20), when_ign_off=when_ign_off)
        else:
            self.ike_text_to_ibus(text[:20], when_ign_off=when_ign_off)
            ticker = 1500
            while ticker > 0:
                if not self.ike_text_scrolling:
                    return
                if not self.piaktiv and not when_pi_is_inactiv:
                    return self.ike_clear_display(0)
                ticker -= 1
                time.sleep(0.001)

            cnt = len(text)
            cnt_tmp = 0
            ticker = 1
            while cnt_tmp + displaylength <= cnt:
                if not self.ike_text_scrolling:
                    return
                if not self.piaktiv and not when_pi_is_inactiv:
                    return self.ike_clear_display(0)
                if ticker >= scrollspeed:
                    self.ike_text_to_ibus(text[cnt_tmp:displaylength + cnt_tmp], when_ign_off=when_ign_off)
                    cnt_tmp += 1
                    ticker = 1
                else:
                    ticker += 1
                time.sleep(0.001)

            ticker = 1
            while ticker < 1000:
                if not self.ike_text_scrolling:
                    return
                if not self.piaktiv and not when_pi_is_inactiv:
                    return self.ike_clear_display(0)
                ticker += 1
                time.sleep(0.001)

            ticker = 1
            cnt_tmp = len(text) - displaylength
            while cnt_tmp + displaylength >= displaylength:
                if not self.ike_text_scrolling:
                    return
                if not self.piaktiv and not when_pi_is_inactiv:
                    return self.ike_clear_display(0)
                if ticker == scrollspeed:
                    self.ike_text_to_ibus(text[cnt_tmp:displaylength + cnt_tmp], when_ign_off=when_ign_off)
                    cnt_tmp -= 1
                    ticker = 1
                else:
                    ticker += 1
                time.sleep(0.001)

        self.ike_text_scrolling = False
        if not when_ign_off:
            return self.ike_clear_display()

    def ike_clear_display(self, delay = 3.0, when_ign_off = False):
        if not self.ike_display:
            return
        if self.ike_text_scrolling:
            self.ike_text_scrolling = False
        while delay > 0.0:
            if self.ike_text_scrolling:
                return
            delay -= 0.001
            time.sleep(0.001)

        if when_ign_off:
            IBUS.write_bus_packet(48, 128, [26, 48, 0])
        else:
            IBUS.write_bus_packet(200, 128, [35, 64, 48])

    def ike_text_to_ibus(self, text, when_ign_off = False):
        dat = [26, 53, 0] if when_ign_off else [35, 98, 48]
        dat.extend(asc_to_hex(text))
        IBUS.write_bus_packet(200, 128, dat)

    def mid_send_text(self, text):
        log('send text to MID: %s' % text)
        text = _encode_ibus_chars(text)
        if len(text) <= 11:
            pass
        else:
            text = text[11:]
        dat = [35, 146, 48]
        dat.extend(asc_to_hex(text.ljust(11)))
        IBUS.write_bus_packet(104, 192, dat)

    def bm_led(self, color, state = False):
        if color.lower() == 'red':
            IBUS.write_bus_packet(200, 240, [43, 1])
        if color.lower() == 'yellow':
            IBUS.write_bus_packet(200, 240, [43, 4])
        if color.lower() == 'green':
            IBUS.write_bus_packet(200, 240, [43, 16])
        if color.lower() == 'off':
            IBUS.write_bus_packet(200, 240, [43, 0])

    def bm_get_state(self):
        IBUS.write_bus_packet(63, 240, [11, 2])

    def bm_set_state(self, dat):
        if len(dat) < 2:
            return
        self.bm_sensor_brightness = dat[12]
        if self.bm_sensor_brightness == 0:
            self.bm_sensor_brightness = 1
        log('BMBT: Brightness = %s' % self.bm_sensor_brightness, 2)

    def bm_set_brightness(self, value):
        if value > 0:
            value = int(translate(value, 1, 10, 0, 127))
        elif value == 0:
            value = 128
        elif value < 0:
            value = int(translate(value * -1, 1, 10, 129, 255))
        IBUS.write_bus_packet(59, 240, [5,
         65,
         1,
         value])
        log('BMBT: Set LCD Brightness = %s' % value)

    def nav_zoom(self, speed_kmh):
        if not self.map_auto_zoom:
            return
        zoom_level = -1
        if speed_kmh < self.map_auto_zoom_200 - 20:
            zoom_level = 100
        elif speed_kmh >= self.map_auto_zoom_5000:
            zoom_level = 5000
        elif speed_kmh >= self.map_auto_zoom_2000 and self.map_states['zoom_level'] < 2000:
            zoom_level = 2000
        elif speed_kmh >= self.map_auto_zoom_1000 and self.map_states['zoom_level'] < 1000:
            zoom_level = 1000
        elif speed_kmh >= self.map_auto_zoom_500 and self.map_states['zoom_level'] < 500:
            zoom_level = 500
        elif speed_kmh >= self.map_auto_zoom_200 and self.map_states['zoom_level'] < 200:
            zoom_level = 200
        elif speed_kmh < self.map_auto_zoom_500 - 10 and self.map_states['zoom_level'] > 200:
            zoom_level = 200
        elif speed_kmh < self.map_auto_zoom_1000 - 10 and self.map_states['zoom_level'] > 500:
            zoom_level = 500
        elif speed_kmh < self.map_auto_zoom_2000 - 10 and self.map_states['zoom_level'] > 1000:
            zoom_level = 1000
        elif speed_kmh < self.map_auto_zoom_5000 - 5 and self.map_states['zoom_level'] > 2000:
            zoom_level = 2000
        if zoom_level != self.map_states['zoom_level'] and zoom_level > -1:
            IBUS.write_bus_packet(*self.map_states[zoom_level])
            self.map_states['zoom_level'] = zoom_level
            log('NAVI: ZOOM LEVEL %sm on %skm/h' % (zoom_level, speed_kmh))

    def nav_show_map(self):
        IBUS.write_bus_packet(176, 127, [170, 4, 0])
        log('Show Navigation Map')

    def pdc_req_start(self):
        if not self.pdc_on:
            return
        if not self.pdc_req_running:
            self.pdc_on_value = None
            thread = Thread(target=self._pdc_req_start)
            thread.setDaemon(True)
            thread.start()

    def _pdc_req_start(self):
        log('PDC: Request Started')
        self.got_pdc_answer = True
        self.pdc_req_running = True
        self.pdc_counter = self.pdc_timeout
        no_answer_counter = 0
        while self.pdc_counter > 0:
            if self.pdc_req_cancel:
                break
            if self.got_pdc_answer or no_answer_counter >= 1 / self.pdc_interval:
                no_answer_counter = 0
                self.got_pdc_answer = False
                IBUS.write_bus_packet(63, 96, [27])
            no_answer_counter += 1
            if self.ike_states['gear_pos'] == 'R':
                self.pdc_counter = self.pdc_timeout
            else:
                self.pdc_counter -= self.pdc_interval
            time.sleep(self.pdc_interval)

        self.pdc_req_running = False
        self.pdc_on_value = None
        log('PDC: Request Stoped')
        if not self.pass_bm_buttons:
            self.gt_av_r_on(False)
        KODI.set_property('IBUSCOMMUNICATOR_PDC_SHOW', '0')
        if not self.pdc_req_cancel and self.pdc_timeout_off:
            IBUS.write_bus_packet(63, 96, [12, 64])
        self.pdc_req_cancel = False

    def pdc_req_stop(self):
        self.pdc_req_cancel = True

    def pdc_put_state(self, dat):
        if not self.pdc_on:
            return
        if len(dat) < 2:
            return
        self.got_pdc_answer = True

        def pdc_image(value):
            log('input: %s' % value, 3)
            value_min = 15
            value_max = 75
            if value <= value_min:
                return '20'
            if value_min <= value <= value_max:
                result = '%s' % abs(int(translate(value, value_min, value_max, -20, 0)))
                if len(result) < 2:
                    return '%s'.zfill(3) % result
                return '%s' % result
            if value > value_max:
                return '00'

        def pdc_label(value):
            if value > 75:
                return '---'
            return '%s' % value

        front_left_side = dat[6]
        front_right_side = dat[7]
        front_left_center = dat[8]
        front_right_center = dat[9]
        rear_left_side = dat[2]
        rear_right_side = dat[3]
        rear_left_center = dat[4]
        rear_right_center = dat[5]
        on_value = get_bit_from_hex(dat[10], BIT[0])
        if rear_left_side + rear_right_side + rear_left_center + rear_right_center + front_left_side + front_right_side + front_left_center + front_right_center < 2040:
            self.pdc_counter = self.pdc_timeout
        if not EVENT.pdc_type:
            KODI.set_property('IBUSCOMMUNICATOR_PDC_FLS', '%s' % pdc_label(front_left_side))
            KODI.set_property('IBUSCOMMUNICATOR_PDC_FLC', '%s' % pdc_label(front_left_center))
            KODI.set_property('IBUSCOMMUNICATOR_PDC_FRC', '%s' % pdc_label(front_right_center))
            KODI.set_property('IBUSCOMMUNICATOR_PDC_FRS', '%s' % pdc_label(front_right_side))
        KODI.set_property('IBUSCOMMUNICATOR_PDC_RLS', '%s' % pdc_label(rear_left_side))
        KODI.set_property('IBUSCOMMUNICATOR_PDC_RLC', '%s' % pdc_label(rear_left_center))
        KODI.set_property('IBUSCOMMUNICATOR_PDC_RRC', '%s' % pdc_label(rear_right_center))
        KODI.set_property('IBUSCOMMUNICATOR_PDC_RRS', '%s' % pdc_label(rear_right_side))
        log('PDC: Values\n                   %s - %s - %s - %s \n                   %s - %s - %s - %s ' % (front_left_side,
         front_left_center,
         front_right_center,
         front_right_side,
         rear_left_side,
         rear_left_center,
         rear_right_center,
         rear_right_side), 2)
        log('pic number - %s' % pdc_image(front_left_center), 3)
        KODI.set_property('IBUSCOMMUNICATOR_PDC_BG_IMG', '%s' % EVENT.pdc_bg)
        if not EVENT.pdc_type:
            KODI.set_property('IBUSCOMMUNICATOR_PDC_FLS_IMG', '%s' % os.path.join(ADDONPDCPATH, 'side', 'SIDE%s.png' % pdc_image(front_left_side)))
            KODI.set_property('IBUSCOMMUNICATOR_PDC_FLC_IMG', '%s' % os.path.join(ADDONPDCPATH, 'mid', 'MID%s.png' % pdc_image(front_left_center)))
            KODI.set_property('IBUSCOMMUNICATOR_PDC_FRC_IMG', '%s' % os.path.join(ADDONPDCPATH, 'mid', 'MID%s.png' % pdc_image(front_right_center)))
            KODI.set_property('IBUSCOMMUNICATOR_PDC_FRS_IMG', '%s' % os.path.join(ADDONPDCPATH, 'side', 'SIDE%s.png' % pdc_image(front_right_side)))
        KODI.set_property('IBUSCOMMUNICATOR_PDC_RLS_IMG', '%s' % os.path.join(ADDONPDCPATH, 'side', 'SIDE%s.png' % pdc_image(rear_left_side)))
        KODI.set_property('IBUSCOMMUNICATOR_PDC_RLC_IMG', '%s' % os.path.join(ADDONPDCPATH, 'mid', 'MID%s.png' % pdc_image(rear_left_center)))
        KODI.set_property('IBUSCOMMUNICATOR_PDC_RRC_IMG', '%s' % os.path.join(ADDONPDCPATH, 'mid', 'MID%s.png' % pdc_image(rear_right_center)))
        KODI.set_property('IBUSCOMMUNICATOR_PDC_RRS_IMG', '%s' % os.path.join(ADDONPDCPATH, 'side', 'SIDE%s.png' % pdc_image(rear_right_side)))
        if self.pdc_on_value:
            if not on_value:
                self.pdc_req_stop()
        else:
            if self.pdc_req_running:
                KODI.set_property('IBUSCOMMUNICATOR_PDC_SHOW', '1')
                if not self.pass_bm_buttons:
                    self.gt_av_r_on(True)
            self.pdc_on_value = on_value

    def rearcam_on(self):
        if self.gpio_rearcam:
            thread = Thread(target=self._rearcam_on)
            thread.setDaemon(True)
            thread.start()

    def _rearcam_on(self):
        if self.rearcam_active:
            return
        if self.gpio_rearcam_counter > 0:
            self.gpio_rearcam_counter = self.gpio_rearcam_timeout * 10
            self.rearcam_active = True
            return
        self.rearcam_active = True
        if self.gpio_rearcam_off == 2:
            self.gpio_rearcam_counter = 600
        else:
            self.gpio_rearcam_counter = self.gpio_rearcam_timeout * 10
        GPIO_REARCAM.set()
        self.gt_av_r_on(True)
        log('REARCAM RELAIS: ON')
        while True:
            if not self.rearcam_active:
                if self.gpio_rearcam_off == 0:
                    break
                elif self.gpio_rearcam_off == 1:
                    if self.gpio_rearcam_counter < 1:
                        break
                    else:
                        log('REARCAM RELAIS: OFF in %ss' % (float(self.gpio_rearcam_counter) / 10), 2)
                        self.gpio_rearcam_counter -= 1
                elif self.gpio_rearcam_off == 2:
                    if self.obc_speed_kmh >= self.gpio_rearcam_speed or self.gpio_rearcam_counter < 1:
                        break
                    else:
                        log('REARCAM RELAIS: OFF in %ss or current Speed(%s) >= %s' % (float(self.gpio_rearcam_counter) / 10, self.obc_speed_kmh, self.gpio_rearcam_speed), 2)
                        self.gpio_rearcam_counter -= 1
            time.sleep(0.1)

        self.gpio_rearcam_counter = 0
        GPIO_REARCAM.reset()
        if not self.pass_bm_buttons:
            self.gt_av_r_on(False)
        log('REARCAM RELAIS: OFF')

    def rearcam_off(self):
        self.rearcam_active = False

    def obc_req(self, resetrunonce = False):
        if self.obc_req_runs:
            return
        if resetrunonce:
            self.obc_req_runonce = False
        if not self.obc_req_runonce:
            thread = Thread(target=self._obc_req_thread)
            thread.setDaemon(True)
            self.obc_req_runs = True
            thread.start()
        self.obc_req_runonce = True

    def _obc_req_thread(self):
        obc_req_delay = 0.21
        log('OBC: START REQUEST')
        time.sleep(0.35)
        self.obc_time_req()
        time.sleep(obc_req_delay)
        self.obc_date_req()
        time.sleep(obc_req_delay)
        self.obc_outtemp_req()
        time.sleep(obc_req_delay)
        self.obc_cons1_req()
        time.sleep(obc_req_delay)
        self.obc_cons2_req()
        time.sleep(obc_req_delay)
        self.obc_range_req()
        time.sleep(obc_req_delay)
        self.obc_dist_req()
        time.sleep(obc_req_delay)
        self.obc_arr_req()
        time.sleep(obc_req_delay)
        self.obc_limit_req()
        time.sleep(obc_req_delay)
        self.obc_avg_req()
        time.sleep(obc_req_delay)
        self.obc_stpwtch_req()
        time.sleep(obc_req_delay)
        self.obc_tmr1_req()
        time.sleep(obc_req_delay)
        self.obc_tmr2_req()
        time.sleep(obc_req_delay)
        self.obc_coolant_req()
        time.sleep(obc_req_delay)
        self.obc_ind_req()
        time.sleep(obc_req_delay)
        self.obc_voltage_req()
        time.sleep(obc_req_delay)
        self.ews_key_req()
        time.sleep(obc_req_delay)
        self.obc_vin_req()
        time.sleep(obc_req_delay)
        self.obc_odometer_req()
        self.obc_req_runs = False

    def obc_time_req(self):
        IBUS.write_bus_packet(59, 128, [65, 1, 1])

    def obc_time_put(self, dat, UTC = False):
        self.obc_settime += 1
        hexstring = dat
        clock = ''
        if hexstring[3] == 32:
            clock = '0'
        else:
            clock = chr(hexstring[3])
        clock = clock + chr(hexstring[4]) + chr(hexstring[5]) + chr(hexstring[6]) + chr(hexstring[7])
        clock = clock + ':00'
        if hexstring[8] != 32:
            clock = clock + chr(hexstring[8]) + chr(hexstring[9])
        curhh, curmm, curss = os.popen('date +%T').readline().strip().split(':')
        newhh, newmm, newss = clock.split(':')
        log('OBC CUR HH: %s' % curhh, 3)
        log('OBC NEW HH: %s' % newhh, 3)
        log('OBC CUR MM: %s' % curmm, 3)
        log('OBC NEW HH: %s' % newmm, 3)
        if self.obc_settime > 2 and curhh == newhh and abs(int(curmm) - int(newmm)) < 2 and self.obc_time[1] == chr(hexstring[8]) + chr(hexstring[9]):
            self.obc_settime = 3
            log('OBC: TIME: ' + clock + ' - no update requiered')
            return
        if newhh == '--' or newmm == '--':
            log('OBC: BAD TIME: ' + clock)
            return
        log('OBC: SET SYSTEM TIME: ' + clock)
        f = os.popen('sudo date +%T%p -s "' + clock + '"')
        self.obc_time = [clock, chr(hexstring[8]) + chr(hexstring[9])]
        time.sleep(0.1)

    def obc_time_get(self):
        return self.obc_time[0]

    def obc_date_req(self):
        IBUS.write_bus_packet(59, 128, [65, 2, 1])

    def obc_date_put(self, dat):
        hexstring = dat[3:]
        if self.obc_date[1] == hexstring:
            log('OBC: DATE: ' + self.obc_date[0] + ' - no update requiered')
            return
        curtime = os.popen('date +%T').readline().strip()
        datestring = hex_to_asc(hexstring)
        if datestring.find('.') > 0:
            day, month, year = datestring.split('.')
        else:
            month, day, year = datestring.split('/')
        newdate = year + month + day
        if day == '--' or month == '--' or year == '----':
            log('OBC: BAD DATE: ' + newdate)
            return
        log('OBC: SET SYSTEM DATE: ' + newdate)
        f = os.popen('sudo date +%Y%m%d -s "' + newdate + '"')
        time.sleep(0.3)
        if self.obc_time[0]:
            f = os.popen('sudo date +%T -s "' + self.obc_time[0] + '"')
        time.sleep(0.1)
        self.obc_date = [datestring, hexstring]

    def obc_date_get(self):
        return self.obc_date[0]

    def obc_outtemp_req(self):
        IBUS.write_bus_packet(59, 128, [65, 3, 1])

    def obc_outtemp_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: SET OUT TEMP: ' + convstring)
        if KODI.get_addon_setting('home_temp') == 'OBC Outtemp':
            KODI.set_property('IBUSCOMMUNICATOR_OBC_OUTTEMP', convstring)
        self.obc_outtemp = convstring

    def obc_outtemp_get(self):
        return self.obc_outtemp

    def obc_cons1_req(self):
        IBUS.write_bus_packet(59, 128, [65, 4, 1])

    def obc_cons1_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: SET CONS1: ' + convstring)
        self.obc_cons1 = convstring

    def obc_cons1_reset(self):
        IBUS.write_bus_packet(59, 128, [65, 4, 16])

    def obc_cons1_get(self):
        return self.obc_cons1

    def obc_cons2_req(self):
        IBUS.write_bus_packet(59, 128, [65, 5, 1])

    def obc_cons2_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: SET CONS2: ' + convstring)
        self.obc_cons2 = convstring

    def obc_cons2_reset(self):
        IBUS.write_bus_packet(59, 128, [65, 5, 16])

    def obc_cons2_get(self):
        return self.obc_cons2

    def obc_range_req(self):
        IBUS.write_bus_packet(59, 128, [65, 6, 1])

    def obc_range_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: SET RANGE: ' + convstring)
        self.obc_range = convstring

    def obc_range_get(self):
        return self.obc_range

    def obc_dist_req(self):
        IBUS.write_bus_packet(59, 128, [65, 7, 1])

    def obc_dist_put(self, dat):
        hexstring = dat[3:]
        try:
            convstring = int(get_number(hex_to_asc(hexstring)))
        except:
            convstring = -10000

        log('OBC: SET DIST: %s' % ('----' if convstring < -9999 else convstring))
        if self.obc_dist != convstring:
            self.obc_dist = convstring
            if OBCGUI.isVisible():
                self.obc_odometer_req()

    def obc_dist_set(self, value):

        def bytes(num):
            return [num >> 8, num & 255]

        value = bytes(value)
        IBUS.write_bus_packet(59, 128, [64,
         7,
         value[0],
         value[1]])

    def obc_dist_reset(self):
        IBUS.write_bus_packet(59, 128, [64,
         7,
         0,
         0])

    def obc_dist_get(self):
        if self.obc_dist < -9999:
            return '---- KM'
        else:
            return '%s KM' % self.obc_dist

    def obc_arr_req(self):
        IBUS.write_bus_packet(59, 128, [65, 8, 1])

    def obc_arr_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: SET ARR: ' + convstring)
        self.obc_arr = convstring

    def obc_arr_get(self):
        return self.obc_arr

    def obc_avg_req(self):
        IBUS.write_bus_packet(59, 128, [65, 10, 1])

    def obc_avg_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: SET AVG: ' + convstring)
        self.obc_avg = convstring

    def obc_avg_reset(self):
        IBUS.write_bus_packet(59, 128, [65, 10, 16])

    def obc_avg_get(self):
        return self.obc_avg

    def obc_stpwtch_req(self):
        IBUS.write_bus_packet(59, 128, [65, 14, 1])

    def obc_stpwtch_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: SET STPWTCH: ' + convstring)
        self.obc_stpwtch = convstring

    def obc_stpwtch_reset(self):
        IBUS.write_bus_packet(59, 128, [65,
         14,
         16,
         16])

    def obc_stpwtch_get(self):
        return self.obc_stpwtch

    def obc_tmr1_req(self):
        IBUS.write_bus_packet(59, 128, [65, 15, 1])

    def obc_tmr1_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: SET TMR1: ' + convstring)
        self.obc_tmr1 = convstring

    def obc_tmr1_set(self, value):
        IBUS.write_bus_packet(59, 128, [65, 9, 1])

    def obc_tmr1_reset(self):
        if '--:--' not in self.obc_tmr1:
            IBUS.write_bus_packet(59, 128, [64,
             15,
             255,
             255])
            self.obc_tmr1_enable(False)

    def obc_tmr1_enable(self, state):
        if state:
            if '--:--' not in self.obc_tmr1:
                IBUS.write_bus_packet(59, 128, [65, 15, 4])
        else:
            IBUS.write_bus_packet(59, 128, [65, 15, 8])

    def obc_tmr1_get(self):
        return self.obc_tmr1

    def obc_tmr1_get_ind(self):
        return self.obc_tmr1ind

    def obc_tmr2_req(self):
        IBUS.write_bus_packet(59, 128, [65, 16, 1])

    def obc_tmr2_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: SET TMR2: ' + convstring)
        self.obc_tmr2 = convstring

    def obc_tmr2_set(self, value):
        IBUS.write_bus_packet(59, 128, [65, 9, 1])

    def obc_tmr2_reset(self):
        if '--:--' not in self.obc_tmr2:
            IBUS.write_bus_packet(59, 128, [64,
             16,
             255,
             255])
            self.obc_tmr2_enable(False)

    def obc_tmr2_enable(self, state):
        if state:
            if '--:--' not in self.obc_tmr2:
                IBUS.write_bus_packet(59, 128, [65, 16, 4])
        else:
            IBUS.write_bus_packet(59, 128, [65, 16, 8])

    def obc_tmr2_get(self):
        return self.obc_tmr2

    def obc_tmr2_get_ind(self):
        return self.obc_tmr2ind

    def obc_auxventheat_label(self):
        return '[COLOR FFFF7E00]     STANDL\xc3\x9cFTUNG / -HEIZUNG[/COLOR]'

    def obc_auxvent_req(self):
        pass

    def obc_auxvent_enable(self, state):
        if state:
            IBUS.write_bus_packet(59, 128, [65, 20])
        else:
            IBUS.write_bus_packet(59, 128, [65, 19])

    def obc_auxvent_get_ind(self):
        return self.ike_states['aux_vent']

    def obc_auxheat_req(self):
        pass

    def obc_auxheat_enable(self, state):
        if not KODI.dialog_yesno(label1='!! AUX-HEATING !!', label2='Do you really have an AUX-HEAT', label3='System in your Car?', nolabel='CANCEL', yeslabel='AUX-HEAT %s' % ('ON' if state else 'OFF'), autoclose=5000):
            log('CANCEL AUX-HEAT')
            return
        if state:
            IBUS.write_bus_packet(59, 128, [65, 18])
        else:
            IBUS.write_bus_packet(59, 128, [65, 17])

    def obc_auxheat_get_ind(self):
        return self.ike_states['aux_heat']

    def obc_ind_req(self):
        IBUS.write_bus_packet(59, 128, [65, 9, 2])

    def obc_ind_put(self, dat):
        xx = dat[1]
        yy = dat[2]
        memoind = get_bit_from_hex(xx, BIT[5])
        limitind = get_bit_from_hex(xx, BIT[1])
        tmr1ind = get_bit_from_hex(yy, BIT[2])
        tmr2ind = get_bit_from_hex(yy, BIT[4])
        if self.obc_memoind != memoind:
            self.obc_memoind = memoind
            log('OBC: SET MEMO IND: %s' % memoind)
        if self.obc_limitind != limitind:
            self.obc_limitind = limitind
            log('OBC: SET LIMIT IND: %s' % limitind)
        if self.obc_tmr1ind != tmr1ind:
            self.obc_tmr1ind = tmr1ind
            log('OBC: SET TIMER1 IND: %s' % tmr1ind)
        if self.obc_tmr2ind != tmr2ind:
            self.obc_tmr2ind = tmr2ind
            log('OBC: SET TIMER2 IND: %s' % tmr2ind)

    def obc_limit_req(self):
        IBUS.write_bus_packet(59, 128, [65, 9, 1])

    def obc_limit_set(self, value = None):
        if not value:
            IBUS.write_bus_packet(59, 128, [65, 9, 32])
        else:

            def bytes(num):
                return [num >> 8, num & 255]

            value = bytes(value)
            IBUS.write_bus_packet(59, 128, [64,
             9,
             value[0],
             value[1]])

    def obc_limit_reset(self):
        IBUS.write_bus_packet(59, 128, [64,
         9,
         255,
         255])
        self.obc_limit_enable(False)

    def obc_limit_enable(self, state):
        if state:
            IBUS.write_bus_packet(59, 128, [65, 9, 4])
        else:
            IBUS.write_bus_packet(59, 128, [65, 9, 8])

    def obc_limit_put(self, dat):
        hexstring = dat[3:]
        try:
            convstring = int(get_number(hex_to_asc(hexstring)))
        except:
            convstring = -1

        log('OBC: SET LIMIT: %s' % ('---' if convstring < 0 else convstring))
        self.obc_limit = convstring

    def obc_limit_get(self):
        if self.obc_limit < 0:
            return '--- KM/H'
        else:
            return '%s KM/H' % self.obc_limit

    def obc_limit_get_ind(self):
        return self.obc_limitind

    def obc_memo_req(self):
        IBUS.write_bus_packet(59, 128, [65, 12, 1])

    def obc_memo_enable(self, state):
        if state:
            IBUS.write_bus_packet(59, 128, [65, 12, 7])
        else:
            IBUS.write_bus_packet(59, 128, [65, 12, 8])

    def obc_memo_get_ind(self):
        return self.obc_memoind

    def obc_coolant_req(self):
        IBUS.write_bus_packet(91, 128, [29])

    def obc_coolant_put(self, dat):
        tmp = dat[2]
        if tmp > 128:
            coolanttemp = tmp - 256
        else:
            coolanttemp = tmp
        log('OBC: SET COOLANT TEMP: %s' % coolanttemp)
        if KODI.get_addon_setting('home_temp') == 'Coolant Temp':
            KODI.set_property('IBUSCOMMUNICATOR_OBC_OUTTEMP', '%s%s\xc2\xb0C' % ('+' if coolanttemp > 0 else '', coolanttemp))
        self.obc_coolant = coolanttemp
        tmp = dat[1]
        if tmp > 128:
            outtemp = tmp - 256
        else:
            outtemp = tmp
        log('OBC: SET IKE OUT TEMP: %s' % outtemp)
        if KODI.get_addon_setting('home_temp') == 'IKE Outtemp':
            KODI.set_property('IBUSCOMMUNICATOR_OBC_OUTTEMP', '%s%s\xc2\xb0C' % ('+' if coolanttemp > 0 else '', outtemp))

    def obc_coolant_get(self):
        return '%s%s\xc2\xb0C' % ('+' if self.obc_coolant > 0 else '', self.obc_coolant)

    def obc_coolant_get_gauge(self):
        temp = self.obc_coolant
        if temp <= 18:
            angle = 101
        elif 18 < temp < 75:
            angle = 101 + (temp - 18) * 79 / 57
        elif 75 <= temp <= 100:
            angle = 180
        elif 100 < temp < 125:
            angle = 180 + (temp - 100) * 79 / 25
        elif temp >= 125:
            angle = 259
        angle = '%s' % angle
        while len(angle) < 3:
            angle = '0%s' % angle

        return os.path.join(ADDONGAUGEPATH, 'grad', 'IBusOBCGAUGE_pin_%s.png' % angle)

    def obc_vin_req(self):
        IBUS.write_bus_packet(128, 208, [83])

    def obc_vin_put(self, dat):
        vin = chr(dat[1]) + chr(dat[2]) + '%02X' % dat[3] + '%02X' % dat[4] + ('%02X' % dat[5])[0]
        if vin != self.obc_vin:
            self.obc_vin = vin
        log('OBC: SET VIN: %s' % vin)

    def obc_vin_get(self):
        return '%s' % self.obc_vin

    def nav_position_req(self):
        IBUS.write_bus_packet(200, 127, [161, 0])

    def nav_location_req(self):
        IBUS.write_bus_packet(200, 127, [163, 0])

    def nav_position_put(self, dat):
        self.nav_states['gpsfix'] = bool(dat[1])
        self.nav_states['latitude'] = '%02X\xc2\xb0%02X\'%02X.%s"%s' % (dat[3],
         dat[4],
         dat[5],
         ('%02X' % dat[6])[0],
         'S' if dat[6] & 15 == 1 else 'N')
        self.nav_states['longitude'] = '%02X\xc2\xb0%02X\'%02X.%s"%s' % (dat[8],
         dat[9],
         dat[10],
         ('%02X' % dat[11])[0],
         'W' if dat[11] & 15 == 1 else 'E')
        self.nav_states['altitude'] = int('%02X%02X' % (dat[12], dat[13]))
        self.nav_states['time'] = '%02X:%02X:%02X' % (dat[15], dat[16], dat[17])
        log('NAV: GPSFIX: %s' % self.nav_states['gpsfix'])
        log('NAV: LATITUDE: %s' % self.nav_states['latitude'])
        log('NAV: LONGITUDE: %s' % self.nav_states['longitude'])
        log('NAV: ALTITUDE: %s m' % self.nav_states['altitude'])
        log('NAV: TIME: %s UTC' % self.nav_states['time'])

    def nav_location_put(self, dat):
        if dat[2] == 1:
            self.nav_states['town'] = hex_to_asc(dat[3:])
            log('NAV: TOWN: %s' % self.nav_states['town'])
        elif dat[2] == 2:
            self.nav_states['street'] = hex_to_asc(dat[3:]).replace(';', '')
            log('NAV: STREET: %s' % self.nav_states['street'])

    def nav_gpsfix_get(self):
        return self.nav_states['gpsfix']

    def nav_latitude_get(self):
        return self.nav_states['latitude']

    def nav_longitude_get(self):
        return self.nav_states['longitude']

    def nav_altitude_get(self):
        return '%s m' % self.nav_states['altitude']

    def nav_time_get(self):
        return '%s UTC' % self.nav_states['time']

    def nav_town_get(self):
        return self.nav_states['town']

    def nav_street_get(self):
        return self.nav_states['street']

    def obc_odometer_req(self):
        IBUS.write_bus_packet(191, 128, [22])

    def obc_odometer_put(self, dat):
        odometer = dat[3] << 16 | dat[2] << 8 | dat[1]
        if odometer != self.obc_odometer:
            self.obc_odometer = odometer
        log('OBC: SET ODOMETER: %s KM' % odometer)

    def obc_odometer_get(self):
        return '%s KM' % self.obc_odometer

    def obc_voltage_req(self):
        IBUS.write_bus_packet(63, 127, [11])

    def obc_voltage_put(self, dat):
        if len(dat) < 2:
            return
        voltage = round(float(dat[13] << 8 | dat[14]) / 1000, 1)
        if voltage != self.obc_voltage:
            self.obc_voltage = voltage
        log('OBC: SET VOLTAGE: %s' % voltage)

    def obc_voltage_get(self):
        return '%s V' % self.obc_voltage

    def obc_speed_rpm_put(self, dat):
        speed_kmh = dat[1] * 2
        speed_mph = int(speed_kmh * 0.6214)
        if speed_kmh >= self.zv_auto_lock_speed and self.zv_auto_lock and not self.gm_states['zvlockstate'] and not self.ike_states['handbrake']:
            self.gm_zv_lock()
        self.nav_zoom(speed_kmh)
        if speed_kmh != self.obc_speed_kmh:
            self.obc_speed_kmh = speed_kmh
            self.obc_speed_mph = speed_mph
        rpm = dat[2] * 100
        if rpm != self.obc_rpm:
            self.obc_rpm = rpm
        log('OBC: SET SPEED KMH - MPH: %s - %s' % (speed_kmh, speed_mph))
        log('OBC: SET SPEED rpm: %s' % rpm)

    def obc_speed_get(self, mph = False):
        if not mph:
            return '%s KM/H' % self.obc_speed_kmh
        else:
            return '%s MPH' % self.obc_speed_mph

    def obc_speed_get_gauge(self):
        return get_pin_pos_img(self.obc_speed_kmh, 260, 34, 326, 45, 315)

    def obc_rpm_get(self):
        return '%s min\xcb\x89\xc2\xb9' % self.obc_rpm

    def obc_rpm_get_gauge(self):
        return get_pin_pos_img(self.obc_rpm, 7000, 40, 320)

    def obc_fuellevel_get(self):
        return '%s%s L' % ('R ' if self.obc_fuellevel_low else '', self.obc_fuellevel)

    def obc_key_get(self):
        if self.obc_inserted_key > -1:
            return 'IN: %s' % self.obc_inserted_key
        else:
            return 'OUT'

    def obc_open_gui(self):
        if xbmcgui.getCurrentWindowDialogId() == 10140:
            KODI.back()
        if OBCGUI.isActive and xbmcgui.getCurrentWindowId() == 13000:
            OBCGUI.onStop()
        elif OBCGUI.isActive:
            OBCGUI.onStop()
            OBCGUI.show()
        else:
            OBCGUI.show()


def log(string, lvl = 1):
    thread = Thread(target=KODI.log, args=(string, lvl))
    thread.setDaemon(True)
    thread.start()


def note(heading, message = None, time = 5000):
    thread = Thread(target=KODI.note, args=(heading, message, time))
    thread.setDaemon(True)
    thread.start()


def dialog_ok(label1, label2 = None, label3 = None):
    thread = Thread(target=KODI.dialog_ok, args=(label1, label2, label3))
    thread.setDaemon(True)
    thread.start()


def get_number(text):
    text = text.replace(',', '.')
    return float(findall('[+-]? *(?:\\d+(?:\\.\\d*)?|\\.\\d+)(?:[eE][+-]?\\d+)?', text)[0])


def get_bit_from_hex(value, bit):
    output = bin(value)[2:].zfill(8)
    if int(output[bit]) == 1:
        return True
    return False


def set_bit_in_hex(hex, bit, value):
    temp = bin(hex)[2:].zfill(8)
    output = list(temp)
    output[bit] = '1' if value else '0'
    return int(''.join(output), 2)


def asc_to_hex(text):
    text = _encode_ibus_chars(text)
    return [ ord(l) for l in text ]


def hex_to_asc(in_hex):
    out_hex = [ chr(l) for l in in_hex ]
    return _decode_ibus_chars(''.join(out_hex))


def _encode_ibus_chars(text):
    letters = {'\xc3\x9f': chr(160),
     '\xc3\x84': chr(161),
     '\xc3\x96': chr(162),
     '\xc3\x9c': chr(163),
     '\xc3\xa4': chr(164),
     'a\xcc\x88': chr(164),
     '\xc3\xb6': chr(165),
     'o\xcc\x88': chr(165),
     '\xc3\xbc': chr(166),
     'u\xcc\x88': chr(166),
     '\xc2\xb0': chr(168),
     '\xc2\xb4': chr(39),
     '\xc3\xba': 'u'}
    for l in letters:
        text = text.replace(l, letters[l])

    return text


def _decode_ibus_chars(text):
    text = text.replace(chr(160), '\xc3\x9f')
    text = text.replace(chr(161), '\xc3\x84')
    text = text.replace(chr(162), '\xc3\x96')
    text = text.replace(chr(163), '\xc3\x9c')
    text = text.replace(chr(164), '\xc3\xa4')
    text = text.replace(chr(165), '\xc3\xb6')
    text = text.replace(chr(166), '\xc3\xbc')
    text = text.replace(chr(168), '\xc2\xb0')
    text = text.replace(chr(220), '\xc3\x9c')
    text = text.replace(chr(39), '\xc2\xb4')
    text = text.replace(chr(0), '')
    text = text.decode('iso-8859-1').encode('latin1')
    return text


def translate(value, leftMin, leftMax, rightMin, rightMax):
    leftSpan = leftMax - leftMin
    rightSpan = rightMax - rightMin
    valueScaled = float(value - leftMin) / float(leftSpan)
    result = rightMin + valueScaled * rightSpan
    if result < rightMin:
        result = rightMin
    if result > rightMax:
        result = rightMax
    return result


def time_now_in_range(time1, time2):
    try:
        now = datetime.datetime.now()
        time_now = datetime.datetime.strptime('%s:%s' % (now.hour, now.minute), '%H:%M')
        if 'AM' in time1.upper() or 'PM' in time1.upper():
            time_start = datetime.datetime.strptime(time1, '%I:%M %p')
        else:
            time_start = datetime.datetime.strptime(time1, '%H:%M')
        if 'AM' in time2.upper() or 'PM' in time2.upper():
            time_end = datetime.datetime.strptime(time2, '%I:%M %p')
        else:
            time_end = datetime.datetime.strptime(time2, '%H:%M')
        if time_start == time_end:
            return False
        if time_start < time_end:
            if time_start <= time_now < time_end:
                return True
            else:
                return False
        else:
            if time_now >= time_start or time_now < time_end:
                return True
            return False
    except:
        log('time 1 or 2 error')
        return False


def get_pin_pos_img(value, value_range, start_angle, end_angle, min_angle = None, max_angle = None):
    if not min_angle:
        min_angle = start_angle
    if not max_angle:
        max_angle = end_angle
    angle = start_angle + value * (end_angle - start_angle) / value_range
    if angle <= min_angle:
        angle = min_angle
    elif angle >= max_angle:
        angle = max_angle
    angle = '%s' % angle
    while len(angle) < 3:
        angle = '0%s' % angle

    return os.path.join(ADDONGAUGEPATH, 'grad', 'IBusOBCGAUGE_pin_%s.png' % angle)


def handle_extern_events():
    serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    serversocket.bind(('localhost', EVENT.tcp_port))
    serversocket.listen(1)
    serversocket.settimeout(1)
    while not xbmc.abortRequested:
        try:
            connection, address = serversocket.accept()
        except socket.timeout:
            continue

        message = connection.recv(100).upper()
        given_args = message.split(';')
        if given_args[0] == 'OBC':
            connection.send('OK\n\n')
            log('TCP %s: RECV >OBC<' % EVENT.tcp_port)
            thread = Thread(target=EVENT.obc_open_gui)
            thread.setDaemon(True)
            thread.start()
        elif given_args[0] == 'SENDIBUS':
            if EVENT.tcp_send_ibus:
                try:
                    IBUS.write_hex_message(given_args[1])
                    connection.send('IBUSCOMMUNICATOR: >%s< sent to IBus\n\n' % given_args[1])
                    log('TCP %s: >%s< sent to IBus' % (EVENT.tcp_port, given_args[1]))
                    note('Sent IBus-Message from TCP Port', '%s' % given_args[1], len(given_args[1]) * 100)
                except:
                    connection.send('IBUSCOMMUNICATOR: >%s< ERROR not sent to IBus\n\n' % given_args[1])
                    log('TCP %s: >%s< not sent to IBus' % (EVENT.tcp_port, given_args[1]))

            else:
                connection.send('IBUSCOMMUNICATOR: send to IBus not enabled\n\n')
                log('TCP %s: send to IBus not enabled' % EVENT.tcp_port)
        elif given_args[0] == 'SIMULATEIBUS':
            EVENT.simulate_ibus_packages(given_args[1])
            connection.send('IBUSCOMMUNICATOR: >%s< simulate\n\n' % given_args[1])
            log('TCP %s: >%s< simulate' % (EVENT.tcp_port, given_args[1]))
            note('Simulate IBus Message from TCP Port', '%s' % given_args[1], len(given_args[1]) * 100)
        else:
            connection.send('IBUSCOMMUNICATOR: unknown Command >%s< recieved\n\n' % message)
            log('TCP %s: unknown Command >%s< recieved' % (EVENT.tcp_port, message))
        connection.close()

    serversocket.close()
    log('TCP 8089: CLOSED')


def load_settings(settings_changed = False):
    cdc_emu_tmp = EVENT.cdc_emu
    gpio_ntsc_tmp = EVENT.gpio_ntsc
    gpio_rearcam_tmp = EVENT.gpio_rearcam
    gpio_gear_shift_tmp = EVENT.gpio_gear_shift
    gpio_gear_shift_up_tmp = EVENT.gpio_gear_shift_up
    gpio_gear_shift_down_tmp = EVENT.gpio_gear_shift_down
    log_to_kodi_tmp = KODI.log_to_kodi
    KODI.log_to_kodi = KODI.get_addon_setting('log_to_kodi')
    if log_to_kodi_tmp != KODI.log_to_kodi:
        if not KODI.log_to_kodi:
            KODI.ibuslogger = Logger(EXTLOGFILEPATH)
            KODI.ibusdatalogger = Logger(EXTERNIBUSLOGFILEFULLPATH)
    log('SETTINGS: LOAD: LOG_TO_KODI=%s' % KODI.log_to_kodi)
    EVENT.device_path = KODI.get_addon_setting('ser_dev')
    log('SETTINGS: LOAD: DEVICE_PATH=%s' % EVENT.device_path)
    EVENT.cdc_emu = KODI.get_addon_setting('cdc_emu')
    piaudiomode = KODI.get_addon_setting('audio_mode')
    EVENT.modefm = False
    EVENT.modecd = False
    EVENT.modecd53 = False
    EVENT.modetape = False
    EVENT.modeaux = False
    EVENT.modecis = False
    EVENT.modealways = False
    EVENT.cdc_disc = 7
    EVENT.cdc_loaded = 64
    if piaudiomode == 'CD':
        EVENT.modecd = True
        EVENT.cdc_emu = True
        log('SETTINGS: LOAD: AUDIOMODE=CD')
    elif piaudiomode == 'TAPE':
        EVENT.modetape = True
        log('SETTINGS: LOAD: AUDIOMODE=TAPE')
    elif piaudiomode == 'AUX':
        EVENT.modeaux = True
        log('SETTINGS: LOAD: AUDIOMODE=AUX')
    elif piaudiomode == 'CIS':
        EVENT.modecis = True
        EVENT.cdc_emu = False
        log('SETTINGS: LOAD: AUDIOMODE=CIS')
    elif piaudiomode == 'ALWAYS':
        EVENT.modealways = True
        log('SETTINGS: LOAD: AUDIOMODE=ALWAYS')
    elif piaudiomode == 'CD53':
        EVENT.modecd53 = True
        EVENT.cdc_emu = True
        EVENT.cdc_disc = 6
        EVENT.cdc_loaded = 32
        log('SETTINGS: LOAD: AUDIOMODE=CD53')
    log('SETTINGS: LOAD: CDC_EMU=%s' % EVENT.cdc_emu)
    EVENT.car_model = KODI.get_addon_setting('car_model')
    log('SETTINGS: LOAD: CAR_MODEL=%s' % EVENT.car_model)
    if EVENT.car_model in ('E38', 'E39', 'E53'):
        EVENT.car_model = 'E39'
        log('SETTINGS: LOAD: CAR_MODEL-LIGHTMODUL=LCM')
    elif EVENT.car_model in ('E46', 'E83', 'E85'):
        EVENT.car_model = 'E46'
        log('SETTINGS: LOAD: CAR_MODEL-LIGHTMODUL=LSZ')
    else:
        EVENT.car_model = 'E39'
    EVENT.tcp_port = int(KODI.get_addon_setting('tcp_port'))
    log('SETTINGS: LOAD: TCP_PORT=%s' % EVENT.tcp_port)
    EVENT.tcp_send_ibus = KODI.get_addon_setting('tcp_send_ibus')
    log('SETTINGS: LOAD: TCP_SEND_IBUS=%s' % EVENT.tcp_send_ibus)
    EVENT.dsp_cd = KODI.get_addon_setting('dsp_cd')
    EVENT.dsp_tuner = KODI.get_addon_setting('dsp_tuner')
    if EVENT.dsp_tuner:
        EVENT.dsp_cd = False
    if not EVENT.modecd:
        EVENT.dsp_tuner = False
    log('SETTINGS: LOAD: DSP_CD=%s' % EVENT.dsp_cd)
    log('SETTINGS: LOAD: DSP_TUNER=%s' % EVENT.dsp_tuner)
    EVENT.mir_unfold = KODI.get_addon_setting('mir_unfold')
    log('SETTINGS: LOAD: MIR_UNFOLD=%s' % EVENT.mir_unfold)
    EVENT.mir_fold = KODI.get_addon_setting('mir_fold')
    log('SETTINGS: LOAD: MIR_FOLD=%s' % EVENT.mir_fold)
    EVENT.welcome_on_boot = KODI.get_addon_setting('welcome_on_boot')
    log('SETTINGS: LOAD: WELCOME_ON_BOOT=%s' % EVENT.welcome_on_boot)
    EVENT.wel_light = KODI.get_addon_setting('wel_light')
    log('SETTINGS: LOAD: WEL_LIGHT=%s' % EVENT.wel_light)
    EVENT.wel_light_time = int(KODI.get_addon_setting('wel_light_time'))
    log('SETTINGS: LOAD: WEL_LIGHT_TIME=%s' % EVENT.wel_light_time)
    EVENT.lev_light = KODI.get_addon_setting('lev_light')
    log('SETTINGS: LOAD: LEV_LIGHT=%s' % EVENT.lev_light)
    EVENT.lev_light_time = int(KODI.get_addon_setting('lev_light_time'))
    log('SETTINGS: LOAD: LEV_LIGHT_TIME=%s' % EVENT.lev_light_time)
    EVENT.keyin_off = KODI.get_addon_setting('keyin_off')
    log('SETTINGS: LOAD: KEYIN_OFF=%s' % EVENT.keyin_off)
    EVENT.lev_light_ign_off = KODI.get_addon_setting('lev_light_ign_off')
    log('SETTINGS: LOAD: LEV_LIGHT_IGN_OFF=%s' % EVENT.lev_light_ign_off)
    EVENT.doors_off = KODI.get_addon_setting('doors_off')
    log('SETTINGS: LOAD: DOORS_OFF=%s' % EVENT.doors_off)
    EVENT.day_time = KODI.get_addon_setting('day_time')
    log('SETTINGS: LOAD: DAY_TIME=%s' % EVENT.day_time)
    EVENT.day_time_start = KODI.get_addon_setting('day_time_start')
    log('SETTINGS: LOAD: DAY_TIME_START=%s' % EVENT.day_time_start)
    EVENT.day_time_end = KODI.get_addon_setting('day_time_end')
    log('SETTINGS: LOAD: DAY_TIME_END=%s' % EVENT.day_time_end)
    EVENT.wel_light_park = KODI.get_addon_setting('wel_light_park')
    log('SETTINGS: LOAD: WEL_LIGHT_PARK=%s' % EVENT.wel_light_park)
    EVENT.wel_light_low = KODI.get_addon_setting('wel_light_low')
    log('SETTINGS: LOAD: WEL_LIGHT_LOW=%s' % EVENT.wel_light_low)
    EVENT.wel_light_fog = KODI.get_addon_setting('wel_light_fog')
    log('SETTINGS: LOAD: WEL_LIGHT_FOG=%s' % EVENT.wel_light_fog)
    EVENT.wel_light_nbrplate = KODI.get_addon_setting('wel_light_nbrplate')
    log('SETTINGS: LOAD: WEL_LIGHT_NBRPLATE=%s' % EVENT.wel_light_nbrplate)
    EVENT.wel_light_turn_front = KODI.get_addon_setting('wel_light_turn_front')
    log('SETTINGS: LOAD: WEL_LIGHT_TURN_FRONT=%s' % EVENT.wel_light_turn_front)
    EVENT.wel_light_turn_back = KODI.get_addon_setting('wel_light_turn_back')
    log('SETTINGS: LOAD: WEL_LIGHT_TURN_BACK=%s' % EVENT.wel_light_turn_back)
    EVENT.ike_display = KODI.get_addon_setting('ike_disp')
    log('SETTINGS: LOAD: IKE_DISP=%s' % EVENT.ike_display)
    EVENT.ike_track = KODI.get_addon_setting('ike_track')
    log('SETTINGS: LOAD: IKE_TRACK=%s' % EVENT.ike_track)
    EVENT.wel_ike = KODI.get_addon_setting('wel_ike')
    log('SETTINGS: LOAD: WEL_IKE=%s' % EVENT.wel_ike)
    EVENT.wel_iketxt = KODI.get_addon_setting('wel_iketxt')
    log('SETTINGS: LOAD: WEL_IKETXT=%s' % EVENT.wel_iketxt)
    EVENT.wel_iketxt_hold = KODI.get_addon_setting('wel_iketxt_hold')
    log('SETTINGS: LOAD: WEL_IKETXT_HOLD=%s' % EVENT.wel_iketxt_hold)
    EVENT.text_scrollspeed = int(KODI.get_addon_setting('text_scrollspeed'))
    log('SETTINGS: LOAD: TEXT_SCROLLSPEED=%s' % EVENT.text_scrollspeed)
    EVENT.seek_sec = int(float(KODI.get_addon_setting('seek_sec')) * 1000)
    log('SETTINGS: LOAD: SEEK_SEC=%s' % EVENT.seek_sec)
    EVENT.seek_max = int(KODI.get_addon_setting('seek_max'))
    log('SETTINGS: LOAD: SEEK_MAX=%s' % EVENT.seek_max)
    EVENT.navhold_event = KODI.get_addon_setting('navhold_event')
    log('SETTINGS: LOAD: NAVHOLD_EVENT=%s' % EVENT.navhold_event)
    EVENT.inv_navturnbtn = KODI.get_addon_setting('inv_navturnbtn')
    log('SETTINGS: LOAD: INV_NAVTURNBTN=%s' % EVENT.inv_navturnbtn)
    setting = int(KODI.get_addon_setting('stw_rt_event'))
    if setting == 2:
        EVENT.use_stw_nav = True
        EVENT.nav_toggle_map = False
    elif setting == 1:
        EVENT.use_stw_nav = False
        EVENT.nav_toggle_map = True
    else:
        EVENT.use_stw_nav = False
        EVENT.nav_toggle_map = False
    log('SETTINGS: LOAD: USE_STW_NAV=%s' % EVENT.use_stw_nav)
    if not EVENT.use_stw_nav:
        EVENT.stw_nav = False
    log('SETTINGS: LOAD: NAV_TOGGLE_MAP=%s' % EVENT.nav_toggle_map)
    EVENT.gpio_ntsc = KODI.get_addon_setting('gpio_ntsc')
    log('SETTINGS: LOAD: GPIO_NTSC=%s' % EVENT.gpio_ntsc)
    EVENT.gpio_ntsc_on = int(KODI.get_addon_setting('gpio_ntsc_on'))
    log('SETTINGS: LOAD: GPIO_NTSC_ON=%s' % EVENT.gpio_ntsc_on)
    EVENT.gpio_gear_shift = int(KODI.get_addon_setting('gpio_gear_shift'))
    log('SETTINGS: LOAD: GPIO_GEAR_SHIFT=%s' % EVENT.gpio_gear_shift)
    EVENT.gpio_gear_shift_trigger_time = float(KODI.get_addon_setting('gpio_gear_shift_trigger_time')) / 1000
    log('SETTINGS: LOAD: GPIO_GEAR_SHIFT_TRIGGER_TIME=%s' % EVENT.gpio_gear_shift_trigger_time)
    EVENT.gpio_gear_shift_up = int(KODI.get_addon_setting('gpio_gear_shift_up'))
    log('SETTINGS: LOAD: GPIO_GEAR_SHIFT_UP=%s' % EVENT.gpio_gear_shift_up)
    EVENT.gpio_gear_shift_down = int(KODI.get_addon_setting('gpio_gear_shift_down'))
    log('SETTINGS: LOAD: GPIO_GEAR_SHIFT_DOWN=%s' % EVENT.gpio_gear_shift_down)
    EVENT.gpio_rearcam = KODI.get_addon_setting('gpio_rearcam')
    log('SETTINGS: LOAD: GPIO_REARCAM=%s' % EVENT.gpio_rearcam)
    EVENT.gpio_rearcam_on = int(KODI.get_addon_setting('gpio_rearcam_on'))
    log('SETTINGS: LOAD: GPIO_REARCAM_ON=%s' % EVENT.gpio_rearcam_on)
    EVENT.gpio_rearcam_off = int(KODI.get_addon_setting('gpio_rearcam_off'))
    log('SETTINGS: LOAD: GPIO_REARCAM_OFF=%s' % EVENT.gpio_rearcam_off)
    EVENT.gpio_rearcam_timeout = int(KODI.get_addon_setting('gpio_rearcam_timeout'))
    log('SETTINGS: LOAD: GPIO_REARCAM_TIMEOUT=%s' % EVENT.gpio_rearcam_timeout)
    EVENT.gpio_rearcam_speed = int(KODI.get_addon_setting('gpio_rearcam_speed'))
    log('SETTINGS: LOAD: GPIO_REARCAM_SPEED=%s' % EVENT.gpio_rearcam_speed)
    EVENT.comfort_blink = KODI.get_addon_setting('comfort_blink')
    log('SETTINGS: LOAD: COMFORT_BLINK=%s' % EVENT.comfort_blink)
    EVENT.comfort_blink_time = int(KODI.get_addon_setting('comfort_blink_time')) * 490
    log('SETTINGS: LOAD: COMFORT_BLINK_TIME=%s' % EVENT.comfort_blink_time)
    EVENT.turn_light = KODI.get_addon_setting('turn_light')
    log('SETTINGS: LOAD: TURN_LIGHT=%s' % EVENT.turn_light)
    EVENT.turn_light_time = int(KODI.get_addon_setting('turn_light_time')) * 1000
    log('SETTINGS: LOAD: TURN_LIGHT_TIME=%s' % EVENT.turn_light_time)
    EVENT.turn_light_max_speed = int(KODI.get_addon_setting('turn_light_max_speed'))
    log('SETTINGS: LOAD: TURN_LIGHT_MAX_SPEED=%s' % EVENT.turn_light_max_speed)
    EVENT.volume_sink_r = KODI.get_addon_setting('volume_sink_r')
    log('SETTINGS: LOAD: VOLUME_SINK_R=%s' % EVENT.volume_sink_r)
    EVENT.volume_sink_r_ibus = KODI.get_addon_setting('volume_sink_r_ibus')
    log('SETTINGS: LOAD: VOLUME_SINK_R_IBUS=%s' % EVENT.volume_sink_r_ibus)
    EVENT.volume_sink_r_value = int(KODI.get_addon_setting('volume_sink_r_value'))
    log('SETTINGS: LOAD: VOLUME_SINK_R_VALUE=%s' % EVENT.volume_sink_r_value)
    EVENT.volume_sink_r_value_ibus = int(KODI.get_addon_setting('volume_sink_r_value_ibus'))
    log('SETTINGS: LOAD: VOLUME_SINK_R_VALUE_IBUS=%s' % EVENT.volume_sink_r_value_ibus)
    EVENT.volume_sink_r_delay = int(KODI.get_addon_setting('volume_sink_r_delay'))
    log('SETTINGS: LOAD: VOLUME_SINK_R_DELAY=%s' % EVENT.volume_sink_r_delay)
    EVENT.volume_sink_r_speed = int(KODI.get_addon_setting('volume_sink_r_speed'))
    log('SETTINGS: LOAD: VOLUME_SINK_R_SPEED=%s' % EVENT.volume_sink_r_speed)
    EVENT.lcd_brightness = KODI.get_addon_setting('lcd_brightness')
    log('SETTINGS: LOAD: LCD_BRIGHTNESS=%s' % EVENT.lcd_brightness)
    EVENT.lcd_brightness_value_on = int(KODI.get_addon_setting('lcd_brightness_value_on'))
    log('SETTINGS: LOAD: LCD_BRIGHTNESS_VALUE_ON=%s' % EVENT.lcd_brightness_value_on)
    EVENT.lcd_brightness_value_off = int(KODI.get_addon_setting('lcd_brightness_value_off'))
    log('SETTINGS: LOAD: LCD_BRIGHTNESS_VALUE_OFF=%s' % EVENT.lcd_brightness_value_off)
    EVENT.pdc_on = KODI.get_addon_setting('pdc_on')
    log('SETTINGS: LOAD: PDC_ON=%s' % EVENT.pdc_on)
    EVENT.pdc_interval = float(KODI.get_addon_setting('pdc_interval')) / 1000
    log('SETTINGS: LOAD: PDC_INTERVAL=%s' % EVENT.pdc_interval)
    EVENT.pdc_type = int(KODI.get_addon_setting('pdc_type'))
    log('SETTINGS: LOAD: PDC_TYPE=%s' % ('REAR' if EVENT.pdc_type else 'FRONT + REAR'))
    EVENT.pdc_timeout = float(KODI.get_addon_setting('pdc_timeout'))
    log('SETTINGS: LOAD: PDC_TIMEOUT=%s' % EVENT.pdc_timeout)
    EVENT.pdc_timeout_off = KODI.get_addon_setting('pdc_timeout_off')
    log('SETTINGS: LOAD: PDC_TIMEOUT_OFF=%s' % EVENT.pdc_timeout_off)
    EVENT.pdc_bg = KODI.get_addon_setting('pdc_bg')
    log('SETTINGS: LOAD: PDC_BG=%s' % EVENT.pdc_bg)
    KODI.set_property('pdc_bg', os.path.splitext(os.path.basename(EVENT.pdc_bg))[0])
    EVENT.zv_auto_lock = KODI.get_addon_setting('zv_auto_lock')
    log('SETTINGS: LOAD: ZV_AUTO_LOCK=%s' % EVENT.zv_auto_lock)
    EVENT.zv_auto_lock_speed = int(KODI.get_addon_setting('zv_auto_lock_speed'))
    log('SETTINGS: LOAD: ZV_AUTO_LOCK_SPEED=%s' % EVENT.zv_auto_lock_speed)
    EVENT.zv_auto_unlock_handbrake = KODI.get_addon_setting('zv_auto_unlock_handbrake')
    log('SETTINGS: LOAD: ZV_AUTO_UNLOCK_HANDBRAKE=%s' % EVENT.zv_auto_unlock_handbrake)
    EVENT.zv_auto_unlock_ign1 = KODI.get_addon_setting('zv_auto_unlock_ign1')
    log('SETTINGS: LOAD: ZV_AUTO_UNLOCK_IGN1=%s' % EVENT.zv_auto_unlock_ign1)
    EVENT.zv_auto_unlock_gear_p = KODI.get_addon_setting('zv_auto_unlock_gear_p')
    log('SETTINGS: LOAD: ZV_AUTO_UNLOCK_GEAR_P=%s' % EVENT.zv_auto_unlock_gear_p)
    EVENT.zv_auto_unlock_door_open = KODI.get_addon_setting('zv_auto_unlock_door_open')
    log('SETTINGS: LOAD: ZV_AUTO_UNLOCK_DOOR_OPEN=%s' % EVENT.zv_auto_unlock_door_open)
    EVENT.map_auto_zoom = KODI.get_addon_setting('map_auto_zoom')
    log('SETTINGS: LOAD: MAP_AUTO_ZOOM=%s' % EVENT.map_auto_zoom)
    EVENT.map_auto_zoom_200 = int(KODI.get_addon_setting('map_auto_zoom_200'))
    log('SETTINGS: LOAD: MAP_AUTO_ZOOM_200=%s' % EVENT.map_auto_zoom_200)
    EVENT.map_auto_zoom_500 = int(KODI.get_addon_setting('map_auto_zoom_500'))
    log('SETTINGS: LOAD: MAP_AUTO_ZOOM_500=%s' % EVENT.map_auto_zoom_500)
    EVENT.map_auto_zoom_1000 = int(KODI.get_addon_setting('map_auto_zoom_1000'))
    log('SETTINGS: LOAD: MAP_AUTO_ZOOM_1000=%s' % EVENT.map_auto_zoom_1000)
    EVENT.map_auto_zoom_2000 = int(KODI.get_addon_setting('map_auto_zoom_2000'))
    log('SETTINGS: LOAD: MAP_AUTO_ZOOM_2000=%s' % EVENT.map_auto_zoom_2000)
    EVENT.map_auto_zoom_5000 = int(KODI.get_addon_setting('map_auto_zoom_5000'))
    log('SETTINGS: LOAD: MAP_AUTO_ZOOM_5000=%s' % EVENT.map_auto_zoom_5000)
    EVENT.flash_to_pass = KODI.get_addon_setting('flash_to_pass')
    log('SETTINGS: LOAD: FLASH_TO_PASS=%s' % EVENT.flash_to_pass)
    EVENT.flash_to_pass_low_beam = KODI.get_addon_setting('flash_to_pass_low_beam')
    log('SETTINGS: LOAD: FLASH_TO_PASS_LOW_BEAM=%s' % EVENT.flash_to_pass_low_beam)
    EVENT.flash_to_pass_fog = KODI.get_addon_setting('flash_to_pass_fog')
    log('SETTINGS: LOAD: FLASH_TO_PASS_FOG=%s' % EVENT.flash_to_pass_fog)
    EVENT.bm_sensor = KODI.get_addon_setting('bm_sensor')
    log('SETTINGS: LOAD: BM_SENSOR=%s' % EVENT.bm_sensor)
    EVENT.bm_sensor_level = int(KODI.get_addon_setting('bm_sensor_level'))
    log('SETTINGS: LOAD: BM_SENSOR_LEVEL=%s' % EVENT.bm_sensor_level)
    loglevel = int(KODI.get_addon_setting('log_lvl'))
    log('SETTINGS: LOAD: LOGLVL=%s' % loglevel, 0)
    KODI.log_level = loglevel
    if settings_changed:
        EVENT.radio_mode_get()
        EVENT.obc_coolant_req()
        EVENT.obc_outtemp_req()
        EVENT.lcm_get_state()
        if EVENT.gpio_ntsc and not gpio_ntsc_tmp:
            GPIO_NTSC.open(7, off_level=True)
            IBUS.ntsc = False
        elif not EVENT.gpio_ntsc:
            GPIO_NTSC.close()
        if EVENT.gpio_rearcam and not gpio_rearcam_tmp:
            GPIO_REARCAM.open(EVENT.gpio_rearcam_on, off_level=True)
        elif not EVENT.gpio_rearcam:
            GPIO_REARCAM.close()
        if EVENT.gpio_gear_shift > 0 and not gpio_gear_shift_tmp:
            GPIO_GEAR_SHIFT_UP.open(EVENT.gpio_gear_shift_up, off_level=True)
            GPIO_GEAR_SHIFT_DOWN.open(EVENT.gpio_gear_shift_down, off_level=True)
        if EVENT.gpio_gear_shift > 0 and gpio_gear_shift_tmp and EVENT.gpio_gear_shift_up != gpio_gear_shift_up_tmp:
            GPIO_GEAR_SHIFT_UP.open(EVENT.gpio_gear_shift_up, off_level=True)
        if EVENT.gpio_gear_shift > 0 and gpio_gear_shift_tmp and EVENT.gpio_gear_shift_down != gpio_gear_shift_down_tmp:
            GPIO_GEAR_SHIFT_DOWN.open(EVENT.gpio_gear_shift_down, off_level=True)
        if EVENT.cdc_emu and not cdc_emu_tmp:
            EVENT.cdch_init()


KODI = Kodi()
KODI.log_to_kodi = KODI.get_addon_setting('log_to_kodi')
if not KODI.log_to_kodi:
    KODI.ibuslogger = Logger(EXTLOGFILEPATH)
    KODI.ibusdatalogger = Logger(EXTERNIBUSLOGFILEFULLPATH)
PLAYER = PlayerClass()
OBCGUI = ObcGuiClass('OBC_SKIN.xml', ADDONPATH, 'Default', '720p')
MONITOR = MonitorClass()
IBUS = IBusFace()
EVENT = EventClass()
GPIO_NTSC = GPIOClass()
GPIO_GEAR_SHIFT_UP = GPIOClass()
GPIO_GEAR_SHIFT_DOWN = GPIOClass()
GPIO_REARCAM = GPIOClass()
DOUBLECLICKDELAY = 0.3
DBL_NEXT = Clicker(DOUBLECLICKDELAY, KODI.right, KODI.track_next)
DBL_PREV = Clicker(DOUBLECLICKDELAY, KODI.left, KODI.track_prev)
DBL_STW_SPEAK = Clicker(DOUBLECLICKDELAY, KODI.select, KODI.back)

def main():
    xbmc.log('IBUSCOMMUNICATOR: Service Started', xbmc.LOGNOTICE)
    log('VERSION: %s' % ADDONVERSION)
    load_settings()
    if EVENT.gpio_gear_shift > 0:
        GPIO_GEAR_SHIFT_UP.open(EVENT.gpio_gear_shift_up, off_level=True)
        GPIO_GEAR_SHIFT_UP.reset()
        GPIO_GEAR_SHIFT_DOWN.open(EVENT.gpio_gear_shift_down, off_level=True)
        GPIO_GEAR_SHIFT_DOWN.reset()
    if EVENT.gpio_ntsc:
        GPIO_NTSC.open(7, off_level=True)
        GPIO_NTSC.reset()
    if EVENT.gpio_rearcam:
        GPIO_REARCAM.open(EVENT.gpio_rearcam_on, off_level=True)
        GPIO_REARCAM.reset()
    log('IBUS: Connecting')
    IBUS.set_port(EVENT.device_path)
    try:
        IBUS.connect()
    except:
        note('IBUS: Error', 'IBus Connection failed')
        time.sleep(2)
        raise

    thread = Thread(target=handle_extern_events)
    thread.setDaemon(True)
    thread.start()
    ibus_st = Thread(target=EVENT.read_ibus_packages)
    ibus_st.setDaemon(True)
    ibus_st.start()
    note('IBus Connected')
    if EVENT.wel_ike:
        EVENT.ike_send_text(EVENT.wel_iketxt, True, EVENT.wel_iketxt_hold)
    time.sleep(0.2)
    wait_counter = 5
    while wait_counter > 0:
        log('Get OBC TIME %s' % wait_counter)
        wait_counter -= 1
        if EVENT.obc_time[0]:
            break
        EVENT.obc_time_req()
        time.sleep(0.2)

    wait_counter = 5
    while wait_counter > 0:
        log('Get 1st IKE States %s' % wait_counter)
        wait_counter -= 1
        if EVENT.ike_states['run_once']:
            break
        EVENT.ike_get_state()
        time.sleep(0.2)

    wait_counter = 5
    while wait_counter > 0:
        log('WAIT FOR IGNITION STATE %s' % wait_counter)
        wait_counter -= 1
        if EVENT.ike_states['ign_mode'] >= 0:
            break
        EVENT.ign_get_state()
        time.sleep(0.2)

    if EVENT.modealways:
        EVENT.pi_on()
        EVENT.pass_bm_buttons = True
    else:
        log('INITIATE CD-CHANGER & GET RADIO MODE')
        EVENT.cdch_init()
        time.sleep(0.2)
        EVENT.radio_mode_get()
    wait_counter = 5
    while wait_counter > 0:
        log('Get 1st GM States %s' % wait_counter)
        wait_counter -= 1
        if EVENT.gm_states['run_once']:
            break
        EVENT.gm_get_state()
        time.sleep(0.2)

    wait_counter = 5
    while wait_counter > 0:
        log('Get 1st LCM States %s' % wait_counter)
        wait_counter -= 1
        if EVENT.lcm_states['run_once']:
            break
        EVENT.lcm_get_state()
        time.sleep(0.2)

    if EVENT.wel_light and EVENT.welcome_on_boot:
        log('LCM: turn lights on', 3)
        EVENT.lcm_lights_on(EVENT.wel_light_time)
        log('LCM: lights should turned on', 3)
    log('Get KEY')
    EVENT.ews_key_req()
    time.sleep(0.2)
    if EVENT.mir_unfold and EVENT.welcome_on_boot and not EVENT.gm_states['zvlockstate']:
        EVENT.gm_mirror_unfold()
    if MONITOR.waitForAbort():
        EVENT.cancel_read_thread = True
        EVENT.cancel_ike_text = True
        GPIO_NTSC.close()
        GPIO_GEAR_SHIFT_UP.close()
        GPIO_GEAR_SHIFT_DOWN.close()
        GPIO_REARCAM.close()
        DBL_NEXT.click()
        DBL_PREV.click()
        DBL_STW_SPEAK.click()
        log('IBUS: Disconnecting')
        IBUS.disconnect()
        log('IBUS: Disconnected')
        xbmc.log('IBUSCOMMUNICATOR: Service Stopped ', xbmc.LOGNOTICE)


if __name__ == '__main__':
    main()
log('SERVICE COMPLETELY CLOSED')
del PLAYER
del OBCGUI
del MONITOR
del EVENT
del GPIO_NTSC
del GPIO_GEAR_SHIFT_UP
del GPIO_GEAR_SHIFT_DOWN
del GPIO_REARCAM
del DBL_NEXT
del DBL_PREV
del DBL_STW_SPEAK
sys.exit(0)
