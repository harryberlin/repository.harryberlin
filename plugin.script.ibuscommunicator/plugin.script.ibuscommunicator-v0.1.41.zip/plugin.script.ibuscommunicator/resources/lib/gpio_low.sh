#! /bin/sh
echo "0" > /sys/class/gpio/gpio7/value
exit 0