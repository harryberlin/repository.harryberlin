#!/usr/bin/env python
# -*- coding: utf-8 -*-

import xbmcaddon

ADDON = xbmcaddon.Addon()

LANGUAGE = ADDON.getLocalizedString
LANGUAGE_DICT = {'IBusCommunicator': 30000,
                 'IBUS: Error': 32001,
                 'IBus Connected': 32002,
                 'IBus Connection failed': 32003,
                 'Development Mode': 32004,
                 'Continue without IBus Connection': 32005,
                 'Settings changed': 32006,
                 'No Function in AUX-Mode': 32007,
                 'Key 1-6 sets Volumelevel': 32008,
                 'No Function for Button defined': 32009,
                 'Invalid Time Input': 32010,
                 'Invalid Date Input': 32011,
                 'Driver Door': 32012,
                 'Passenger Door': 32013,
                 'Driver Rear Door': 32014,
                 'Passenger Rear Door': 32015,
                 'Central Locksystem': 32016,
                 'Indoor Lights turned': 32017,
                 'Driver Window': 32018,
                 'Passenger Window': 32019,
                 'Driver Rear Window': 32020,
                 'Passenger Rear Window': 32021,
                 'Sunroof': 32022,
                 'Trunk': 32023,
                 'Bonnet': 32024,
                 'Trunk Button': 32025,
                 'opened': 32026,
                 'closed': 32027,
                 'locked': 32028,
                 'unlocked': 32029,
                 'hard locked': 32030,
                 'ON': 32031,
                 'OFF': 32032,
                 'pressed': 32033,
                 'released': 32034,
                 'Sent IBus-Message from TCP Port': 32035,
                 'Simulate IBus Message from TCP Port': 32036}

def language(string):
    return LANGUAGE(LANGUAGE_DICT[string])


