#! /bin/sh
echo "7" > /sys/class/gpio/unexport
exit 0