#!/usr/bin/python
# -*- coding: utf-8 -*-

###### intall these pakets #####
# sudo apt-get install python-pip
# sudo pip install pyserial

from resources.lib.log import *
import resources.lib.syscheck as syscheck
import xbmc, xbmcplugin, xbmcgui, xbmcaddon
import threading

__author__ = 'harryberlin'
# __monitor__ = xbmc.Monitor()

if not syscheck.check():
    note('pySerial is missing')
    quit()

import sys
from os import system
from resources.lib.events import sendSongToIKE, loadSettings, kodiSaidPlay, isPiAktiv
import resources.lib.core as core
from resources.lib.functions import as_thread


class Player(xbmc.Player):
    def __init__(self):
        self.RESUMEONCE = False
        xbmc.Player.__init__(self)

    def onQueueNextItem(self):
        # xbmc.executebuiltin("Notification(Next,,250)")
        pass

    def onPlayBackStarted(self):
        # self.RESUMEONCE = True
        # xbmc.sleep(2000)
        # print ('PLAYERTIME: ' + str(xbmc.Player().getTime()))

        # print ('PLAYERTIME: ' + str(xbmc.Player().getTime()))
        sendSongToIKE()
        kodiSaidPlay()
        # xbmc.executebuiltin("Notification(Started,,250)")
        pass

    def onPlayBackEnded(self):
        # xbmc.executebuiltin("Notification(Ended,,250)")
        pass

    def onPlayBackStopped(self):
        # xbmc.executebuiltin("Notification(Stopped,,250)")
        pass

    def onPlayBackPaused(self):
        # xbmc.executebuiltin("Notification(Pause,,250)")
        pass

    def onPlayBackResumed(self):
        if not self.RESUMEONCE:
            if isPiAktiv(): self.RESUMEONCE = True
            sendSongToIKE()
        # xbmc.executebuiltin("Notification(Resumed,,250)")
        kodiSaidPlay()
        pass

    def onPlayBackSeek(self, time, seekOffset):
        # xbmc.executebuiltin("Notification(Seek," + str(time) + ",250)")
        pass


class Monitor(xbmc.Monitor):
    def __init__(self):
        xbmc.Monitor.__init__(self)

    def onSettingsChanged(self):
        # log('SETTINGS: ################ CHANGED ###############',0)
        note('Settings changed')
        loadSettings(True)
        pass


def listen():
    log('IBus start reading...')
    while True:
        core.listen()


# init and start the TCP/IP service thread...
player = Player()
monitor = Monitor()


# while not monitor.abortRequested():
#  core.listen()

core_thread = threading.Thread(target=listen)
core_thread.start()
core.initialize()
note('IBus connected')

if monitor.waitForAbort():
    core_thread.join(1)

# Close socket gracefully (XBMC/KODI waits for thread to finish before it closes down)
# don't note on exit, it's bad for Kodi
log("Shutting down IBus")
core.shutdown()

del player
del monitor

quit()
sys.exit()
