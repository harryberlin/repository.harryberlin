#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'harryberlin'
import sys
import os
import xbmc, xbmcgui, xbmcaddon, xbmcvfs
ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_USER_PATH = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data', ADDON_ID)
ADDON_MEDIA_PATH = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media')
ADDON_MEDIA_PDC_PATH = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'pdc')
ADDON_MEDIA_GAUGE_PATH = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'gauges')
ADDON_ICON = os.path.join(ADDON_PATH, 'icon.png')
ADDON_ICON_OBC = os.path.join(ADDON_MEDIA_PATH, 'limit-active-logo.png')
ADDON_ICON_LIMIT = os.path.join(ADDON_MEDIA_PATH, 'icon-limit.png')
ADDON_ICON_MEMO = os.path.join(ADDON_MEDIA_PATH, 'icon-memo.png')
ADDON_ICON_TIMER = os.path.join(ADDON_MEDIA_PATH, 'icon-timer.png')
ADDON_ICON_GPSFIX = os.path.join(ADDON_MEDIA_PATH, 'icon-gpsfix.png')
ADDON_ICON_AUXVENT = os.path.join(ADDON_MEDIA_PATH, 'icon-auxvent.png')
ADDON_ICON_AUXHEAT = os.path.join(ADDON_MEDIA_PATH, 'icon-auxheat.png')
ADDON_ICON_RESERVE = os.path.join(ADDON_MEDIA_PATH, 'icon-reserve.png')
ADDON_ICON_COOLANT_RED = os.path.join(ADDON_MEDIA_PATH, 'icon-coolant-red.png')
ADDON_ICON_COOLANT_YELLOW = os.path.join(ADDON_MEDIA_PATH, 'icon-coolant-yellow.png')
ADDON_ICON_COOLANT_GREEN = os.path.join(ADDON_MEDIA_PATH, 'icon-coolant-green.png')
ADDON_ICON_COOLANT_BLUE = os.path.join(ADDON_MEDIA_PATH, 'icon-coolant-blue.png')
ADDON_ICON_COOLANT_RED2 = os.path.join(ADDON_MEDIA_PATH, 'icon-coolant-red2.png')
ADDON_ICON_COOLANT_YELLOW2 = os.path.join(ADDON_MEDIA_PATH, 'icon-coolant-yellow2.png')
ADDON_ICON_COOLANT_GREEN2 = os.path.join(ADDON_MEDIA_PATH, 'icon-coolant-green2.png')
ADDON_ICON_COOLANT_BLUE2 = os.path.join(ADDON_MEDIA_PATH, 'icon-coolant-blue2.png')
BASE_RESOURCE_PATH = os.path.join(ADDON_PATH, 'resources')
BASE_LIB_PATH = os.path.join(ADDON_PATH, 'resources', 'lib')
sys.path.append(BASE_RESOURCE_PATH)
sys.path.append(BASE_LIB_PATH)
import math
import json
import time
import serial
import socket
import logging
import zipfile
import platform
import subprocess
from re import findall, split
from datetime import datetime
from functools import partial
from resources.lib.kodi_actions import KODI_ACTIONS
from threading import Thread, Lock, Event
from Queue import PriorityQueue, Empty, Queue
PLATFORM = platform.system()
KODILOGFILE = '/home/osmc/.kodi/temp/kodi.log'
BACKUPLOGFILEPATH = '/boot/ibuscommunicator'
EXTLOGFILEPATH = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data', ADDON_ID, 'logfiles', 'info.log')
EXTERNIBUSLOGFILEFULLPATH = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data', ADDON_ID, 'logfiles', 'data.log')
try:
    dateprefix = datetime.fromtimestamp(os.path.getatime(EXTLOGFILEPATH)).strftime('%Y%m%d_%H%M%S')
    EXTLOGFILEPATH_OLD = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data', ADDON_ID, 'logfiles', '%s_info.log' % dateprefix)
    EXTERNIBUSLOGFILEFULLPATH_OLD = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data', ADDON_ID, 'logfiles', '%s_data.log' % dateprefix)
    os.rename(EXTLOGFILEPATH, EXTLOGFILEPATH_OLD)
    os.rename(EXTERNIBUSLOGFILEFULLPATH, EXTERNIBUSLOGFILEFULLPATH_OLD)
except:
    pass

BIT = [7,
 6,
 5,
 4,
 3,
 2,
 1,
 0]

class RepeatTimer(Thread):

    def __init__(self, interval, function, iterations = 0, args = [], kwargs = {}):
        Thread.__init__(self)
        self.daemon = True
        self.interval = interval
        self.function = function
        self.iterations = iterations
        self.args = args
        self.kwargs = kwargs
        self.finished = Event()

    def run(self):
        count = 0
        while not self.finished.isSet() and (self.iterations <= 0 or count < self.iterations):
            self.finished.wait(self.interval)
            if not self.finished.isSet():
                self.function(*self.args, **self.kwargs)
                count += 1

        log('Timer Thread finished')

    def cancel(self):
        self.finished.set()


class TimerClass(Thread):

    def __init__(self, interval, function, args = [], kwargs = {}, loop = False):
        Thread.__init__(self)
        self.interval = interval
        self.counter = interval
        self.function = function
        self.args = args
        self.kwargs = kwargs
        self.loop = loop
        self.cancelTimer = False
        self.pauseTimer = False
        self.finished = Event()

    def run(self):
        while not self.cancelTimer:
            if self.cancelTimer:
                break
            if not self.finished.isSet():
                if self.counter <= 0:
                    self.function(*self.args, **self.kwargs)
                    if self.loop:
                        self.counter = self.interval
                    else:
                        break
                elif not self.pauseTimer:
                    self.counter -= 1

        self.finished.set()
        self.cancelTimer = False
        self.finished.set()

    def cancel(self):
        self.cancelTimer = True

    def restart(self):
        self.counter = self.interval

    def pause(self):
        self.pauseTimer = True

    def resume(self):
        self.pauseTimer = False

    def isPause(self):
        return self.pauseTimer


class Logger(object):

    def __init__(self, filefullpath):
        logger_name = '%s' % time.time()
        self.logger = logging.getLogger(logger_name)
        directoryname, filename = os.path.split(filefullpath)
        print directoryname
        print filename
        if not os.path.exists(directoryname):
            os.makedirs(directoryname)
        with open(filefullpath, 'wb') as f:
            f.write(bytearray([239, 187, 191]))
        self.logger = logging.getLogger(logger_name)
        fileHandler = logging.FileHandler(filefullpath, mode='a', encoding='utf-8')
        formatter = logging.Formatter('%(asctime)-15s: %(message)s')
        fileHandler.setFormatter(formatter)
        self.logger.setLevel(logging.INFO)
        self.logger.addHandler(fileHandler)

    def log(self, string):
        self.logger.info('%s' % string.decode('utf-8'))


class ObcGuiClass(xbmcgui.WindowXML):
    ACTION_PARENT_DIR = 9
    ACTION_PREVIOUS_MENU = 10
    ACTION_CLOSE_DIALOG = 51
    ACTION_SELECT_ITEM = 7
    ACTION_MOVE_LEFT = 1
    ACTION_MOVE_RIGHT = 2
    ACTION_MOVE_UP = 3
    ACTION_MOVE_DOWN = 4
    ACTION_NAV_BACK = 92
    ACTION_BACKSPACE = 110
    ACTION_MOUSE_LEFT_CLICK = 100
    ACTION_SHOW_FULLSCREEN = 36

    def __init__(self, xmlFilename, scriptPath, defaultSkin, defaultRes):
        log('Initializing OBC Gui...')
        KODI.set_property('IBUSCOMMUNICATOR_OBC_LOADED', '0')
        KODI.set_property('IBUSCOMMUNICATOR_OBC_Gauges', '0')
        KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', '0')
        self.obc_screen = 0
        self.MAINLABEL = {}
        self.BUTTON1 = {}
        self.BUTTON2 = {}
        self.BUTTON3 = {}
        self.BUTTON4 = {}
        self.BUTTON5 = {}
        self.BUTTON6 = {}
        self.BUTTON7 = {}
        self.BUTTON8 = {}
        self.LABEL1 = {}
        self.LABEL2 = {}
        self.LABEL3 = {}
        self.LABEL4 = {}
        self.LABEL5 = {}
        self.LABEL6 = {}
        self.LABEL7 = {}
        self.LABEL8 = {}
        self.IMAGE1 = {}
        self.IMAGE2 = {}
        self.IMAGE3 = {}
        self.IMAGE4 = {}
        self.IMAGE5 = {}
        self.IMAGE6 = {}
        self.IMAGE7 = {}
        self.IMAGE8 = {}
        self.GAUGE_L = [None, None]
        self.GAUGE_M = [None, None]
        self.GAUGE_R = [None, None]
        self.isActive = False
        self.mouse_clicked = False
        self.updateTimer = None
        self.updateObc = None
        self.submenuCounter = None
        self.pause_submenu_counter = False
        self.window_id = -10000

    def isVisible(self):
        log('OBC: VISIBLE: WINDOW ID: %s' % xbmcgui.getCurrentWindowId(), 2)
        if self.isActive and bool(xbmc.getCondVisibility('Window.IsActive(%s)' % self.window_id)):
            return True
        else:
            return False

    def onInit(self):
        log('OBC INIT: WINDOW ID: %s' % xbmcgui.getCurrentWindowId())
        self.window_id = xbmcgui.getCurrentWindowId()
        self.COOLANT = [[language('- Coolant Temperature'), True, False], [partial(EVENT.obc_coolant_get),
          True,
          True,
          [],
          []], [True, partial(EVENT.obc_coolant_get_icon)]]
        self.OILTEMP = [['- Oil Temperature', True, False], [partial(EVENT.obc_oiltemp_get),
          True,
          True,
          [],
          []], [True, partial(EVENT.obc_oiltemp_get_icon)]]
        self.CONS1 = [[language('Consumption 1'), True, True], [partial(EVENT.obc_cons1_get),
          True,
          True,
          [language('RESET')],
          [partial(EVENT.obc_cons1_reset)]], []]
        self.CONS2 = [[language('Consumption 2'), True, True], [partial(EVENT.obc_cons2_get),
          True,
          True,
          [language('RESET')],
          [partial(EVENT.obc_cons2_reset)]], []]
        self.RANGE = [[language('- Range'), True, False], [partial(EVENT.obc_range_get),
          True,
          True,
          [],
          []], []]
        self.FUELLEVEL = [[language('- Fuel Level'), True, False], [partial(EVENT.obc_fuellevel_get),
          True,
          True,
          [],
          []], [EVENT.obc_fuellevel_get_ind, ADDON_ICON_RESERVE]]
        self.DIST = [[language('Distance'), True, True], [partial(EVENT.obc_dist_get),
          True,
          True,
          [language('SET'), language('RESET')],
          [partial(self.set_distance), partial(EVENT.obc_dist_reset)]], []]
        self.ARR = [[language('- Arrival'), True, False], [partial(EVENT.obc_arr_get),
          True,
          True,
          [],
          []], []]
        self.RPM = [[language('- Engine speed'), True, False], [partial(EVENT.obc_rpm_get),
          True,
          True,
          [],
          []], []]
        self.SPEED = [[language('- Current Speed'), True, False], [partial(EVENT.obc_speed_get),
          True,
          True,
          [],
          []], []]
        self.AVG = [[language('Speed'), True, True], [partial(EVENT.obc_avg_get),
          True,
          True,
          [language('RESET')],
          [partial(EVENT.obc_avg_reset)]], []]
        self.LIMIT = [[language('Limit'), True, True], [partial(EVENT.obc_limit_get),
          True,
          True,
          [language('SET'),
           language('SPEED'),
           language('RESET'),
           language('ACTIVATE'),
           language('DEACTIVATE')],
          [partial(self.set_limit),
           partial(EVENT.obc_limit_set),
           partial(EVENT.obc_limit_reset),
           partial(EVENT.obc_limit_enable, True),
           partial(EVENT.obc_limit_enable, False)]], [EVENT.obc_limit_get_ind, ADDON_ICON_LIMIT]]
        self.MEMO = [[language('Memo'), True, True], [' ',
          True,
          True,
          [language('ACTIVATE'), language('DEACTIVATE')],
          [partial(EVENT.obc_memo_enable, True), partial(EVENT.obc_memo_enable, False)]], [EVENT.obc_memo_get_ind, ADDON_ICON_MEMO]]
        self.TMR1 = [[language('Timer 1'), True, True], [partial(EVENT.obc_tmr1_get),
          True,
          True,
          [language('SET'),
           language('RESET'),
           language('ACTIVATE'),
           language('DEACTIVATE')],
          [partial(self.set_timer, 1),
           partial(EVENT.obc_tmr1_reset),
           partial(EVENT.obc_tmr1_enable, True),
           partial(EVENT.obc_tmr1_enable, False)]], [EVENT.obc_tmr1_get_ind, ADDON_ICON_TIMER]]
        self.TMR2 = [[language('Timer 2'), True, True], [partial(EVENT.obc_tmr2_get),
          True,
          True,
          [language('SET'),
           language('RESET'),
           language('ACTIVATE'),
           language('DEACTIVATE')],
          [partial(self.set_timer, 2),
           partial(EVENT.obc_tmr2_reset),
           partial(EVENT.obc_tmr2_enable, True),
           partial(EVENT.obc_tmr2_enable, False)]], [EVENT.obc_tmr2_get_ind, ADDON_ICON_TIMER]]
        self.STPWTCH = [[language('- Stopwatch'), True, False], [partial(EVENT.obc_stpwtch_get),
          True,
          True,
          [],
          []], []]
        self.VOLTAGE = [[language('- Board Voltage'), True, False], [partial(EVENT.obc_voltage_get),
          True,
          True,
          [],
          []], []]
        self.KEYS = [[language('- Vehicle key'), True, False], [partial(EVENT.obc_key_get),
          True,
          True,
          [],
          []], []]
        self.VIN = [[language('- VIN'), True, False], [partial(EVENT.obc_vin_get),
          True,
          True,
          [],
          []], []]
        self.ODOMETER = [[language('- Odometer'), True, False], [partial(EVENT.obc_odometer_get),
          True,
          True,
          [],
          []], []]
        self.CARMODEL = [[language('- Vehicle type'), True, False], [partial(EVENT.obc_network_get),
          True,
          True,
          [],
          []], []]
        self.LANGUAGE = [[language('- Language'), True, False], [partial(EVENT.obc_language_get),
          True,
          True,
          [],
          []], []]
        self.AUXLBL = [[' ', True, False], [partial(EVENT.obc_auxventheat_label),
          True,
          True,
          [],
          []], []]
        self.AUXVENT = [[language('Aux Ventilation'), partial(EVENT.obc_auxvent_exist), partial(EVENT.obc_auxvent_enabled)], [' ',
          EVENT.obc_auxvent_available,
          EVENT.obc_auxvent_enable,
          [language('ACTIVATE'), language('DEACTIVATE')],
          [partial(EVENT.obc_auxvent_control, True), partial(EVENT.obc_auxvent_control, False)]], [EVENT.obc_auxvent_get_ind, ADDON_ICON_AUXVENT]]
        self.AUXHEAT = [[language('Aux Heating'), partial(EVENT.obc_auxheat_exist), partial(EVENT.obc_auxheat_enabled)], [' ',
          EVENT.obc_auxheat_available,
          EVENT.obc_auxheat_enable,
          [language('ACTIVATE'), language('DEACTIVATE')],
          [partial(EVENT.obc_auxheat_control, True), partial(EVENT.obc_auxheat_control, False)]], [EVENT.obc_auxheat_get_ind, ADDON_ICON_AUXHEAT]]
        self.GPSFIX = [[language('- GPS FIX'), True, False], [partial(EVENT.nav_time_get),
          True,
          True,
          [],
          []], [EVENT.nav_gpsfix_get, ADDON_ICON_GPSFIX]]
        self.GPSTOWN = [[language('- Town'), True, False], [partial(EVENT.nav_town_get),
          True,
          True,
          [],
          []], []]
        self.GPSSTREET = [[language('- Street'), True, False], [partial(EVENT.nav_street_get),
          True,
          True,
          [],
          []], []]
        self.GPSLAT = [[language('- Latitude'), True, False], [partial(EVENT.nav_latitude_get),
          True,
          True,
          [],
          []], []]
        self.GPSLON = [[language('- Longitude'), True, False], [partial(EVENT.nav_longitude_get),
          True,
          True,
          [],
          []], []]
        self.GPSALT = [[language('- Altitude'), True, False], [partial(EVENT.nav_altitude_get),
          True,
          True,
          [],
          []], []]
        self.EMPTY = [[' ', False, False], [' ',
          False,
          False,
          [],
          []], []]
        self.obc_screen_min = 0
        self.obc_screen_max = 4
        self.MAINLABEL[0] = [language('ON-BOARD'), True, True]
        self.BUTTON1[0], self.LABEL1[0], self.IMAGE1[0] = self.CONS1
        self.BUTTON2[0], self.LABEL2[0], self.IMAGE2[0] = self.CONS2
        self.BUTTON3[0], self.LABEL3[0], self.IMAGE3[0] = self.RANGE
        self.BUTTON4[0], self.LABEL4[0], self.IMAGE4[0] = self.FUELLEVEL
        self.BUTTON5[0], self.LABEL5[0], self.IMAGE5[0] = self.DIST
        self.BUTTON6[0], self.LABEL6[0], self.IMAGE6[0] = self.ARR
        self.BUTTON7[0], self.LABEL7[0], self.IMAGE7[0] = self.LIMIT
        self.BUTTON8[0], self.LABEL8[0], self.IMAGE8[0] = self.SPEED
        self.MAINLABEL[1] = [language('ON-BOARD'), True, True]
        self.BUTTON1[1], self.LABEL1[1], self.IMAGE1[1] = self.AVG
        self.BUTTON2[1], self.LABEL2[1], self.IMAGE2[1] = self.MEMO
        self.BUTTON3[1], self.LABEL3[1], self.IMAGE3[1] = self.STPWTCH
        self.BUTTON4[1], self.LABEL4[1], self.IMAGE4[1] = self.EMPTY
        self.BUTTON5[1], self.LABEL5[1], self.IMAGE5[1] = self.TMR1
        self.BUTTON6[1], self.LABEL6[1], self.IMAGE6[1] = self.TMR2
        self.BUTTON7[1], self.LABEL7[1], self.IMAGE7[1] = self.AUXVENT
        self.BUTTON8[1], self.LABEL8[1], self.IMAGE8[1] = self.AUXHEAT
        self.MAINLABEL[2] = [language('INFORMATION'), True, True]
        self.BUTTON1[2], self.LABEL1[2], self.IMAGE1[2] = self.KEYS
        self.BUTTON2[2], self.LABEL2[2], self.IMAGE2[2] = self.ODOMETER
        self.BUTTON3[2], self.LABEL3[2], self.IMAGE3[2] = self.VIN
        self.BUTTON4[2], self.LABEL4[2], self.IMAGE4[2] = self.RPM
        self.BUTTON5[2], self.LABEL5[2], self.IMAGE5[2] = self.COOLANT
        self.BUTTON6[2], self.LABEL6[2], self.IMAGE6[2] = self.OILTEMP if EVENT.engine_type == 0 else self.VOLTAGE
        self.BUTTON7[2], self.LABEL7[2], self.IMAGE7[2] = self.CARMODEL
        self.BUTTON8[2], self.LABEL8[2], self.IMAGE8[2] = self.LANGUAGE
        self.MAINLABEL[3] = [language('GPS'), True, True]
        self.BUTTON1[3], self.LABEL1[3], self.IMAGE1[3] = self.GPSFIX
        self.BUTTON2[3], self.LABEL2[3], self.IMAGE2[3] = self.GPSTOWN
        self.BUTTON3[3], self.LABEL3[3], self.IMAGE3[3] = self.GPSSTREET
        self.BUTTON4[3], self.LABEL4[3], self.IMAGE4[3] = self.GPSLAT
        self.BUTTON5[3], self.LABEL5[3], self.IMAGE5[3] = self.GPSLON
        self.BUTTON6[3], self.LABEL6[3], self.IMAGE6[3] = self.GPSALT
        self.BUTTON7[3], self.LABEL7[3], self.IMAGE7[3] = self.EMPTY
        self.BUTTON8[3], self.LABEL8[3], self.IMAGE8[3] = self.EMPTY
        self.MAINLABEL[self.obc_screen_max] = [language('INSTRUMENTS'), True, True]
        self.BUTTON1[self.obc_screen_max], self.LABEL1[self.obc_screen_max], self.IMAGE1[self.obc_screen_max] = self.EMPTY
        self.BUTTON2[self.obc_screen_max], self.LABEL2[self.obc_screen_max], self.IMAGE2[self.obc_screen_max] = self.EMPTY
        self.BUTTON3[self.obc_screen_max], self.LABEL3[self.obc_screen_max], self.IMAGE3[self.obc_screen_max] = self.EMPTY
        self.BUTTON4[self.obc_screen_max], self.LABEL4[self.obc_screen_max], self.IMAGE4[self.obc_screen_max] = self.EMPTY
        self.BUTTON5[self.obc_screen_max], self.LABEL5[self.obc_screen_max], self.IMAGE5[self.obc_screen_max] = self.EMPTY
        self.BUTTON6[self.obc_screen_max], self.LABEL6[self.obc_screen_max], self.IMAGE6[self.obc_screen_max] = self.EMPTY
        self.BUTTON7[self.obc_screen_max], self.LABEL7[self.obc_screen_max], self.IMAGE7[self.obc_screen_max] = self.EMPTY
        self.BUTTON8[self.obc_screen_max], self.LABEL8[self.obc_screen_max], self.IMAGE8[self.obc_screen_max] = self.EMPTY
        log('OBC: GUI Opening')
        self.selectedButton = -1
        self.selectedSubButton = -1
        self.timeoutSubMenu = 0
        self.obc_screen_next = False
        self.isActive = True
        self.MAINLABEL[-1] = self.getControl(200)
        self.mainleft = self.getControl(201)
        self.mainright = self.getControl(202)
        self.IMAGE1[-1] = self.getControl(101)
        self.IMAGE2[-1] = self.getControl(102)
        self.IMAGE3[-1] = self.getControl(103)
        self.IMAGE4[-1] = self.getControl(104)
        self.IMAGE5[-1] = self.getControl(105)
        self.IMAGE6[-1] = self.getControl(106)
        self.IMAGE7[-1] = self.getControl(107)
        self.IMAGE8[-1] = self.getControl(108)
        self.BUTTON1[-1] = self.getControl(111)
        self.BUTTON2[-1] = self.getControl(112)
        self.BUTTON3[-1] = self.getControl(113)
        self.BUTTON4[-1] = self.getControl(114)
        self.BUTTON5[-1] = self.getControl(115)
        self.BUTTON6[-1] = self.getControl(116)
        self.BUTTON7[-1] = self.getControl(117)
        self.BUTTON8[-1] = self.getControl(118)
        self.LABEL1[-1] = self.getControl(121)
        self.LABEL2[-1] = self.getControl(122)
        self.LABEL3[-1] = self.getControl(123)
        self.LABEL4[-1] = self.getControl(124)
        self.LABEL5[-1] = self.getControl(125)
        self.LABEL6[-1] = self.getControl(126)
        self.LABEL7[-1] = self.getControl(127)
        self.LABEL8[-1] = self.getControl(128)
        self.GAUGE_L = [self.getControl(203), self.getControl(213)]
        self.GAUGE_M = [self.getControl(204), self.getControl(214)]
        self.GAUGE_R = [self.getControl(205), self.getControl(215)]
        self.LABEL211 = self.getControl(211)
        self.update(startup=True)
        self.set_default_navigation()
        if self.updateTimer:
            self.updateTimer.cancel()
            self.updateTimer.join()
            delete_object(self.updateTimer)
        self.updateTimer = RepeatTimer(0.333, self.update)
        self.updateTimer.start()
        self.some_obc_req()
        if self.updateObc:
            self.updateObc.cancel()
            self.updateObc.join()
            delete_object(self.updateObc)
        self.updateObc = RepeatTimer(1, self.some_obc_req)
        self.updateObc.start()
        EVENT.obc_req(True)
        if self.obc_screen == self.obc_screen_max and self.MAINLABEL[self.obc_screen_max][2]:
            KODI.set_property('IBUSCOMMUNICATOR_OBC_Gauges', '2')
        KODI.set_property('IBUSCOMMUNICATOR_OBC_LOADED', '1')

    def onMouseLeftClick(self, controlId):
        log('ONCLICK: %s' % controlId, 3)
        if controlId == 201:
            self.obcPrev()
        elif controlId == 202:
            self.obcNext()
        elif 111 <= controlId <= 118:
            self.click_submenu(controlId)

    def onAction(self, Action):
        if Action in [self.ACTION_PREVIOUS_MENU,
         self.ACTION_CLOSE_DIALOG,
         self.ACTION_NAV_BACK,
         self.ACTION_BACKSPACE,
         self.ACTION_SHOW_FULLSCREEN]:
            self.onStop()
        log('OBCGUI ACTION ID: %s' % Action.getId(), 3)
        log('OBCGUI FOCUS ID: %s' % self.getFocusId(), 3)
        if Action == self.ACTION_MOUSE_LEFT_CLICK:
            log('OBCGUI MOUSE CLICKED', 3)
            self.onMouseLeftClick(self.getFocusId())
            return
        if Action == self.ACTION_MOVE_LEFT and self.obc_screen > self.obc_screen_min:
            self.obcPrev()
        elif Action == self.ACTION_MOVE_RIGHT and self.obc_screen < self.obc_screen_max:
            self.obcNext()
        elif Action == self.ACTION_SELECT_ITEM:
            if self.selectedButton < 0:
                if self.set_submenu(0):
                    self.counter_submenu()
            else:
                log('submenu selected')
                log('obc screen %s' % self.obc_screen)
                log('Button %s' % self.selectedButton)
                log('SubButton %s' % self.selectedSubButton)
                self.onSubmenuSelected(self.obc_screen, self.selectedButton, self.selectedSubButton)
                self.timeoutSubMenu = 0
        elif Action == self.ACTION_MOVE_UP:
            if self.selectedButton > 0:
                self.set_submenu(self.selectedSubButton - 1)
                self.counter_submenu()
        elif Action == self.ACTION_MOVE_DOWN:
            if self.selectedButton > 0:
                self.set_submenu(self.selectedSubButton + 1)
                self.counter_submenu()
        log('OBCGUI FOCUSED ID: %s' % self.getFocusId(), 3)

    def onFocus(self, controlId):
        pass

    def onStop(self, close_window = True):
        log('OBC: GUI Closing')
        self.updateObc.cancel()
        self.updateTimer.cancel()
        self.isActive = False
        self.updateObc.join()
        self.updateTimer.join()
        if self.submenuCounter:
            self.timeoutSubMenu = 0
            self.submenuCounter.join()
        log('Timers joined')
        delete_object(self.updateObc)
        delete_object(self.updateTimer)
        delete_object(self.submenuCounter)
        self.MAINLABEL[-1] = None
        self.mainleft = None
        self.mainright = None
        self.IMAGE1[-1] = None
        self.IMAGE2[-1] = None
        self.IMAGE3[-1] = None
        self.IMAGE4[-1] = None
        self.IMAGE5[-1] = None
        self.IMAGE6[-1] = None
        self.IMAGE7[-1] = None
        self.IMAGE8[-1] = None
        self.BUTTON1[-1] = None
        self.BUTTON2[-1] = None
        self.BUTTON3[-1] = None
        self.BUTTON4[-1] = None
        self.BUTTON5[-1] = None
        self.BUTTON6[-1] = None
        self.BUTTON7[-1] = None
        self.BUTTON8[-1] = None
        self.LABEL1[-1] = None
        self.LABEL2[-1] = None
        self.LABEL3[-1] = None
        self.LABEL4[-1] = None
        self.LABEL5[-1] = None
        self.LABEL6[-1] = None
        self.LABEL7[-1] = None
        self.LABEL8[-1] = None
        self.GAUGE_L = [None, None]
        self.GAUGE_M = [None, None]
        self.GAUGE_R = [None, None]
        self.LABEL211 = None
        if close_window:
            self.close()
        KODI.set_property('IBUSCOMMUNICATOR_OBC_LOADED', '0')

    def set_default_navigation(self):
        self.BUTTON1[-1].setNavigation(self.BUTTON1[-1], self.BUTTON2[-1], self.BUTTON1[-1], self.BUTTON1[-1])
        self.BUTTON2[-1].setNavigation(self.BUTTON1[-1], self.BUTTON3[-1], self.BUTTON2[-1], self.BUTTON2[-1])
        self.BUTTON3[-1].setNavigation(self.BUTTON2[-1], self.BUTTON4[-1], self.BUTTON3[-1], self.BUTTON3[-1])
        self.BUTTON4[-1].setNavigation(self.BUTTON3[-1], self.BUTTON5[-1], self.BUTTON4[-1], self.BUTTON4[-1])
        self.BUTTON5[-1].setNavigation(self.BUTTON4[-1], self.BUTTON6[-1], self.BUTTON5[-1], self.BUTTON5[-1])
        self.BUTTON6[-1].setNavigation(self.BUTTON5[-1], self.BUTTON7[-1], self.BUTTON6[-1], self.BUTTON6[-1])
        self.BUTTON7[-1].setNavigation(self.BUTTON6[-1], self.BUTTON8[-1], self.BUTTON7[-1], self.BUTTON7[-1])
        self.BUTTON8[-1].setNavigation(self.BUTTON7[-1], self.BUTTON8[-1], self.BUTTON8[-1], self.BUTTON8[-1])

    def set_submenu(self, menu_pos):
        if self.getFocusId() == 111:
            label_textlist = self.LABEL1
            label_control = self.LABEL1[-1]
            self.selectedButton = 1
            button_control = self.BUTTON1[-1]
        elif self.getFocusId() == 112:
            label_textlist = self.LABEL2
            label_control = self.LABEL2[-1]
            self.selectedButton = 2
            button_control = self.BUTTON2[-1]
        elif self.getFocusId() == 113:
            label_textlist = self.LABEL3
            label_control = self.LABEL3[-1]
            self.selectedButton = 3
            button_control = self.BUTTON3[-1]
        elif self.getFocusId() == 114:
            label_textlist = self.LABEL4
            label_control = self.LABEL4[-1]
            self.selectedButton = 4
            button_control = self.BUTTON4[-1]
        elif self.getFocusId() == 115:
            label_textlist = self.LABEL5
            label_control = self.LABEL5[-1]
            self.selectedButton = 5
            button_control = self.BUTTON5[-1]
        elif self.getFocusId() == 116:
            label_textlist = self.LABEL6
            label_control = self.LABEL6[-1]
            self.selectedButton = 6
            button_control = self.BUTTON6[-1]
        elif self.getFocusId() == 117:
            label_textlist = self.LABEL7
            label_control = self.LABEL7[-1]
            self.selectedButton = 7
            button_control = self.BUTTON7[-1]
        elif self.getFocusId() == 118:
            label_textlist = self.LABEL8
            label_control = self.LABEL8[-1]
            self.selectedButton = 8
            button_control = self.BUTTON8[-1]
        else:
            return False
        if not len(label_textlist[self.obc_screen][3]) > 0:
            self.selectedButton = -1
            self.selectedSubButton = -1
            return False
        else:
            if menu_pos < 0:
                menu_pos = len(label_textlist[self.obc_screen][3]) - 1
            elif menu_pos > len(label_textlist[self.obc_screen][3]) - 1:
                menu_pos = 0
            if label_textlist[self.obc_screen][3][menu_pos]:
                label_control.setLabel(' ')
                time.sleep(0.1)
                color = 'FFFF7E00'
                label_control.setLabel('[COLOR %s]- %s -[/COLOR]' % (color, label_textlist[self.obc_screen][3][menu_pos]))
                self.selectedSubButton = menu_pos
                button_control.setNavigation(button_control, button_control, button_control, button_control)
                return True
            self.selectedButton = -1
            self.selectedSubButton = -1
            return False

    def reset_submenu(self):
        self.selectedButton = -1
        self.selectedSubButton = -1
        self.update()
        self.set_default_navigation()

    def click_submenu(self, item):
        """
        item = 111 - 118
        """
        if item == 111:
            header = self.BUTTON1[self.obc_screen][0]
            obc_event_list = self.LABEL1[self.obc_screen][3]
            obc_event_action = self.LABEL1[self.obc_screen][4]
        elif item == 112:
            header = self.BUTTON2[self.obc_screen][0]
            obc_event_list = self.LABEL2[self.obc_screen][3]
            obc_event_action = self.LABEL2[self.obc_screen][4]
        elif item == 113:
            header = self.BUTTON3[self.obc_screen][0]
            obc_event_list = self.LABEL3[self.obc_screen][3]
            obc_event_action = self.LABEL3[self.obc_screen][4]
        elif item == 114:
            header = self.BUTTON4[self.obc_screen][0]
            obc_event_list = self.LABEL4[self.obc_screen][3]
            obc_event_action = self.LABEL4[self.obc_screen][4]
        elif item == 115:
            header = self.BUTTON5[self.obc_screen][0]
            obc_event_list = self.LABEL5[self.obc_screen][3]
            obc_event_action = self.LABEL5[self.obc_screen][4]
        elif item == 116:
            header = self.BUTTON6[self.obc_screen][0]
            obc_event_list = self.LABEL6[self.obc_screen][3]
            obc_event_action = self.LABEL6[self.obc_screen][4]
        elif item == 117:
            header = self.BUTTON7[self.obc_screen][0]
            obc_event_list = self.LABEL7[self.obc_screen][3]
            obc_event_action = self.LABEL7[self.obc_screen][4]
        elif item == 118:
            header = self.BUTTON8[self.obc_screen][0]
            obc_event_list = self.LABEL8[self.obc_screen][3]
            obc_event_action = self.LABEL8[self.obc_screen][4]
        if len(obc_event_list) > 0:
            selected = xbmcgui.Dialog().select(header, obc_event_list)
            if selected > -1:
                self.mouse_clicked = True
                obc_event_action[selected]()
                self.mouse_clicked = False

    def onSubmenuSelected(self, obc_screen, button, sub_button):
        if button == 1:
            obc_event = self.LABEL1[obc_screen][4]
        elif button == 2:
            obc_event = self.LABEL2[obc_screen][4]
        elif button == 3:
            obc_event = self.LABEL3[obc_screen][4]
        elif button == 4:
            obc_event = self.LABEL4[obc_screen][4]
        elif button == 5:
            obc_event = self.LABEL5[obc_screen][4]
        elif button == 6:
            obc_event = self.LABEL6[obc_screen][4]
        elif button == 7:
            obc_event = self.LABEL7[obc_screen][4]
        elif button == 8:
            obc_event = self.LABEL8[obc_screen][4]
        else:
            return
        obc_event[sub_button]()

    def counter_submenu(self):
        if self.timeoutSubMenu > 0:
            log('OBCGUI: Submenu Counter restart', 2)
            self.timeoutSubMenu = 2000
            return
        if self.submenuCounter:
            self.timeoutSubMenu = 0
            self.submenuCounter.join()
            delete_object(self.submenuCounter)
        self.timeoutSubMenu = 2000
        log('OBCGUI: Submenu Counter start', 2)
        self.submenuCounter = Thread(target=self._counter_submenu)
        self.submenuCounter.daemon = True
        self.submenuCounter.start()

    def _counter_submenu(self):
        while self.timeoutSubMenu > 0:
            if not self.pause_submenu_counter:
                self.timeoutSubMenu -= 1
            time.sleep(0.001)

        self.reset_submenu()
        log('OBCGUI: Submenu Counter finshed', 2)

    def some_obc_req(self):
        log('OBCGUI: isVISIBLE: %s' % xbmc.getCondVisibility('Window.IsActive(%s)' % self.window_id), 3)
        if not bool(xbmc.getCondVisibility('Window.IsActive(%s)' % self.window_id)):
            thread = Thread(target=self.onStop, args=(False,))
            thread.daemon = True
            thread.start()
            return
        if self.obc_screen_next or self.obc_screen == self.obc_screen_max:
            return
        log('OBCGUI: SOME REQUEST TICK', 3)
        if self.obc_screen == 2:
            EVENT.obc_voltage_req()
        elif self.obc_screen == 0:
            EVENT.ike_get_state()
        elif self.obc_screen == 3:
            EVENT.nav_position_req()
            EVENT.nav_location_req()

    def obcNext(self):
        if True not in [self.MAINLABEL[1][1],
         self.MAINLABEL[2][1],
         self.MAINLABEL[3][1],
         self.MAINLABEL[4][1]]:
            return
        self.obc_screen_next = True
        if self.obc_screen == self.obc_screen_max:
            KODI.set_property('IBUSCOMMUNICATOR_OBC_Gauges', '0')
        else:
            KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', 'left_out')
        self.obc_screen += 1
        if self.obc_screen > self.obc_screen_max:
            inv_slide_direction = True
            self.obc_screen = self.obc_screen_min
        else:
            inv_slide_direction = False
        while not self.MAINLABEL[self.obc_screen][1]:
            self.obc_screen += 1
            if self.obc_screen > self.obc_screen_max:
                inv_slide_direction = True
                self.obc_screen = self.obc_screen_min
            else:
                inv_slide_direction = False

        time.sleep(0.5)
        self.obc_screen_next = False
        self.reset_submenu()
        if self.obc_screen == self.obc_screen_max and self.MAINLABEL[self.obc_screen_max][2]:
            KODI.set_property('IBUSCOMMUNICATOR_OBC_Gauges', '1')
        else:
            if inv_slide_direction:
                KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', 'left_in')
            else:
                KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', 'right_in')
            self.setFocus(self.BUTTON1[-1])

    def obcPrev(self):
        if True not in [self.MAINLABEL[1][1],
         self.MAINLABEL[2][1],
         self.MAINLABEL[3][1],
         self.MAINLABEL[4][1]]:
            return
        self.obc_screen_next = True
        if self.obc_screen == self.obc_screen_max and self.MAINLABEL[self.obc_screen_max][2]:
            KODI.set_property('IBUSCOMMUNICATOR_OBC_Gauges', '0')
        else:
            KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', 'right_out')
        self.obc_screen -= 1
        if self.obc_screen < self.obc_screen_min:
            inv_slide_direction = True
            self.obc_screen = self.obc_screen_max
        else:
            inv_slide_direction = False
        while not self.MAINLABEL[self.obc_screen][1]:
            self.obc_screen -= 1
            if self.obc_screen < self.obc_screen_min:
                inv_slide_direction = True
                self.obc_screen = self.obc_screen_max
            else:
                inv_slide_direction = False

        time.sleep(0.5)
        self.obc_screen_next = False
        self.reset_submenu()
        if self.obc_screen == self.obc_screen_max:
            KODI.set_property('IBUSCOMMUNICATOR_OBC_Gauges', '1')
        else:
            if inv_slide_direction:
                KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', 'right_in')
            else:
                KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', 'left_in')
            self.setFocus(self.BUTTON1[-1])

    def update(self, startup = False):

        def set_button_control(button, obc_screen):
            try:
                button[-1].setLabel(button[obc_screen][0])
            except:
                button[-1].setLabel(button[obc_screen][0]())

            try:
                button[-1].setVisible(button[obc_screen][1])
            except:
                button[-1].setVisible(button[obc_screen][1]())

            try:
                button[-1].setEnabled(button[obc_screen][2])
            except:
                button[-1].setEnabled(button[obc_screen][2]())

        def set_label_control(label, obc_screen):
            if label[obc_screen][0] != ' ':
                try:
                    label[-1].setLabel(label[obc_screen][0]())
                except TypeError:
                    label[-1].setLabel(label[obc_screen][0])

            else:
                label[-1].setLabel(' ')
            if not label[obc_screen][1] or not label[obc_screen][2]:
                label[-1].setLabel(' ')

        def set_img_control(image, obc_screen):
            if len(image[obc_screen]) > 0:
                try:
                    image[-1].setVisible(image[obc_screen][0]())
                except TypeError:
                    image[-1].setVisible(image[obc_screen][0])

            else:
                image[-1].setVisible(False)
            try:
                image[-1].setImage(image[obc_screen][1](), False)
            except TypeError:
                image[-1].setImage(image[obc_screen][1], False)
            except IndexError:
                image[-1].setImage(ADDON_ICON_OBC, False)

        def set_gauges():
            self.GAUGE_L[0].setImage(EVENT.obc_speed_get_gauge(), False)
            self.GAUGE_M[0].setImage(EVENT.obc_coolant_get_gauge(), False)
            self.GAUGE_R[0].setImage(EVENT.obc_rpm_get_gauge(), False)
            rpm = EVENT.obc_rpm
            if rpm < 1:
                rpm = '---'
                speed = '---'
            else:
                speed = EVENT.obc_speed_kmh
            self.GAUGE_L[1].setLabel('%s' % speed)
            if EVENT.obc_temperature_unit == '\xc2\xb0F':
                self.GAUGE_M[1].setLabel('%s' % EVENT.obc_coolant_F)
            else:
                self.GAUGE_M[1].setLabel('%s' % EVENT.obc_coolant_C)
            self.GAUGE_R[1].setLabel('%s' % rpm)

        set_button_control(self.MAINLABEL, self.obc_screen)
        if self.obc_screen == self.obc_screen_max:
            self.mainright.setVisible(False)
        else:
            self.mainright.setVisible(True)
        if self.obc_screen == self.obc_screen_min:
            self.mainleft.setVisible(False)
        else:
            self.mainleft.setVisible(True)
        if not startup:
            if self.obc_screen_next:
                return
            if self.obc_screen == self.obc_screen_max:
                set_gauges()
                return
        if self.selectedButton != 1:
            set_button_control(self.BUTTON1, self.obc_screen)
            set_label_control(self.LABEL1, self.obc_screen)
            set_img_control(self.IMAGE1, self.obc_screen)
        if self.selectedButton != 2:
            set_button_control(self.BUTTON2, self.obc_screen)
            set_label_control(self.LABEL2, self.obc_screen)
            set_img_control(self.IMAGE2, self.obc_screen)
        if self.selectedButton != 3:
            set_button_control(self.BUTTON3, self.obc_screen)
            set_label_control(self.LABEL3, self.obc_screen)
            set_img_control(self.IMAGE3, self.obc_screen)
        if self.selectedButton != 4:
            set_button_control(self.BUTTON4, self.obc_screen)
            set_label_control(self.LABEL4, self.obc_screen)
            set_img_control(self.IMAGE4, self.obc_screen)
        if self.selectedButton != 5:
            set_button_control(self.BUTTON5, self.obc_screen)
            set_label_control(self.LABEL5, self.obc_screen)
            set_img_control(self.IMAGE5, self.obc_screen)
        if self.selectedButton != 6:
            set_button_control(self.BUTTON6, self.obc_screen)
            set_label_control(self.LABEL6, self.obc_screen)
            set_img_control(self.IMAGE6, self.obc_screen)
        if self.selectedButton != 7:
            set_button_control(self.BUTTON7, self.obc_screen)
            set_label_control(self.LABEL7, self.obc_screen)
            set_img_control(self.IMAGE7, self.obc_screen)
        if self.selectedButton != 8:
            set_button_control(self.BUTTON8, self.obc_screen)
            set_label_control(self.LABEL8, self.obc_screen)
            set_img_control(self.IMAGE8, self.obc_screen)
        self.LABEL211.setLabel('%s' % EVENT.obc_outtemp_get())

    def set_distance(self):
        if self.mouse_clicked:
            if EVENT.obc_distance_unit == 'MLS':
                min_value = 1
                max_value = 6213
            else:
                min_value = 1
                max_value = 9999
            current_value = EVENT.obc_dist
            if current_value < min_value:
                current_value = min_value
            elif current_value > max_value:
                current_value = max_value
            result = int(xbmcgui.Dialog().numeric(0, 'Distance %s - %s' % (min_value, max_value)))
            if min_value > result > max_value or result == current_value:
                result = -1
            self.mouse_clicked = False
        else:
            self.pause_submenu_counter = True
            obc_set_value = ObcSetValueClass('OBC_SETVALUE.xml', ADDON_PATH, 'Default', '720p')
            if EVENT.obc_distance_unit == 'MLS':
                result = obc_set_value.get_value(EVENT.obc_dist, 1, 6213)
            else:
                result = obc_set_value.get_value(EVENT.obc_dist, 1, 9999)
        log('Value set %s' % result)
        if result != -1:
            EVENT.obc_dist_set(result)
        delete_object(obc_set_value)
        self.pause_submenu_counter = False

    def set_limit(self):
        if self.mouse_clicked:
            if EVENT.obc_distance_unit == 'MLS':
                min_value = 4
                max_value = 199
            else:
                min_value = 6
                max_value = 299
            current_value = EVENT.obc_limit
            if current_value < min_value:
                current_value = min_value
            elif current_value > max_value:
                current_value = max_value
            result = int(xbmcgui.Dialog().numeric(0, 'Speed %s - %s' % (min_value, max_value)))
            if min_value > result > max_value or result == current_value:
                result = -1
            self.mouse_clicked = False
        else:
            self.pause_submenu_counter = True
            obc_set_value = ObcSetValueClass('OBC_SETVALUE.xml', ADDON_PATH, 'Default', '720p')
            if EVENT.obc_speed_unit == 'MPH':
                result = obc_set_value.get_value(EVENT.obc_limit, 4, 199)
            else:
                result = obc_set_value.get_value(EVENT.obc_limit, 6, 299)
        log('Value set %s' % result)
        if result != -1:
            EVENT.obc_limit_set(result)
        delete_object(obc_set_value)
        self.pause_submenu_counter = False

    def set_timer(self, timer):
        if self.mouse_clicked:
            result = xbmcgui.Dialog().numeric(2, 'Time').split(':')
            if len(result) < 2:
                result = None
            result = [int(result[0]), int(result[1])]
            self.mouse_clicked = False
        else:
            self.pause_submenu_counter = True
            if EVENT.obc_time_unit == '12H' or not KODI.get_condition('IsEmpty(System.Time(xx))'):
                obc_set_timer = ObcSetTimer12Class('OBC_SETTIMER12.xml', ADDON_PATH, 'Default', '720p')
            else:
                obc_set_timer = ObcSetTimer24Class('OBC_SETTIMER24.xml', ADDON_PATH, 'Default', '720p')
            result = obc_set_timer.get_value()
        log('Value set %s' % result)
        if result:
            if timer == 1:
                EVENT.obc_tmr1_set(result[0], result[1])
            if timer == 2:
                EVENT.obc_tmr2_set(result[0], result[1])
        delete_object(obc_set_timer)
        self.pause_submenu_counter = False


class ObcSetValueClass(xbmcgui.WindowXMLDialog):
    isActive = False
    ACTION_PARENT_DIR = 9
    ACTION_PREVIOUS_MENU = 10
    ACTION_CLOSE_DIALOG = 51
    ACTION_SELECT_ITEM = 7
    ACTION_MOVE_LEFT = 1
    ACTION_MOVE_RIGHT = 2
    ACTION_MOVE_UP = 3
    ACTION_MOVE_DOWN = 4
    ACTION_NAV_BACK = 92
    ACTION_BACKSPACE = 110

    def __init__(self, xmlFilename, scriptPath, defaultSkin, defaultRes):
        log('Initializing OBC Set-Value Gui...')
        self.input_value_start = -1
        self.input_value_min = 0
        self.input_value_max = 0

    def onInit(self):
        log('OBC: Set-Value GUI Opening')
        self.input_value = self.input_value_start
        self.ENTER = self.getControl(201)
        self.BUTTON2 = self.getControl(203)
        self.CANCEL = self.getControl(205)
        self.selectedButton = -1
        self.isActive = True
        self.setFocus(self.BUTTON2)
        self.BUTTON2.setLabel(('%s' % self.input_value).zfill(2))
        self.set_default_navigation()
        time.sleep(0.05)
        self.submenu_set()

    def onAction(self, Action):
        log('OBC VALUE: ACTION ID: %s' % Action.getId(), 2)
        log('OBC VALUE: FOCUS ID: %s' % self.getFocusId(), 2)
        if Action in [self.ACTION_PREVIOUS_MENU,
         self.ACTION_CLOSE_DIALOG,
         self.ACTION_NAV_BACK,
         self.ACTION_BACKSPACE]:
            self.input_value = -1
            self.onStop()
        if Action == self.ACTION_MOVE_LEFT:
            pass
        elif Action == self.ACTION_MOVE_RIGHT:
            pass
        elif Action == self.ACTION_SELECT_ITEM:
            if self.getFocus() == self.ENTER:
                self.onStop()
                return
            if self.getFocus() == self.CANCEL:
                self.input_value = -1
                self.onStop()
                return
            if self.selectedButton < 0:
                log('OBC Value: SubAction Enable')
                self.submenu_set()
            else:
                log('OBC Value: SubAction Disable')
                kodi_jump = False
                if self.selectedButton == 203:
                    kodi_jump = True
                self.submenu_reset()
                if kodi_jump:
                    KODI.left()
        elif Action == self.ACTION_MOVE_UP:
            if self.selectedButton == 203:
                self.input_value += 1
                if self.input_value > self.input_value_max:
                    self.input_value = self.input_value_max
                self.BUTTON2.setLabel(('%s' % self.input_value).zfill(2))
        elif Action == self.ACTION_MOVE_DOWN:
            if self.selectedButton == 203:
                self.input_value -= 1
                if self.input_value < self.input_value_min:
                    self.input_value = self.input_value_min
                self.BUTTON2.setLabel(('%s' % self.input_value).zfill(2))

    def onFocus(self, controlId):
        pass

    def onStop(self):
        log('OBC: GUI Closing')
        self.submenu_reset()
        self.close()
        self.isActive = False

    def get_value(self, value_start = 0, value_min = 0, value_max = 500):
        if value_start < value_min or value_start > value_max:
            self.input_value_start = value_min
        else:
            self.input_value_start = value_start
        self.input_value_min = value_min
        self.input_value_max = value_max
        self.doModal()
        return self.input_value

    def set_default_navigation(self):
        self.ENTER.setNavigation(self.BUTTON2, self.ENTER, self.ENTER, self.BUTTON2)
        self.BUTTON2.setNavigation(self.CANCEL, self.ENTER, self.ENTER, self.CANCEL)
        self.CANCEL.setNavigation(self.CANCEL, self.BUTTON2, self.BUTTON2, self.CANCEL)

    def submenu_set(self):
        if self.getFocusId() == 203:
            self.selectedButton = 203
            self.BUTTON2.setLabel(('%s' % self.input_value).zfill(2), textColor='0xFF000000')
            self.BUTTON2.setNavigation(self.BUTTON2, self.BUTTON2, self.BUTTON2, self.BUTTON2)

    def submenu_reset(self):
        self.BUTTON2.setLabel(('%s' % self.input_value).zfill(2), textColor='0xFFEEEEFF')
        self.selectedButton = -1
        self.set_default_navigation()


class ObcSetTimer12Class(xbmcgui.WindowXMLDialog):
    isActive = False
    ACTION_PARENT_DIR = 9
    ACTION_PREVIOUS_MENU = 10
    ACTION_CLOSE_DIALOG = 51
    ACTION_SELECT_ITEM = 7
    ACTION_MOVE_LEFT = 1
    ACTION_MOVE_RIGHT = 2
    ACTION_MOVE_UP = 3
    ACTION_MOVE_DOWN = 4
    ACTION_NAV_BACK = 92
    ACTION_BACKSPACE = 110

    def __init__(self, xmlFilename, scriptPath, defaultSkin, defaultRes):
        log('Initializing OBC Set-Time 12 Gui...')
        self.input_value_hour = -1
        self.input_value_minute = -1
        self.input_value_am_pm = 'AM'

    def onInit(self):
        log('OBC: Set-Value GUI Opening')
        self.ENTER = self.getControl(201)
        self.BUTTON1 = self.getControl(202)
        self.BUTTON2 = self.getControl(203)
        self.BUTTON3 = self.getControl(204)
        self.CANCEL = self.getControl(205)
        self.selectedButton = -1
        self.isActive = True
        self.setFocus(self.BUTTON3)
        self.BUTTON1.setLabel(('%s' % self.input_value_hour).zfill(2))
        self.BUTTON2.setLabel(('%s' % self.input_value_minute).zfill(2))
        self.BUTTON3.setLabel('%s' % self.input_value_am_pm)
        self.set_default_navigation()
        time.sleep(0.05)
        self.submenu_set()

    def onAction(self, Action):
        if Action in [self.ACTION_PREVIOUS_MENU,
         self.ACTION_CLOSE_DIALOG,
         self.ACTION_NAV_BACK,
         self.ACTION_BACKSPACE]:
            self.input_value_hour = -1
            self.input_value_minute = -1
            self.input_value_am_pm = ' '
            self.onStop()
        if Action == self.ACTION_MOVE_LEFT:
            pass
        elif Action == self.ACTION_MOVE_RIGHT:
            pass
        elif Action == self.ACTION_SELECT_ITEM:
            if self.getFocus() == self.ENTER:
                self.onStop()
                return
            if self.getFocus() == self.CANCEL:
                self.input_value_hour = -1
                self.input_value_minute = -1
                self.input_value_am_pm = ' '
                self.onStop()
                return
            if self.selectedButton < 0:
                self.submenu_set()
            else:
                log('submenu selected')
                self.submenu_reset()
        elif Action == self.ACTION_MOVE_UP:
            if self.selectedButton == 202:
                self.input_value_hour += 1
                if self.input_value_hour > 12:
                    self.input_value_hour = 1
                self.BUTTON1.setLabel(('%s' % self.input_value_hour).zfill(2))
            elif self.selectedButton == 203:
                self.input_value_minute += 1
                if self.input_value_minute > 59:
                    self.input_value_minute = 0
                self.BUTTON2.setLabel(('%s' % self.input_value_minute).zfill(2))
            elif self.selectedButton == 204:
                if self.input_value_am_pm == 'AM':
                    self.input_value_am_pm = 'PM'
                else:
                    self.input_value_am_pm = 'AM'
                self.BUTTON3.setLabel('%s' % self.input_value_am_pm)
        elif Action == self.ACTION_MOVE_DOWN:
            if self.selectedButton == 202:
                self.input_value_hour -= 1
                if self.input_value_hour < 1:
                    self.input_value_hour = 12
                self.BUTTON1.setLabel(('%s' % self.input_value_hour).zfill(2))
            elif self.selectedButton == 203:
                self.input_value_minute -= 1
                if self.input_value_minute < 0:
                    self.input_value_minute = 59
                self.BUTTON2.setLabel(('%s' % self.input_value_minute).zfill(2))
            elif self.selectedButton == 204:
                if self.input_value_am_pm == 'AM':
                    self.input_value_am_pm = 'PM'
                else:
                    self.input_value_am_pm = 'AM'
                self.BUTTON3.setLabel('%s' % self.input_value_am_pm)
        log('OBCGUI FOCUSED ID: %s' % self.getFocusId(), 3)

    def onFocus(self, controlId):
        pass

    def onStop(self):
        log('OBC: GUI Closing')
        self.submenu_reset()
        self.close()
        self.isActive = False

    def get_value(self, value_hour = 12, value_minute = 0, value_am_pm = 'AM'):
        self.input_value_hour = value_hour
        self.input_value_minute = value_minute
        self.input_value_am_pm = value_am_pm
        self.doModal()
        if self.input_value_hour < 0:
            return None
        else:
            if self.input_value_am_pm == 'AM':
                if self.input_value_hour == 12:
                    self.input_value_hour = 0
            if self.input_value_am_pm == 'PM':
                if self.input_value_hour <= 12:
                    self.input_value_hour += 12
                if self.input_value_hour > 23:
                    self.input_value_hour = 0
            return [self.input_value_hour, self.input_value_minute]

    def set_default_navigation(self):
        self.ENTER.setNavigation(self.BUTTON1, self.ENTER, self.ENTER, self.BUTTON1)
        self.BUTTON1.setNavigation(self.BUTTON2, self.ENTER, self.ENTER, self.BUTTON2)
        self.BUTTON2.setNavigation(self.BUTTON3, self.BUTTON1, self.BUTTON1, self.BUTTON3)
        self.BUTTON3.setNavigation(self.CANCEL, self.BUTTON2, self.BUTTON2, self.CANCEL)
        self.CANCEL.setNavigation(self.CANCEL, self.BUTTON3, self.BUTTON3, self.CANCEL)

    def submenu_set(self):
        if self.getFocusId() == 202:
            self.selectedButton = 202
            self.BUTTON1.setLabel(('%s' % self.input_value_hour).zfill(2), textColor='0xFF000000')
            self.BUTTON1.setNavigation(self.BUTTON1, self.BUTTON1, self.BUTTON1, self.BUTTON1)
        elif self.getFocusId() == 203:
            self.selectedButton = 203
            self.BUTTON2.setLabel(('%s' % self.input_value_minute).zfill(2), textColor='0xFF000000')
            self.BUTTON2.setNavigation(self.BUTTON2, self.BUTTON2, self.BUTTON2, self.BUTTON2)
        elif self.getFocusId() == 204:
            self.selectedButton = 204
            self.BUTTON3.setLabel('%s' % self.input_value_am_pm, textColor='0xFF000000')
            self.BUTTON3.setNavigation(self.BUTTON3, self.BUTTON3, self.BUTTON3, self.BUTTON3)

    def submenu_reset(self):
        self.BUTTON1.setLabel(('%s' % self.input_value_hour).zfill(2), textColor='0xFFEEEEFF')
        self.BUTTON2.setLabel(('%s' % self.input_value_minute).zfill(2), textColor='0xFFEEEEFF')
        self.BUTTON3.setLabel('%s' % self.input_value_am_pm, textColor='0xFFEEEEFF')
        self.selectedButton = -1
        self.set_default_navigation()


class ObcSetTimer24Class(xbmcgui.WindowXMLDialog):
    isActive = False
    ACTION_PARENT_DIR = 9
    ACTION_PREVIOUS_MENU = 10
    ACTION_CLOSE_DIALOG = 51
    ACTION_SELECT_ITEM = 7
    ACTION_MOVE_LEFT = 1
    ACTION_MOVE_RIGHT = 2
    ACTION_MOVE_UP = 3
    ACTION_MOVE_DOWN = 4
    ACTION_NAV_BACK = 92
    ACTION_BACKSPACE = 110

    def __init__(self, xmlFilename, scriptPath, defaultSkin, defaultRes):
        log('Initializing OBC Set-Time 24 Gui...')
        self.input_value_hour = -1
        self.input_value_minute = -1

    def onInit(self):
        log('OBC: Set-Value GUI Opening')
        self.ENTER = self.getControl(201)
        self.BUTTON1 = self.getControl(202)
        self.BUTTON3 = self.getControl(204)
        self.CANCEL = self.getControl(205)
        self.selectedButton = -1
        self.isActive = True
        self.setFocus(self.BUTTON3)
        self.BUTTON1.setLabel(('%s' % self.input_value_hour).zfill(2))
        self.BUTTON3.setLabel(('%s' % self.input_value_minute).zfill(2))
        self.set_default_navigation()
        time.sleep(0.05)
        self.submenu_set()

    def onAction(self, Action):
        if Action in [self.ACTION_PREVIOUS_MENU,
         self.ACTION_CLOSE_DIALOG,
         self.ACTION_NAV_BACK,
         self.ACTION_BACKSPACE]:
            self.input_value_hour = -1
            self.input_value_minute = -1
            self.onStop()
        if Action == self.ACTION_MOVE_LEFT:
            pass
        elif Action == self.ACTION_MOVE_RIGHT:
            pass
        elif Action == self.ACTION_SELECT_ITEM:
            if self.getFocus() == self.ENTER:
                self.onStop()
                return
            if self.getFocus() == self.CANCEL:
                self.input_value_hour = -1
                self.input_value_minute = -1
                self.onStop()
                return
            if self.selectedButton < 0:
                self.submenu_set()
            else:
                log('submenu selected')
                self.submenu_reset()
        elif Action == self.ACTION_MOVE_UP:
            if self.selectedButton == 202:
                self.input_value_hour += 1
                if self.input_value_hour > 23:
                    self.input_value_hour = 0
                self.BUTTON1.setLabel(('%s' % self.input_value_hour).zfill(2))
            elif self.selectedButton == 204:
                self.input_value_minute += 1
                if self.input_value_minute > 59:
                    self.input_value_minute = 0
                self.BUTTON3.setLabel(('%s' % self.input_value_minute).zfill(2))
        elif Action == self.ACTION_MOVE_DOWN:
            if self.selectedButton == 202:
                self.input_value_hour -= 1
                if self.input_value_hour < 0:
                    self.input_value_hour = 23
                self.BUTTON1.setLabel(('%s' % self.input_value_hour).zfill(2))
            elif self.selectedButton == 204:
                self.input_value_minute -= 1
                if self.input_value_minute < 0:
                    self.input_value_minute = 59
                self.BUTTON3.setLabel(('%s' % self.input_value_minute).zfill(2))
        log('OBCGUI FOCUSED ID: %s' % self.getFocusId(), 3)

    def onFocus(self, controlId):
        pass

    def onStop(self):
        log('OBC: GUI Closing')
        self.submenu_reset()
        self.close()
        self.isActive = False

    def get_value(self, value_hour = 0, value_minute = 0):
        self.input_value_hour = value_hour
        self.input_value_minute = value_minute
        self.doModal()
        if self.input_value_hour < 0:
            return None
        else:
            return [self.input_value_hour, self.input_value_minute]

    def set_default_navigation(self):
        self.ENTER.setNavigation(self.BUTTON1, self.ENTER, self.ENTER, self.BUTTON1)
        self.BUTTON1.setNavigation(self.BUTTON3, self.ENTER, self.ENTER, self.BUTTON3)
        self.BUTTON3.setNavigation(self.CANCEL, self.BUTTON1, self.BUTTON1, self.CANCEL)
        self.CANCEL.setNavigation(self.CANCEL, self.BUTTON3, self.BUTTON3, self.CANCEL)

    def submenu_set(self):
        if self.getFocusId() == 202:
            self.selectedButton = 202
            self.BUTTON1.setLabel(('%s' % self.input_value_hour).zfill(2), textColor='0xFF000000')
            self.BUTTON1.setNavigation(self.BUTTON1, self.BUTTON1, self.BUTTON1, self.BUTTON1)
        elif self.getFocusId() == 204:
            self.selectedButton = 204
            self.BUTTON3.setLabel(('%s' % self.input_value_minute).zfill(2), textColor='0xFF000000')
            self.BUTTON3.setNavigation(self.BUTTON3, self.BUTTON3, self.BUTTON3, self.BUTTON3)

    def submenu_reset(self):
        self.BUTTON1.setLabel(('%s' % self.input_value_hour).zfill(2), textColor='0xFFEEEEFF')
        self.BUTTON3.setLabel(('%s' % self.input_value_minute).zfill(2), textColor='0xFFEEEEFF')
        self.selectedButton = -1
        self.set_default_navigation()


class Kodi(object):
    log_to_kodi = True
    log_level = 1
    kodi_play = -1
    ibuslogger = None
    ibusdatalogger = None
    volume_backup = -1
    volume_reset_active = False
    volume_delay_counter = 0

    def __init__(self):
        self.circle = ['\\', '/', '-']
        self.circle_counter = 0
        self.xbmc = xbmc

    def up(self, steps = '01'):
        steps = int(steps, 16)
        while steps > 0:
            self.xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Up", "id": 1 }')
            steps -= 1
            time.sleep(0.02)

    def down(self, steps = '01'):
        steps = int(steps, 16)
        while steps > 0:
            self.xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Down", "id": 1 }')
            steps -= 1
            time.sleep(0.02)

    def left(self):
        self.xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Left", "id": 1 }')

    def right(self):
        self.xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Right", "id": 1 }')

    def back(self):
        self.xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Back", "id": 1 }')

    def select(self):
        self.xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Select", "id": 1 }')

    def home(self):
        self.xbmc.executebuiltin('Dialog.Close(all,true)')
        self.xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Home", "id": 1 }')

    def track_play(self):
        if self.kodi_play == 1:
            return
        self.kodi_play = 1
        self.xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Player.SetSpeed","params":{"playerid":%s,"speed":1 },"id":1}' % self.player_id())
        log('KODI: PLAY')

    def track_pause(self):
        if self.kodi_play == 0:
            return
        self.kodi_play = 0
        time.sleep(1)
        if self.kodi_play == 1:
            return
        self.xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Player.SetSpeed","params":{"playerid":%s,"speed":0 },"id":1}' % self.player_id())
        log('KODI: PAUSE')

    def track_seek(self, SPEED):
        self.kodi_play = 2
        self.xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Player.SetSpeed","params":{"playerid":%s,"speed":%s },"id":1}' % (self.player_id(), SPEED))

    def track_next(self):
        self.xbmc.Player().playnext()

    def track_prev(self):
        try:
            if xbmc.Player().getTime() <= 3:
                self.xbmc.Player().playprevious()
            else:
                self.track_pos(0)
        except:
            pass

    def track_pos(self, milliseconds):
        self.xbmc.Player().seekTime(milliseconds)

    def volume_up(self, steps = '01'):
        steps = int(steps, 16)
        while steps > 0:
            self.xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Application.SetVolume", "params": { "volume": "increment" }, "id": 1 }')
            steps -= 1
            time.sleep(0.08)

    def volume_down(self, steps = '01'):
        steps = int(steps, 16)
        while steps > 0:
            self.xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Application.SetVolume", "params": { "volume": "decrement" }, "id": 1 }')
            steps -= 1
            time.sleep(0.08)

    def volume_get(self):
        request = self.xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Application.GetProperties", "params": { "properties": [ "volume" ] }, "id": 1}')
        volume = json.loads(u'%s' % request)['result']['volume']
        log('KODI: VOLUME: Get %s' % volume)
        return volume

    def volume_set(self, volume):
        if self.volume_reset_active:
            self.volume_reset_active = False
        if self.volume_backup < 0:
            self.volume_backup = self.volume_get()
            if EVENT.volume_sink_r_ibus:
                EVENT.radio_volume_set(EVENT.volume_sink_r_value_ibus * -1)
            else:
                self.xbmc.executebuiltin('SetVolume(%s, False)' % volume)
            log('KODI: VOLUME: Set = %s' % volume)

    def volume_reset(self, delay = 0):
        if self.volume_backup == -1:
            log('KODI: VOLUME: Reset not available', 2)
            self.volume_reset_active = False
            return
        if self.volume_reset_active:
            self.volume_delay_counter = delay
            log('KODI: VOLUME: Reset Change to %ss' % self.volume_delay_counter, 2)
            return
        thread = Thread(target=self._volume_reset)
        thread.daemon = True
        self.volume_reset_active = True
        self.volume_delay_counter = delay
        thread.start()

    def _volume_reset(self):
        log('KODI: VOLUME: Reset Start with %ss' % self.volume_delay_counter, 2)
        while self.volume_delay_counter > 0:
            time.sleep(0.1)
            log('KODI: VOLUME: Countdown %s' % self.volume_delay_counter, 3)
            self.volume_delay_counter -= 0.1
            if not self.volume_reset_active:
                return
            if EVENT.obc_speed_kmh > EVENT.volume_sink_r_speed:
                break
            if self.volume_backup < 0:
                self.volume_reset_active = False
                return

        if EVENT.volume_sink_r_ibus:
            EVENT.radio_volume_set(EVENT.volume_sink_r_value_ibus)
        else:
            self.xbmc.executebuiltin('SetVolume(%s, False)' % self.volume_backup)
        log('KODI: Volume Reset = %s' % self.volume_backup)
        self.volume_backup = -1
        self.volume_reset_active = False

    def shutdown_timer_start(self, minutes):
        self.action('AlarmClock(shutdowntimer,Powerdown(),%s:00)' % minutes)

    def shutdown_timer_cancel(self):
        if self.get_condition('System.HasAlarm(shutdowntimer)'):
            self.action('CancelAlarm(shutdowntimer)')

    def track_title(self):
        log('get song', 3)
        if self.xbmc.Player().isPlayingAudio():
            log('music', 3)
            artist = self.xbmc.getInfoLabel('MusicPlayer.Artist')
            title = self.xbmc.getInfoLabel('MusicPlayer.Title')
            log('SONG MUSIC: "%s" - "%s"' % (artist, title), 2)
            if artist == title:
                return '%s' % artist
            if artist == '':
                return '%s' % title
            if title == '':
                return '%s' % artist
            return '%s - %s' % (artist, title)
        if self.xbmc.Player().isPlayingVideo():
            log('video', 3)
            title = self.xbmc.getInfoLabel('VideoPlayer.Title')
            file = self.xbmc.Player().getVideoInfoTag().getFile()
            log('SONG VIDEO: "%s"' % title, 2)
            if title != '':
                return '%s' % title
            else:
                return '%s' % file
        else:
            log('SONG: empty')
            return ''

    def action(self, action_event):
        log('KODI ACTION EVENT: %s' % action_event)
        self.xbmc.executebuiltin('%s' % action_event)

    def player_id(self):
        response = self.xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.GetActivePlayers","id": 1}')
        log('JSONREPLY: ' + response, 3)
        try:
            playerID_tmp = json.loads(u'%s' % response)['result'][0]['playerid']
            log('PLAYERID: %s' % playerID_tmp, 3)
            return '%s' % playerID_tmp
        except:
            log('PLAYERID: -1', 3)
            return '-1'

    def get_current_listlabel(self, old_label = ''):
        wait = 5
        while old_label == self.xbmc.getInfoLabel('ListItem.Label') and wait > 0:
            time.sleep(0.1)
            wait += -1

        new_label = self.xbmc.getInfoLabel('ListItem.Label')
        if new_label != '':
            return new_label
        return 'Kodi Control'

    def copy_log_fileOLD(self):
        log('COPY LOG FILE TO "/boot/ibuscommunicator"')
        if not xbmcvfs.exists(BACKUPLOGFILEPATH):
            os.popen('sudo -s mkdir %s' % BACKUPLOGFILEPATH)
        if self.log_to_kodi:
            file_name = datetime.now().strftime('%Y%m%d_%H%M%S_kodi.txt')
            dest_logfile = os.path.join(BACKUPLOGFILEPATH, file_name)
            os.popen('sudo -s cp %s %s' % (KODILOGFILE, dest_logfile))
        else:
            file_name1 = datetime.now().strftime('%Y%m%d_%H%M%S_info.txt')
            file_name2 = datetime.now().strftime('%Y%m%d_%H%M%S_data.txt')
            dest_logfile = os.path.join(BACKUPLOGFILEPATH, file_name1)
            os.popen('sudo -s cp %s %s' % (EXTLOGFILEPATH, dest_logfile))
            dest_logfile = os.path.join(BACKUPLOGFILEPATH, file_name2)
            os.popen('sudo -s cp %s %s' % (EXTERNIBUSLOGFILEFULLPATH, dest_logfile))

    def copy_log_file(self):
        if not xbmcvfs.exists(BACKUPLOGFILEPATH):
            os.popen('sudo -s mkdir %s' % BACKUPLOGFILEPATH)
        log('LOGFILE: COPY LOG FILE TO "/boot/ibuscommunicator"')
        if not xbmcvfs.exists(BACKUPLOGFILEPATH):
            os.popen('sudo -s mkdir %s' % BACKUPLOGFILEPATH)
        log('LOGFILE: Create Zip File')
        filename = datetime.now().strftime('%Y%m%d_%H%M%S_ibuscommunicator.zip')
        dest_logfile = os.path.join(BACKUPLOGFILEPATH, filename)
        zip = zipfile.ZipFile(os.path.join(ADDON_USER_PATH, filename), 'w', zipfile.ZIP_DEFLATED)
        try:
            zip.write(KODILOGFILE, os.path.split(KODILOGFILE)[1])
            if not self.log_to_kodi:
                zip.write(EXTLOGFILEPATH, os.path.split(EXTLOGFILEPATH)[1])
                zip.write(EXTERNIBUSLOGFILEFULLPATH, os.path.split(EXTERNIBUSLOGFILEFULLPATH)[1])
            zip.close()
        except ValueError:
            log('LOGFILE: Can not create Zip File')
            zip.close()
            return

        log('LOGFILE: Move Zip File')
        os.popen('sudo -s mv %s %s' % (os.path.join(ADDON_USER_PATH, filename), dest_logfile))

    def get_condition(self, condition):
        return bool(self.xbmc.getCondVisibility(condition))

    @staticmethod
    def get_addon_setting(id):
        setting = ADDON.getSetting(id)
        if setting.upper() == 'TRUE':
            return True
        if setting.upper() == 'FALSE':
            return False
        return '%s' % setting

    @staticmethod
    def set_addon_setting(id, value):
        if type(value) == 'bool':
            ADDON.setSetting(id, 'true' if value else 'false')
        else:
            ADDON.setSetting(id, '%s' % value)

    @staticmethod
    def get_property(property, id = 10000):
        value = xbmcgui.Window(id).getProperty(property)
        return value

    @staticmethod
    def set_property(property, value, id = 10000):
        xbmcgui.Window(id).setProperty(property, value)

    @staticmethod
    def clear_property(property, id = 10000):
        value = xbmcgui.Window(id).clearProperty(property)

    def get_addon_string(id, replacements = None):
        string = ADDON.getLocalizedString(id)
        if replacements is not None:
            return string % replacements
        else:
            return string

    def set_log_level(self, level):
        self.log_level = level

    def log(self, string, lvl = 1):
        if self.log_level < 1 and lvl > 0:
            return
        if lvl <= self.log_level <= 3 or self.log_level == 5 and lvl == 5:
            if self.log_to_kodi:
                try:
                    circle_char = self.circle[self.circle_counter]
                except:
                    self.circle_counter = 0
                    circle_char = self.circle[self.circle_counter]

                self.xbmc.log('IBUSCOMMUNICATOR: %s %s' % (circle_char, string), xbmc.LOGNOTICE)
                if self.circle_counter + 1 > 2:
                    self.circle_counter = 0
                else:
                    self.circle_counter += 1
            elif self.log_level < 5:
                self.ibuslogger.log('%s' % string)
        if self.log_level >= 1 and lvl == 5 and not self.log_to_kodi:
            self.ibusdatalogger.log('%s' % string)

    def note(self, heading, message = None, time = -1, icon = None):
        if EVENT.pi_is_visible:
            if time == -1:
                xbmcgui.Dialog().notification(heading='%s' % heading, message='%s' % message if message else ' ', icon='%s' % (icon if icon else ADDON_ICON))
            else:
                xbmcgui.Dialog().notification(heading='%s' % heading, message='%s' % message if message else ' ', icon='%s' % (icon if icon else ADDON_ICON), time=time)
        log('NOTIFICATION: "%s%s"' % (heading, ' - %s' % message if message else ''))

    def dialog_ok(self, label1, label2 = None, label3 = None):
        log('DIALOG_OK: "%s%s%s"' % (label1, ' - %s' % label2 if label2 else '', ' - %s' % label3 if label3 else ''))
        xbmcgui.Dialog().ok('IBusCommunicator', label1, label2, label3)

    def dialog_yesno(self, label1, label2 = None, label3 = None, nolabel = '', yeslabel = '', autoclose = 0):
        return xbmcgui.Dialog().yesno('IBusCommunicator', line1=label1, line2=label2, line3=label3, nolabel=nolabel, yeslabel=yeslabel, autoclose=autoclose)


class Clicker():

    def __init__(self, double_click_interval, single_func, double_func, single_args = (), double_args = ()):
        self._queue = Queue()
        self._close = False
        latch = Event()

        def handle_clicks():
            latch.set()
            while True:
                self._queue.get()
                if self._close:
                    return
                try:
                    self._queue.get(True, double_click_interval)
                except Empty:
                    if self._close:
                        return
                    single_func(*single_args)
                else:
                    if self._close:
                        return
                    double_func(*double_args)

        thread = Thread(target=handle_clicks)
        thread.daemon = True
        thread.start()
        latch.wait()

    def click(self):
        self._queue.put(None)

    def close(self):
        self._close = True
        self._queue.put(None)


class RemoteKeyClass(object):
    remote_state = -1
    remote_accept_cmd = True
    remote_press = False
    hold_time = 700 / 50

    def __init__(self, hold_time_seconds, lock_pres = None, lock_hold = None, lock_rel = None, unlock_pres = None, unlock_hold = None, unlock_rel = None, boot_pres = None, boot_hold = None, boot_rel = None):
        self.hold_time = hold_time_seconds * 1000 / 50
        self.lock_pres = lock_pres
        self.lock_hold = lock_hold
        self.lock_rel = lock_rel
        self.unlock_pres = unlock_pres
        self.unlock_hold = unlock_hold
        self.unlock_rel = unlock_rel
        self.boot_pres = boot_pres
        self.boot_hold = boot_hold
        self.boot_rel = boot_rel

    def _hold_loop(self):
        counter = self.hold_time
        while self.remote_press and counter > 0:
            time.sleep(0.05)
            counter -= 1

    def key_event(self, dat):
        dat = ('%02X' % dat[1])[0]
        if dat == '1':
            if self.remote_press:
                return
            self.remote_state = 1
            self.remote_press = True
            if self.lock_pres:
                thread = Thread(target=self.lock_pres)
                thread.daemon = True
                thread.start()
            if self.lock_hold:
                self._hold_loop()
                if self.remote_press:
                    self.lock_hold()
        elif dat == '2':
            if self.remote_press:
                return
            self.remote_state = 2
            self.remote_press = True
            if self.unlock_pres:
                thread = Thread(target=self.unlock_pres)
                thread.daemon = True
                thread.start()
            if self.unlock_hold:
                self._hold_loop()
                if self.remote_press:
                    self.unlock_hold()
        elif dat == '4':
            if self.remote_press:
                return
            self.remote_state = 4
            self.remote_press = True
            if self.boot_pres:
                thread = Thread(target=self.boot_pres)
                thread.daemon = True
                thread.start()
            if self.boot_hold:
                self._hold_loop()
                if self.remote_press:
                    self.boot_hold()
        elif dat == '0':
            self.remote_press = False
            if self.remote_state == 1:
                if self.lock_rel:
                    self.lock_rel()
            elif self.remote_state == 2:
                if self.unlock_rel:
                    self.unlock_rel()
            elif self.remote_state == 4:
                if self.boot_rel:
                    self.boot_rel()
            self.remote_state = 0


class PlayerClass(xbmc.Player):

    def __init__(self):
        self.RESUMEONCE = False
        xbmc.Player.__init__(self)

    def onQueueNextItem(self):
        pass

    def onPlayBackStarted(self):
        if not EVENT.new_song:
            EVENT.new_song = True
            EVENT.send_song_to_ike()
        EVENT.kodi_said_play()

    def onPlayBackEnded(self):
        pass

    def onPlayBackStopped(self):
        pass

    def onPlayBackPaused(self):
        EVENT.kodi_said_pause()

    def onPlayBackResumed(self):
        EVENT.kodi_said_play()

    def onPlayBackSeek(self, time, seekOffset):
        pass


class MonitorClass(xbmc.Monitor):

    def __init__(self):
        xbmc.Monitor.__init__(self)

    def onSettingsChanged(self):
        time.sleep(0.6)
        note(language('Settings changed'))
        load_settings(True)


class GPIOClass(object):
    isOpen = False

    def _call(self, command):
        try:
            try:
                output = subprocess.check_output(command, stderr=subprocess.STDOUT)
            except subprocess.CalledProcessError as error:
                output = error.output
                return error.returncode

            return output
        finally:
            pass

    def open(self, pinnumber, mode = 'out', level = False, off_level = False):
        if pinnumber not in (4, 5, 6, 7, 12, 13, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27):
            raise ValueError('%s is not a valid GPIO' % pinnumber)
        self.pinnumber = pinnumber
        self.invert_signal = off_level
        os.popen('sudo chmod 222 /sys/class/gpio/export /sys/class/gpio/unexport')
        os.popen('sudo echo %s >/sys/class/gpio/export' % self.pinnumber)
        os.popen('sudo chmod 222 /sys/class/gpio/gpio%s/direction' % self.pinnumber)
        os.popen('sudo chmod 222 /sys/class/gpio/gpio%s/value' % self.pinnumber)
        os.popen('sudo echo %s >/sys/class/gpio/gpio%s/direction' % ('high' if self.invert_signal else 'low', self.pinnumber))
        if mode == 'out':
            if level:
                self.set()
            else:
                self.reset()
        elif mode == 'in':
            pass
        self.isOpen = True

    def change(self, pinnumber, mode = 'out', level = False, off_level = False):
        self.close()
        self.open(pinnumber, mode, level, off_level)

    def close(self, other_pinnumber = -1):
        if other_pinnumber >= 0:
            os.popen('sudo echo %s > /sys/class/gpio/unexport' % other_pinnumber)
        elif self.isOpen:
            os.popen('sudo echo %s > /sys/class/gpio/unexport' % self.pinnumber)
            self.isOpen = False

    def set(self):
        if self.isOpen:
            if self.invert_signal:
                os.popen('sudo echo "0" > /sys/class/gpio/gpio%s/value' % self.pinnumber)
                log('Set GPIO%s Low' % self.pinnumber, 2)
            else:
                os.popen('sudo echo "1" > /sys/class/gpio/gpio%s/value' % self.pinnumber)
                log('Set GPIO%s High' % self.pinnumber, 2)

    def reset(self):
        if self.isOpen:
            if self.invert_signal:
                os.popen('sudo echo "1" > /sys/class/gpio/gpio%s/value' % self.pinnumber)
                log('Reset GPIO%s High' % self.pinnumber, 2)
            else:
                os.popen('sudo echo "0" > /sys/class/gpio/gpio%s/value' % self.pinnumber)
                log('Reset GPIO%s Low' % self.pinnumber, 2)

    def toggle(self):
        if self.isOpen:
            pin_level = bool(os.popen('sudo cat /sys/class/gpio/gpio%s/value' % self.pinnumber))
            if pin_level:
                self.reset()
            else:
                self.set()

    def trigger(self, holdtime = 0.2):
        if self.isOpen:
            self.set()
            while holdtime > 0:
                holdtime -= 0.001
                time.sleep(0.001)

            self.reset()

    def get(self):
        if self.isOpen:
            value = bool(os.popen('sudo cat /sys/class/gpio/gpio%s/value' % self.pinnumber))
            return value


class IBusFace(object):

    def __init__(self):
        log('SERIAL_VERSION: %s' % serial.VERSION)
        self.serial_port = serial.Serial()
        self.serial_port.baudrate = 9600
        self.serial_port.parity = serial.PARITY_EVEN
        self.serial_port.stopbits = serial.STOPBITS_ONE
        self.serial_port.timeout = 0.001
        if PLATFORM != 'Linux':
            self.serial_port.rtscts = True
        self.rts_state = False
        self.read_buffer = []
        self.read_lock = Lock()
        self.read_error_counter = 0
        self.read_error_container = []
        self.cancel_read_thread = False
        self.read_thread = Thread(target=self._reading)
        self.read_thread.deamon = True
        self.cts_counter = 0.0
        self.cts_thread = Thread(target=self._cts_watcher)
        self.cts_thread.daemon = True
        self.packet_buffer = Queue()
        self.write_buffer = PriorityQueue()
        self.write_counter = 0
        self.write_in_progress = False
        self.cancel_write_thread = False
        self.write_thread = Thread(target=self._writing)
        self.write_thread.daemon = True
        self.msg_callback = None
        self.got_first_good_packet = False

    @staticmethod
    def _calculate_checksum(packet):
        result = 0
        for value in packet:
            result ^= value

        return result

    def _cut_read_buffer(self, offset = 1):
        with self.read_lock:
            self.read_buffer = self.read_buffer[offset:]

    def _wait_free_bus(self, waiting = 17, timeout = 1000):
        if waiting >= timeout:
            log('IBUS: ERROR: Waiting Time (%sms) is bigger than Timeout Time (%sms)' % (waiting, timeout), 3)
            return False
        while timeout > 0:
            if self.cts_counter >= waiting:
                return True
            timeout -= 1
            time.sleep(0.001)

        return False

    def _reading(self):
        while not self.cancel_read_thread:
            input = self.serial_port.read(40)
            if len(input) > 0:
                input = [ ord(x) for x in input ]
                with self.read_lock:
                    self.read_buffer.extend(input)
            if not self.msg_callback:
                if not self._read_bus_packet():
                    time.sleep(0.001)
            else:
                self._read_bus_packet_thread()

        log('IBUS: READ Thread finished', 2)

    def _writing(self):
        while not self.cancel_read_thread:
            try:
                prio, write_counter, data = self.write_buffer.get()
                if prio == -1:
                    break
                try:
                    while self.cts_counter < 8.0:
                        if EVENT.develop:
                            break
                        time.sleep(0.001)

                    self.cts_counter = 0.0
                    self.serial_port.write(data)
                    self.serial_port.flush()
                    self.cts_counter = 0.0
                except serial.SerialException:
                    self.write_buffer.put((prio, write_counter, data))

            except Empty:
                pass

        log('IBUS: WRITE Thread finished', 2)

    def _cts_watcher(self):
        while not self.cancel_read_thread:
            try:
                if self.serial_port.getCTS():
                    self.cts_counter += 0.1
                else:
                    self.cts_counter = 0.0
            except IOError:
                self.cts_counter = 0.0

            time.sleep(0.0001)

        log('IBUS: CTS-WATCHER Thread finished', 2)

    def set_port(self, device_path):
        if PLATFORM == 'Linux':
            if not os.path.exists(device_path):
                log('IBUS: ERROR: Serial Port does not exist >%s<' % device_path)
                raise Exception('IBUS: ERROR: Serial Port does not exist >%s<' % device_path)
        self.serial_port.port = device_path

    def connect(self, msg_callback = None):
        try:
            self.serial_port.open()
        except serial.SerialException:
            log('IBUS: ERROR: Can not open Serial Port >%s<' % self.serial_port.port)
            raise

        self.msg_callback = msg_callback
        while not self.serial_port.isOpen():
            time.sleep(0.01)

        self.serial_port.set_input_flow_control(True)
        self.serial_port.set_output_flow_control(True)
        self.serial_port.setDTR(1)
        self.serial_port.setRTS(0)
        self.cts_thread.start()
        self.got_first_good_packet = False
        self.serial_port.flushInput()
        self.read_thread.start()
        self.write_thread.start()
        self.read_error_counter = 0
        self.read_error_container = []
        KODI.set_property('msgerr_cnt', '0')

    def disconnect(self):
        self.packet_buffer.put(-1)
        self.cancel_write_thread = True
        self.write_buffer.put((-1, None, None))
        self.cancel_read_thread = True
        self.ntsc = False
        try:
            self.read_thread.join()
        except RuntimeError:
            pass

        try:
            self.write_thread.join()
        except RuntimeError:
            pass

        try:
            self.cts_thread.join()
        except RuntimeError:
            pass

        self.serial_port.close()

    @property
    def ntsc(self):
        return self.rts_state

    @ntsc.setter
    def ntsc(self, value):
        if self.rts_state == value:
            return
        self.serial_port.setRTS(value)
        self.rts_state = value

    def read_bus_packet(self):
        try:
            return self.packet_buffer.get(timeout=1)
        except:
            return None

    def _read_bus_packet_thread(self):
        try:
            data_length = self.read_buffer[1]
        except:
            return

        if data_length < 3 or data_length > 37:
            self.read_error_container.append(self.read_buffer[0])
            self._cut_read_buffer()
            return
        buffer_len = len(self.read_buffer)
        if buffer_len < 5 or buffer_len < data_length + 2:
            return
        message = self.read_buffer[:data_length + 2]
        if self._calculate_checksum(message) == 0:
            thread = Thread(target=self.msg_callback, args=(message[0], message[2], message[3:data_length + 1]))
            thread.deamon = True
            thread.start()
            self._cut_read_buffer(data_length + 2)
            if len(self.read_error_container) > 0 and self.got_first_good_packet:
                error_hex_string = ' '.join([ '%02X' % i for i in self.read_error_container ])
                if self.read_error_container in [[4,
                  4,
                  191,
                  255], [128, 4, 239], [128,
                  4,
                  191,
                  255]]:
                    log('# IBUS: READ-ERR: %s (no counter increase)' % error_hex_string, 5)
                else:
                    log('# IBUS: READ-ERR: %s' % error_hex_string, 5)
                    self.read_error_counter += len(self.read_error_container)
                    KODI.set_property('msgerr_cnt', '%s' % self.read_error_counter)
                self.read_error_container = []
            self.got_first_good_packet = True
            log('IBUS-READ: %s' % ' '.join([ '%02X' % i for i in message ]), 5)
        else:
            self.read_error_container.append(self.read_buffer[0])
            self._cut_read_buffer()

    def _read_bus_packet(self):
        if self.cancel_read_thread:
            return False
        else:
            try:
                data_length = self.read_buffer[1]
            except:
                return False

            if data_length < 3 or data_length > 37:
                self.read_error_container.append(self.read_buffer[0])
                self._cut_read_buffer()
                return False
            buffer_len = len(self.read_buffer)
            if buffer_len < 5 or buffer_len < data_length + 2:
                return False
            message = self.read_buffer[:data_length + 2]
            if self._calculate_checksum(message) == 0:
                if len(self.read_error_container) > 0 and self.got_first_good_packet:
                    error_hex_string = ' '.join([ '%02X' % i for i in self.read_error_container ])
                    if self.read_error_container in [[4,
                      4,
                      191,
                      255], [128, 4, 239], [128,
                      4,
                      191,
                      255]]:
                        log('# IBUS: READ-ERR: %s (no counter increase)' % error_hex_string, 5)
                    else:
                        log('# IBUS: READ-ERR: %s' % error_hex_string, 5)
                        self.read_error_counter += len(self.read_error_container)
                        KODI.set_property('msgerr_cnt', '%s' % self.read_error_counter)
                    self.read_error_container = []
                self._cut_read_buffer(data_length + 2)
                self.packet_buffer.put({'src': message[0],
                 'len': data_length,
                 'dst': message[2],
                 'data': message[3:data_length + 1],
                 'xor': message[-1]}, block=False)
                self.got_first_good_packet = True
                log('IBUS-READ: %s' % ' '.join([ '%02X' % i for i in message ]), 5)
                return True
            self.read_error_container.append(self.read_buffer[0])
            self._cut_read_buffer()
            return False

    def write_bus_packet(self, src, dst, data, highprio = False, veryhighprio = False, repeat = 1):
        try:
            packet = [src, len(data) + 2, dst]
            packet.extend(data)
        except:
            packet = [int(src, 16), len(data) + 2, int(dst, 16)]
            packet.extend([ int(s, 16) for s in data ])

        packet.append(self._calculate_checksum(packet))
        bytepacket = bytearray(packet)
        while repeat > 0:
            repeat -= 1
            if veryhighprio:
                self.write_buffer.put_nowait((0, 0, bytepacket))
            else:
                self.write_buffer.put_nowait((0 if highprio else 1, self.write_counter, bytepacket))
            self.write_counter += 1

    def write_hex_message(self, hexstring):
        hexstring_tmp = hexstring.upper().split(' ')
        src = int(hexstring_tmp[0], 16)
        dst = int(hexstring_tmp[2], 16)
        data = [ int(s, 16) for s in hexstring_tmp[3:-1] ]
        self.write_bus_packet(src, dst, data)


class EventClass(object):
    TUNER_MODES = [[165,
      98,
      1,
      1,
      32,
      70,
      77,
      68],
     [165,
      98,
      1,
      1,
      32,
      32,
      70,
      77],
     [165,
      98,
      1,
      1,
      32,
      32,
      65,
      77],
     [165,
      98,
      1,
      1,
      32,
      32,
      77,
      87],
     [165,
      98,
      1,
      1,
      32,
      77,
      87,
      65],
     [165,
      98,
      1,
      1,
      32,
      32,
      76,
      87],
     [165,
      98,
      1,
      1,
      32,
      76,
      87,
      65],
     [165,
      98,
      1,
      1,
      32,
      32,
      83,
      87],
     [165,
      98,
      1,
      1,
      32,
      83,
      87,
      65],
     [165,
      98,
      1,
      1,
      32,
      70,
      77,
      32,
      32],
     [165,
      98,
      1,
      1,
      32,
      70,
      77,
      68,
      32],
     [165,
      98,
      1,
      1,
      32,
      65,
      77,
      32,
      32],
     [165,
      98,
      1,
      1,
      32,
      77,
      87,
      32,
      32],
     [165,
      98,
      1,
      1,
      32,
      77,
      87,
      65,
      32],
     [165,
      98,
      1,
      1,
      32,
      76,
      87,
      32,
      32],
     [165,
      98,
      1,
      1,
      32,
      76,
      87,
      65,
      32],
     [165,
      98,
      1,
      1,
      32,
      83,
      87,
      32,
      32],
     [165,
      98,
      1,
      1,
      32,
      83,
      87,
      65,
      32],
     [165,
      98,
      1,
      65,
      32,
      32,
      70,
      77,
      32],
     [165,
      98,
      1,
      65,
      32,
      70,
      77,
      68,
      32],
     [165,
      98,
      1,
      65,
      32,
      65,
      77,
      32,
      32],
     [165,
      98,
      1,
      65,
      32,
      77,
      87,
      32,
      32],
     [165,
      98,
      1,
      65,
      32,
      77,
      87,
      65,
      32],
     [165,
      98,
      1,
      65,
      32,
      76,
      87,
      32,
      32],
     [165,
      98,
      1,
      65,
      32,
      76,
      87,
      65,
      32],
     [165,
      98,
      1,
      65,
      32,
      83,
      87,
      32,
      32],
     [165,
      98,
      1,
      65,
      32,
      83,
      87,
      65,
      32],
     [165,
      98,
      1,
      65,
      70,
      77,
      32],
     [165,
      98,
      1,
      65,
      70,
      77,
      68],
     [165,
      98,
      1,
      65,
      65,
      77,
      32],
     [165,
      98,
      1,
      65,
      77,
      87,
      32],
     [165,
      98,
      1,
      65,
      77,
      87,
      65],
     [165,
      98,
      1,
      65,
      76,
      87,
      32],
     [165,
      98,
      1,
      65,
      76,
      87,
      65],
     [165,
      98,
      1,
      65,
      83,
      87,
      32],
     [165,
      98,
      1,
      65,
      83,
      87,
      65]]
    TP_MESSAGES = [[165,
      98,
      1,
      68,
      32,
      32,
      84,
      80,
      32]]
    cancel_ike_thread = False
    cancel_pdc_thread = False
    cancel_read_thread = False
    ike_states = {'run_once': False,
     'ign_mode': -1,
     'handbrake': False,
     'motor_running': False,
     'vehicle_driving': False,
     'gear_pos': 'X',
     'aux_heat': False,
     'aux_vent': False}
    gm_states = {'run_once': False,
     'driverdoor': False,
     'passengerdoor': False,
     'driverreardoor': False,
     'passengerreardoor': False,
     'doorsopen': False,
     'zvunlocked': False,
     'zvlocked': False,
     'zvlockstate': False,
     'zvhardlocked': False,
     'zvprocessed': False,
     'indoorlights': False,
     'driverwindow': False,
     'passengerwindow': False,
     'driverrearwindow': False,
     'passengerrearwindow': False,
     'sunroof': False,
     'trunk': False,
     'bonnet': False,
     'trunkbuttonpress': False}
    lcm_states = {'run_once': False,
     'park': False,
     'low_beam': False,
     'high_beam': False,
     'fog_front': False,
     'fog_rear': False,
     'turn_left': False,
     'turn_right': False,
     'turn_fast_blink': False,
     'tail': False,
     'reverse': False,
     'hazard': False,
     'dim_level': 0,
     'diag_dim_level': [120, 1]}
    nav_states = {'gpsfix': False,
     'latitude': ' ',
     'longitude': ' ',
     'altitude': ' ',
     'time': ' ',
     'town': ' ',
     'street': ' '}
    reverse_hold = False
    clock_hold = False
    bm_next_hold = False
    bm_prev_hold = False
    nav_hold = False
    select_hold = False
    always_hold = False
    stw_up_hold = False
    stw_dn_hold = False
    stw_rt_hold = False
    stw_vol_up_active = False
    stw_vol_down_active = False
    stw_speak_hold = False
    stw_nav = False
    btn_bcpres = False
    btnx_hold = {1: False,
     2: False,
     3: False,
     4: False,
     5: False,
     6: False}
    lcm_on = 0
    lcm_delay = -1
    remote_state = 2
    remote_accept_cmd = True
    navmenu = False
    tonemenu = False
    selectmenu = False
    tpmenu = False
    pi_is_active = False
    pi_is_visible = False
    pass_bm_buttons = False
    cancel_ike_text = False
    cdc_play = True
    cdc_pause = False
    cdc_scan = False
    cdc_seek = False
    cdc_rnd = False
    cdc_skip_counter = 0
    cdc_state = 1
    track_change_counter = 0
    cdc_disc = 7
    cdc_track = 151
    cdc_track_prev = 148
    cdc_track_next = 153
    cdc_loaded = 64
    phone_mute = False
    got_audiomode = 0
    develop = False
    modefm = False
    modecd = False
    modetape = False
    modeaux = False
    modecis = False
    modealways = False
    device_path = None
    car_model = None
    gm_mode = -1
    engine_type = -1
    tcp_port = 8089
    tcp_send_ibus = False
    cdc_emu = False
    gpio_ntsc = False
    dsp_cd = False
    dsp_tuner = False
    ike_display = False
    ike_track = False
    wel_ike = False
    wel_iketxt = None
    wel_iketxt_hold = False
    text_scrollspeed = 220
    welcome_on_boot = True
    wel_light = False
    wel_light_time = 10
    wel_light_park = False
    wel_light_low = False
    wel_light_fog = False
    wel_light_nbrplate = False
    wel_light_turn_front = False
    wel_light_turn_back = False
    lev_light = False
    lev_light_time = 10
    keyin_off = False
    doors_off = False
    lev_light_ign_off = False
    day_time = False
    day_time_start = '00:00'
    day_time_end = '00:00'
    mir_unfold = False
    mir_unfold_ign = False
    mir_fold = False
    mir_fold_hold = False
    mir_state = 0
    seek_sec = 3000
    seek_max = 32
    use_stw_nav = False
    navhold_event = False
    inv_navturnbtn = False
    traffic = False
    gpio_gear_shift = -1
    gpio_gear_shift_trigger_time = 500
    gpio_gear_shift_up = 4
    gpio_gear_shift_down = 8
    rearcam_active = False
    gpio_rearcam = False
    gpio_rearcam_on = 5
    gpio_rearcam_off = 0
    gpio_rearcam_timeout = 15
    gpio_rearcam_speed = 30
    comfort_blink = False
    comfort_blink_time = 1500
    turn_light = False
    turn_light_time = 7000
    turn_light_max_speed = 50
    drl_light = False
    drl_light_park = False
    drl_light_fog = False
    drl_light_turn = False
    drl_light_low_beam = False
    obc_time = [None, None]
    obc_date = [None, None]
    obc_cons1 = '---'
    obc_cons2 = '---'
    obc_range = '---'
    obc_dist = -1
    obc_arr = '--:--'
    obc_limit = -1
    obc_avg = '---'
    obc_stpwtch = '----'
    obc_tmr1 = '--:--'
    obc_tmr1ind = False
    obc_tmr2 = '--:--'
    obc_tmr2ind = False
    obc_limitind = False
    obc_memoind = False
    obc_outtemp = '--.-'
    obc_fuellevel = '--'
    obc_fuellevel_low = False
    obc_speed_kmh = -1
    obc_speed_mph = -1
    obc_rpm = 0
    obc_coolant_C = 0
    obc_coolant_F = 32
    obc_oiltemp_C = 0
    obc_oiltemp_F = 32
    obc_oiltemp_tick = 0
    obc_auxventind = False
    obc_auxheatind = False
    obc_voltage = None
    obc_inserted_key = -1
    obc_vin = ''
    obc_odometer = -1
    obc_position = None
    obc_auxheat_available = False
    obc_auxheat_enable = False
    obc_auxvent_available = False
    obc_auxvent_enable = False
    obc_req_runs = False
    obc_settime = 0
    obc_req_runonce = False
    pdc_on = False
    pdc_type = 0
    pdc_timeout = 30
    pdc_timeout_off = False
    pdc_interval = 0.25
    pdc_bg = os.path.join(ADDON_MEDIA_PDC_PATH, 'bgs', 'default.png')
    zv_auto_lock = False
    zv_selective = False
    zv_auto_lock_speed = 6
    zv_auto_unlock_handbrake = False
    zv_auto_unlock_ign1 = False
    zv_auto_unlock_gear_p = False
    zv_auto_unlock_door_open = False
    aux_heat_zv_lock_hold = False
    map_auto_zoom = False
    map_auto_zoom_100 = 10
    map_auto_zoom_200 = 30
    map_auto_zoom_500 = 55
    map_auto_zoom_1000 = 80
    map_auto_zoom_2000 = 120
    map_auto_zoom_5000 = 145
    map_states = {'zoom_level': -1,
     'speed_old': -1,
     100: (176, 127, [170, 16, 1]),
     200: (176, 127, [170, 16, 2]),
     500: (176, 127, [170, 16, 4]),
     1000: (176, 127, [170, 16, 16]),
     2000: (176, 127, [170, 16, 17]),
     5000: (176, 127, [170, 16, 18])}
    nav_toggle_map = False
    flash_to_pass = False
    flash_to_pass_low_beam = False
    flash_to_pass_fog = False
    bm_sensor = False
    bm_sensor_level = 50
    volume_sink_r = False
    volume_sink_r_ibus = False
    volume_sink_r_value = 50
    volume_sink_r_value_ibus = 15
    volume_sink_r_delay = 0
    volume_sink_r_speed = 6
    volume_store = 100
    lcd_brightness = False
    lcd_brightness_value_on = 0
    lcd_brightness_value_off = 0
    mid_ignore_radio_text = False
    new_song = False
    cdch_state_counter = -1

    def __init__(self):
        self.startup_done = False
        self.gt_av_r_manual = False
        self.remote_lock_hold = False
        self.remote_unlock_hold = False
        self.remote_boot_hold = False
        self.OBCGUI = None
        self.obc_screen = 0
        self.lcm_read_coding = False
        self.lcm_ticker = None
        self.lcm_light = {'switch_turn_left': False,
         'switch_turn_right': False,
         'park_front_left': False,
         'park_front_right': False,
         'park_rear_left': False,
         'park_rear_right': False,
         'low_beam_left': False,
         'low_beam_right': False,
         'high_beam_left': False,
         'high_beam_right': False,
         'fog_front_left': False,
         'fog_front_right': False,
         'fog_rear_left': False,
         'fog_rear_right': False,
         'turn_front_left': False,
         'turn_front_right': False,
         'turn_rear_left': False,
         'turn_rear_right': False,
         'licence_plate': False,
         'reverse_left': False,
         'reverse_right': False}
        self.remote = RemoteKeyClass(2, lock_pres=self.remote_key_lock_pres, lock_hold=self.remote_key_lock_hold, lock_rel=self.remote_key_lock_rel, unlock_pres=self.remote_key_unlock_pres, unlock_hold=self.remote_key_unlock_hold, unlock_rel=self.remote_key_unlock_rel, boot_pres=self.remote_key_boot_pres, boot_hold=self.remote_key_boot_hold, boot_rel=self.remote_key_boot_rel)
        self.ike_text_scrolling = False
        self.ike_text_scroll_thread = Thread()
        self.ike_text_scroll_pause = False
        self.cancel_turn_left = False
        self.turning_left = False
        self.turning_fog_left = False
        self.cancel_turn_right = False
        self.turning_right = False
        self.turning_fog_right = False
        self.flashing_to_pass_low = False
        self.flashing_to_pass_fog = False
        self.gpio_rearcam_counter = 0
        self.pdc_req_cancel = False
        self.pdc_req_running = False
        self.pdc_counter = 30
        self.tel_rt_active = False
        self.bm_sensor_brightness = None
        self.shutdown_timer_enable = False
        self.shutdown_timer_time = 14
        self.obc_speed_unit = '---'
        self.obc_distance_unit = '---'
        self.obc_consumption_unit = '---'
        self.obc_fuel_unit = ''
        self.pdc_unit = ''
        self.obc_network = '---'
        self.obc_language = '---'
        self.obc_time_unit = '---'
        self.obc_temperature_unit = '--'
        self.obc_engine = '---'
        self.engine_cold_warning = False
        self.engine_cold_warning_text = 'ENGINE NOT WARM'
        self.engine_overheat_warning = False
        self.engine_overheat_warning_text = '! ENGINE OVER HEAT !'
        self.engine_overheat_temp = 100
        self.engine_cold_warned_before = False

    def read_ibus_packages(self):
        while True:
            packet = IBUS.read_bus_packet()
            if packet == -1:
                break
            if packet:
                thread = Thread(target=self.manage, args=(packet['src'], packet['dst'], packet['data']))
                thread.daemon = True
                thread.start()

        log('MANAGE: READ PACKAGES CLOSED')

    def simulate_ibus_packages(self, hex_message):
        hexstring_tmp = hex_message.upper().split(' ')
        src = int(hexstring_tmp[0], 16)
        dst = int(hexstring_tmp[2], 16)
        data = [ int(s, 16) for s in hexstring_tmp[3:-1] ]
        thread = Thread(target=self.manage, args=(src, dst, data))
        thread.daemon = True
        thread.start()

    def manage(self, src, dst, dat):
        if src == 208:
            if dat[0] == 91:
                self.lcm_state_put(dat)
                log('MANAGE: LCM STATE: %s' % ' '.join([ '%02X' % i for i in dat[1:] ]))
                return
            if dat[0] == 92:
                log('MANAGE: LCM DIM STATE')
                self.lcm_dim_level_put(dat)
                return
            if dst == 63 and dat[0] == 160:
                self.lcm_diag_state_put(dat)
                return
        if dst == 24:
            if dat == [1]:
                self.cdch_alive()
                log('MANAGE: RAD ASKED FOR CDC ALIVE')
                return
            if dat == [56, 0, 0]:
                self.cdch_state()
                log('MANAGE: RAD ASKED FOR CDC STATE')
                return
            if dat == [56, 3, 0]:
                self.cdch_play()
                log('MANAGE: RAD SAID PLAY')
                return
            if dat == [56, 2, 0]:
                self.cdch_pause()
                log('MANAGE: RAD SAID PAUSE')
                return
            if dat == [56, 7, 0]:
                self.cdch_scan(False)
                log('MANAGE: RAD SAID SCAN OFF')
                return
            if dat == [56, 7, 1]:
                self.cdch_scan(True)
                log('MANAGE: RAD SAID SCAN ON')
                return
            if dat == [56, 1, 0]:
                self.cdch_stop()
                log('MANAGE: RAD SAID STOP')
                return
            if dat == [56, 4, 1]:
                self.cdch_ffwd()
                log('MANAGE: RAD SAID FFWD')
                return
            if dat == [56, 4, 0]:
                self.cdch_frwd()
                log('MANAGE: RAD SAID FRWD')
                return
            if dat == [56, 10, 0]:
                self.cdch_next()
                log('MANAGE: RAD SAID NEXT')
                return
            if dat == [56, 10, 1]:
                self.cdch_prev()
                log('MANAGE: RAD SAID PREV')
                return
            if dat == [56, 8, 0]:
                self.cdch_rnd(False)
                log('MANAGE: RAD SAID RANDOM OFF')
                return
            if dat == [56, 8, 1]:
                self.cdch_rnd(True)
                log('MANAGE: RAD SAID RANDOM ON')
                return
        if dst in (191, 104):
            if dat == [2, 0, 3]:
                self._cdch_state()
                log("MANAGE: RAD SAID I'M READY")
                return
            if dat == [78, 1, 0]:
                self.gt_tv_on()
                log('MANAGE: GT TV ON')
                return
            if dat == [78, 0, 0]:
                self.gt_tv_off()
                log('MANAGE: GT TV OFF')
                return
            if dat[0] == 17:
                if dat[1] == 0:
                    log('MANAGE: IGN_OFF')
                    self.ign_off()
                    return
                if dat[1] == 1:
                    log('MANAGE: IGN_RAD')
                    self.ign_acc()
                    return
                if dat[1] == 3:
                    log('MANAGE: IGN_ON')
                    self.ign_on()
                    return
                if dat[1] == 7:
                    log('MANAGE: IGN_START')
                    self.ign_start()
                    return
            if dat[0] == 114:
                log('MANAGE: REMOTE KEY', 2)
                self.remote.key_event(dat)
                return
            if dat[0] == 25:
                self.obc_coolant_put(dat)
                return
            if dat[0] == 24:
                self.obc_speed_rpm_put(dat)
                return
            if dat[0] == 19:
                log('MANAGE: IKE STATE', 2)
                self.ike_state_put(dat)
                return
            if dat[0] == 21:
                log('MANAGE: IKE COONTRY CODING', 2)
                self.obc_country_coding_put(dat)
                return
            if dat[0] == 23:
                log('MANAGE: IKE ODOMETER', 2)
                self.obc_odometer_put(dat)
                return
        if src == 96:
            if dat[0] == 90:
                log('MANAGE: PDC TURNED ON', 1)
                self.pdc_req_start()
            if dat[0] == 160:
                log('MANAGE: PDC VALUE REPLY', 2)
                self.pdc_put_state(dat)
        if src == 0:
            if dat[0] == 122:
                log('MANAGE: GM STATE', 2)
                self.gm_state_put(dat)
        if dst == 104:
            if dat == [72, 64]:
                log('MANAGE: BM_NEXT_HOLD')
                self.btn_bm_next_hold()
                return
            if dat == [72, 128]:
                log('MANAGE: BM_NEXT_REL')
                self.btn_bm_next_rel()
                return
            if dat == [72, 80]:
                log('MANAGE: BM_PREV_HOLD')
                self.btn_bm_prev_hold()
                return
            if dat == [72, 144]:
                log('MANAGE: BM_PREV_REL')
                self.btn_bm_prev_rel()
                return
            if dat == [72, 84]:
                log('MANAGE: BM_REVERSE_HOLD')
                self.btn_bm_reverse_hold()
                return
            if dat == [72, 148]:
                log('MANAGE: BM_REVERSE_REL')
                self.btn_bm_reverse_rel()
                return
            if dat == [72, 4]:
                log('MANAGE: BM_TONE_PRES')
                self.btn_bm_tone_pres()
                return
            if dat == [72, 68]:
                log('MANAGE: BM_TONE_HOLD')
                self.btn_bm_tone_hold()
                return
            if dat == [72, 132]:
                log('MANAGE: BM_TONE_REL')
                self.btn_bm_tone_rel()
                return
            if dat == [72, 81]:
                log('MANAGE: BM_BTN1_HOLD')
                self.btn_bm_x_hold(7)
                return
            if dat == [72, 145]:
                log('MANAGE: BM_BTN1_REL')
                self.btn_bm_x_rel(1)
                return
            if dat == [72, 65]:
                log('MANAGE: BM_BTN2_HOLD')
                self.btn_bm_x_hold(8)
                return
            if dat == [72, 129]:
                log('MANAGE: BM_BTN2_REL')
                self.btn_bm_x_rel(2)
                return
            if dat == [72, 82]:
                log('MANAGE: BM_BTN3_HOLD')
                self.btn_bm_x_hold(9)
                return
            if dat == [72, 146]:
                log('MANAGE: BM_BTN3_REL')
                self.btn_bm_x_rel(3)
                return
            if dat == [72, 66]:
                log('MANAGE: BM_BTN4_HOLD')
                self.btn_bm_x_hold(10)
                return
            if dat == [72, 130]:
                log('MANAGE: BM_BTN4_REL')
                self.btn_bm_x_rel(4)
                return
            if dat == [72, 83]:
                log('MANAGE: BM_BTN5_HOLD')
                self.btn_bm_x_hold(11)
                return
            if dat == [72, 147]:
                log('MANAGE: BM_BTN5_REL')
                self.btn_bm_x_rel(5)
                return
            if dat == [72, 67]:
                log('MANAGE: BM_BTN6_HOLD')
                self.btn_bm_x_hold(12)
                return
            if dat == [72, 131]:
                log('MANAGE: BM_BTN6_REL')
                self.btn_bm_x_rel(6)
                return
            if src == 240 and dat[0] == 50 and ('%02X' % dat[1])[1] == '1':
                steps = ('%02X' % dat[1])[0]
                log('MANAGE: BM_VOL_KNOB_RIGHT -steps: %s' % int(steps, 16))
                self.btn_bm_vol_right(steps)
                return
            if src == 240 and dat[0] == 50 and ('%02X' % dat[1])[1] == '0':
                steps = ('%02X' % dat[1])[0]
                log('MANAGE: BM_VOL_KNOB_LEFT -steps: %s' % int(steps, 16))
                self.btn_bm_vol_left(steps)
                return
            if src == 240 and dat == [72, 134]:
                log('MANAGE: BM_VOL_KNOB_REL')
                self.btn_bm_vol_rel()
                return
            if src == 240 and dat == [72, 70]:
                log('MANAGE: BM_VOL_KNOB_HOLD')
                self.btn_bm_vol_hold()
                return
            if dat == [72, 35]:
                log('MANAGE: BM_MODE_PRES')
                self.btn_bm_mode_pres()
                self.btn_bm_always_hold('mode')
                return
            if dat == [72, 99]:
                log('MANAGE: BM_MODE_HOLD')
                self.btn_bm_always_hold('mode')
                return
            if dat == [72, 163]:
                log('MANAGE: BM_MODE_REL')
                self.btn_bm_always_rel('mode')
                return
            if dat == [72, 49]:
                self.btn_fm_pres()
                log('MANAGE: BM_FM_PRES')
                return
            if dat == [72, 113]:
                self.btn_fm_hold()
                log('MANAGE: BM_FM_HOLD')
                return
            if dat == [72, 177]:
                self.btn_fm_rel()
                log('MANAGE: BM_FM_REL')
                return
            if dat == [72, 33]:
                self.btn_am_pres()
                log('MANAGE: BM_AM_PRES')
                return
            if dat == [72, 97]:
                self.btn_am_hold()
                log('MANAGE: BM_AM_HOLD')
                return
            if dat == [72, 161]:
                self.btn_am_rel()
                log('MANAGE: BM_AM_REL')
                return
        if src == 80:
            if dat == [50, 17]:
                log('MANAGE: STW_VOL_UP')
                self.btn_stw_vol_up()
                return
            if dat == [50, 16]:
                log('MANAGE: STW_VOL_DOWN')
                self.btn_stw_vol_down()
                return
            if dat == [59, 1]:
                log('MANAGE: STW_UP_PRES')
                self.btn_stw_up_pres()
                return
            if dat == [59, 17]:
                log('MANAGE: STW_UP_HOLD')
                self.btn_stw_up_hold()
                return
            if dat == [59, 33]:
                log('MANAGE: STW_UP_REL')
                self.btn_stw_up_rel()
                return
            if dat == [59, 8]:
                log('MANAGE: STW_DN_PRES')
                self.btn_stw_down_pres()
                return
            if dat == [59, 24]:
                log('MANAGE: STW_DN_HOLD')
                self.btn_stw_down_hold()
                return
            if dat == [59, 40]:
                log('MANAGE: STW_DN_REL')
                self.btn_stw_down_rel()
                return
            if dat == [59, 18]:
                log('MANAGE: STW_R/T_HOLD')
                self.btn_stw_rt_hold()
                return
            if dat in [[59, 34], [1]]:
                log('MANAGE: STW_R/T_REL')
                self.btn_stw_rt_rel()
                return
            if dat == [59, 64]:
                log('MANAGE: STW_R/T_ON with Phone')
                self.btn_stw_rt_on()
                return
            if dat == [59, 0]:
                log('MANAGE: STW_R/T_OFF with Phone')
                self.btn_stw_rt_off()
                return
            if dat == [59, 128]:
                log('MANAGE: STW_SPEAK_PRES')
                return
            if dat == [59, 144]:
                log('MANAGE: STW_SPEAK_HOLD')
                self.btn_stw_speak_hold()
                return
            if dat == [59, 160]:
                log('MANAGE: STW_SPEAK_REL')
                self.btn_stw_speak_rel()
                return
        if dst == 128:
            if dat[:11] == [35,
             65,
             48,
             32,
             32,
             32,
             84,
             82,
             3,
             32,
             57]:
                if not self.ike_text_scrolling:
                    time.sleep(0.1)
                self.ike_clear_display(0)
                log('MANAGE: Clear IKE Track Message in IKE', 2)
                return
            if dat[:16] == [35,
             65,
             48,
             32,
             32,
             32,
             32,
             32,
             3,
             67,
             68,
             67,
             32,
             55,
             45,
             57]:
                if not self.ike_text_scrolling:
                    time.sleep(0.1)
                    self.ike_clear_display(0)
                log('MANAGE: Clear IKE Track Message in IKE', 2)
                return
            if dat[:16] == [35,
             98,
             48,
             7,
             32,
             32,
             32,
             32,
             32,
             8,
             67,
             68,
             32,
             55,
             45,
             57]:
                if not self.ike_text_scrolling:
                    time.sleep(0.1)
                    self.ike_clear_display(0)
                log('MANAGE: Clear IKE Track Message in IKE', 2)
                return
            if dat[0] == 84:
                log('MANAGE: VIN', 2)
                self.obc_vin_put(dat)
        if dst == 59:
            if dat == [165,
             98,
             1,
             65,
             67,
             68,
             55]:
                self.gt_mode_cd()
                log('MANAGE: BMBT TEXT: CD7')
                return
            if dat[:7] == [165,
             98,
             1,
             65,
             67,
             68,
             55]:
                self.gt_mode_cd()
                log('MANAGE: BMBT TEXT: CD7')
                return
            if dat[:7] == [165,
             98,
             1,
             65,
             67,
             68,
             54]:
                self.gt_mode_cis()
                log('MANAGE: BMBT TEXT: CD6 CIS')
                return
            if dat == [165,
             98,
             1,
             65,
             67,
             68]:
                self.gt_mode_tape()
                log('MANAGE: BMBT TEXT: CD E46 BM-CD')
                return
            if dat[:3] == [35, 98, 16]:
                if dat[3:7] == [84,
                 82,
                 32,
                 32]:
                    self.gt_mode_cd()
                    self.cdch_play()
                    log('MANAGE: BMBT TEXT: "TR  "')
                    return
                if dat[3:6] == [67, 68, 67]:
                    self.gt_mode_cd()
                    log('MANAGE: BMBT TEXT: CDC...')
                    return
                if dat[3:10] == [78,
                 79,
                 32,
                 68,
                 73,
                 83,
                 67] or dat[3:10] == [78,
                 111,
                 32,
                 68,
                 105,
                 115,
                 99]:
                    log('MANAGE: BMBT TEXT: NO DISC')
                    return
                if dat[3:7] == [84,
                 65,
                 80,
                 69]:
                    self.gt_mode_tape()
                    log('MANAGE: BMBT TEXT: TAPE...')
                    return
                if dat[3:10] == [78,
                 79,
                 32,
                 84,
                 65,
                 80,
                 69]:
                    self.gt_mode_tape()
                    log('MANAGE: BMBT TEXT: NO TAPE')
                    return
                if dat[3:6] == [67, 68, 32]:
                    self.gt_mode_tape()
                    log('MANAGE: BMBT TEXT: CD / E46 CD Screen')
                    return
                if dat[3:6] == [65, 85, 88]:
                    self.gt_mode_aux()
                    log('MANAGE: BMBT TEXT: AUX ')
                    return
            if dat[:9] == [35,
             196,
             32,
             67,
             68,
             32,
             55,
             45,
             57]:
                self.gt_mode_cd()
                log('MANAGE: BMBT TEXT: CD 7-9...')
                return
            if dat[:7] == [35,
             80,
             32,
             84,
             65,
             80,
             69]:
                self.gt_mode_tape()
                log('MANAGE: BMBT TEXT: TAPE')
                return
            if dat[:10] == [35,
             80,
             32,
             78,
             79,
             32,
             84,
             65,
             80,
             69]:
                self.gt_mode_tape()
                log('MANAGE: BMBT TEXT: NO TAPE')
                return
            if dat[:3] == [35, 64, 32] or dat[:3] == [35, 80, 32]:
                self.gt_mode_radio()
                self.cdch_state()
                log('MANAGE: BMBT TEXT: what ever')
                return
            if dat[:18] == [35,
             98,
             48,
             32,
             32,
             7,
             32,
             32,
             32,
             32,
             32,
             8,
             67,
             68,
             32,
             55,
             45,
             57]:
                self.gt_mode_cd()
                log('MANAGE: BMBT TEXT: CD 7-9...')
                return
            if dat[:16] == [35,
             98,
             48,
             32,
             32,
             7,
             32,
             32,
             32,
             32,
             32,
             8,
             84,
             65,
             80,
             69]:
                self.gt_mode_tape()
                log('MANAGE: BMBT TEXT: TAPE')
                return
            if dat[:19] == [35,
             98,
             48,
             32,
             32,
             7,
             32,
             32,
             32,
             32,
             32,
             8,
             78,
             79,
             32,
             84,
             65,
             80,
             69]:
                self.gt_mode_tape()
                log('MANAGE: BMBT TEXT: NO TAPE')
                return
            if dat[:19] == [35,
             98,
             48,
             7,
             32,
             32,
             32,
             32,
             32,
             8,
             32,
             32,
             78,
             79,
             32,
             84,
             65,
             80,
             69]:
                self.gt_mode_tape()
                log('MANAGE: BMBT TEXT: NO TAPE')
                return
            if dat in self.TUNER_MODES:
                self.gt_mode_radio()
                self.cdch_state()
                log('MANAGE: BMBT TEXT: FMD %s' % [ chr(x) for x in dat ])
                return
            if dat in self.TP_MESSAGES:
                self.gt_tp_message()
                log('MANAGE: TRAFFIC')
                return
            if dat == [70, 1]:
                self.gt_nav_menu_on()
                log('MANAGE: NAV MENU ON')
                return
            if dat == [70, 2]:
                self.gt_radio_menu_off()
                log('MANAGE: RADIO MENU OFF')
                return
            if dat == [70, 4]:
                log('MANAGE: SELECT MENU OFF')
                return
            if dat == [70, 8]:
                self.gt_tone_menu_off()
                log('MANAGE: TONE MENU OFF')
                return
            if dat == [70, 12]:
                self.gt_select_tone_menu_off()
                log('MANAGE: TONE + SELECT MENU OFF')
                return
            if dat == [55, 12]:
                log('MANAGE: SELECT MENU ON')
                return
            if dat[:8] == [33,
             96,
             0,
             64,
             84,
             80,
             32,
             32]:
                log('MANAGE: TP MENU ON')
                return
            if dat[:4] == [165,
             98,
             1,
             65]:
                return
            if dat == [33,
             96,
             0,
             7,
             80,
             54,
             58,
             32,
             78,
             79,
             32,
             68,
             73,
             83,
             67,
             32,
             32,
             32,
             6,
             6,
             6]:
                self.gt_clear_cd_list()
                self.gt_select_tone_menu_off()
                log('MANAGE: BMBT Bottom Right " P6: NO DISC   "')
                return
            if dat[0] == 73 and ('%02X' % dat[1])[0] == '8':
                steps = ('%02X' % dat[1])[1]
                log('MANAGE: BM_NAV_KNOB_RIGHT -steps: %s' % int(steps, 16))
                self.btn_bm_nav_right(steps)
                return
            if dat[0] == 73 and ('%02X' % dat[1])[0] == '0':
                steps = ('%02X' % dat[1])[1]
                log('MANAGE: BM_NAV_KNOB_LEFT -steps: %s' % int(steps, 16))
                self.btn_bm_nav_left(steps)
                return
            if dat == [72, 133]:
                log('MANAGE: BM_NAV_KNOB_REL')
                self.btn_bm_nav_rel()
                return
            if dat == [72, 69]:
                log('MANAGE: BM_NAV_KNOB_HOLD')
                self.btn_bm_nav_hold()
                return
        if dst == 192:
            if dat[:9] == [35,
             196,
             48,
             67,
             68,
             32,
             55,
             45,
             57]:
                self.mid_mode_cd()
                log('MANAGE: MID TEXT: CD 7-9...')
                return
            if src == 104 and dat == [35,
             146,
             48,
             82,
             97,
             115,
             112,
             98,
             101,
             114,
             114,
             121,
             80,
             105]:
                log('MANAGE: MID TEXT: RaspberryPi')
                return
            if dat[:7] == [35,
             146,
             48,
             84,
             65,
             80,
             69] or dat[:7] == [35,
             130,
             48,
             84,
             65,
             80,
             69]:
                self.mid_mode_tape()
                log('MANAGE: MID TEXT: TAPE')
                return
            if dat[:11] == [35,
             196,
             48,
             32,
             78,
             79,
             32,
             84,
             65,
             80,
             69]:
                self.mid_mode_tape()
                log('MANAGE: MID TEXT: NO TAPE')
                return
            if dat[:1] == [35]:
                self.mid_mode_radio()
                log('MANAGE: MID TEXT: RADIO')
                return
        if src == 192 and dst == 255:
            if dat == [32,
             1,
             176,
             0]:
                self.btn_mid_audio()
                log('MANAGE: MID BTN AUDIO')
                return
            if dat == [32,
             32,
             142,
             0]:
                self.btn_mid_onoff()
                log('MANAGE: MID BTN ON/OFF')
                return
        if dst == 200:
            if dat == [59, 144]:
                log('MANAGE: STW_SPEAK_HOLD')
                self.btn_stw_speak_hold()
                return
            if dat == [59, 160]:
                log('MANAGE: STW_SPEAK_REL')
                self.btn_stw_speak_rel()
                return
            if dat[0] == 162:
                log('MANAGE: NAV POSITION', 2)
                self.nav_position_put(dat)
                return
            if dat[0] == 164:
                log('MANAGE: NAV LOCATION', 2)
                self.nav_location_put(dat)
                return
        if dst == 240:
            if dat == [74, 255]:
                self.radio_led_on()
                log('MANAGE: RADIO LED TURNED ON')
                return
            if dat == [74, 0]:
                self.radio_led_off()
                log('MANAGE: RADIO LED TURNED OFF')
                return
        if dst in (231, 255):
            if dat[:2] == [36, 1]:
                log('OBC: TIME', 2)
                self.obc_time_put(dat)
                return
            if dat[:2] == [36, 2]:
                log('OBC: DATE', 2)
                self.obc_date_put(dat)
                return
            if dat[:2] == [36, 3]:
                log('OBC: OUTTEMP', 2)
                self.obc_outtemp_put(dat)
                return
            if dat[:2] == [36, 4]:
                log('OBC: CONS1', 2)
                self.obc_cons1_put(dat)
                return
            if dat[:2] == [36, 5]:
                log('OBC: CONS2', 2)
                self.obc_cons2_put(dat)
                return
            if dat[:2] == [36, 6]:
                log('OBC: RANGE', 2)
                self.obc_range_put(dat)
                return
            if dat[:2] == [36, 7]:
                log('OBC: DIST', 2)
                self.obc_dist_put(dat)
                return
            if dat[:2] == [36, 8]:
                log('OBC: ARR', 2)
                self.obc_arr_put(dat)
                return
            if dat[:2] == [36, 9]:
                log('OBC: LIMIT', 2)
                self.obc_limit_put(dat)
                return
            if dat[:2] == [36, 10]:
                log('OBC: AVG', 2)
                self.obc_avg_put(dat)
                return
            if dat[:2] == [36, 14]:
                log('OBC: STPWTCH', 2)
                self.obc_stpwtch_put(dat)
                return
            if dat[:2] == [36, 15]:
                log('OBC: TMR1', 2)
                self.obc_tmr1_put(dat)
                return
            if dat[:2] == [36, 16]:
                log('OBC: TMR2', 2)
                self.obc_tmr2_put(dat)
                return
            if dat[0] == 42:
                log('OBC: IND', 2)
                self.obc_ind_put(dat)
            if src == 200 and dat[:1] == [43]:
                log('PHONE: STATE')
                self.phone_state(dat)
                return
            if dat == [71, 0, 15]:
                log('MANAGE: BM_SEL_PRES')
                self.btn_bm_select_pres()
                return
            if dat == [71, 0, 79]:
                log('MANAGE: BM_SEL_HOLD')
                self.btn_bm_select_hold()
                return
            if dat == [71, 0, 143]:
                log('MANAGE: BM_SEL_REL')
                self.btn_bm_select_rel()
                return
            if dat == [71, 0, 56]:
                log('MANAGE: BM_INFO_PRES')
                self.btn_bm_info_pres()
                return
            if dat == [71, 0, 184]:
                log('MANAGE: BM_INFO_REL')
                return
            if dat == [72, 71]:
                log('MANAGE: BM_CLK_HOLD')
                self.btn_bm_clock_hold()
                return
            if dat == [72, 135]:
                log('MANAGE: BM_CLK_REL')
                self.btn_bm_clock_rel()
                return
            if dat == [72, 48]:
                log('MANAGE: BM_SCREEN_PRES')
                self.btn_bm_screen_pres()
                return
            if dat == [72, 112]:
                log('MANAGE: BM_SCREEN_HOLD')
                self.btn_bm_screen_hold()
                return
            if dat == [72, 176]:
                log('MANAGE: BM_SCREEN_REL')
                self.btn_bm_screen_rel()
                return
            if dat == [72, 116]:
                log('MANAGE: BM_MENU_HOLD')
                self.btn_bm_always_hold('menu')
                return
            if dat == [72, 180]:
                log('MANAGE: BM_MENU_REL')
                self.btn_bm_always_rel('menu')
                return
            if dat == [72, 72]:
                log('MANAGE: BM_PHONE_HOLD')
                self.btn_bm_always_hold('phone')
                return
            if dat == [72, 136]:
                log('MANAGE: BM_PHONE_REL')
                self.btn_bm_always_rel('phone')
                return
            if dat == [87, 2]:
                log('MANAGE: IKE_BC_PRES')
                self.btn_bc_pres()
                return
        if src == 68:
            if dat[0] == 116:
                log('MANAGE: EWS_KEY')
                self.ews_key_put(dat)
                return
        if dst == 106:
            if dat == [54, 160]:
                if self.dsp_tuner:
                    self.dsp_set_tuner()
        if dst == 63:
            if src == 240 and dat[0] == 160:
                self.bm_set_state(dat)
                return
            if src == 127 and dat[0] == 160:
                self.obc_voltage_put(dat)
                return

    def cdch_init(self):
        if not self.cdc_emu:
            return
        IBUS.write_bus_packet(24, 255, [2, 1], True)
        time.sleep(0.05)
        IBUS.write_bus_packet(24, 255, [2, 0], True)
        time.sleep(0.1)
        IBUS.write_bus_packet(24, 104, [57,
         2,
         9,
         0,
         self.cdc_loaded,
         0,
         self.cdc_disc,
         self.cdc_track], True)

    def cdch_alive(self):
        if not self.cdc_emu:
            return
        IBUS.write_bus_packet(24, 255, [2, 0], True)
        log('CDC EMU: SENT CDC ALIVE')

    def cdch_state(self):
        self._cdch_state()
        if self.cdch_state_counter > 0:
            self.cdch_state_counter = 9
            return
        thread = Thread(target=self.cdch_state_thread)
        thread.daemon = True
        self.cdch_state_counter = 9
        thread.start()

    def cdch_state_thread(self):
        while self.cdch_state_counter >= 0:
            self.cdch_state_counter -= 1
            time.sleep(1)

        self._cdch_state()

    def _cdch_state(self):
        if self.modecis:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             9,
             0,
             32,
             0,
             6,
             153], True)
            log('CDC EMU: SENT CDC STATE: CIS')
            return
        if not self.cdc_emu:
            return
        if self.track_change_counter < 20:
            self.cdc_track = 151
        if self.track_change_counter >= 20:
            self.cdc_track = 150
        if self.track_change_counter > 40:
            self.track_change_counter = 0
        self.track_change_counter += 1
        if self.cdc_state == 7:
            IBUS.write_bus_packet(24, 104, [57,
             7,
             153,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
            log('CDC EMU: SENT CDC STATE: SCAN')
        elif self.cdc_state in (5, 6):
            IBUS.write_bus_packet(24, 104, [57,
             2,
             137,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
            log('CDC EMU: SENT CDC STATE: SEEK')
        elif self.cdc_state == 8:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             169,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
            log('CDC EMU: SENT CDC STATE: RANDOM')
        elif self.cdc_state == 2:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             0,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
            log('CDC EMU: SENT CDC STATE: PLAY')
        elif self.cdc_state == 1:
            IBUS.write_bus_packet(24, 104, [57,
             1,
             0,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
            log('CDC EMU: SENT CDC STATE: PAUSE')
        elif self.cdc_state == 0:
            IBUS.write_bus_packet(24, 104, [57,
             0,
             140,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
            log('CDC EMU: SENT CDC STATE: STOP')
        else:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             2,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
            log('CDC EMU: SENT CDC STATE: PLAY REQUEST=PAUSE')

    def cdch_play(self):
        if not self.cdc_emu:
            return
        if self.cdc_state in (5, 6):
            IBUS.write_bus_packet(24, 104, [57,
             2,
             137,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
        if self.cdc_state == 8:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             169,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
            self.cdc_rnd = False
        if self.cdc_state == 7:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             153,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
        else:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             2,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
        self.cdc_state = 2
        if self.modecd and self.pi_is_active:
            KODI.track_play()

    def cdch_pause(self):
        if not self.cdc_emu:
            return
        IBUS.write_bus_packet(24, 104, [57,
         1,
         0,
         0,
         self.cdc_loaded,
         0,
         self.cdc_disc,
         self.cdc_track], True)
        self.cdc_state = 1
        if self.modecd and self.pi_is_active:
            KODI.track_pause()

    def cdch_stop(self):
        if not self.cdc_emu:
            return
        IBUS.write_bus_packet(24, 104, [57,
         0,
         140,
         0,
         self.cdc_loaded,
         0,
         self.cdc_disc,
         self.cdc_track], True)
        self.cdc_state = 0

    def cdch_scan(self, enabled):
        if not self.cdc_emu:
            return
        time.sleep(0.25)
        if enabled:
            self.cdc_state = 7
            IBUS.write_bus_packet(24, 104, [57,
             7,
             153,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
        else:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             137,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
            self.cdc_state = 2

    def cdch_rnd(self, enabled):
        if not self.cdc_emu:
            return
        time.sleep(0.25)
        if enabled:
            self.cdc_state = 8
            IBUS.write_bus_packet(24, 104, [57,
             2,
             169,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
        else:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             137,
             0,
             self.cdc_loaded,
             0,
             self.cdc_disc,
             self.cdc_track], True)
            self.cdc_state = 2

    def cdch_ffwd(self):
        if not self.cdc_emu:
            return
        time.sleep(0.25)
        self.cdc_state = 5
        IBUS.write_bus_packet(24, 104, [57,
         3,
         137,
         0,
         self.cdc_loaded,
         0,
         self.cdc_disc,
         self.cdc_track], True)

    def cdch_frwd(self):
        if not self.cdc_emu:
            return
        time.sleep(0.25)
        self.cdc_state = 6
        IBUS.write_bus_packet(24, 104, [57,
         4,
         137,
         0,
         self.cdc_loaded,
         0,
         self.cdc_disc,
         self.cdc_track], True)

    def cdch_next(self):
        if not self.cdc_emu:
            return
        log('CDC: NEXT TRACK %02X' % self.cdc_track_next)
        IBUS.write_bus_packet(24, 104, [57,
         2,
         9,
         0,
         self.cdc_loaded,
         0,
         self.cdc_disc,
         self.cdc_track_next], True)
        if self.cdc_track_next == 153:
            self.cdc_track_next = 152
        else:
            self.cdc_track_next = 153
        self.cdc_state = 2

    def cdch_prev(self):
        if not self.cdc_emu:
            return
        log('CDC: PREV TRACK %02X' % self.cdc_track_prev)
        IBUS.write_bus_packet(24, 104, [57,
         2,
         9,
         0,
         self.cdc_loaded,
         0,
         self.cdc_disc,
         self.cdc_track_prev], True)
        if self.cdc_track_prev == 148:
            self.cdc_track_prev = 149
        else:
            self.cdc_track_prev = 148
        self.cdc_state = 2

    def btn_bm_vol_right(self, steps = '1'):
        if self.pass_bm_buttons and self.modealways:
            KODI.volume_up(steps)
        if self.volume_sink_r_ibus:
            KODI.volume_backup = -1

    def btn_bm_vol_left(self, steps = '1'):
        if self.pass_bm_buttons and self.modealways:
            KODI.volume_down(steps)
        if self.volume_sink_r_ibus:
            KODI.volume_backup = -1

    def btn_bm_vol_hold(self):
        return
        if self.pass_bm_buttons and self.modealways:
            self.nav_hold = True
            if self.navhold_event != ' ':
                xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.%s", "id": 1 }' % self.navhold_event)

    def btn_bm_vol_rel(self):
        return
        if self.pass_bm_buttons and self.modealways:
            if self.nav_hold:
                if self.navhold_event == ' ':
                    KODI.select()
            else:
                KODI.select()
            self.nav_hold = False

    def btn_bm_nav_right(self, steps = '1'):
        if self.pass_bm_buttons:
            KODI.down(steps) if self.inv_navturnbtn else KODI.up(steps)

    def btn_bm_nav_left(self, steps = '1'):
        if self.pass_bm_buttons:
            KODI.up(steps) if self.inv_navturnbtn else KODI.down(steps)

    def btn_bm_nav_hold(self):
        if self.pass_bm_buttons:
            self.nav_hold = True
            if self.navhold_event != ' ':
                xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.%s", "id": 1 }' % self.navhold_event)

    def btn_bm_nav_rel(self):
        if self.pass_bm_buttons:
            if self.nav_hold:
                if self.navhold_event == ' ':
                    KODI.select()
            else:
                KODI.select()
            self.nav_hold = False

    def btn_bm_next_hold(self):
        if not self.pass_bm_buttons:
            return
        log('state next hold: %s' % self.bm_next_hold)
        if self.bm_next_hold:
            return
        self.bm_next_hold = True
        speed = 4
        ticker = self.seek_sec
        while self.bm_next_hold:
            if ticker >= self.seek_sec:
                KODI.track_seek(speed)
                speed *= 2
                if speed > self.seek_max:
                    speed = self.seek_max
                ticker = 0
            time.sleep(0.001)
            ticker += 1

    def btn_bm_next_rel(self):
        self.bm_prev_hold = False
        if not self.pass_bm_buttons:
            return
        if self.bm_next_hold:
            self.bm_next_hold = False
            KODI.track_play()
        else:
            DBL_NEXT.click()

    def btn_bm_prev_hold(self):
        if not self.pass_bm_buttons:
            return
        if self.bm_prev_hold:
            return
        self.bm_prev_hold = True
        speed = -4
        ticker = self.seek_sec
        while self.bm_prev_hold:
            if ticker >= self.seek_sec:
                KODI.track_seek(speed)
                speed *= 2
                if speed > self.seek_max:
                    speed = self.seek_max
                ticker = 0
            time.sleep(0.001)
            ticker += 1

    def btn_bm_prev_rel(self):
        self.bm_next_hold = False
        if not self.pass_bm_buttons:
            return
        if self.bm_prev_hold:
            self.bm_prev_hold = False
            KODI.track_play()
        else:
            DBL_PREV.click()

    def btn_bm_reverse_hold(self):
        if self.pass_bm_buttons:
            self.reverse_hold = True
            KODI.home()

    def btn_bm_reverse_rel(self):
        if not self.pi_is_active:
            KODI.action(KODI.get_addon_setting('bm_btn_30'))
            return
        if self.pass_bm_buttons:
            if self.reverse_hold:
                pass
            else:
                KODI.back()
            self.reverse_hold = False

    def btn_bm_x_hold(self, button_number):
        if not self.pass_bm_buttons:
            return
        self.btnx_hold[button_number - 6] = True
        if KODI.get_addon_setting('bm_btn_%s' % button_number) in KODI_ACTIONS.keys():
            self.btn_bm_action(KODI_ACTIONS.get(KODI.get_addon_setting('bm_btn_%s' % button_number)))
        else:
            self.btn_bm_action(KODI.get_addon_setting('bm_btn_%s' % button_number))

    def btn_bm_x_rel(self, button_number):
        if not self.pass_bm_buttons:
            return
        if self.btnx_hold[button_number]:
            pass
        elif KODI.get_addon_setting('bm_btn_%s' % button_number) in KODI_ACTIONS.keys():
            self.btn_bm_action(KODI_ACTIONS.get(KODI.get_addon_setting('bm_btn_%s' % button_number)))
        else:
            self.btn_bm_action(KODI.get_addon_setting('bm_btn_%s' % button_number))
        self.btnx_hold[button_number] = False

    def btn_bm_action(self, action_event):
        if self.modecd:
            pass
        elif self.modetape:
            pass
        else:
            if self.modeaux:
                return note(heading=language('No Function in AUX-Mode'), message=language('Key 1-6 sets Volumelevel'), time=2000)
            if self.modecis or self.modealways:
                return
        if action_event == '':
            return note(language('No Function for Button defined'), time=2000)
        return KODI.action(action_event)

    def btn_bm_tone_pres(self):
        self.gt_av_r_manual = False

    def btn_bm_tone_hold(self):
        pass

    def btn_bm_tone_rel(self):
        self.gt_tone_menu()

    def btn_bm_select_pres(self):
        self.gt_av_r_manual = False

    def btn_bm_select_hold(self):
        if self.pass_bm_buttons:
            self.select_hold = True

    def btn_bm_select_rel(self):
        if self.pass_bm_buttons:
            if self.select_hold:
                pass
            else:
                xbmc.executebuiltin('Action(ContextMenu)')
            self.select_hold = False
        else:
            self.gt_select_menu()

    def btn_bm_info_pres(self):
        self.gt_av_r_manual = False
        self.tpmenu = True
        self.pi_hide()

    def btn_bm_info_hold(self):
        pass

    def btn_bm_info_rel(self):
        pass

    def btn_bm_mode_pres(self):
        self.gt_av_r_manual = False

    def btn_bm_mode_hold(self):
        pass

    def btn_bm_mode_rel(self):
        pass

    def btn_fm_pres(self):
        self.gt_av_r_manual = False

    def btn_fm_hold(self):
        self.btn_bm_always_hold('fm')

    def btn_fm_rel(self):
        self.btn_bm_always_rel('fm')

    def btn_am_pres(self):
        self.gt_av_r_manual = False

    def btn_am_hold(self):
        self.btn_bm_always_hold('am')

    def btn_am_rel(self):
        self.btn_bm_always_rel('am')

    def btn_bm_clock_hold(self):
        self.clock_hold = True
        self.gt_av_r_manual = False
        self.gt_av_r_on(False)
        ticker = 0
        while self.clock_hold:
            if ticker >= 3000:
                self.bm_led('green')
                time.sleep(0.5)
                self.bm_led('red')
                time.sleep(0.5)
                self.bm_led('yellow')
                time.sleep(0.5)
                self.bm_led('off')
                os.popen('sudo systemctl restart mediacenter')
                self.clock_hold = False
            time.sleep(0.001)
            ticker += 1

    def btn_bm_clock_rel(self):
        if self.clock_hold:
            pass
        else:
            self.gt_av_r_on(True)
            self.gt_av_r_manual = True
        self.clock_hold = False

    def btn_bm_screen_pres(self):
        self.gt_av_r_manual = False

    def btn_bm_screen_hold(self):
        pass

    def btn_bm_screen_rel(self):
        if self.pi_is_active:
            self.pi_show()

    def btn_bm_always_pres(self, action):
        if self.modealways:
            event_pres = None
            if action == 'menu':
                event_pres = None
            elif action == 'mode':
                event_pres = None
            elif action == 'fm':
                event_pres = None
            elif action == 'am':
                event_pres = None
            elif action == 'phone':
                event_pres = None
            event_pres

    def btn_bm_always_hold(self, action):
        if self.modealways:
            self.always_hold = True
            event_hold = None
            if action == 'menu':
                event_hold = None
            elif action == 'mode':
                event_hold = None
            elif action == 'fm':
                event_hold = None
            elif action == 'am':
                event_hold = None
            elif action == 'phone':
                event_hold = None
            event_hold

    def btn_bm_always_rel(self, action):
        if self.modealways:
            event_hold_rel = None
            event_rel = None
            if action == 'menu':
                event_hold_rel = None
                event_rel = None
            elif action == 'mode':
                event_hold_rel = None
                event_rel = None
            elif action == 'fm':
                event_hold_rel = None
                event_rel = None
            elif action == 'am':
                event_hold_rel = None
                event_rel = None
            elif action == 'phone':
                event_hold_rel = None
                event_rel = None
            else:
                log('UNKNOWN BTN BM ALWAYS KEY', 2)
                event_hold_rel = None
                event_rel = None
            if self.always_hold:
                event_hold_rel
            else:
                event_rel
        self.always_hold = False

    def btn_stw_vol_up(self):
        if self.gpio_gear_shift == 1:
            if not self.stw_vol_up_active:
                self.stw_vol_up_active = True
                log('GEAR SHIFT: UP - GPIO%s' % GPIO_GEAR_SHIFT_UP.pinnumber)
                GPIO_GEAR_SHIFT_UP.trigger(self.gpio_gear_shift_trigger_time)
                self.stw_vol_up_active = False
        elif self.modealways:
            KODI.volume_up()
        if self.volume_sink_r_ibus:
            KODI.volume_backup = -1

    def btn_stw_vol_down(self):
        if self.gpio_gear_shift == 1:
            if not self.stw_vol_down_active:
                self.stw_vol_down_active = True
                log('GEAR SHIFT: DOWN - GPIO%s' % GPIO_GEAR_SHIFT_DOWN.pinnumber)
                GPIO_GEAR_SHIFT_DOWN.trigger(self.gpio_gear_shift_trigger_time)
                self.stw_vol_down_active = False
        elif self.modealways:
            KODI.volume_down()
        if self.volume_sink_r_ibus:
            KODI.volume_backup = -1

    def btn_stw_up_pres(self):
        if self.gpio_gear_shift == 2:
            log('GEAR SHIFT: UP - GPIO%s' % GPIO_GEAR_SHIFT_UP.pinnumber)
            GPIO_GEAR_SHIFT_UP.trigger(self.gpio_gear_shift_trigger_time)

    def btn_stw_up_hold(self):
        if self.stw_up_hold or self.gpio_gear_shift == 2:
            return
        self.stw_up_hold = True
        if self.ike_text_scrolling:
            self.ike_text_scrolling = False
        if self.tel_rt_active:
            log('PHONE: Ignore STW UP', 2)
            return
        if self.stw_nav:
            KODI.select()
        else:
            speed = 4
            ticker = self.seek_sec
            while self.stw_up_hold:
                if ticker >= self.seek_sec:
                    KODI.track_seek(speed)
                    speed *= 2
                    if speed > self.seek_max:
                        speed = self.seek_max
                    ticker = 0
                time.sleep(0.001)
                ticker += 1

    def btn_stw_up_rel(self):
        if self.gpio_gear_shift == 2:
            return
        if self.tel_rt_active:
            log('PHONE: Ignore STW UP', 2)
            self.stw_up_hold = False
            return
        if self.stw_nav:
            if self.stw_up_hold:
                self.stw_up_hold = False
            else:
                KODI.up()
        else:
            self.stw_dn_hold = False
            if self.stw_up_hold:
                self.stw_up_hold = False
                KODI.track_play()
            else:
                KODI.track_next()

    def btn_stw_down_pres(self):
        if self.gpio_gear_shift == 2:
            log('GEAR SHIFT: DOWN - GPIO%s' % GPIO_GEAR_SHIFT_DOWN.pinnumber)
            GPIO_GEAR_SHIFT_DOWN.trigger(self.gpio_gear_shift_trigger_time)

    def btn_stw_down_hold(self):
        if self.stw_dn_hold or self.gpio_gear_shift == 2:
            return
        self.stw_dn_hold = True
        if self.ike_text_scrolling:
            self.ike_text_scrolling = False
        if self.tel_rt_active:
            log('PHONE: Ignore STW DOWN', 2)
            return
        if self.stw_nav:
            KODI.back()
        else:
            speed = -4
            ticker = self.seek_sec
            while self.stw_dn_hold:
                if ticker >= self.seek_sec:
                    KODI.track_seek(speed)
                    speed *= 2
                    if speed > self.seek_max:
                        speed = self.seek_max
                    ticker = 0
                time.sleep(0.001)
                ticker += 1

    def btn_stw_down_rel(self):
        if self.gpio_gear_shift == 2:
            return
        if self.tel_rt_active:
            log('PHONE: Ignore STW DOWN', 2)
            self.stw_dn_hold = False
            return
        if self.stw_nav:
            if self.stw_dn_hold:
                self.stw_dn_hold = False
            else:
                KODI.down()
        else:
            self.stw_up_hold = False
            if self.stw_dn_hold:
                self.stw_dn_hold = False
                KODI.track_play()
            else:
                KODI.track_prev()

    def btn_stw_rt_hold(self):
        if self.stw_rt_hold:
            return
        self.stw_rt_hold = True

    def btn_stw_rt_rel(self):
        self.stw_rt_hold = False
        self.btn_stw_rt_on()
        log('Reset Telefon Option to ignore STW UP/DOWN')
        self.tel_rt_active = False

    def btn_stw_rt_on(self):
        if self.ike_text_scrolling:
            self.ike_text_scrolling = False
        if self.stw_rt_hold:
            pass
        elif self.use_stw_nav:
            if self.stw_nav:
                self.stw_nav = False
                KODI.set_property('IBUSCOMMUNICATOR_MFL_SHOW', '0')
                self.ike_clear_display(0, True)
                log('Disable MFL Control for Kodi')
            elif self.pass_bm_buttons:
                KODI.set_property('IBUSCOMMUNICATOR_MFL_SHOW', '1')
                IBUS.write_bus_packet(200, 128, [26,
                 55,
                 0,
                 32,
                 32,
                 32,
                 32,
                 75,
                 79,
                 68,
                 73,
                 32,
                 67,
                 79,
                 78,
                 84,
                 82,
                 79,
                 76,
                 32,
                 32,
                 32,
                 32])
                self.stw_nav = True
                log('Enable MFL Control for Kodi')
        elif self.nav_toggle_map:
            if self.navmenu:
                log('Toggle to Audio-Screen')
                self.radio_mode_get()
            else:
                log('Toggle to Navi-Screen')
                self.nav_map_show()
        else:
            log('Set Telefon Option to ignore STW UP/DOWN')
            self.tel_rt_active = True
        self.stw_rt_hold = False

    def btn_stw_rt_off(self):
        if self.stw_rt_hold:
            pass
        else:
            if self.use_stw_nav:
                self.stw_nav = False
                KODI.set_property('IBUSCOMMUNICATOR_MFL_SHOW', '0')
                self.ike_clear_display(0, True)
                log('Disable MFL Control for Kodi')
            elif self.nav_toggle_map:
                if self.navmenu:
                    log('Toggle to Audio-Screen')
                    self.radio_mode_get()
                else:
                    log('Toggle to Navi-Screen')
                    self.nav_map_show()
            if self.tel_rt_active:
                log('Reset Telefon Option to ignore STW UP/DOWN')
                self.tel_rt_active = False
        self.stw_rt_hold = False

    def btn_stw_speak_hold(self):
        if self.stw_speak_hold:
            return
        self.stw_speak_hold = True
        if self.stw_nav:
            KODI.back()

    def btn_stw_speak_rel(self):
        if self.stw_speak_hold:
            pass
        elif self.stw_nav:
            DBL_STW_SPEAK.click()
        self.stw_speak_hold = False

    def btn_mid_onoff(self):
        self.radio_mode_get()

    def btn_mid_audio(self):
        if self.pi_is_active:
            self.mid_ignore_radio_text = True
            log('MID: set ignore text = true')

    def btn_bc_pres(self):
        if self.obc_gui_is_visible() and self.stw_nav and self.pass_bm_buttons:
            self.OBCGUI.obcNext()
        elif self.ike_text_scrolling:
            self.ike_text_scrolling = False
        elif not self.stw_nav:
            self.ike_clear_display(delay=0, when_ign_off=True)

    def radio_mode_get(self):
        thread = Thread(target=self._radio_mode_get)
        thread.daemon = True
        thread.start()

    def _radio_mode_get(self):
        if self.ike_states['ign_mode'] < 1:
            return
        IBUS.write_bus_packet(59, 104, [69, 0])
        time.sleep(0.25)
        IBUS.write_bus_packet(192, 104, [32,
         0,
         179,
         0])
        log('RAD: ASK AUDIO MODE')

    def radio_volume_set(self, steps):
        if steps > 0:
            steps = hex(steps)
            value = int('%s1' % steps, 16)
            IBUS.write_bus_packet(59, 104, [50, value])
        elif steps < 0:
            steps = hex(steps * -1)
            value = int('%s0' % steps, 16)
            IBUS.write_bus_packet(59, 104, [50, value])

    def radio_led_on(self):
        self.cdch_init()
        self.cdch_play()
        time.sleep(0.2)
        self.radio_mode_get()

    def radio_led_off(self):
        self.pi_off()

    def radio_bm_led_on(self):
        IBUS.write_bus_packet(104, 240, [74, 255])
        log('Set Radio Led ON')

    def radio_bm_led_off(self):
        IBUS.write_bus_packet(104, 240, [74, 0])
        log('Set Radio Led OFF')

    def radio_diag_state_get(self):
        IBUS.write_bus_packet(63, 104, [11])

    def radio_diag_state_put(self, dat):
        pass

    def ign_state_get(self):
        IBUS.write_bus_packet(231, 128, [16])

    def ign_off(self):
        ign_mode = self.ike_states['ign_mode']
        self.ike_states['ign_mode'] = 0
        log('IGN == 0')
        self.pi_off()
        if self.modealways:
            self.radio_bm_led_off()
        if ign_mode > 0:
            self.lcm_drl_off()
            self.cdch_pause()
            if self.zv_auto_lock and self.zv_auto_unlock_ign1 and self.gm_states['zvlockstate']:
                self.gm_zv_unlock()
            if self.lev_light and self.lev_light_ign_off:
                self.lcm_welcome_on(self.lev_light_time)
            KODI.home()
            if KODI.volume_backup - self.volume_sink_r_value == KODI.volume_get():
                KODI.volume_reset()
            if self.OBCGUI:
                if self.OBCGUI.isActive:
                    self.OBCGUI.onStop()
            KODI.copy_log_file()
        KODI.track_pause()
        self.set_audiomode(0)
        self.stw_nav = False
        KODI.set_property('IBUSCOMMUNICATOR_MFL_SHOW', '0')
        self.tel_rt_active = False
        self.obc_req_runonce = False

    def ign_acc(self):
        ign_mode = self.ike_states['ign_mode']
        self.ike_states['ign_mode'] = 1
        log('IGN == 1')
        if ign_mode > 1:
            self.lcm_drl_off()
            time.sleep(0.25)
            if self.zv_auto_lock and self.zv_auto_unlock_ign1 and self.gm_states['zvlockstate']:
                self.gm_zv_unlock()
        if ign_mode < 1:
            if self.modealways:
                self.radio_bm_led_on()
            time.sleep(0.25)
            self.lcm_welcome_off()
            while self.lcm_on:
                time.sleep(0.5)

            self.obc_req(True)

    def ign_on(self):
        ign_mode = self.ike_states['ign_mode']
        self.ike_states['ign_mode'] = 2
        log('IGN == 2')
        if ign_mode < 1:
            pass
        if ign_mode < 2:
            self.lcm_drl_on()
            time.sleep(0.25)
            self.obc_req(True)

    def ign_start(self):
        ign_mode = self.ike_states['ign_mode']
        self.ike_states['ign_mode'] = 3
        log('IGN == 3')

    def engine_temprature_warning(self):
        if self.engine_cold_warning:
            warning = False
            if self.obc_coolant_C <= 25 and self.obc_rpm > (2500 if self.engine_type == 0 else 2200) or self.obc_coolant_C <= 50 and self.obc_rpm > (2900 if self.engine_type == 0 else 2300) or self.obc_coolant_C <= 65 and self.obc_rpm > (3100 if self.engine_type == 0 else 2400) or self.obc_coolant_C <= 70 and self.obc_rpm > (3300 if self.engine_type == 0 else 2600) or self.obc_coolant_C <= 75 and self.obc_rpm > (3500 if self.engine_type == 0 else 2800):
                warning = True
            else:
                self.engine_cold_warned_before = False
            if warning and not self.engine_cold_warned_before:
                log('Engine Temprature: %s\xc2\xb0C at %srpm' % (self.obc_coolant_C, self.obc_rpm), 3)
                self.engine_cold_warned_before = True
                if not self.ike_display:
                    note('[COLOR FFFF0000]%s[/COLOR]' % self.engine_cold_warning_text, time=2500, icon=ADDON_ICON_COOLANT_BLUE2)
                else:
                    note('[COLOR FFFF0000]%s[/COLOR]' % self.engine_cold_warning_text, time=2500, icon=ADDON_ICON_COOLANT_BLUE2)
                    self.ike_send_text_warning(self.engine_cold_warning_text)
        if self.engine_overheat_warning:
            if self.obc_coolant_C >= self.engine_overheat_temp:
                log('Engine Overheat: %s\xc2\xb0C' % self.obc_coolant_C, 3)
                if not self.ike_display:
                    note('[COLOR FFFF0000]%s[/COLOR]' % self.engine_overheat_warning_text, time=2500, icon=ADDON_ICON_COOLANT_RED2)
                else:
                    note('[COLOR FFFF0000]%s[/COLOR]' % self.engine_overheat_warning_text, time=2500, icon=ADDON_ICON_COOLANT_RED2)
                    self.ike_send_text_warning(self.engine_overheat_warning_text)

    def set_audiomode(self, mode):
        self.got_audiomode = mode
        if mode == 0:
            KODI.set_property('IBUS_RADIO_MODE', '---')
        elif mode == 1:
            KODI.set_property('IBUS_RADIO_MODE', 'RADIO')
        elif mode == 2:
            KODI.set_property('IBUS_RADIO_MODE', 'CD')
        elif mode == 3:
            KODI.set_property('IBUS_RADIO_MODE', 'AUX')

    def gt_mode_radio(self):
        self.set_audiomode(1)
        self.navmenu = False
        self.pi_off()

    def gt_mode_cd(self):
        self.set_audiomode(2)
        self.navmenu = False
        if not self.cdc_play:
            self.cdch_play()
        if self.modecd:
            if self.pi_is_active:
                self.pi_show()
            else:
                self.pi_on()
        else:
            self.pi_off()

    def gt_mode_tape(self):
        self.set_audiomode(3)
        self.navmenu = False
        if self.modetape:
            if self.pi_is_active:
                self.pi_show()
            else:
                self.pi_on()
        else:
            self.pi_off()

    def gt_mode_aux(self):
        self.set_audiomode(4)
        self.navmenu = False
        if self.modeaux:
            if self.pi_is_active:
                self.pi_show()
            else:
                self.pi_on()
        else:
            self.pi_off()

    def gt_mode_cis(self):
        self.set_audiomode(2)
        self.navmenu = False
        if self.modecis:
            if self.pi_is_active:
                self.pi_show()
            else:
                self.pi_on()
        else:
            self.pi_off()

    def gt_clear_cd_list(self):
        if self.modecd and self.pi_is_visible:
            IBUS.write_bus_packet(104, 59, [70, 12])

    def gt_nav_menu_on(self):
        self.navmenu = True
        self.tonemenu = False
        self.tpmenu = False
        self.pi_hide()

    def gt_radio_menu_off(self):
        self.tpmenu = False
        self.tonemenu = False
        self.navmenu = True
        self.pi_hide()

    def gt_tp_menu(self):
        self.tpmenu = True
        self.tonemenu = False
        self.pi_hide()

    def gt_tone_menu(self):
        self.tonemenu = True
        self.tpmenu = False
        self.navmenu = False
        self.pi_hide()

    def gt_select_menu(self):
        self.tonemenu = False
        self.tpmenu = False
        self.navmenu = False
        self.pi_show()

    def gt_tone_menu_off(self):
        self.tonemenu = False
        self.pi_show()

    def gt_select_tone_menu_off(self):
        self.tpmenu = False
        self.pi_show()

    def gt_tv_on(self):
        self.pi_hide()
        KODI.track_pause()

    def gt_tv_off(self):
        if self.pi_is_active:
            KODI.track_play()

    def gt_tp_message(self):
        self.pi_off()

    def gt_new_field1(self):
        self.pi_show()

    def mid_mode_radio(self):
        if not self.mid_ignore_radio_text:
            self.gt_mode_radio()

    def mid_mode_cd(self):
        if self.modecd:
            self.mid_send_text('RaspberryPi')
            self.mid_ignore_radio_text = False
        self.gt_mode_cd()

    def mid_mode_tape(self):
        if self.modetape:
            self.mid_send_text('RaspberryPi')
            self.mid_ignore_radio_text = False
        self.gt_mode_tape()

    def phone_state(self, dat):
        dat = dat[1]
        if get_bit_from_hex(dat, BIT[4]) == 1:
            if self.pi_is_active:
                KODI.track_pause()
            self.phone_mute = True
        elif get_bit_from_hex(dat, BIT[4]) == 0:
            self.phone_mute = False
            if self.pi_is_active:
                KODI.track_play()

    def remote_key_lock_pres(self):
        log('REMOTE LOCK PRES')
        if self.lev_light:
            if self.lcm_on:
                if self.remote_state == 1:
                    self.lcm_welcome_off()
                else:
                    self.lcm_delay = self.lev_light_time
            else:
                self.lcm_welcome_on(self.lev_light_time)
        elif self.lcm_on:
            self.lcm_welcome_off()
        if self.shutdown_timer_enable:
            KODI.shutdown_timer_start(self.shutdown_timer_time)
        self.remote_state = 1

    def remote_key_lock_hold(self):
        log('REMOTE LOCK HOLD')
        self.remote_lock_hold = True
        if self.aux_heat_zv_lock_hold:
            if not self.obc_auxheat_get_ind():
                self.obc_auxheat_control(True)
                self.lcm_hazard_strobe(2)
            else:
                self.obc_auxheat_control(False)
                self.lcm_hazard_strobe(0.1, 4)

    def remote_key_lock_rel(self):
        log('REMOTE LOCK REL')
        if self.remote_lock_hold:
            self.remote_lock_hold = False
            if self.mir_fold_hold:
                self.gm_mirror_fold(0)
        elif self.mir_fold:
            log('mirror should fold')
            self.gm_mirror_fold(0)

    def remote_key_unlock_pres(self):
        log('REMOTE UNLOCK PRES')
        if self.wel_light:
            if self.lcm_on:
                if self.remote_state == 2:
                    self.lcm_welcome_off()
                else:
                    self.lcm_delay = self.wel_light_time
            else:
                self.lcm_welcome_on(self.wel_light_time)
        elif self.lcm_on:
            self.lcm_welcome_off()
        if self.remote_state == 1:
            if self.wel_ike:
                self.ike_send_text(self.wel_iketxt, True, self.wel_iketxt_hold)
        if self.shutdown_timer_enable:
            KODI.shutdown_timer_cancel()
        self.remote_state = 2

    def remote_key_unlock_hold(self):
        log('REMOTE UNLOCK HOLD')

    def remote_key_unlock_rel(self):
        log('REMOTE UNLOCK REL')
        if self.mir_unfold:
            self.gm_mirror_unfold(0)

    def remote_key_boot_pres(self):
        log('REMOTE TRUNK PRES')

    def remote_key_boot_hold(self):
        log('REMOTE TRUNK HOLD')

    def remote_key_boot_rel(self):
        log('REMOTE TRUNK REL')

    def ews_key_req(self):
        IBUS.write_bus_packet(48, 68, [115,
         0,
         0,
         128])

    def ews_key_put(self, dat):
        if dat[1] == 0:
            self.obc_inserted_key = -1
            log('EWS: KEY_OUT')
            self.mir_state = 0
        elif dat[1] != 0 and dat[2] == 255:
            self.obc_inserted_key = -1
            log('EWS: KEY_OUT')
            self.mir_state = 0
        elif dat[1] != 0 and dat[2] != 255:
            self.obc_inserted_key = dat[2]
            log('EWS: KEY_IN: %s' % dat[2])
            if self.mir_unfold_ign:
                self.gm_mirror_unfold(0.5)
            if self.keyin_off:
                self.lcm_welcome_off()
                while self.lcm_on:
                    time.sleep(0.5)

    def ike_set_time(self):
        result = xbmcgui.Dialog().numeric(2, 'Time')
        if ':' in result:
            HH, MM = result.split(':')
        else:
            note(language('Invalid Time Input'), message='%s' % result, time=3000)
            return
        IBUS.write_bus_packet(59, 128, [64,
         1,
         int(HH),
         int(MM)])

    def ike_set_date(self):
        result = xbmcgui.Dialog().numeric(1, 'Date')
        if '/' in result:
            DD, MM, YYYY = result.split('/')
            YY = YYYY[-2:]
        else:
            note(language('Invalid Date Input'), message='%s' % result, time=3000)
            return
        IBUS.write_bus_packet(59, 128, [64,
         2,
         int(DD),
         int(MM),
         int(YY)])

    def ike_get_state(self, timer = False):
        if timer:
            counter = 10000
            while not MONITOR.abortRequested():
                if counter == 10000:
                    IBUS.write_bus_packet(231, 128, [18])
                elif counter <= 0:
                    counter = 10000
                counter -= 1
                time.sleep(0.001)

        else:
            IBUS.write_bus_packet(231, 128, [18])

    def ike_get_state_timer(self):
        thread = Thread(target=self.ike_get_state, args=True)
        thread.daemon = True
        thread.start()

    def ike_state_put(self, dat):
        aa = dat[1]
        bb = dat[2]
        cc = dat[3]
        try:
            gg = dat[7]
        except IndexError:
            gg = 0

        handbrake = get_bit_from_hex(aa, BIT[0])
        motor_running = get_bit_from_hex(bb, BIT[0])
        vehicle_driving = get_bit_from_hex(bb, BIT[1])
        if ('%02X' % bb)[0] == '1':
            gear_pos = 'R'
            gear_target = self.ike_gear
        elif ('%02X' % bb)[0] == '2':
            gear_pos = '1'
            gear_target = self.ike_gear
        elif ('%02X' % bb)[0] == '4':
            gear_pos = '2'
            gear_target = self.ike_gear
        elif ('%02X' % bb)[0] == '6':
            gear_pos = 'N'
            gear_target = self.ike_gear
        elif ('%02X' % bb)[0] == '8':
            gear_pos = 'D'
            gear_target = self.ike_gear
        elif ('%02X' % bb)[0] == 'B':
            gear_pos = 'P'
            gear_target = self.ike_gear
        elif ('%02X' % bb)[0] == 'C':
            gear_pos = '4'
            gear_target = self.ike_gear
        elif ('%02X' % bb)[0] == 'D':
            gear_pos = '3'
            gear_target = self.ike_gear
        elif ('%02X' % bb)[0] == 'E':
            gear_pos = '5'
            gear_target = self.ike_gear
        else:
            gear_pos = 'X'
            gear_target = self.ike_gear
        gear_position_new = gear_pos
        gear_position_old = self.ike_states['gear_pos']
        self.ike_states['gear_pos'] = gear_pos
        aux_heat = get_bit_from_hex(cc, BIT[2])
        aux_vent = get_bit_from_hex(cc, BIT[3])
        if ('%02X' % gg)[0] == '8':
            obc_fuellevel_low = True
            obc_fuellevel = int(('%02X' % gg)[1])
        else:
            obc_fuellevel_low = False
            obc_fuellevel = gg
        if aux_vent != self.ike_states['aux_vent']:
            self.ike_states['aux_vent'] = aux_vent
        if aux_heat != self.ike_states['aux_heat']:
            self.ike_states['aux_heat'] = aux_heat
        if self.ike_states['run_once']:
            if handbrake and self.zv_auto_lock and self.zv_auto_unlock_handbrake and self.gm_states['zvlockstate']:
                self.gm_zv_unlock()
            self.ike_states['handbrake'] = handbrake
            log('GM: HANDBRAKE=%s' % handbrake, 2)
            gear_thread = Thread(target=gear_target, args=(gear_position_new, gear_position_old))
            gear_thread.daemon = True
            gear_thread.start()
            if gear_pos != self.ike_states['gear_pos']:
                if gear_pos == 'R':
                    if self.volume_sink_r:
                        KODI.volume_set(KODI.volume_get() - self.volume_sink_r_value)
                    if self.gpio_rearcam:
                        self.rearcam_on()
                elif gear_pos != 'R' and self.ike_states['gear_pos'] == 'R':
                    if self.volume_sink_r:
                        KODI.volume_reset(self.volume_sink_r_delay)
                    if self.gpio_rearcam:
                        self.rearcam_off()
                self.ike_states['gear_pos'] = gear_pos
            self.obc_fuellevel = obc_fuellevel
            self.obc_fuellevel_low = obc_fuellevel_low
            log('OBC: PUT: FUELLEVEL: %s' % obc_fuellevel)
        self.ike_states['run_once'] = True

    def ike_gear(self, position_new, position_old = 'x'):
        if position_new == 'P' and self.zv_auto_lock and self.zv_auto_unlock_gear_p and self.gm_states['zvlockstate']:
            self.gm_zv_unlock()
        if position_new == 'R':
            for _ in range(0, 5):
                if self.ike_states['gear_pos'] != 'R':
                    return
                time.sleep(0.1)

            if self.volume_sink_r:
                KODI.volume_set(KODI.volume_get() - self.volume_sink_r_value)
            if self.gpio_rearcam:
                self.rearcam_on()
        elif position_new != 'R' and position_old == 'R':
            if self.volume_sink_r:
                KODI.volume_reset(self.volume_sink_r_delay)
            if self.gpio_rearcam:
                self.rearcam_off()

    def ike_gear_r(self, position_old):
        pass

    def ike_gear_1(self, position_old):
        pass

    def ike_gear_2(self, position_old):
        pass

    def ike_gear_n(self, position_old):
        pass

    def ike_gear_d(self, position_old):
        pass

    def ike_gear_p(self, position_old):
        pass

    def ike_gear_4(self, position_before):
        pass

    def ike_gear_3(self, position_before):
        pass

    def ike_gear_5(self, position_before):
        pass

    def ike_gear_x(self, position_before):
        pass

    def gm_state_req(self):
        IBUS.write_bus_packet(191, 0, [121])

    def gm_state_put(self, dat):
        driverdoor_old = self.gm_states['driverdoor']
        passengerdoor_old = self.gm_states['passengerdoor']
        driverreardoor_old = self.gm_states['driverreardoor']
        passengerreardoor_old = self.gm_states['passengerreardoor']
        doorsopen_old = self.gm_states['doorsopen']
        zvunlocked_old = self.gm_states['zvunlocked']
        zvlocked_old = self.gm_states['zvlocked']
        zvhardlocked_old = self.gm_states['zvhardlocked']
        zvlockstate_old = self.gm_states['zvlockstate']
        indoorlights_old = self.gm_states['indoorlights']
        driverwindow_old = self.gm_states['driverwindow']
        passengerwindow_old = self.gm_states['passengerwindow']
        driverrearwindow_old = self.gm_states['driverrearwindow']
        passengerrearwindow_old = self.gm_states['passengerrearwindow']
        sunroof_old = self.gm_states['sunroof']
        trunk_old = self.gm_states['trunk']
        bonnet_old = self.gm_states['bonnet']
        trunkbuttonpress_old = self.gm_states['trunkbuttonpress']
        aa = dat[1]
        bb = dat[2]
        driverdoor = get_bit_from_hex(aa, BIT[0])
        passengerdoor = get_bit_from_hex(aa, BIT[1])
        driverreardoor = get_bit_from_hex(aa, BIT[2])
        passengerreardoor = get_bit_from_hex(aa, BIT[3])
        if driverdoor or passengerdoor or driverreardoor or passengerreardoor:
            doorsopen = True
        else:
            doorsopen = False
        zvunlocked = get_bit_from_hex(aa, BIT[4])
        zvlocked = get_bit_from_hex(aa, BIT[5])
        zvhardlocked = True if zvunlocked and zvlocked else False
        zvlockstate = True if zvlocked else False
        indoorlights = get_bit_from_hex(aa, BIT[6])
        driverwindow = get_bit_from_hex(bb, BIT[0])
        passengerwindow = get_bit_from_hex(bb, BIT[1])
        driverrearwindow = get_bit_from_hex(bb, BIT[2])
        passengerrearwindow = get_bit_from_hex(bb, BIT[3])
        sunroof = get_bit_from_hex(bb, BIT[4])
        trunk = get_bit_from_hex(bb, BIT[5])
        bonnet = get_bit_from_hex(bb, BIT[6])
        trunkbuttonpress = get_bit_from_hex(bb, BIT[7])
        if self.gm_states['zvprocessed']:
            self.gm_states['zvprocessed'] = False
            self.gm_diag_off()
        self.gm_states['driverdoor'] = driverdoor
        self.gm_states['passengerdoor'] = passengerdoor
        self.gm_states['driverreardoor'] = driverreardoor
        self.gm_states['passengerreardoor'] = passengerreardoor
        self.gm_states['doorsopen'] = doorsopen
        self.gm_states['zvunlocked'] = zvunlocked
        self.gm_states['zvlocked'] = zvlocked
        self.gm_states['zvhardlocked'] = zvhardlocked
        self.gm_states['zvlockstate'] = zvlockstate
        self.gm_states['indoorlights'] = indoorlights
        self.gm_states['driverwindow'] = driverwindow
        self.gm_states['passengerwindow'] = passengerwindow
        self.gm_states['driverrearwindow'] = driverrearwindow
        self.gm_states['passengerrearwindow'] = passengerrearwindow
        self.gm_states['sunroof'] = sunroof
        self.gm_states['trunk'] = trunk
        self.gm_states['bonnet'] = bonnet
        self.gm_states['trunkbuttonpress'] = trunkbuttonpress
        notemsg = [None, None]
        notetime = 50
        if self.gm_states['run_once']:
            if driverdoor_old != driverdoor:
                notemsg[0] = language('Driver Door')
                notemsg[1] = language('opened') if driverdoor else language('closed')
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if passengerdoor_old != passengerdoor:
                notemsg[0] = language('Passenger Door')
                notemsg[1] = language('opened') if passengerdoor else language('closed')
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if driverreardoor_old != driverreardoor:
                notemsg[0] = language('Driver Rear Door')
                notemsg[1] = language('opened') if driverreardoor else language('closed')
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if passengerreardoor_old != passengerreardoor:
                notemsg[0] = language('Passenger Rear Door')
                notemsg[1] = language('opened') if passengerreardoor else language('closed')
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if doorsopen_old != doorsopen:
                if doorsopen and self.doors_off:
                    self.lcm_welcome_off()
            if zvlockstate_old != zvlockstate:
                notemsg[0] = language('Central Locksystem')
                if zvhardlocked:
                    self.gm_zv_hardlocked()
                    notemsg[1] = language('hard locked')
                elif zvlockstate:
                    notemsg[1] = language('locked')
                else:
                    self.gm_zv_unlocked()
                    notemsg[1] = language('unlocked')
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if indoorlights_old != indoorlights:
                notemsg[0] = language('Indoor Lights turned')
                notemsg[1] = language('ON') if indoorlights else language('OFF')
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if driverwindow_old != driverwindow:
                notemsg[0] = language('Driver Window')
                notemsg[1] = language('opened') if driverwindow else language('closed')
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if passengerwindow_old != passengerwindow:
                notemsg[0] = language('Passenger Window')
                notemsg[1] = language('opened') if passengerwindow else language('closed')
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if driverrearwindow_old != driverrearwindow:
                notemsg[0] = language('Driver Rear Window')
                notemsg[1] = language('opened') if driverrearwindow else language('closed')
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if passengerrearwindow_old != passengerrearwindow:
                notemsg[0] = language('Passenger Rear Window')
                notemsg[1] = language('opened') if passengerrearwindow else language('closed')
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if sunroof_old != sunroof:
                notemsg[0] = language('Sunroof')
                notemsg[1] = language('opened') if sunroof else language('closed')
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if trunk_old != trunk:
                notemsg[0] = language('Trunk')
                notemsg[1] = language('opened') if trunk else language('closed')
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if bonnet_old != bonnet:
                notemsg[0] = language('Bonnet')
                notemsg[1] = language('opened') if bonnet else language(language('closed'))
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if trunkbuttonpress_old != trunkbuttonpress:
                notemsg[0] = language('Trunk Button')
                notemsg[1] = language('pressed') if trunkbuttonpress else language('released')
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if doorsopen and self.zv_auto_lock and self.zv_auto_unlock_door_open:
                self.gm_zv_unlock()
        self.gm_states['run_once'] = True

    def gm_zv_hardlocked(self):
        log('GM: ZV Hardlocked')

    def gm_zv_unlocked(self):
        log('GM: ZV Unlocked')

    def gm_zv_lock(self):
        if self.gm_states['zvprocessed']:
            log('CENTRAL-LOCK-SYSTEM: IS IN PROCESS', 2)
            return
        if self.gm_states['zvlockstate']:
            log('CENTRAL-LOCK-SYSTEM: IS LOCKED', 2)
            return
        thread = Thread(target=self._gm_zv_lock)
        thread.daemon = True
        thread.start()

    def gm_zv_unlock(self):
        if self.gm_states['zvprocessed']:
            log('CENTRAL-LOCK-SYSTEM: IS IN PROCESS', 2)
            return
        if not self.gm_states['zvlockstate']:
            log('CENTRAL-LOCK-SYSTEM: IS UNLOCKED', 2)
            return
        thread = Thread(target=self._gm_zv_unlock)
        thread.daemon = True
        thread.start()

    def _gm_zv_lock(self):
        if self.car_model == 'E39':
            if self.gm_mode == 1:
                IBUS.write_bus_packet(63, 0, [12,
                 0,
                 20,
                 1])
            else:
                IBUS.write_bus_packet(63, 0, [12, 0, 11])
        elif self.car_model == 'E46':
            IBUS.write_bus_packet(63, 0, [12, 52, 1])
        self.gm_states['zvprocessed'] = True
        log('CENTRAL-LOCK-SYSTEM: LOCK')

    def _gm_zv_unlock(self):
        if self.car_model == 'E39':
            if self.gm_mode == 1:
                IBUS.write_bus_packet(63, 0, [12,
                 0,
                 20,
                 1])
            elif self.zv_selective:
                IBUS.write_bus_packet(63, 0, [12, 0, 11])
            else:
                IBUS.write_bus_packet(63, 0, [12, 1, 0])
        elif self.car_model == 'E46':
            IBUS.write_bus_packet(63, 0, [12, 3, 1])
        self.gm_states['zvprocessed'] = True
        log('CENTRAL-LOCK-SYSTEM: UNLOCK')

    def gm_mirror_unfold(self, delay = 2):
        thread = Thread(target=self._gm_mirror_unfold, args=(delay,))
        thread.daemon = True
        thread.start()

    def gm_mirror_fold(self, delay = 2):
        thread = Thread(target=self._gm_mirror_fold, args=(delay,))
        thread.daemon = True
        thread.start()

    def _gm_mirror_unfoldOLD(self):
        if self.mir_unfolded:
            return
        if self.mir_fold_mov:
            self.mir_fold_mov = False
            self.mir_folded = False
            self.mir_unfolded = False
            self.gm_diag_off()
            time.sleep(1)
        log('GM: UNFOLD MIRROS')
        self.mir_unfold_mov = True
        time.sleep(2)
        IBUS.write_bus_packet(63, 0, [12, 1, 48])
        time.sleep(0.2)
        IBUS.write_bus_packet(63, 0, [12, 2, 48])
        self.mir_folded = False
        time.sleep(8)
        if self.mir_unfold_mov:
            self.mir_unfolded = True
        self.mir_unfold_mov = False

    def _gm_mirror_foldOLD(self):
        if self.mir_folded:
            return
        if self.mir_unfold_mov:
            self.mir_unfold_mov = False
            self.mir_folded = False
            self.mir_unfolded = False
            self.gm_diag_off()
            time.sleep(1)
        log('GM: FOLD MIRROS')
        self.mir_fold_mov = True
        time.sleep(2)
        IBUS.write_bus_packet(63, 0, [12, 1, 49])
        time.sleep(0.2)
        IBUS.write_bus_packet(63, 0, [12, 2, 49])
        self.mir_unfolded = False
        time.sleep(8)
        if self.mir_fold_mov:
            self.mir_folded = True
        self.mir_fold_mov = False

    def _gm_mirror_unfold(self, delay = 2):
        if self.mir_state in (1, 2):
            return
        if self.mir_state in (2, 3):
            self.gm_diag_off()
            time.sleep(1)
        log('GM: UNFOLD MIRROS')
        self.mir_state = 2
        time.sleep(delay)
        IBUS.write_bus_packet(63, 0, [12, 1, 48])
        time.sleep(0.2)
        IBUS.write_bus_packet(63, 0, [12, 2, 48])
        for _ in range(32, 1, -1):
            if self.mir_state != 2:
                return
            time.sleep(0.25)
            log('GM: UNFOLDING MIRROS %s' % _, 3)

        self.mir_state = 1

    def _gm_mirror_fold(self, delay = 2):
        if self.mir_state in (3, 4):
            return
        if self.mir_state in (2, 3):
            self.gm_diag_off()
            time.sleep(1)
        log('GM: FOLD MIRROS')
        self.mir_state = 3
        time.sleep(delay)
        IBUS.write_bus_packet(63, 0, [12, 1, 49])
        time.sleep(0.2)
        IBUS.write_bus_packet(63, 0, [12, 2, 49])
        for _ in range(32, 1, -1):
            if self.mir_state != 3:
                return
            time.sleep(0.25)
            log('GM: FOLDING MIRROS %s' % _, 3)

        self.mir_state = 4

    def gm_diag_off(self):
        if self.ike_states['ign_mode'] > 0:
            return
        IBUS.write_bus_packet(63, 0, [159])
        log('GM: DIAG OFF')

    def pi_on(self):
        self.pi_is_active = True
        log('RASPBERRY: ACTIVATE PI')
        self.pi_show()
        if self.dsp_cd:
            self.dsp_set_cd()
        KODI.track_play()
        if self.modealways:
            self.radio_bm_led_on()

    def pi_off(self):
        if self.modealways:
            return
        self.pi_is_active = False
        log('RASPBERRY: DEACTIVATE PI')
        self.pi_hide()
        if self.dsp_cd:
            self.dsp_set_tuner()
        KODI.track_pause()

    def pi_show(self):
        if self.navmenu or self.tpmenu or self.tonemenu or not self.pi_is_active:
            return
        self.pass_bm_buttons = True
        log('RASPBERRY: SHOW PI')
        self.gt_av_r_on(True)
        self.pi_is_visible = True

    def pi_hide(self):
        self.pass_bm_buttons = False
        if self.gpio_rearcam_counter > 0 or self.pdc_req_running:
            return
        log('RASPBERRY: HIDE PI')
        self.gt_av_r_on(False)
        self.pi_is_visible = False

    def gt_av_r_on(self, ntscstate):
        if self.gt_av_r_manual:
            return
        if self.gpio_ntsc:
            if ntscstate:
                GPIO_NTSC.set()
            else:
                GPIO_NTSC.reset()
        else:
            IBUS.ntsc = 1 if ntscstate else 0

    def dsp_set_tuner(self):
        IBUS.write_bus_packet(104, 106, [54, 161])
        log('RASPBERRY: DSP SOURCE TUNER')

    def dsp_set_cd(self):
        IBUS.write_bus_packet(104, 106, [54, 160])
        log('RASPBERRY: DSP SOURCE CD')

    def kodi_said_play(self):
        if not self.pi_is_active or self.phone_mute:
            KODI.kodi_play = 1
            if not self.develop:
                KODI.track_pause()

    def kodi_said_pause(self):
        pass

    def lcm_state_req(self):
        IBUS.write_bus_packet(191, 208, [90])
        time.sleep(0.2)
        IBUS.write_bus_packet(191, 208, [93])
        time.sleep(0.2)
        self.lcm_diag_state_req()

    def lcm_diag_state_req(self):
        IBUS.write_bus_packet(63, 208, [11])

    def lcm_state_put(self, dat):
        aa = dat[1]
        cc = dat[3]
        park = get_bit_from_hex(aa, BIT[0])
        low_beam = get_bit_from_hex(aa, BIT[1])
        high_beam = get_bit_from_hex(aa, BIT[2])
        fog_front = get_bit_from_hex(aa, BIT[3])
        fog_rear = get_bit_from_hex(aa, BIT[4])
        turn_left = get_bit_from_hex(aa, BIT[5])
        turn_right = get_bit_from_hex(aa, BIT[6])
        turn_fast_blink = get_bit_from_hex(aa, BIT[7])
        tail = get_bit_from_hex(cc, BIT[3])
        reverse = get_bit_from_hex(cc, BIT[5])
        hazard = turn_left and turn_right
        if self.lcm_states['run_once']:
            if turn_left != self.lcm_states['turn_left'] and not turn_right:
                if turn_left:
                    self.lcm_turn_left()
            if turn_right != self.lcm_states['turn_right'] and not turn_left:
                if turn_right:
                    self.lcm_turn_right()
            if hazard != self.lcm_states['hazard']:
                self.lcm_states['hazard'] = hazard
                if hazard:
                    log('LCM: HAZARD ON')
                else:
                    log('LCM: HAZARD OFF')
            if high_beam != self.lcm_states['high_beam']:
                self.lcm_flash_to_pass(high_beam)
        if park != self.lcm_states['park']:
            self.lcm_states['park'] = park
            if park:
                self.lcm_drl_off()
                if self.lcd_brightness:
                    self.bm_set_brightness(self.lcd_brightness_value_on)
            else:
                self.lcm_drl_on()
                if self.lcd_brightness:
                    self.bm_set_brightness(self.lcd_brightness_value_off)
        self.lcm_states['park'] = park
        self.lcm_states['low_beam'] = low_beam
        self.lcm_states['high_beam'] = high_beam
        self.lcm_states['fog_front'] = fog_front
        self.lcm_states['fog_rear'] = fog_rear
        self.lcm_states['turn_left'] = turn_left
        self.lcm_states['turn_right'] = turn_right
        self.lcm_states['turn_fast_blink'] = turn_fast_blink
        self.lcm_states['tail'] = tail
        self.lcm_states['reverse'] = reverse
        self.lcm_states['hazard'] = hazard
        self.lcm_states['run_once'] = True

    def lcm_diag_state_put(self, dat):
        if len(dat) < 2:
            return
        if self.lcm_read_coding:
            self.lcm_read_coding = False
            if dat[1] == 0:
                self.lcm_us_put(dat)
            if dat[1] == 2:
                self.lcm_pwm_park_put(dat)
            if dat[1] == 129:
                self.obc_oiltemp_put(dat)
        else:
            self.lcm_states['diag_dim_level'] = [dat[16], dat[17]]
            log('LCM: Dim Diag Value = %s' % self.lcm_states['diag_dim_level'])

    def lcm_dim_level_put(self, dat):
        if self.lcm_states['dim_level'] != dat[1]:
            log('LCM: Dim Value = %s' % dat[1])
            self.lcm_states['dim_level'] = dat[1]
            self.lcm_diag_state_req()

    def lcm_us_req(self):
        if self.car_model == 'E39':
            self.lcm_read_coding = True
            IBUS.write_bus_packet(63, 208, [8, 0])

    def lcm_us_put(self, dat):
        us_sidemark = get_bit_from_hex(dat[21], BIT[5])
        log('LCM: US SIDEMARK=%s' % us_sidemark)
        if us_sidemark:
            us_sidemark_list = ['[>  US SIDEMARK ON   <]', '    US SIDEMARK OFF    ']
        else:
            us_sidemark_list = ['    US SIDEMARK ON     ', '[>  US SIDEMARK OFF  <]']
        ret = xbmcgui.Dialog().select('LCM Coding: US Sidemark', us_sidemark_list)
        if ret >= 0:
            if ret == 0 and not us_sidemark:
                dat[21] = set_bit_in_hex(dat[21], BIT[5], True)
                log('LCM: Enable US Sidemark %s' % dat, 2)
            elif ret == 1 and us_sidemark:
                dat[21] = set_bit_in_hex(dat[21], BIT[5], False)
                log('LCM: Disable US Sidemark %s' % dat, 3)
            else:
                note('LCM Coding: US Sidemark', 'Abbruch')
                return
            dat[0] = 9
            IBUS.write_bus_packet(63, 208, dat)
        else:
            note('LCM Coding: US Sidemark', 'Abbruch')

    def lcm_pwm_park_req(self):
        if self.car_model == 'E39':
            self.lcm_read_coding = True
            IBUS.write_bus_packet(63, 208, [8, 2])

    def lcm_pwm_park_put(self, dat):
        pwm_park_light_left = dat[7]
        pwm_park_light_right = dat[17]
        log('LCM: PWM Left=%02X Right=%02X' % (pwm_park_light_left, pwm_park_light_right))
        pwm_park_light_list = []
        for _ in range(0, 21):
            if int('%02X' % pwm_park_light_left) == _:
                pwm_park_light_list.append('[>   %s   <]' % ('%s' % _).zfill(2))
            else:
                pwm_park_light_list.append('     %s     ' % ('%s' % _).zfill(2))

        ret = xbmcgui.Dialog().select('LCM Coding: PWM Park Light Front', pwm_park_light_list)
        if ret >= 0:
            if ret != int('%X02' % pwm_park_light_left):
                dat[7] = int('0x%s' % ret, 16)
                dat[17] = int('0x%s' % ret, 16)
                log('LCM: PWM Park Light Front %s' % dat, 2)
            else:
                note('LCM Coding: PWM Park Light Front', 'Abbruch')
                return
            dat[0] = 9
            IBUS.write_bus_packet(63, 208, dat)
        else:
            note('LCM Coding: PWM Park Light Front', 'Abbruch')

    def obc_oiltemp_req(self):
        if self.ike_states['ign_mode'] < 2 or self.engine_type != 0:
            return
        self.lcm_read_coding = True
        log('LCM T\xc3\x96NS: REQ')
        IBUS.write_bus_packet(63, 208, [11])

    def obc_oiltemp_put(self, dat):
        log('LCM T\xc3\x96NS: HEIZ:%02X%02X ABK\xc3\x9cHL:%02X%02X' % (dat[19],
         dat[20],
         dat[21],
         dat[22]))
        temp_heat = dat[19] * 5e-05 + dat[20] * 0.01275
        temp_cool = dat[21] * 5e-05 + dat[22] * 0.01275
        self.obc_oiltemp_C = int(67 * math.log(temp_heat) + 310)
        self.obc_oiltemp_F = int(self.obc_oiltemp_C * 1.8 + 32)
        if KODI.get_addon_setting('home_temp') == 'Oil Temp':
            KODI.set_property('IBUS_OBC_TEMP', '%s' % self.obc_oiltemp_get())
        log('LCM T\xc3\x96NS: OILTEMP: %s\xc2\xb0C' % self.obc_oiltemp_C)
        log('LCM T\xc3\x96NS: OILTEMP: %s\xc2\xb0F' % self.obc_oiltemp_F)

    def obc_oiltemp_get(self):
        if self.ike_states['ign_mode'] < 2:
            if self.obc_temperature_unit == '\xc2\xb0F':
                return '--\xc2\xb0F'
            return '--\xc2\xb0C'
        elif self.obc_temperature_unit == '\xc2\xb0F':
            return '%s%s\xc2\xb0F' % ('+' if self.obc_oiltemp_F > 0 else '', self.obc_oiltemp_F)
        else:
            return '%s%s\xc2\xb0C' % ('+' if self.obc_oiltemp_C > 0 else '', self.obc_oiltemp_C)

    def obc_oiltemp_get_icon(self):
        if self.obc_oiltemp_C <= 25:
            return ADDON_ICON_COOLANT_BLUE
        if self.obc_oiltemp_C <= 75:
            return ADDON_ICON_COOLANT_YELLOW
        if self.engine_overheat_warning:
            if self.obc_oiltemp_C < self.engine_overheat_temp:
                return ADDON_ICON_COOLANT_GREEN
            if self.obc_oiltemp_C >= self.engine_overheat_temp:
                return ADDON_ICON_COOLANT_RED

    def lcm_hazard_strobe(self, interval = 0.1, repeat = 1):
        thread = Thread(target=self._lcm_hazard_strobe, args=(interval, repeat))
        thread.daemon = True
        thread.start()

    def _lcm_hazard_strobe(self, interval = 0.1, repeat = 1):
        for _ in range(0, repeat):
            self.lcm_light['turn_front_left'] = True
            self.lcm_light['turn_front_right'] = True
            self.lcm_light['turn_rear_left'] = True
            self.lcm_light['turn_rear_right'] = True
            self.lcm_light_set()
            time.sleep(interval)
            self.lcm_light['turn_front_left'] = False
            self.lcm_light['turn_front_right'] = False
            self.lcm_light['turn_rear_left'] = False
            self.lcm_light['turn_rear_right'] = False
            self.lcm_light_set()
            time.sleep(interval)

    def lcm_light_set(self):
        if True not in self.lcm_light.values():
            IBUS.write_bus_packet(63, 208, [159], veryhighprio=True, repeat=2)
            log('LCM: ALL LIGHTS OFF')
            return
        AA = 0
        BB = 0
        CC = 0
        DD = 0
        EE = 0
        FF = 0
        GG = 0
        HH = 0
        II = 0
        JJ = self.lcm_states['diag_dim_level'][0]
        KK = self.lcm_states['diag_dim_level'][1]
        LL = 0
        if self.car_model == 'E39':
            CC = set_bit_in_hex(CC, BIT[7], self.lcm_light['switch_turn_left'])
            CC = set_bit_in_hex(CC, BIT[6], self.lcm_light['switch_turn_right'])
            FF = set_bit_in_hex(FF, BIT[0], self.lcm_light['park_front_left'])
            FF = set_bit_in_hex(FF, BIT[1], self.lcm_light['park_rear_left'])
            GG = set_bit_in_hex(GG, BIT[3], self.lcm_light['park_rear_left'])
            GG = set_bit_in_hex(GG, BIT[5], self.lcm_light['park_front_right'])
            HH = set_bit_in_hex(HH, BIT[3], self.lcm_light['park_rear_right'])
            HH = set_bit_in_hex(HH, BIT[4], self.lcm_light['park_rear_right'])
            FF = set_bit_in_hex(FF, BIT[4], self.lcm_light['low_beam_left'])
            FF = set_bit_in_hex(FF, BIT[5], self.lcm_light['low_beam_right'])
            EE = set_bit_in_hex(EE, BIT[6], self.lcm_light['high_beam_left'])
            EE = set_bit_in_hex(EE, BIT[5], self.lcm_light['high_beam_right'])
            FF = set_bit_in_hex(FF, BIT[2], self.lcm_light['fog_front_left'])
            FF = set_bit_in_hex(FF, BIT[6], self.lcm_light['fog_front_right'])
            GG = set_bit_in_hex(GG, BIT[2], self.lcm_light['licence_plate'])
            HH = set_bit_in_hex(HH, BIT[6], self.lcm_light['turn_front_left'])
            GG = set_bit_in_hex(GG, BIT[6], self.lcm_light['turn_front_right'])
            GG = set_bit_in_hex(GG, BIT[7], self.lcm_light['turn_rear_left'])
            HH = set_bit_in_hex(HH, BIT[1], self.lcm_light['turn_rear_right'])
            IBUS.write_bus_packet(63, 208, [12,
             AA,
             BB,
             CC,
             DD,
             EE,
             FF,
             GG,
             HH,
             II,
             JJ,
             KK,
             LL], veryhighprio=True)
        elif self.car_model == 'E46':
            CC = 255
            if self.lcm_light['switch_turn_left'] or self.lcm_light['switch_turn_right']:
                DD = set_bit_in_hex(DD, BIT[6], self.lcm_light['switch_turn_left'])
                DD = set_bit_in_hex(DD, BIT[7], self.lcm_light['switch_turn_right'])
            else:
                DD = 255
            FF = set_bit_in_hex(FF, BIT[3], self.lcm_light['park_front_left'])
            EE = set_bit_in_hex(EE, BIT[1], self.lcm_light['park_front_right'])
            FF = set_bit_in_hex(FF, BIT[6], self.lcm_light['park_rear_left'])
            GG = set_bit_in_hex(GG, BIT[3], self.lcm_light['park_rear_right'])
            FF = set_bit_in_hex(FF, BIT[1], self.lcm_light['low_beam_right'])
            FF = set_bit_in_hex(FF, BIT[2], self.lcm_light['low_beam_left'])
            FF = set_bit_in_hex(FF, BIT[4], self.lcm_light['high_beam_left'])
            FF = set_bit_in_hex(FF, BIT[5], self.lcm_light['high_beam_right'])
            if self.lcm_light['fog_front_left'] and self.lcm_light['fog_front_right']:
                GG = set_bit_in_hex(GG, BIT[0], True)
            else:
                GG = set_bit_in_hex(GG, BIT[0], False)
            GG = set_bit_in_hex(GG, BIT[1], self.lcm_light['licence_plate'])
            EE = set_bit_in_hex(EE, BIT[5], self.lcm_light['turn_front_left'])
            EE = set_bit_in_hex(EE, BIT[6], self.lcm_light['turn_front_right'])
            GG = set_bit_in_hex(GG, BIT[5], self.lcm_light['turn_rear_left'])
            GG = set_bit_in_hex(GG, BIT[7], self.lcm_light['turn_rear_right'])
            IBUS.write_bus_packet(63, 208, [12,
             AA,
             BB,
             CC,
             DD,
             EE,
             FF,
             GG,
             HH,
             II,
             JJ,
             0,
             0,
             0,
             0,
             0], veryhighprio=True)

    def lcm_welcome_on(self, timedelay = 10):
        thread = Thread(target=self._lcm_welcome_on, args=(timedelay,))
        thread.daemon = True
        thread.start()

    def _lcm_welcome_on(self, timedelay = 10):
        if self.day_time and time_now_in_range(self.day_time_start, self.day_time_end):
            return
        self.lcm_delay = timedelay
        if self.ike_states['ign_mode'] > 0:
            log('LCM: Skip Welcomelight, IGN is turned ON')
            return
        sendcount = 10
        self.lcm_on = True
        while self.lcm_delay > 0 and self.lcm_on:
            if self.ike_states['ign_mode'] > 0:
                break
            if sendcount >= 10:
                sendcount = 0
                if self.bm_sensor and not self.bm_sensor_brightness:
                    for _ in range(5):
                        if self.bm_sensor_brightness:
                            break
                        self.bm_get_state()
                        time.sleep(0.2)

                    if self.bm_sensor_brightness:
                        if self.bm_sensor_brightness > self.bm_sensor_level:
                            break
                if self.wel_light_park:
                    self.lcm_light['park_front_left'] = True
                    self.lcm_light['park_front_right'] = True
                    self.lcm_light['park_rear_left'] = True
                    self.lcm_light['park_rear_right'] = True
                if self.wel_light_low:
                    self.lcm_light['low_beam_left'] = True
                    self.lcm_light['low_beam_right'] = True
                if self.wel_light_fog:
                    self.lcm_light['fog_front_left'] = True
                    self.lcm_light['fog_front_right'] = True
                if self.wel_light_nbrplate:
                    self.lcm_light['licence_plate'] = True
                if self.wel_light_turn_front:
                    self.lcm_light['turn_front_left'] = True
                    self.lcm_light['turn_front_right'] = True
                if self.wel_light_turn_back:
                    self.lcm_light['turn_rear_left'] = True
                    self.lcm_light['turn_rear_right'] = True
                self.lcm_light_set()
                log('LCM: LIGHTS ON - Turn OFF in %ss - %s' % (self.lcm_delay, self.car_model))
            sendcount += 1
            self.lcm_delay -= 1
            if self.ike_states['ign_mode'] < 0:
                self.ign_state_get()
            time.sleep(1)

        if self.lcm_on:
            self.lcm_welcome_off()

    def lcm_welcome_off(self):
        self.lcm_delay = -1
        if self.lcm_on:
            self.lcm_light['park_front_left'] = False
            self.lcm_light['park_front_right'] = False
            self.lcm_light['park_rear_left'] = False
            self.lcm_light['park_rear_right'] = False
            self.lcm_light['low_beam_left'] = False
            self.lcm_light['low_beam_right'] = False
            self.lcm_light['fog_front_left'] = False
            self.lcm_light['fog_front_right'] = False
            self.lcm_light['licence_plate'] = False
            self.lcm_light['turn_front_left'] = False
            self.lcm_light['turn_front_right'] = False
            self.lcm_light['turn_rear_left'] = False
            self.lcm_light['turn_rear_right'] = False
            self.lcm_light_set()
            log('LCM: LIGHTS OFF')
        self.lcm_on = False
        self.bm_sensor_brightness = None

    def _lcm_welcome_onOLD(self, timedelay = 10):
        if self.day_time and time_now_in_range(self.day_time_start, self.day_time_end):
            return
        self.lcm_delay = timedelay
        if self.ike_states['ign_mode'] > 0:
            log('LCM: Skip Welcomelight, IGN is turned ON')
            return
        sendcount = 10
        self.lcm_on = True
        while self.lcm_delay > 0 and self.lcm_on:
            if self.ike_states['ign_mode'] > 0:
                break
            if sendcount >= 10:
                sendcount = 0
                if self.bm_sensor and not self.bm_sensor_brightness:
                    wait_counter = 5
                    while wait_counter > 0:
                        wait_counter -= 1
                        if self.bm_sensor_brightness:
                            break
                        self.bm_get_state()
                        time.sleep(0.2)

                    if self.bm_sensor_brightness:
                        if self.bm_sensor_brightness > self.bm_sensor_level:
                            break
                if self.car_model == 'E39':
                    AA = 0
                    BB = 0
                    CC = 0
                    DD = 0
                    EE = 0
                    FF = 0
                    GG = 0
                    HH = 0
                    II = 0
                    if self.wel_light_park:
                        FF = set_bit_in_hex(FF, BIT[0], True)
                        FF = set_bit_in_hex(FF, BIT[1], True)
                        GG = set_bit_in_hex(GG, BIT[3], True)
                        GG = set_bit_in_hex(GG, BIT[5], True)
                        HH = set_bit_in_hex(HH, BIT[3], True)
                        HH = set_bit_in_hex(HH, BIT[4], True)
                    if self.wel_light_low:
                        FF = set_bit_in_hex(FF, BIT[4], True)
                        FF = set_bit_in_hex(FF, BIT[5], True)
                    if self.wel_light_fog:
                        FF = set_bit_in_hex(FF, BIT[2], True)
                        FF = set_bit_in_hex(FF, BIT[6], True)
                    if self.wel_light_nbrplate:
                        GG = set_bit_in_hex(GG, BIT[2], True)
                    if self.wel_light_turn_front:
                        GG = set_bit_in_hex(GG, BIT[6], True)
                        HH = set_bit_in_hex(HH, BIT[6], True)
                    if self.wel_light_turn_back:
                        GG = set_bit_in_hex(GG, BIT[7], True)
                        HH = set_bit_in_hex(HH, BIT[1], True)
                    IBUS.write_bus_packet(63, 208, [12,
                     AA,
                     BB,
                     CC,
                     DD,
                     EE,
                     FF,
                     GG,
                     HH,
                     II,
                     self.lcm_states['diag_dim_level'][0],
                     self.lcm_states['diag_dim_level'][1],
                     0], True)
                elif self.car_model == 'E46':
                    AA = 0
                    BB = 0
                    CC = 255
                    DD = 0
                    EE = 0
                    FF = 0
                    GG = 0
                    HH = 0
                    if self.wel_light_park:
                        EE = set_bit_in_hex(EE, BIT[1], True)
                        FF = set_bit_in_hex(FF, BIT[3], True)
                        FF = set_bit_in_hex(FF, BIT[6], True)
                        GG = set_bit_in_hex(GG, BIT[3], True)
                    if self.wel_light_low:
                        FF = set_bit_in_hex(FF, BIT[1], True)
                        FF = set_bit_in_hex(FF, BIT[2], True)
                    if self.wel_light_fog:
                        GG = set_bit_in_hex(GG, BIT[0], True)
                    if self.wel_light_nbrplate:
                        GG = set_bit_in_hex(GG, BIT[1], True)
                    if self.wel_light_turn_front:
                        EE = set_bit_in_hex(EE, BIT[5], True)
                        EE = set_bit_in_hex(EE, BIT[6], True)
                    if self.wel_light_turn_back:
                        GG = set_bit_in_hex(GG, BIT[5], True)
                        GG = set_bit_in_hex(GG, BIT[7], True)
                    IBUS.write_bus_packet(63, 208, [12,
                     AA,
                     BB,
                     CC,
                     DD,
                     EE,
                     FF,
                     GG,
                     HH,
                     0,
                     self.lcm_states['diag_dim_level'][0],
                     0,
                     0,
                     0,
                     0,
                     0], True)
                log('LCM: LIGHTS ON - Turn OFF in %ss - %s' % (self.lcm_delay, self.car_model))
            sendcount += 1
            self.lcm_delay += -1
            if self.ike_states['ign_mode'] < 0:
                self.ign_state_get()
            time.sleep(1)

        if self.lcm_on:
            self.lcm_welcome_off()

    def lcm_welcome_offOLD(self):
        self.lcm_delay = -1
        if self.lcm_on:
            IBUS.write_bus_packet(63, 208, [159], True, repeat=2)
            log('LCM: LIGHTS OFF')
        self.lcm_on = False
        self.bm_sensor_brightness = None

    def lcm_flash_to_pass(self, state):
        if self.lcm_states['low_beam'] and self.flash_to_pass_low_beam:
            return
        if (self.lcm_states['low_beam'] or self.lcm_states['fog_front']) and self.flash_to_pass_fog:
            return
        if state:
            if self.flash_to_pass and (self.flash_to_pass_low_beam or self.flash_to_pass_fog):
                if self.flash_to_pass_low_beam:
                    self.lcm_light['low_beam_left'] = True
                    self.lcm_light['low_beam_right'] = True
                    self.flashing_to_pass_low = True
                if self.flash_to_pass_fog:
                    self.lcm_light['fog_front_left'] = True
                    self.lcm_light['fog_front_right'] = True
                    self.flashing_to_pass_fog = True
                log('LCM: FLASH TO PASS: FOG=%s; LOWBEAM=%s' % (self.flash_to_pass_fog, self.flash_to_pass_low_beam))
                self.lcm_light_set()
        else:
            self.lcm_light['low_beam_left'] = self.lcm_drl_is_active() and self.drl_light_low_beam
            self.lcm_light['low_beam_right'] = self.lcm_drl_is_active() and self.drl_light_low_beam
            if self.turning_fog_left:
                self.lcm_light['fog_front_left'] = True
            elif self.lcm_drl_is_active() and self.drl_light_fog:
                self.lcm_light['fog_front_left'] = True
            else:
                self.lcm_light['fog_front_left'] = False
            if self.turning_fog_right:
                self.lcm_light['fog_front_right'] = True
            elif self.lcm_drl_is_active() and self.drl_light_fog:
                self.lcm_light['fog_front_right'] = True
            else:
                self.lcm_light['fog_front_right'] = False
            self.flashing_to_pass_low = False
            self.flashing_to_pass_fog = False
            self.lcm_light_set()

    def lcm_flash_to_passOLD(self, state):
        if True in [self.turning_left,
         self.turning_fog_left,
         self.turning_right,
         self.turning_fog_right]:
            return
        if self.lcm_states['low_beam'] and self.flash_to_pass_low_beam:
            return
        if (self.lcm_states['low_beam'] or self.lcm_states['fog_front']) and self.flash_to_pass_fog:
            return
        if state:
            if self.flash_to_pass and (self.flash_to_pass_low_beam or self.flash_to_pass_fog):
                if self.car_model == 'E39':
                    ff = 0
                    if self.flash_to_pass_low_beam and self.flash_to_pass_fog:
                        ff = 116
                    elif self.flash_to_pass_low_beam:
                        ff = 48
                    elif self.flash_to_pass_fog:
                        ff = 68
                    log('LCM: FLASH TO PASS: FOG=%s; LOWBEAM=%s' % (self.flash_to_pass_fog, self.flash_to_pass_low_beam))
                    IBUS.write_bus_packet(63, 208, [12,
                     0,
                     0,
                     0,
                     0,
                     0,
                     ff,
                     0,
                     0,
                     0,
                     self.lcm_states['diag_dim_level'][0],
                     self.lcm_states['diag_dim_level'][1],
                     0], veryhighprio=True)
                elif self.car_model == 'E46':
                    ff = 0
                    gg = 0
                    if self.flash_to_pass_low_beam and self.flash_to_pass_fog:
                        ff = 6
                        gg = 1
                    elif self.flash_to_pass_low_beam:
                        ff = 6
                        gg = 0
                    elif self.flash_to_pass_fog:
                        ff = 0
                        gg = 1
                    log('LCM: FLASH TO PASS: FOG=%s; LOWBEAM=%s' % (self.flash_to_pass_fog, self.flash_to_pass_low_beam))
                    IBUS.write_bus_packet(63, 208, [12,
                     0,
                     0,
                     255,
                     0,
                     0,
                     ff,
                     gg,
                     0,
                     0,
                     self.lcm_states['diag_dim_level'][0],
                     0,
                     0,
                     0,
                     0,
                     0], veryhighprio=True)
        else:
            self._lcm_turn_off()

    def lcm_turn_left(self):
        if not self.turning_left:
            if self.comfort_blink or self.turn_light:
                if not self.turning_right and self.turning_fog_right:
                    self.cancel_turn_right = True
                elif self.turning_right:
                    self.cancel_turn_right = True
                    self._lcm_turn_off()
                    return
                while self.cancel_turn_right:
                    time.sleep(0.001)

                if self.turning_fog_left:
                    self.cancel_turn_left = True
                    while self.cancel_turn_left:
                        time.sleep(0.001)

            thread = Thread(target=self._lcm_turn_left_on)
            thread.daemon = True
            thread.start()
        else:
            self.cancel_turn_left = True
            self._lcm_turn_off()

    def lcm_turn_right(self):
        if not self.turning_right:
            if self.comfort_blink or self.turn_light:
                if not self.turning_left and self.turning_fog_left:
                    self.cancel_turn_left = True
                elif self.turning_left:
                    self.cancel_turn_left = True
                    self._lcm_turn_off()
                    return
                while self.cancel_turn_left:
                    time.sleep(0.001)

                if self.turning_fog_right:
                    self.cancel_turn_right = True
                    while self.cancel_turn_right:
                        time.sleep(0.001)

            thread = Thread(target=self._lcm_turn_right_on)
            thread.daemon = True
            thread.start()
        else:
            self.cancel_turn_left = True
            self._lcm_turn_off()

    def _lcm_turn_left_onOLD(self):
        log('LCM: LIGHTS TURN LEFT')
        if self.comfort_blink:
            log('LCM: LIGHTS TURN LEFT FLASH')
            self.turning_left = True
            if self.car_model == 'E39':
                fog = 4 if self.turn_light and self.lcm_states['park'] and self.obc_speed_kmh <= self.turn_light_max_speed else 0
                IBUS.write_bus_packet(63, 208, [12,
                 0,
                 0,
                 128,
                 0,
                 0,
                 fog,
                 0,
                 0,
                 0,
                 self.lcm_states['diag_dim_level'][0],
                 self.lcm_states['diag_dim_level'][1],
                 0], veryhighprio=True)
            elif self.car_model == 'E46':
                IBUS.write_bus_packet(63, 208, [12,
                 0,
                 0,
                 255,
                 64,
                 0,
                 0,
                 0,
                 0,
                 0,
                 self.lcm_states['diag_dim_level'][0],
                 0,
                 0,
                 0,
                 0,
                 0], veryhighprio=True)
            counter = self.comfort_blink_time
            while counter > 0:
                if self.cancel_turn_left:
                    break
                counter -= 1
                time.sleep(0.001)

        if self.turn_light and self.lcm_states['park'] and self.car_model == 'E39' and not self.cancel_turn_left and self.obc_speed_kmh <= self.turn_light_max_speed:
            log('LCM: LIGHTS TURN LEFT FOG')
            self.turning_fog_left = True
            IBUS.write_bus_packet(63, 208, [12,
             0,
             0,
             0,
             0,
             0,
             4,
             0,
             0,
             0,
             self.lcm_states['diag_dim_level'][0],
             self.lcm_states['diag_dim_level'][1],
             0], veryhighprio=True, repeat=2)
            self.turning_left = False
            counter = self.turn_light_time - (self.comfort_blink_time if self.comfort_blink else 0)
            light_counter = 10000
            while counter > 0:
                if self.cancel_turn_left or self.obc_speed_kmh > self.turn_light_max_speed or not self.lcm_states['park']:
                    break
                if self.lcm_states['turn_left']:
                    counter = self.turn_light_time / 2
                else:
                    counter -= 1
                light_counter -= 1
                if light_counter == 0:
                    light_counter = 10000
                    IBUS.write_bus_packet(63, 208, [12,
                     0,
                     0,
                     0,
                     0,
                     0,
                     4,
                     0,
                     0,
                     0,
                     self.lcm_states['diag_dim_level'][0],
                     self.lcm_states['diag_dim_level'][1],
                     0], veryhighprio=True)
                time.sleep(0.001)

        if not self.cancel_turn_left:
            self._lcm_turn_off()
        self.turning_left = False
        self.turning_fog_left = False
        self.cancel_turn_left = False

    def _lcm_turn_left_on(self):
        log('LCM: LIGHTS TURN LEFT')
        if self.comfort_blink:
            log('LCM: LIGHTS TURN LEFT FLASH')
            self.turning_left = True
            if self.turn_light and self.lcm_states['park'] and self.obc_speed_kmh <= self.turn_light_max_speed:
                self.turning_fog_left = True
                self.lcm_light['fog_front_left'] = True
                self.lcm_light['fog_front_right'] = False
            else:
                self.lcm_light['fog_front_left'] = False
            if self.lcm_drl_is_active() and self.drl_light_fog:
                self.lcm_light['fog_front_left'] = True
                self.lcm_light['fog_front_right'] = True
            self.lcm_light['switch_turn_left'] = True
            self.lcm_light['switch_turn_right'] = False
            self.lcm_light_set()
            counter = self.comfort_blink_time
            while counter > 0:
                if self.cancel_turn_left:
                    break
                counter -= 1
                time.sleep(0.001)

        if self.turn_light and self.lcm_states['park'] and self.car_model == 'E39' and not self.cancel_turn_left and self.obc_speed_kmh <= self.turn_light_max_speed:
            log('LCM: LIGHTS TURN LEFT FOG')
            self.lcm_light['switch_turn_left'] = False
            self.lcm_light['switch_turn_right'] = False
            self.lcm_light_set()
            self.turning_left = False
            counter = self.turn_light_time - (self.comfort_blink_time if self.comfort_blink else 0)
            light_counter = 10000
            while counter > 0:
                if self.cancel_turn_left or self.obc_speed_kmh > self.turn_light_max_speed or not self.lcm_states['park']:
                    break
                if self.lcm_states['turn_left']:
                    counter = self.turn_light_time / 2
                else:
                    counter -= 1
                light_counter -= 1
                if light_counter == 0:
                    light_counter = 10000
                    self.lcm_light_set()
                time.sleep(0.001)

        if not self.cancel_turn_left:
            self._lcm_turn_off()
        self.turning_left = False
        self.turning_fog_left = False
        self.cancel_turn_left = False

    def _lcm_turn_right_onOLD(self):
        log('LCM: LIGHTS TURN RIGHT')
        if self.comfort_blink:
            log('LCM: LIGHTS TURN RIGHT FLASH')
            self.turning_right = True
            if self.car_model == 'E39':
                fog = 64 if self.turn_light and self.lcm_states['park'] and self.obc_speed_kmh <= self.turn_light_max_speed else 0
                IBUS.write_bus_packet(63, 208, [12,
                 0,
                 0,
                 64,
                 0,
                 0,
                 fog,
                 0,
                 0,
                 0,
                 self.lcm_states['diag_dim_level'][0],
                 self.lcm_states['diag_dim_level'][1],
                 0], veryhighprio=True)
            elif self.car_model == 'E46':
                IBUS.write_bus_packet(63, 208, [12,
                 0,
                 0,
                 255,
                 128,
                 0,
                 0,
                 0,
                 0,
                 0,
                 self.lcm_states['diag_dim_level'][0],
                 0,
                 0,
                 0,
                 0,
                 0], veryhighprio=True)
            counter = self.comfort_blink_time
            while counter > 0:
                if self.cancel_turn_right:
                    break
                counter -= 1
                time.sleep(0.001)

        if self.turn_light and self.lcm_states['park'] and self.car_model == 'E39' and not self.cancel_turn_right and self.obc_speed_kmh <= self.turn_light_max_speed:
            log('LCM: LIGHTS TURN RIGHT FOG')
            self.turning_fog_right = True
            IBUS.write_bus_packet(63, 208, [12,
             0,
             0,
             0,
             0,
             0,
             64,
             0,
             0,
             0,
             self.lcm_states['diag_dim_level'][0],
             self.lcm_states['diag_dim_level'][1],
             0], veryhighprio=True, repeat=2)
            self.turning_right = False
            counter = self.turn_light_time - (self.comfort_blink_time if self.comfort_blink else 0)
            light_counter = 10000
            while counter > 0:
                if self.cancel_turn_right or self.obc_speed_kmh > self.turn_light_max_speed or not self.lcm_states['park']:
                    break
                if self.lcm_states['turn_right']:
                    counter = self.turn_light_time / 2
                else:
                    counter -= 1
                light_counter -= 1
                if light_counter == 0:
                    light_counter = 10000
                    IBUS.write_bus_packet(63, 208, [12,
                     0,
                     0,
                     0,
                     0,
                     0,
                     64,
                     0,
                     0,
                     0,
                     self.lcm_states['diag_dim_level'][0],
                     self.lcm_states['diag_dim_level'][1],
                     0], veryhighprio=True)
                time.sleep(0.001)

        if not self.cancel_turn_right:
            self._lcm_turn_off()
        self.cancel_turn_right = False
        self.turning_right = False
        self.turning_fog_right = False

    def _lcm_turn_right_on(self):
        log('LCM: LIGHTS TURN RIGHT')
        if self.comfort_blink:
            log('LCM: LIGHTS TURN RIGHT FLASH')
            self.turning_right = True
            if self.turn_light and self.lcm_states['park'] and self.obc_speed_kmh <= self.turn_light_max_speed:
                self.turning_fog_right = True
                self.lcm_light['fog_front_right'] = True
                self.lcm_light['fog_front_left'] = False
            else:
                self.lcm_light['fog_front_right'] = False
            if self.lcm_drl_is_active() and self.drl_light_fog:
                self.lcm_light['fog_front_left'] = True
                self.lcm_light['fog_front_right'] = True
            self.lcm_light['switch_turn_left'] = False
            self.lcm_light['switch_turn_right'] = True
            self.lcm_light_set()
            counter = self.comfort_blink_time
            while counter > 0:
                if self.cancel_turn_right:
                    break
                counter -= 1
                time.sleep(0.001)

        if self.turn_light and self.lcm_states['park'] and self.car_model == 'E39' and not self.cancel_turn_right and self.obc_speed_kmh <= self.turn_light_max_speed:
            log('LCM: LIGHTS TURN RIGHT FOG')
            self.lcm_light['switch_turn_left'] = False
            self.lcm_light['switch_turn_right'] = False
            self.lcm_light_set()
            self.turning_right = False
            counter = self.turn_light_time - (self.comfort_blink_time if self.comfort_blink else 0)
            light_counter = 10000
            while counter > 0:
                if self.cancel_turn_right or self.obc_speed_kmh > self.turn_light_max_speed or not self.lcm_states['park']:
                    break
                if self.lcm_states['turn_right']:
                    counter = self.turn_light_time / 2
                else:
                    counter -= 1
                light_counter -= 1
                if light_counter == 0:
                    light_counter = 10000
                    self.lcm_light_set()
                time.sleep(0.001)

        if not self.cancel_turn_right:
            self._lcm_turn_off()
        self.cancel_turn_right = False
        self.turning_right = False
        self.turning_fog_right = False

    def _lcm_turn_offOLD(self):
        IBUS.write_bus_packet(63, 208, [159], veryhighprio=True, repeat=2)

    def _lcm_turn_off(self):
        log('LCM: COMFORT BLINK SHOULD TURN OFF', 2)
        self.lcm_light['switch_turn_left'] = False
        self.lcm_light['switch_turn_right'] = False
        self.lcm_light['fog_front_left'] = self.ike_states['ign_mode'] > 1 and not self.lcm_states['park'] and self.drl_light_fog
        self.lcm_light['fog_front_right'] = self.ike_states['ign_mode'] > 1 and not self.lcm_states['park'] and self.drl_light_fog
        self.lcm_light_set()

    def lcm_drl_tick(self):
        if self.lcm_drl_is_active():
            self.lcm_light_set()
        KODI.set_property('IBUSCOMMUNICATOR_DRL_SHOW', '1')
        counter = 11
        while not self.cancel_read_thread and not self.cancel_lcm_ticker:
            if counter <= 0:
                if self.lcm_drl_is_active():
                    self.lcm_light_set()
                    log('LCM: DRL TICK')
                counter = 11
            else:
                counter -= 0.5
            time.sleep(0.5)

        log('LCM: DRL TICK FINISHED')
        KODI.set_property('IBUSCOMMUNICATOR_DRL_SHOW', '0')
        self.lcm_ticker = None

    def lcm_drl_on(self):
        log('LCM: DRL try to start...', 2)
        for _ in range(0, 10):
            if self.lcm_states['run_once']:
                break
            time.sleep(0.2)

        if self.lcm_states['park']:
            log('LCM: DRL canceled, Park Lights turned ON', 1)
            return
        if not self.drl_light:
            log('LCM: DRL Setting is not enabled', 1)
            return
        if True not in [self.drl_light_park, self.drl_light_fog]:
            log('LCM: DRL All Lights are disabled', 1)
            return
        self.lcm_light['park_front_left'] = self.drl_light_park
        self.lcm_light['park_front_right'] = self.drl_light_park
        self.lcm_light['fog_front_left'] = self.drl_light_fog
        self.lcm_light['fog_front_right'] = self.drl_light_fog
        if self.lcm_drl_is_active():
            self.lcm_light_set()
            log('LCM: DRL Thread exist already', 2)
            return
        if self.ike_states['ign_mode'] < 2:
            log("LCM: DRL don't start", 2)
            return
        self.lcm_ticker = Thread(target=self.lcm_drl_tick)
        self.lcm_ticker.daemon = True
        self.cancel_lcm_ticker = False
        self.lcm_ticker.start()
        log('LCM: DRL started')

    def lcm_drl_off(self):
        KODI.set_property('IBUSCOMMUNICATOR_DRL_SHOW', '0')
        self.lcm_light['park_front_left'] = False
        self.lcm_light['park_front_right'] = False
        self.lcm_light['fog_front_left'] = self.turning_fog_left
        self.lcm_light['fog_front_right'] = self.turning_fog_right
        self.lcm_light['low_beam_left'] = False
        self.lcm_light['low_beam_right'] = False
        try:
            if not self.lcm_ticker:
                return
        except:
            return

        self.cancel_lcm_ticker = True
        self.lcm_light_set()
        self.lcm_ticker.join()
        log('LCM: DRL stopped')

    def lcm_drl_is_active(self):
        if not self.drl_light:
            log('LCM: DRL Settings is False', 2)
            return False
        if self.ike_states['ign_mode'] < 2:
            log('LCM: IGN is < 2', 2)
            return False
        if self.lcm_states['park']:
            log('LCM: Park Lights are turned ON', 2)
            return False
        if not self.lcm_ticker:
            log('LCM: DRL Thread exist already', 2)
            return False
        return True

    def send_song_to_ike(self):
        if not self.ike_display or not self.ike_track:
            self.new_song = False
            return
        thread = Thread(target=self._send_song_to_ike_thread)
        thread.daemon = True
        thread.start()

    def _send_song_to_ike_thread(self):
        try:
            while int(xbmc.Player().getTime()) > 0.2:
                time.sleep(0.01)

            while not xbmc.Player().isPlaying():
                time.sleep(0.01)

            while int(xbmc.Player().getTime()) < 0.5:
                time.sleep(0.01)

            Song = KODI.track_title()
            if Song == '':
                return
            log('SEND SONG: "%s" to IKE Display' % Song, 2)
            self.ike_send_text(Song)
        except:
            log('Kodi has an error with playing or -> not playing <- media.')

        self.new_song = False

    def ike_send_text_warning(self, text):
        if self.ike_text_scrolling:
            self.ike_text_scroll_pause = True
        self.ike_send_text(Text='%s' % text, when_pi_is_inactiv=True, gong=True)
        self.ike_clear_display(delay=2.5, gong=True)
        self.ike_text_scroll_pause = False

    def ike_send_text(self, Text, when_pi_is_inactiv = False, when_ign_off = False, gong = False):
        if not self.ike_display or self.stw_nav:
            return
        time.sleep(0.05)
        while self.ike_text_scroll_thread.isAlive():
            self.ike_text_scrolling = False if self.ike_text_scrolling else True
            time.sleep(0.001)

        self.ike_text_scroll_thread = Thread(target=self._ike_send_text_thread, args=(Text,
         when_pi_is_inactiv,
         when_ign_off,
         gong))
        self.ike_text_scroll_thread.daemon = True
        self.ike_text_scrolling = True
        self.ike_text_scroll_thread.start()

    def _ike_send_text_thread(self, text, when_pi_is_inactiv = False, when_ign_off = False, gong = False):
        if not self.pi_is_active and not when_pi_is_inactiv:
            return
        scrollspeed = self.text_scrollspeed
        displaylength = 20
        text = _encode_ibus_chars(text)
        if len(text) <= displaylength:
            self.ike_text_to_ibus(text.center(20), when_ign_off=when_ign_off, gong=gong)
        else:
            self.ike_text_to_ibus(text[:20], when_ign_off=when_ign_off)
            ticker = 1500
            while ticker > 0:
                if not self.ike_text_scrolling:
                    return
                if self.ike_text_scroll_pause:
                    continue
                if not self.pi_is_active and not when_pi_is_inactiv:
                    return self.ike_clear_display(0)
                ticker -= 1
                time.sleep(0.001)

            cnt = len(text)
            cnt_tmp = 0
            ticker = 1
            while cnt_tmp + displaylength <= cnt:
                if not self.ike_text_scrolling:
                    return
                if self.ike_text_scroll_pause:
                    continue
                if not self.pi_is_active and not when_pi_is_inactiv:
                    return self.ike_clear_display(0)
                if ticker >= scrollspeed:
                    self.ike_text_to_ibus(text[cnt_tmp:displaylength + cnt_tmp], when_ign_off=when_ign_off)
                    cnt_tmp += 1
                    ticker = 1
                else:
                    ticker += 1
                time.sleep(0.001)

            ticker = 1
            while ticker < 1000:
                if not self.ike_text_scrolling:
                    return
                if self.ike_text_scroll_pause:
                    continue
                if not self.pi_is_active and not when_pi_is_inactiv:
                    return self.ike_clear_display(0)
                ticker += 1
                time.sleep(0.001)

            ticker = 1
            cnt_tmp = len(text) - displaylength
            while cnt_tmp + displaylength >= displaylength:
                if not self.ike_text_scrolling:
                    return
                if self.ike_text_scroll_pause:
                    continue
                if not self.pi_is_active and not when_pi_is_inactiv:
                    return self.ike_clear_display(0)
                if ticker == scrollspeed:
                    self.ike_text_to_ibus(text[cnt_tmp:displaylength + cnt_tmp], when_ign_off=when_ign_off)
                    cnt_tmp -= 1
                    ticker = 1
                else:
                    ticker += 1
                time.sleep(0.001)

        self.ike_text_scrolling = False
        if not when_ign_off:
            return self.ike_clear_display()

    def ike_text_to_ibus(self, text, when_ign_off = False, gong = False):
        if gong:
            dat = [26, 63, 15]
            time.sleep(0.2)
        else:
            dat = [26, 53, 0] if when_ign_off else [35, 98, 48]
        dat.extend(asc_to_hex(text))
        IBUS.write_bus_packet(200, 128, dat)
        log('IKE TEXT: %s GONG=%s' % (text, gong))

    def ike_clear_display(self, delay = 3.0, when_ign_off = False, gong = False):
        if not self.ike_display:
            return
        if self.ike_text_scrolling:
            self.ike_text_scrolling = False
        while delay > 0.0:
            if self.ike_text_scrolling:
                return
            delay -= 0.001
            time.sleep(0.001)

        if when_ign_off or gong:
            IBUS.write_bus_packet(200, 128, [26, 48, 0])
        else:
            IBUS.write_bus_packet(200, 128, [35, 64, 48])

    def mid_fond_ike_ready_req(self):
        log('FMID: REQUEST: IS IKE READY')
        IBUS.write_bus_packet(160, 128, [1])

    def mid_send_text(self, text, gong = False):
        log('send text to MID: %s' % text)
        text = _encode_ibus_chars(text)
        if len(text) <= 11:
            text = text.ljust(11, ' ')
        else:
            text = text[11:]
        dat = [35, 146, 48]
        dat.extend(asc_to_hex(text.ljust(11)))
        IBUS.write_bus_packet(104, 192, dat)

    def bm_led(self, color, state = False):
        if color.lower() == 'red':
            IBUS.write_bus_packet(200, 240, [43, 1])
        if color.lower() == 'yellow':
            IBUS.write_bus_packet(200, 240, [43, 4])
        if color.lower() == 'green':
            IBUS.write_bus_packet(200, 240, [43, 16])
        if color.lower() == 'off':
            IBUS.write_bus_packet(200, 240, [43, 0])

    def bm_get_state(self):
        IBUS.write_bus_packet(63, 240, [11, 2])

    def bm_set_state(self, dat):
        if len(dat) < 2:
            return
        self.bm_sensor_brightness = dat[12]
        if self.bm_sensor_brightness == 0:
            self.bm_sensor_brightness = 1
        log('BMBT: Brightness = %s' % self.bm_sensor_brightness, 2)

    def bm_set_brightness(self, value):
        if value > 0:
            value = int(translate(value, 1, 10, 0, 127))
        elif value == 0:
            value = 128
        elif value < 0:
            value = int(translate(value * -1, 1, 10, 129, 255))
        IBUS.write_bus_packet(59, 240, [5,
         65,
         1,
         value])
        log('BMBT: Set LCD Brightness = %s' % value)

    def pdc_req_start(self):
        if not self.pdc_on:
            return
        if not self.pdc_req_running:
            self.pdc_on_value = None
            thread = Thread(target=self._pdc_req_start)
            thread.daemon = True
            thread.start()

    def _pdc_req_start(self):
        log('PDC: Request Started')
        self.got_pdc_answer = True
        self.pdc_req_running = True
        self.pdc_counter = self.pdc_timeout
        no_answer_counter = 0
        while self.pdc_counter > 0:
            if self.pdc_req_cancel:
                break
            if self.got_pdc_answer or no_answer_counter >= 1 / self.pdc_interval:
                no_answer_counter = 0
                self.got_pdc_answer = False
                IBUS.write_bus_packet(63, 96, [27])
            no_answer_counter += 1
            if self.ike_states['gear_pos'] == 'R':
                self.pdc_counter = self.pdc_timeout
            else:
                self.pdc_counter -= self.pdc_interval
            time.sleep(self.pdc_interval)

        self.pdc_req_running = False
        self.pdc_on_value = None
        log('PDC: Request Stoped')
        if not self.pass_bm_buttons:
            self.gt_av_r_on(False)
        KODI.set_property('IBUS_PDC_SHOW', '0')
        if not self.pdc_req_cancel and self.pdc_timeout_off:
            IBUS.write_bus_packet(63, 96, [12, 64])
        self.pdc_req_cancel = False

    def pdc_req_stop(self):
        self.pdc_req_cancel = True

    def pdc_put_state(self, dat):
        if not self.pdc_on:
            return
        if len(dat) < 2:
            return
        self.got_pdc_answer = True

        def pdc_image(value):
            log('input: %s' % value, 3)
            value_min = 15
            value_max = 75
            if value <= value_min:
                return '20'
            if value_min <= value <= value_max:
                result = '%s' % abs(int(translate(value, value_min, value_max, -20, 0)))
                if len(result) < 2:
                    return '%s'.zfill(3) % result
                return '%s' % result
            if value > value_max:
                return '00'

        def pdc_label(value):
            if value > 75:
                return '---'
            return '%s' % value

        front_left_side = dat[6]
        front_right_side = dat[7]
        front_left_center = dat[8]
        front_right_center = dat[9]
        rear_left_side = dat[2]
        rear_right_side = dat[3]
        rear_left_center = dat[4]
        rear_right_center = dat[5]
        on_value = get_bit_from_hex(dat[10], BIT[0])
        if rear_left_side + rear_right_side + rear_left_center + rear_right_center + front_left_side + front_right_side + front_left_center + front_right_center < 2040:
            self.pdc_counter = self.pdc_timeout
        if not EVENT.pdc_type:
            KODI.set_property('IBUS_PDC_FLS', '%s' % pdc_label(front_left_side))
            KODI.set_property('IBUS_PDC_FLC', '%s' % pdc_label(front_left_center))
            KODI.set_property('IBUS_PDC_FRC', '%s' % pdc_label(front_right_center))
            KODI.set_property('IBUS_PDC_FRS', '%s' % pdc_label(front_right_side))
        else:
            KODI.set_property('IBUS_PDC_FLS', ' ')
            KODI.set_property('IBUS_PDC_FLC', ' ')
            KODI.set_property('IBUS_PDC_FRC', ' ')
            KODI.set_property('IBUS_PDC_FRS', ' ')
        KODI.set_property('IBUS_PDC_RLS', '%s' % pdc_label(rear_left_side))
        KODI.set_property('IBUS_PDC_RLC', '%s' % pdc_label(rear_left_center))
        KODI.set_property('IBUS_PDC_RRC', '%s' % pdc_label(rear_right_center))
        KODI.set_property('IBUS_PDC_RRS', '%s' % pdc_label(rear_right_side))
        log('PDC: Values\n                   %s - %s - %s - %s \n                   %s - %s - %s - %s ' % (front_left_side,
         front_left_center,
         front_right_center,
         front_right_side,
         rear_left_side,
         rear_left_center,
         rear_right_center,
         rear_right_side), 2)
        log('pic number - %s' % pdc_image(front_left_center), 3)
        KODI.set_property('IBUS_PDC_BG_IMG', '%s' % EVENT.pdc_bg)
        if not EVENT.pdc_type:
            KODI.set_property('IBUS_PDC_FLS_IMG', '%s' % pdc_image(front_left_side))
            KODI.set_property('IBUS_PDC_FLC_IMG', '%s' % pdc_image(front_left_center))
            KODI.set_property('IBUS_PDC_FRC_IMG', '%s' % pdc_image(front_right_center))
            KODI.set_property('IBUS_PDC_FRS_IMG', '%s' % pdc_image(front_right_side))
        else:
            KODI.set_property('IBUS_PDC_FLS_IMG', '00')
            KODI.set_property('IBUS_PDC_FLC_IMG', '00')
            KODI.set_property('IBUS_PDC_FRC_IMG', '00')
            KODI.set_property('IBUS_PDC_FRS_IMG', '00')
        KODI.set_property('IBUS_PDC_RLS_IMG', '%s' % pdc_image(rear_left_side))
        KODI.set_property('IBUS_PDC_RLC_IMG', '%s' % pdc_image(rear_left_center))
        KODI.set_property('IBUS_PDC_RRC_IMG', '%s' % pdc_image(rear_right_center))
        KODI.set_property('IBUS_PDC_RRS_IMG', '%s' % pdc_image(rear_right_side))
        if self.pdc_on_value:
            if not on_value:
                self.pdc_req_stop()
        else:
            if self.pdc_req_running:
                KODI.set_property('IBUS_PDC_SHOW', '1')
                if not self.pass_bm_buttons:
                    self.gt_av_r_on(True)
            self.pdc_on_value = on_value

    def rearcam_on(self):
        if self.gpio_rearcam:
            thread = Thread(target=self._rearcam_on)
            thread.daemon = True
            thread.start()

    def _rearcam_on(self):
        if self.rearcam_active:
            return
        if self.gpio_rearcam_counter > 0:
            self.gpio_rearcam_counter = self.gpio_rearcam_timeout * 10
            self.rearcam_active = True
            return
        self.rearcam_active = True
        if self.gpio_rearcam_off == 2:
            self.gpio_rearcam_counter = 600
        else:
            self.gpio_rearcam_counter = self.gpio_rearcam_timeout * 10
        GPIO_REARCAM.set()
        self.gt_av_r_on(True)
        log('REARCAM RELAIS: ON')
        while True:
            if not self.rearcam_active:
                if self.gpio_rearcam_off == 0:
                    break
                elif self.gpio_rearcam_off == 1:
                    if self.gpio_rearcam_counter < 1:
                        break
                    else:
                        log('REARCAM RELAIS: OFF in %ss' % (float(self.gpio_rearcam_counter) / 10), 2)
                        self.gpio_rearcam_counter -= 1
                elif self.gpio_rearcam_off == 2:
                    if self.obc_speed_kmh >= self.gpio_rearcam_speed or self.gpio_rearcam_counter < 1:
                        break
                    else:
                        log('REARCAM RELAIS: OFF in %ss or current Speed(%s) >= %s' % (float(self.gpio_rearcam_counter) / 10, self.obc_speed_kmh, self.gpio_rearcam_speed), 2)
                        self.gpio_rearcam_counter -= 1
            time.sleep(0.1)

        self.gpio_rearcam_counter = 0
        GPIO_REARCAM.reset()
        if not self.pass_bm_buttons:
            self.gt_av_r_on(False)
        log('REARCAM RELAIS: OFF')

    def rearcam_off(self):
        self.rearcam_active = False

    def nav_position_req(self):
        IBUS.write_bus_packet(200, 127, [161, 0])
        log('NAV: REQ: POSITION', 2)

    def nav_position_get(self):

        def dms2dd(degrees, minutes, seconds, direction):
            dd = float(degrees) + float(minutes) / 60 + float(seconds) / 3600
            if direction == 'S' or direction == 'W':
                dd *= -1
            return dd

        def dd2dms(deg):
            d = int(deg)
            md = abs(deg - d) * 60
            m = int(md)
            sd = (md - m) * 60
            return [d, m, sd]

        def parse_dms(dms):
            parts = split('[\xc2\xb0\'"]+', dms)
            lat = dms2dd(parts[0], parts[1], parts[2], parts[3])
            return lat

        self.nav_states['latitude'] = ' '
        self.nav_states['longitude'] = ' '
        for _ in range(0, 4):
            self.nav_position_req()
            if self.nav_states['latitude'] != ' ' and self.nav_states['longitude'] != ' ':
                lat = parse_dms(self.nav_states['latitude'])
                lon = parse_dms(self.nav_states['longitude'])
                return [lat, lon]
            time.sleep(0.2)

    def nav_location_req(self):
        IBUS.write_bus_packet(200, 127, [163, 0])
        log('NAV: REQ: LOCATION', 2)

    def nav_position_put(self, dat):
        self.nav_states['gpsfix'] = bool(dat[1])
        self.nav_states['latitude'] = '%02X\xc2\xb0%02X\'%02X.%s"%s' % (dat[3],
         dat[4],
         dat[5],
         ('%02X' % dat[6])[0],
         'S' if dat[6] & 15 == 1 else 'N')
        self.nav_states['longitude'] = '%02X\xc2\xb0%02X\'%02X.%s"%s' % (dat[8],
         dat[9],
         dat[10],
         ('%02X' % dat[11])[0],
         'W' if dat[11] & 15 == 1 else 'E')
        self.nav_states['altitude'] = int('%02X%02X' % (dat[12], dat[13]))
        self.nav_states['time'] = '%02X:%02X:%02X' % (dat[15], dat[16], dat[17])
        log('NAV: PUT: GPSFIX: %s' % self.nav_states['gpsfix'])
        log('NAV: PUT: LATITUDE: %s' % self.nav_states['latitude'])
        log('NAV: PUT: LONGITUDE: %s' % self.nav_states['longitude'])
        log('NAV: PUT: ALTITUDE: %s m' % self.nav_states['altitude'])
        log('NAV: PUT: TIME: %s UTC' % self.nav_states['time'])

    def nav_location_put(self, dat):
        if dat[2] == 1:
            self.nav_states['town'] = hex_to_asc(dat[3:])
            log('NAV: PUT: TOWN: %s' % self.nav_states['town'])
        elif dat[2] == 2:
            self.nav_states['street'] = hex_to_asc(dat[3:]).replace(';', '')
            log('NAV: PUT: STREET: %s' % self.nav_states['street'])

    def nav_gpsfix_get(self):
        return self.nav_states['gpsfix']

    def nav_latitude_get(self):
        return '%s' % self.nav_states['latitude']

    def nav_longitude_get(self):
        return '%s' % self.nav_states['longitude']

    def nav_altitude_get(self):
        return '%s m' % self.nav_states['altitude']

    def nav_time_get(self):
        return '%s UTC' % self.nav_states['time']

    def nav_town_get(self):
        return '%s' % self.nav_states['town']

    def nav_street_get(self):
        return '%s' % self.nav_states['street']

    def nav_zoom(self, speed_kmh):
        if not self.map_auto_zoom:
            return
        zoom_level = -1
        if speed_kmh < self.map_auto_zoom_200 - 20:
            zoom_level = 100
        elif speed_kmh >= self.map_auto_zoom_5000:
            zoom_level = 5000
        elif speed_kmh >= self.map_auto_zoom_2000 and self.map_states['zoom_level'] < 2000:
            zoom_level = 2000
        elif speed_kmh >= self.map_auto_zoom_1000 and self.map_states['zoom_level'] < 1000:
            zoom_level = 1000
        elif speed_kmh >= self.map_auto_zoom_500 and self.map_states['zoom_level'] < 500:
            zoom_level = 500
        elif speed_kmh >= self.map_auto_zoom_200 and self.map_states['zoom_level'] < 200:
            zoom_level = 200
        elif speed_kmh < self.map_auto_zoom_500 - 10 and self.map_states['zoom_level'] > 200:
            zoom_level = 200
        elif speed_kmh < self.map_auto_zoom_1000 - 10 and self.map_states['zoom_level'] > 500:
            zoom_level = 500
        elif speed_kmh < self.map_auto_zoom_2000 - 10 and self.map_states['zoom_level'] > 1000:
            zoom_level = 1000
        elif speed_kmh < self.map_auto_zoom_5000 - 5 and self.map_states['zoom_level'] > 2000:
            zoom_level = 2000
        if zoom_level != self.map_states['zoom_level'] and zoom_level > -1:
            IBUS.write_bus_packet(*self.map_states[zoom_level])
            self.map_states['zoom_level'] = zoom_level
            log('NAVI: ZOOM LEVEL %sm on %skm/h' % (zoom_level, speed_kmh))

    def nav_map_show(self):
        IBUS.write_bus_packet(176, 127, [170, 4, 0])
        log('Show Navigation Map')

    def obc_req(self, resetRunOnce = False):
        if not self.startup_done:
            return
        if self.ike_states['ign_mode'] < 1:
            return
        if self.obc_req_runs:
            return
        if resetRunOnce:
            self.obc_req_runonce = False
        if not self.obc_req_runonce:
            thread = Thread(target=self._obc_req_thread)
            thread.daemon = True
            self.obc_req_runs = True
            thread.start()
        self.obc_req_runonce = True

    def _obc_req_thread(self):
        if self.obc_gui_is_visible():
            obc_req_delay = 1.0
            obcgui_isvisble = True
        else:
            obc_req_delay = 0.25
            obcgui_isvisble = False
        log('OBC: REQUEST STARTED')
        time.sleep(1.5)
        obc_events = [self.obc_country_coding_req,
         self.obc_time_req,
         self.obc_date_req,
         self.obc_outtemp_req,
         self.obc_cons1_req,
         self.obc_cons2_req,
         self.obc_range_req,
         self.obc_dist_req,
         self.obc_arr_req,
         self.obc_limit_req,
         self.obc_avg_req,
         self.obc_stpwtch_req,
         self.obc_tmr1_req,
         self.obc_tmr2_req,
         self.obc_coolant_req,
         self.obc_ind_req,
         self.obc_voltage_req,
         self.ews_key_req,
         self.obc_vin_req,
         self.obc_odometer_req]
        for obc_event in obc_events:
            if self.cancel_read_thread or obcgui_isvisble != self.obc_gui_is_visible() and not self.obc_gui_is_visible():
                break
            obc_event()
            time.sleep(obc_req_delay)

        log('OBC: REQUEST FINISHED')
        self.obc_req_runs = False

    def obc_time_req(self):
        IBUS.write_bus_packet(231, 128, [65, 1, 1])
        log('OBC: REQ: TIME', 2)

    def obc_time_put(self, dat, UTC = False):
        if not PLATFORM == 'Linux':
            return
        self.obc_settime += 1
        hexstring = dat
        clock = ''
        if hexstring[3] == 32:
            clock = '0'
        else:
            clock = '%c' % hexstring[3]
        clock = clock + '%c%c%c%c' % (hexstring[4],
         hexstring[5],
         hexstring[6],
         hexstring[7])
        clock = clock + ':00'
        if hexstring[8] != 32:
            clock = clock + chr(hexstring[8]) + chr(hexstring[9])
        curhh, curmm, curss = os.popen('date +%T').readline().strip().split(':')
        newhh, newmm, newss = clock.split(':')
        if not ('%s%s' % (newhh, newmm)).isdigit():
            log('OBC: BAD TIME: %s' % clock)
            return
        log('OBC CUR HH: %s' % curhh, 3)
        log('OBC NEW HH: %s' % newhh, 3)
        log('OBC CUR MM: %s' % curmm, 3)
        log('OBC NEW HH: %s' % newmm, 3)
        if self.obc_settime > 2 and curhh in ('11', '23') and curmm == '59':
            self.obc_time[1] = '%c%c' % (hexstring[8], hexstring[9])
            log('OBC: TIME: DAYJUMP')
        if self.obc_settime > 2 and curhh == newhh and abs(int(curmm) - int(newmm)) < 2 and self.obc_time[1] == '%c%c' % (hexstring[8], hexstring[9]):
            self.obc_settime = 3
            log('OBC: TIME: %s - no update requiered' % clock)
            return
        log('OBC: PUT: SYSTEM TIME: %s' % clock)
        f = os.popen('sudo date +%T%p -s "' + clock + '"')
        self.obc_time = [clock, '%c%c' % (hexstring[8], hexstring[9])]
        time.sleep(0.1)

    def obc_time_get(self):
        return '%s' % self.obc_time[0]

    def obc_date_req(self):
        IBUS.write_bus_packet(231, 128, [65, 2, 1])
        log('OBC: REQ: DATE', 2)

    def obc_date_put(self, dat):
        if not PLATFORM == 'Linux':
            return
        hexstring = dat[3:]
        if self.obc_date[1] == hexstring:
            log('OBC: DATE: %s - no update requiered' % self.obc_date[0])
            return
        datestring = hex_to_asc(hexstring)
        if '.' in datestring:
            day, month, year = datestring.split('.')
        else:
            month, day, year = datestring.split('/')
        newdate = '%s%s%s' % (year, month, day)
        if not newdate.isdigit():
            log('OBC: BAD DATE: %s' % newdate)
            return
        log('OBC: PUT: SYSTEM DATE: %s' % newdate)
        f = os.popen('sudo date +%Y%m%d -s "' + newdate + '"')
        time.sleep(0.3)
        if self.obc_time[0]:
            f = os.popen('sudo date +%T -s "' + self.obc_time[0] + '"')
        time.sleep(0.1)
        self.obc_date = [datestring, hexstring]

    def obc_date_get(self):
        return '%s' % self.obc_date[0]

    def obc_outtemp_req(self):
        IBUS.write_bus_packet(59, 128, [65, 3, 1])
        log('OBC: REQ: OUTTEMP', 2)

    def obc_outtemp_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: PUT: OUT TEMP: ' + convstring)
        if KODI.get_addon_setting('home_temp') == 'OBC Outtemp':
            KODI.set_property('IBUS_OBC_TEMP', convstring)
        self.obc_outtemp = convstring

    def obc_outtemp_get(self):
        return '%s' % self.obc_outtemp

    def obc_cons1_req(self):
        IBUS.write_bus_packet(59, 128, [65, 4, 1])
        log('OBC: REQ: CONS1', 2)

    def obc_cons1_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: PUT: CONS1: ' + convstring)
        self.obc_cons1 = convstring

    def obc_cons1_reset(self):
        IBUS.write_bus_packet(59, 128, [65, 4, 16])

    def obc_cons1_get(self):
        return '%s' % self.obc_cons1

    def obc_cons2_req(self):
        IBUS.write_bus_packet(59, 128, [65, 5, 1])
        log('OBC: REQ: CONS2', 2)

    def obc_cons2_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: PUT: CONS2: ' + convstring)
        self.obc_cons2 = convstring

    def obc_cons2_reset(self):
        IBUS.write_bus_packet(59, 128, [65, 5, 16])

    def obc_cons2_get(self):
        return '%s' % self.obc_cons2

    def obc_range_req(self):
        IBUS.write_bus_packet(59, 128, [65, 6, 1])
        log('OBC: REQ: RANGE', 2)

    def obc_range_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: PUT: RANGE: ' + convstring)
        self.obc_range = convstring

    def obc_range_get(self):
        return '%s' % self.obc_range

    def obc_dist_req(self):
        IBUS.write_bus_packet(59, 128, [65, 7, 1])
        log('OBC: REQ: DIST', 2)

    def obc_dist_put(self, dat):
        hexstring = dat[3:]
        try:
            convstring = int(get_number(hex_to_asc(hexstring)))
        except:
            convstring = -10000

        log('OBC: PUT: DIST: %s KM' % ('----' if convstring < -9999 else convstring))
        if self.obc_dist != convstring:
            self.obc_dist = convstring
            if self.obc_gui_is_visible():
                self.obc_odometer_req()

    def obc_dist_set(self, value):

        def bytes(num):
            return [num >> 8, num & 255]

        value = bytes(value)
        IBUS.write_bus_packet(59, 128, [64,
         7,
         value[0],
         value[1]])

    def obc_dist_reset(self):
        IBUS.write_bus_packet(59, 128, [64,
         7,
         0,
         0])

    def obc_dist_get(self):
        if self.obc_dist < -9999:
            return '---- %s' % self.obc_distance_unit
        else:
            return '%s %s' % (self.obc_dist, self.obc_distance_unit)

    def obc_arr_req(self):
        IBUS.write_bus_packet(59, 128, [65, 8, 1])
        log('OBC: REQ: ARR', 2)

    def obc_arr_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: PUT: ARR: ' + convstring)
        self.obc_arr = convstring

    def obc_arr_get(self):
        return '%s' % self.obc_arr

    def obc_avg_req(self):
        IBUS.write_bus_packet(59, 128, [65, 10, 1])
        log('OBC: REQ: AVG', 2)

    def obc_avg_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: PUT: AVG: ' + convstring)
        self.obc_avg = convstring

    def obc_avg_reset(self):
        IBUS.write_bus_packet(59, 128, [65, 10, 16])

    def obc_avg_get(self):
        return '%s' % self.obc_avg

    def obc_stpwtch_req(self):
        IBUS.write_bus_packet(59, 128, [65, 14, 1])
        log('OBC: REQ: STPWTCH', 2)

    def obc_stpwtch_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: PUT: STPWTCH: ' + convstring)
        self.obc_stpwtch = convstring

    def obc_stpwtch_reset(self):
        IBUS.write_bus_packet(59, 128, [65,
         14,
         16,
         16])

    def obc_stpwtch_get(self):
        return '%s' % self.obc_stpwtch

    def obc_tmr1_req(self):
        IBUS.write_bus_packet(59, 128, [65, 15, 1])
        log('OBC: REQ: TMR1', 2)

    def obc_tmr1_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: PUT: TMR1: ' + convstring)
        self.obc_tmr1 = convstring

    def obc_tmr1_set(self, hour, minute):
        IBUS.write_bus_packet(59, 128, [64,
         15,
         hour,
         minute])

    def obc_tmr1_reset(self):
        if '--:--' not in self.obc_tmr1:
            IBUS.write_bus_packet(59, 128, [64,
             15,
             255,
             255])
            self.obc_tmr1_enable(False)

    def obc_tmr1_enable(self, state):
        if state:
            if '--:--' not in self.obc_tmr1:
                IBUS.write_bus_packet(59, 128, [65, 15, 4])
        else:
            IBUS.write_bus_packet(59, 128, [65, 15, 8])

    def obc_tmr1_get(self):
        return '%s' % self.obc_tmr1

    def obc_tmr1_get_ind(self):
        return self.obc_tmr1ind

    def obc_tmr2_req(self):
        IBUS.write_bus_packet(59, 128, [65, 16, 1])
        log('OBC: REQ: TMR2', 2)

    def obc_tmr2_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: PUT: TMR2: ' + convstring)
        self.obc_tmr2 = convstring

    def obc_tmr2_set(self, hour, minute):
        IBUS.write_bus_packet(59, 128, [64,
         16,
         hour,
         minute])

    def obc_tmr2_reset(self):
        if '--:--' not in self.obc_tmr2:
            IBUS.write_bus_packet(59, 128, [64,
             16,
             255,
             255])
            self.obc_tmr2_enable(False)

    def obc_tmr2_enable(self, state):
        if state:
            if '--:--' not in self.obc_tmr2:
                IBUS.write_bus_packet(59, 128, [65, 16, 4])
        else:
            IBUS.write_bus_packet(59, 128, [65, 16, 8])

    def obc_tmr2_get(self):
        return '%s' % self.obc_tmr2

    def obc_tmr2_get_ind(self):
        return self.obc_tmr2ind

    def obc_auxventheat_label(self):
        return '[COLOR FFFF7E00]     STANDL\xc3\x9cFTUNG / -HEIZUNG[/COLOR]'

    def obc_auxvent_req(self):
        pass

    def obc_auxvent_control(self, state):
        if state:
            IBUS.write_bus_packet(59, 128, [65, 20])
        else:
            IBUS.write_bus_packet(59, 128, [65, 19])

    def obc_auxvent_get_ind(self):
        return self.ike_states['aux_vent']

    def obc_auxvent_exist(self):
        return self.obc_auxvent_available

    def obc_auxvent_enabled(self):
        if self.ike_states['ign_mode'] < 2 and self.obc_auxvent_enable:
            return True
        else:
            return False

    def obc_auxheat_req(self):
        pass

    def obc_auxheat_control(self, state):
        if not self.obc_auxvent_exist():
            return
        if state:
            log('AUX-HEAT ON')
            IBUS.write_bus_packet(59, 128, [65, 18])
        else:
            log('AUX-HEAT OFF')
            IBUS.write_bus_packet(59, 128, [65, 17])

    def obc_auxheat_get_ind(self):
        return self.ike_states['aux_heat']

    def obc_auxheat_exist(self):
        return self.obc_auxheat_available

    def obc_auxheat_enabled(self):
        if self.ike_states['ign_mode'] < 2 and self.obc_auxheat_enable:
            return True
        else:
            return False

    def obc_ind_req(self):
        IBUS.write_bus_packet(59, 128, [65, 9, 2])
        log('OBC: REQ: IND LIMIT/MEMO', 2)

    def obc_ind_put(self, dat):
        xx = dat[1]
        yy = dat[2]
        memoind = get_bit_from_hex(xx, BIT[5])
        limitind = get_bit_from_hex(xx, BIT[1])
        tmr1ind = get_bit_from_hex(yy, BIT[2])
        tmr2ind = get_bit_from_hex(yy, BIT[4])
        if self.obc_memoind != memoind:
            self.obc_memoind = memoind
            log('OBC: PUT: MEMO IND: %s' % memoind)
        if self.obc_limitind != limitind:
            self.obc_limitind = limitind
            log('OBC: PUT: LIMIT IND: %s' % limitind)
        if self.obc_tmr1ind != tmr1ind:
            self.obc_tmr1ind = tmr1ind
            log('OBC: PUT: TIMER1 IND: %s' % tmr1ind)
        if self.obc_tmr2ind != tmr2ind:
            self.obc_tmr2ind = tmr2ind
            log('OBC: PUT: TIMER2 IND: %s' % tmr2ind)

    def obc_limit_req(self):
        IBUS.write_bus_packet(59, 128, [65, 9, 1])
        log('OBC: REQ: LIMIT', 2)

    def obc_limit_set(self, value = None):
        if not value:
            IBUS.write_bus_packet(59, 128, [65, 9, 32])
        else:

            def bytes(num):
                return [num >> 8, num & 255]

            value = bytes(value)
            IBUS.write_bus_packet(59, 128, [64,
             9,
             value[0],
             value[1]])

    def obc_limit_reset(self):
        IBUS.write_bus_packet(59, 128, [64,
         9,
         255,
         255])
        self.obc_limit_enable(False)

    def obc_limit_enable(self, state):
        if state:
            IBUS.write_bus_packet(59, 128, [65, 9, 4])
        else:
            IBUS.write_bus_packet(59, 128, [65, 9, 8])

    def obc_limit_put(self, dat):
        hexstring = dat[3:]
        try:
            convstring = int(get_number(hex_to_asc(hexstring)))
        except:
            convstring = -1

        log('OBC: PUT: LIMIT: %s KM/H' % ('---' if convstring < 0 else convstring))
        self.obc_limit = convstring

    def obc_limit_get(self):
        if self.obc_limit < 0:
            return '--- %s' % self.obc_speed_unit
        else:
            return '%s %s' % (self.obc_limit, self.obc_speed_unit)

    def obc_limit_get_ind(self):
        return self.obc_limitind

    def obc_memo_req(self):
        IBUS.write_bus_packet(59, 128, [65, 12, 1])
        log('OBC: REQ: MEMO', 2)

    def obc_memo_enable(self, state):
        if state:
            IBUS.write_bus_packet(59, 128, [65, 12, 7])
        else:
            IBUS.write_bus_packet(59, 128, [65, 12, 8])

    def obc_memo_get_ind(self):
        return self.obc_memoind

    def obc_coolant_req(self):
        IBUS.write_bus_packet(91, 128, [29])
        log('OBC: REQ: COOLANT/OUTTEMP IKE', 2)

    def obc_coolant_put(self, dat):
        tmp = dat[2]
        if tmp > 128:
            coolanttemp = tmp - 256
        else:
            coolanttemp = tmp
        log('OBC: PUT: COOLANT TEMP: %s' % coolanttemp)
        self.obc_coolant_C = coolanttemp
        self.obc_coolant_F = int(coolanttemp * 1.8 + 32)
        if KODI.get_addon_setting('home_temp') == 'Coolant Temp':
            KODI.set_property('IBUS_OBC_TEMP', '%s' % self.obc_coolant_get())
        tmp = dat[1]
        if tmp > 128:
            outtemp = tmp - 256
        else:
            outtemp = tmp
        log('OBC: PUT: IKE OUT TEMP: %s' % outtemp)
        if KODI.get_addon_setting('home_temp') == 'IKE Outtemp':
            KODI.set_property('IBUS_OBC_TEMP', '%s%s\xc2\xb0C' % ('+' if coolanttemp > 0 else '', outtemp))
        self.obc_oiltemp_req()
        self.engine_temprature_warning()

    def obc_coolant_get(self):
        if self.obc_temperature_unit == '\xc2\xb0F':
            return '%s%s\xc2\xb0F' % ('+' if self.obc_coolant_F > 0 else '', self.obc_coolant_F)
        else:
            return '%s%s\xc2\xb0C' % ('+' if self.obc_coolant_C > 0 else '', self.obc_coolant_C)

    def obc_coolant_get_icon(self):
        if self.obc_coolant_C <= 25:
            return ADDON_ICON_COOLANT_BLUE
        if self.obc_coolant_C <= 75:
            return ADDON_ICON_COOLANT_YELLOW
        if self.engine_overheat_warning:
            if self.obc_coolant_C < self.engine_overheat_temp:
                return ADDON_ICON_COOLANT_GREEN
            if self.obc_coolant_C >= self.engine_overheat_temp:
                return ADDON_ICON_COOLANT_RED
        else:
            if self.obc_coolant_C < 110:
                return ADDON_ICON_COOLANT_GREEN
            if self.obc_coolant_C >= 110:
                return ADDON_ICON_COOLANT_RED

    def obc_coolant_get_gauge(self):
        temp = self.obc_coolant_C
        if temp <= 18:
            angle = 101
        elif 18 < temp < 75:
            angle = 101 + (temp - 18) * 79 / 57
        elif 75 <= temp <= 100:
            angle = 180
        elif 100 < temp < 125:
            angle = 180 + (temp - 100) * 79 / 25
        elif temp >= 125:
            angle = 259
        angle = '%s' % angle
        while len(angle) < 3:
            angle = '0%s' % angle

        return os.path.join(ADDON_MEDIA_GAUGE_PATH, 'grad', 'IBusOBCGAUGE_pin_%s.png' % angle)

    def obc_vin_req(self):
        IBUS.write_bus_packet(128, 208, [83])
        log('OBC: REQ: VIN', 2)

    def obc_vin_put(self, dat):
        vin = chr(dat[1]) + chr(dat[2]) + '%02X' % dat[3] + '%02X' % dat[4] + ('%02X' % dat[5])[0]
        if vin != self.obc_vin:
            self.obc_vin = vin
        log('OBC: PUT: VIN: %s' % vin)

    def obc_vin_get(self):
        return '%s' % self.obc_vin

    def obc_country_coding_req(self):
        IBUS.write_bus_packet(59, 128, [20])
        log('OBC: REQ: COUNTRY CODING', 2)

    def obc_country_coding_put(self, dat):
        network, language = '%02X' % dat[1]
        if network == '0':
            self.obc_network = 'E39/E38'
        elif network == '2':
            self.obc_network = 'E52'
        elif network == '3':
            self.obc_network = 'E39B/E53B/E52'
        elif network == '4':
            self.obc_network = 'E46'
        elif network == '5':
            self.obc_network = 'R40'
        elif network == '6':
            self.obc_network = 'E46'
        elif network == '8':
            self.obc_network = 'RR01'
        elif network == 'A':
            self.obc_network = 'E83'
        elif network == 'B':
            self.obc_network = 'R50'
        elif network == 'C':
            self.obc_network = 'R55'
        elif network == 'E':
            self.obc_network = 'E65'
        elif network == 'F':
            self.obc_network = 'E46'
        else:
            self.obc_network = '---'
        if language == '0':
            self.obc_language = 'GERMAN'
        elif language == '1':
            self.obc_language = 'ENGLISH (GB)'
        elif language == '2':
            self.obc_language = 'ENGLISH (US)'
        elif language == '3':
            self.obc_language = 'ITALIAN'
        elif language == '4':
            self.obc_language = 'SPANISH'
        elif language == '5':
            self.obc_language = 'ENGLISH (JP)'
        elif language == '6':
            self.obc_language = 'FRENCH'
        elif language == '7':
            self.obc_language = 'ENGLISH (CDN)'
        elif language == '8':
            self.obc_language = 'ENGLISH (AUS/Golf/ZA)'
        elif language == '9':
            self.obc_language = 'DUTCH'
        elif language == 'A':
            self.obc_language = 'RUSSIAN'
        else:
            self.obc_language = '---'
        if get_bit_from_hex(dat[2], BIT[6]):
            self.obc_distance_unit = 'MLS'
            self.pdc_unit = 'in'
        else:
            self.obc_distance_unit = 'KM'
            self.pdc_unit = 'cm'
        if get_bit_from_hex(dat[2], BIT[0]):
            self.obc_time_unit = '12H'
        else:
            self.obc_time_unit = '24H'
        if get_bit_from_hex(dat[2], BIT[4]):
            self.obc_speed_unit = 'MPH'
        else:
            self.obc_speed_unit = 'KM/H'
        if get_bit_from_hex(dat[2], BIT[1]):
            self.obc_temperature_unit = '\xc2\xb0F'
        else:
            self.obc_temperature_unit = '\xc2\xb0C'
        consumption = ('%02X' % dat[3])[1]
        if consumption == '0':
            self.obc_consumption_unit = 'L/100KM'
            self.obc_fuel_unit = 'L'
        elif consumption in ('5', 'A'):
            self.obc_consumption_unit = 'MPG'
            self.obc_fuel_unit = 'gal'
        elif consumption == '0':
            self.obc_consumption_unit = 'KM/L'
            self.obc_fuel_unit = 'L'
        if get_bit_from_hex(dat[4], BIT[0]):
            self.obc_auxheat_available = True
            self.obc_auxheat_enable = True
        else:
            self.obc_auxheat_available = False
            self.obc_auxheat_enable = False
        log('OBC: PUT: AUX HEAT/VENT: %02X' % dat[4])
        if get_bit_from_hex(dat[4], BIT[1]):
            self.obc_auxvent_available = True
            self.obc_auxvent_enable = True
        else:
            self.obc_auxvent_available = False
            self.obc_auxvent_enable = False
        log('OBC: PUT: SPEED UNIT: %s' % self.obc_speed_unit)
        log('OBC: PUT: DISTANCE UNIT: %s' % self.obc_distance_unit)
        log('OBC: PUT: CONSUMPTION UNIT: %s' % self.obc_consumption_unit)
        log('OBC: PUT: FUEL UNIT: %s' % self.obc_fuel_unit)
        log('OBC: PUT: PDC UNIT: %s' % self.pdc_unit)
        log('OBC: PUT: CAR TYPE: %s' % self.obc_network)
        log('OBC: PUT: LANGUAGE: %s' % self.obc_language)
        log('OBC: PUT: TIME UNIT: %s' % self.obc_time_unit)
        log('OBC: PUT: TEMPERATURE UNIT: %s' % self.obc_temperature_unit)
        log('OBC: PUT: AUX HEAT: %s' % self.obc_auxheat_available)
        log('OBC: PUT: AUX VENT: %s' % self.obc_auxvent_available)
        self.obc_coolant_req()

    def obc_network_get(self):
        return '%s' % self.obc_network

    def obc_language_get(self):
        return '%s' % self.obc_language

    def obc_odometer_req(self):
        IBUS.write_bus_packet(191, 128, [22])
        log('OBC: REQ: ODOMETER', 2)

    def obc_odometer_put(self, dat):
        odometer = dat[3] << 16 | dat[2] << 8 | dat[1]
        if odometer != self.obc_odometer:
            self.obc_odometer = odometer
        log('OBC: PUT: ODOMETER: %s KM' % odometer)

    def obc_odometer_get(self):
        return '%s %s' % (self.obc_odometer, self.obc_distance_unit)

    def obc_voltage_req(self):
        IBUS.write_bus_packet(63, 127, [11])
        log('OBC: REQ: VOLTAGE', 2)

    def obc_voltage_put(self, dat):
        if len(dat) < 2:
            return
        voltage = round(float(dat[13] << 8 | dat[14]) / 1000, 1)
        self.obc_voltage = voltage
        log('OBC: PUT: VOLTAGE: %s' % voltage)

    def obc_voltage_get(self):
        return '%s V' % (self.obc_voltage if self.obc_voltage else '--.-')

    def obc_speed_rpm_put(self, dat):
        speed_kmh = dat[1] * 2
        speed_mph = int(speed_kmh * 0.6214)
        self.obc_speed_kmh = speed_kmh
        self.obc_speed_mph = speed_mph
        rpm = dat[2] * 100
        self.obc_rpm = rpm
        log('OBC: PUT: SPEED KMH - MPH: %s - %s' % (speed_kmh, speed_mph))
        log('OBC: PUT: SPEED rpm: %s' % rpm)
        if speed_kmh >= self.zv_auto_lock_speed and self.zv_auto_lock and not self.ike_states['handbrake']:
            self.gm_zv_lock()
        self.nav_zoom(speed_kmh)
        self.engine_temprature_warning()

    def obc_speed_get(self):
        if self.obc_speed_unit == 'KM/H':
            return '%s %s' % ('---' if self.obc_speed_kmh < 0 else self.obc_speed_kmh, self.obc_speed_unit)
        else:
            return '%s %s' % ('---' if self.obc_speed_mph < 0 else self.obc_speed_mph, self.obc_speed_unit)

    def obc_speed_get_gauge(self):
        return get_pin_pos_img(self.obc_speed_kmh, 260, 34, 326, 45, 315)

    def obc_rpm_get(self):
        return '%s min\xcb\x89\xc2\xb9' % self.obc_rpm

    def obc_rpm_get_gauge(self):
        return get_pin_pos_img(self.obc_rpm, 7000, 40, 320)

    def obc_fuellevel_get(self):
        return '%s %s' % (self.obc_fuellevel, self.obc_fuel_unit)

    def obc_fuellevel_get_ind(self):
        return self.obc_fuellevel_low

    def obc_key_get(self):
        if self.obc_inserted_key > -1:
            return 'IN: %s' % self.obc_inserted_key
        else:
            return 'OUT'

    def obc_gui_open(self):
        if xbmcgui.getCurrentWindowDialogId() == 10140:
            KODI.back()
        if self.OBCGUI:
            if self.obc_gui_is_visible():
                self.obc_gui_close()
            elif self.OBCGUI.isActive:
                self.obc_gui_close()
                time.sleep(0.5)
                self.obc_gui_show()
            else:
                self.obc_gui_show()
        else:
            self.obc_gui_show()

    def obc_gui_show(self):
        log('Current selected ADDON SKIN: %s' % addon_skin_path())
        self.OBCGUI = ObcGuiClass('OBC_SKIN.xml', ADDON_PATH, addon_skin_path(), '720p')
        self.OBCGUI.obc_screen = self.obc_screen
        self.OBCGUI.doModal()
        self.obc_screen = self.OBCGUI.obc_screen

    def obc_gui_close(self):
        if self.OBCGUI:
            self.obc_screen = self.OBCGUI.obc_screen
            self.OBCGUI.onStop()
            delete_object(self.OBCGUI)

    def obc_gui_is_visible(self):
        if self.OBCGUI:
            return self.OBCGUI.isVisible()
        else:
            return False


def log(string, lvl = 1):
    thread = Thread(target=KODI.log, args=(string, lvl))
    thread.daemon = True
    thread.start()


def note(heading, message = None, time = -1, icon = None):
    thread = Thread(target=KODI.note, args=(heading,
     message,
     time,
     icon))
    thread.daemon = True
    thread.start()


def dialog_ok(label1, label2 = None, label3 = None):
    thread = Thread(target=KODI.dialog_ok, args=(label1, label2, label3))
    thread.daemon = True
    thread.start()


def language(string):
    language_dict = {'IBusCommunicator': 30000,
     'Main': 30001,
     'Welcome/Leaving': 30002,
     'Car Features': 30003,
     'Kodi': 30004,
     'Copy Log File                              IBus Read-Errors:': 30010,
     'Serial Device': 30011,
     'Log Level': 30012,
     'Write log messages to kodi.log': 30013,
     'TCP Communication Port (default 8089)': 30014,
     'Process IBus Messages from TCP': 30015,
     'Car Model': 30016,
     'Activate RaspPi (Resler NTSC Switch)': 30017,
     'Audio Mode': 30018,
     'CD Changer Emulation': 30019,
     'CD Changer Emulation -- is autom. TRUE': 30020,
     'Switch DSP to KOAX Input(CD)': 30021,
     'Switch DSP to TUNER on CD-Mode': 30022,
     'Use GPIO instead NTSC(RTS)': 30023,
     'GPIO for NTSC': 30024,
     'IKE Display': 30025,
     'Enable Text to IKE Display': 30026,
     'Track Title to IKE': 30027,
     'IKE Message on Start': 30028,
     'Welcome Message': 30029,
     'Hold Welcome Message in IKE Display': 30030,
     'Text Scrolling Speed': 30031,
     'Set IKE Time': 30032,
     'Set IKE Date': 30033,
     'Run Addon in Development Mode': 30034,
     'Install Skin Files': 30035,
     'Connection status': 30036,
     'Connect': 30037,
     'Disconnect': 30038,
     'Day Time': 30039,
     'Time Range to disable Light Function': 30040,
     'Day starts': 30041,
     'Day ends': 30042,
     'Use BMBT Lightsensor': 30043,
     'High = Lights ON by high Brightness': 30044,
     'Welcome': 30045,
     'Initiate Welcome Events after bootup': 30046,
     'Light': 30047,
     'Light Time': 30048,
     'Cancel on Key insert': 30049,
     'Cancel on Door open': 30050,
     'Unfold Mirrors': 30051,
     'Leaving': 30052,
     'Start on Ignition Off': 30053,
     'Fold Mirrors': 30054,
     'Set Lights': 30055,
     'Park Lights': 30056,
     'Low Beam': 30057,
     'Fog Lights Front': 30058,
     'Licence Plate': 30059,
     'Turn Lights Front': 30060,
     'Turn Lights Back': 30061,
     'Comfortblinking': 30062,
     'Enable Comfort Blinking': 30063,
     'Comfort Blink Interval': 30064,
     'Fog Turn Light (only E38|E39|E53)': 30065,
     'Fog Turn Light Time': 30066,
     'Fog Turn Light Max Speed': 30067,
     'LCD Brightness': 30068,
     'Set LCD Brightness by Light State': 30069,
     'Value Lights On': 30070,
     'Value Lights Off': 30071,
     'Sink Volume': 30072,
     'Gear Position R': 30073,
     'Control Volume of BMW Radio': 30074,
     'Value to decrease the Volume': 30075,
     'Delay Seconds to reset the Volume': 30076,
     'Max Speed to reset the Volume': 30077,
     'RearCam Relais Control': 30078,
     'Enable': 30079,
     'GPIO for RearCam Relais': 30080,
     'RearCam Relais turn off': 30081,
     'DIRECTLY': 30144,
     'by TIMEOUT': 30145,
     'by SPEED': 30146,
     'Timeout to turn RearCam Relais off': 30082,
     'Max Speed to turn RearCam Relais off': 30083,
     'PDC': 30084,
     'Activate PDC Screen': 30085,
     'PDC Type': 30086,
     'Front + Rear': 30087,
     'Rear': 30088,
     'Timeout PDC Screen': 30089,
     'Turn PDC off, after timeout': 30090,
     'PDC Model Type': 30091,
     'PDC Refreshrate': 30092,
     'Central Lock System': 30093,
     'Auto Lock': 30094,
     'Auto Lock Speed km/h': 30095,
     'Auto Unlock on Handbrake': 30096,
     'Auto Unlock on Ignition OFF + ACC': 30097,
     "Auto Unlock on Gear Position 'P'": 30098,
     'Auto Unlock on Door open': 30099,
     'Navigation': 30100,
     'Map Auto Zoom': 30101,
     '  200m OUT (- 20km/h IN)': 30102,
     '  500m OUT (- 10km/h IN)': 30103,
     '1000m OUT (- 10km/h IN)': 30104,
     '2000m OUT (- 10km/h IN)': 30105,
     '5000m OUT (-   5km/h IN)': 30106,
     'Steering Wheel Buttons': 30107,
     'STW R/T Event': 30108,
     'None': 30109,
     'Toggle Map <> Audio Screen(Kodi)': 30110,
     'Menu Control(en-/disable)': 30111,
     'Flash to Pass': 30112,
     'Use STW for Gear Shift': 30113,
     'Enabled for Keys:': 30114,
     'VOLUME + / -': 30115,
     'UP / DOWN': 30116,
     'Trigger Time': 30117,
     'GPIO for shift up': 30118,
     'GPIO for shift down': 30119,
     'Player': 30120,
     'Seconds to double FFWD/FRWD Speed': 30121,
     'Max FFWD/FRWD Speed': 30122,
     'Shutdown Timer': 30123,
     'Activate Shutdown Timer on Central Lock Close': 30124,
     'Time': 30125,
     'OBC Settings': 30126,
     'Temprature on Homescreen': 30127,
     'Bordscreen Buttons': 30128,
     'Invert Up/Down Direction of NavTurn-Button': 30129,
     'NAV Button Hold Event:': 30130,
     'Buttons 1 - 6 (only CD or TAPE MODE)': 30131,
     'Button 1 Press': 30132,
     'Button 1 Hold': 30133,
     'Button 2 Press': 30134,
     'Button 2 Hold': 30135,
     'Button 3 Press': 30136,
     'Button 3 Hold': 30137,
     'Button 4 Press': 30138,
     'Button 4 Hold': 30139,
     'Button 5 Press': 30140,
     'Button 5 Hold': 30141,
     'Button 6 Press': 30142,
     'Button 6 Hold': 30143,
     'IBUS: Error': 32001,
     'IBus Connected': 32002,
     'IBus Connection failed': 32003,
     'Development Mode': 32004,
     'Continue without IBus Connection': 32005,
     'Settings changed': 32006,
     'No Function in AUX-Mode': 32007,
     'Key 1-6 sets Volumelevel': 32008,
     'No Function for Button defined': 32009,
     'Invalid Time Input': 32010,
     'Invalid Date Input': 32011,
     'Driver Door': 32012,
     'Passenger Door': 32013,
     'Driver Rear Door': 32014,
     'Passenger Rear Door': 32015,
     'Central Locksystem': 32016,
     'Indoor Lights turned': 32017,
     'Driver Window': 32018,
     'Passenger Window': 32019,
     'Driver Rear Window': 32020,
     'Passenger Rear Window': 32021,
     'Sunroof': 32022,
     'Trunk': 32023,
     'Bonnet': 32024,
     'Trunk Button': 32025,
     'opened': 32026,
     'closed': 32027,
     'locked': 32028,
     'unlocked': 32029,
     'hard locked': 32030,
     'ON': 32031,
     'OFF': 32032,
     'pressed': 32033,
     'released': 32034,
     'Sent IBus-Message from TCP Port': 32035,
     'Simulate IBus Message from TCP Port': 32036,
     '- Coolant Temperature': 32037,
     'Consumption 1': 32038,
     'Consumption 2': 32039,
     '- Range': 32040,
     '- Fuel Level': 32041,
     'Distance': 32042,
     '- Arrival': 32043,
     '- Engine speed': 32044,
     '- Current Speed': 32045,
     'Speed': 32046,
     'Limit': 32047,
     'Memo': 32048,
     'Timer 1': 32049,
     'Timer 2': 32050,
     '- Stopwatch': 32051,
     '- Board Voltage': 32052,
     '- Vehicle key': 32053,
     '- VIN': 32054,
     '- Odometer': 32055,
     '- Vehicle type': 32056,
     '- Language': 32057,
     'Aux Ventilation': 32058,
     'Aux Heating': 32059,
     '- GPS FIX': 32060,
     '- Town': 32061,
     '- Street': 32062,
     '- Latitude': 32063,
     '- Longitude': 32064,
     '- Altitude': 32065,
     'SET': 32066,
     'RESET': 32067,
     'SPEED': 32068,
     'ACTIVATE': 32069,
     'DEACTIVATE': 32070,
     'ON-BOARD': 32071,
     'INFORMATION': 32072,
     'GPS': 32073,
     'INSTRUMENTS': 32074}
    return ADDON.getLocalizedString(language_dict[string]).encode('utf-8')


def get_number(text):
    text = text.replace(',', '.')
    return float(findall('[+-]? *(?:\\d+(?:\\.\\d*)?|\\.\\d+)(?:[eE][+-]?\\d+)?', text)[0])


def get_bit_from_hex(value, bit):
    output = bin(value)[2:].zfill(8)
    if int(output[bit]) == 1:
        return True
    return False


def set_bit_in_hex(hex, bit, value):
    temp = bin(hex)[2:].zfill(8)
    output = list(temp)
    output[bit] = '1' if value else '0'
    return int(''.join(output), 2)


def asc_to_hex(text):
    text = _encode_ibus_chars(text)
    return [ ord(l) for l in text ]


def hex_to_asc(in_hex):
    out_hex = [ chr(l) for l in in_hex ]
    return _decode_ibus_chars(''.join(out_hex))


def _encode_ibus_chars(text):
    letters = {'\xc3\x80': 'A',
     '\xc3\x81': 'A',
     '\xc3\x82': 'A',
     '\xc3\x83': 'A',
     '\xc3\x85': 'A',
     '\xc4\x80': 'A',
     '\xc4\x82': 'A',
     '\xc4\x84': 'A',
     '\xc7\x8d': 'A',
     '\xc7\x9e': 'A',
     '\xc7\xa0': 'A',
     '\xc7\xba': 'A',
     '\xc8\x82': 'A',
     '\xe1\xb8\x80': 'A',
     '\xe1\xba\xa0': 'A',
     '\xe1\xba\xa2': 'A',
     '\xe1\xba\xa4': 'A',
     '\xe1\xba\xa6': 'A',
     '\xe1\xba\xa8': 'A',
     '\xe1\xba\xaa': 'A',
     '\xe1\xba\xac': 'A',
     '\xe1\xba\xae': 'A',
     '\xe1\xba\xb0': 'A',
     '\xe1\xba\xb2': 'A',
     '\xe1\xba\xb4': 'A',
     '\xe1\xba\xb6': 'A',
     '\xc3\xa0': 'a',
     '\xc3\xa1': 'a',
     '\xc3\xa2': 'a',
     '\xc3\xa3': 'a',
     '\xc3\xa5': 'a',
     '\xc4\x81': 'a',
     '\xc4\x83': 'a',
     '\xc4\x85': 'a',
     '\xc7\x9f': 'a',
     '\xc7\xa1': 'a',
     '\xc7\xbb': 'a',
     '\xc8\x83': 'a',
     '\xc9\x90': 'a',
     '\xe1\xb8\x81': 'a',
     '\xe1\xba\x9a': 'a',
     '\xe1\xba\xa1': 'a',
     '\xe1\xba\xa3': 'a',
     '\xe1\xba\xa5': 'a',
     '\xe1\xba\xa7': 'a',
     '\xe1\xba\xa9': 'a',
     '\xe1\xba\xab': 'a',
     '\xe1\xba\xad': 'a',
     '\xe1\xba\xaf': 'a',
     '\xe1\xba\xb1': 'a',
     '\xe1\xba\xb3': 'a',
     '\xe1\xba\xb5': 'a',
     '\xe1\xba\xb7': 'a',
     '\xc3\x84': chr(161),
     '\xc8\x80': chr(161),
     '\xc3\xa4': chr(164),
     '\xc8\x81': chr(164),
     '\xc3\x86': 'AE',
     '\xc7\xa2': 'AE',
     '\xc7\xbc': 'AE',
     '\xc3\xa6': 'ae',
     '\xc7\xa3': 'ae',
     '\xc7\xbd': 'ae',
     '\xc6\x81': 'B',
     '\xc6\x82': 'B',
     '\xe1\xb8\x82': 'B',
     '\xe1\xb8\x84': 'B',
     '\xe1\xb8\x86': 'B',
     '\xca\x99': 'B',
     '\xc6\x80': 'b',
     '\xc6\x83': 'b',
     '\xc9\x93': 'b',
     '\xe1\xb8\x83': 'b',
     '\xe1\xb8\x85': 'b',
     '\xe1\xb8\x87': 'b',
     '\xc3\x87': 'C',
     '\xc4\x86': 'C',
     '\xc4\x88': 'C',
     '\xc4\x8a': 'C',
     '\xc4\x8c': 'C',
     '\xc6\x87': 'C',
     '\xe1\xb8\x88': 'C',
     '\xc6\x86': 'C',
     '\xc3\xa7': 'c',
     '\xc4\x87': 'c',
     '\xc4\x89': 'c',
     '\xc4\x8b': 'c',
     '\xc4\x8d': 'c',
     '\xc6\x88': 'c',
     '\xe1\xb8\x89': 'c',
     '\xc9\x94': 'c',
     '\xc9\x95': 'c',
     '\xc3\x98': chr(169),
     '\xc7\xbe': chr(169),
     '\xc3\xb8': chr(169),
     '\xc7\xbf': chr(169),
     '\xc3\x90': 'D',
     '\xc4\x8e': 'D',
     '\xc4\x90': 'D',
     '\xc6\x89': 'D',
     '\xc6\x8a': 'D',
     '\xe1\xb8\x8a': 'D',
     '\xe1\xb8\x8c': 'D',
     '\xe1\xb8\x8e': 'D',
     '\xe1\xb8\x90': 'D',
     '\xe1\xb8\x92': 'D',
     '\xc6\x8b': 'D',
     '\xc3\xb0': 'd',
     '\xc4\x8f': 'd',
     '\xc4\x91': 'd',
     '\xc6\x8c': 'd',
     '\xc6\x8d': 'd',
     '\xc9\x96': 'd',
     '\xc9\x97': 'd',
     '\xe1\xb8\x8b': 'd',
     '\xe1\xb8\x8d': 'd',
     '\xe1\xb8\x8f': 'd',
     '\xe1\xb8\x91': 'd',
     '\xe1\xb8\x93': 'd',
     '\xc7\x84': 'DZ',
     '\xc7\x85': 'Dz',
     '\xc7\xb1': 'DZ',
     '\xc7\xb2': 'Dz',
     '\xc7\xb3': 'dz',
     '\xca\xa3': 'dz',
     '\xca\xa4': 'dz',
     '\xca\xa5': 'dz',
     '\xc3\x88': 'E',
     '\xc3\x89': 'E',
     '\xc3\x8a': 'E',
     '\xc3\x8b': 'E',
     '\xc4\x92': 'E',
     '\xc4\x94': 'E',
     '\xc4\x96': 'E',
     '\xc4\x98': 'E',
     '\xc4\x9a': 'E',
     '\xc6\x8e': 'E',
     '\xc8\x84': 'E',
     '\xc8\x86': 'E',
     '\xe1\xb8\x94': 'E',
     '\xe1\xb8\x96': 'E',
     '\xe1\xb8\x98': 'E',
     '\xe1\xb8\x9a': 'E',
     '\xe1\xb8\x9c': 'E',
     '\xe1\xba\xb8': 'E',
     '\xe1\xba\xba': 'E',
     '\xe1\xba\xbc': 'E',
     '\xe1\xba\xbe': 'E',
     '\xe1\xbb\x80': 'E',
     '\xe1\xbb\x82': 'E',
     '\xe1\xbb\x84': 'E',
     '\xe1\xbb\x86': 'E',
     '\xc3\xa8': 'e',
     '\xc3\xa9': 'e',
     '\xc3\xaa': 'e',
     '\xc3\xab': 'e',
     '\xc4\x93': 'e',
     '\xc4\x95': 'e',
     '\xc4\x97': 'e',
     '\xc4\x99': 'e',
     '\xc4\x9b': 'e',
     '\xc7\x9d': 'e',
     '\xc8\x85': 'e',
     '\xc8\x87': 'e',
     '\xe1\xb8\x95': 'e',
     '\xe1\xb8\x97': 'e',
     '\xe1\xb8\x99': 'e',
     '\xe1\xb8\x9b': 'e',
     '\xe1\xb8\x9d': 'e',
     '\xe1\xba\xb9': 'e',
     '\xe1\xba\xbb': 'e',
     '\xe1\xba\xbd': 'e',
     '\xe1\xba\xbf': 'e',
     '\xe1\xbb\x81': 'e',
     '\xe1\xbb\x83': 'e',
     '\xe1\xbb\x85': 'e',
     '\xe1\xbb\x87': 'e',
     '\xc4\x9c': 'G',
     '\xc4\x9e': 'G',
     '\xc4\xa0': 'G',
     '\xc4\xa2': 'G',
     '\xc6\x93': 'G',
     '\xc7\xa4': 'G',
     '\xc7\xa6': 'G',
     '\xc7\xb4': 'G',
     '\xe1\xb8\xa0': 'G',
     '\xc4\x9d': 'g',
     '\xc4\x9f': 'g',
     '\xc4\xa1': 'g',
     '\xc4\xa3': 'g',
     '\xc7\xa5': 'g',
     '\xc7\xa7': 'g',
     '\xe1\xb8\xa1': 'g',
     '\xc4\xa4': 'H',
     '\xc4\xa6': 'H',
     '\xca\x9c': 'H',
     '\xe1\xb8\xa2': 'H',
     '\xe1\xb8\xa4': 'H',
     '\xe1\xb8\xa6': 'H',
     '\xe1\xb8\xa8': 'H',
     '\xe1\xb8\xaa': 'H',
     '\xc4\xa5': 'h',
     '\xc4\xa7': 'h',
     '\xc9\xa5': 'h',
     '\xc9\xa6': 'h',
     '\xc9\xa7': 'h',
     '\xe1\xb8\xa3': 'h',
     '\xe1\xb8\xa5': 'h',
     '\xe1\xb8\xa7': 'h',
     '\xe1\xb8\xa9': 'h',
     '\xe1\xb8\xab': 'h',
     '\xe1\xba\x96': 'h',
     '\xc6\x95': 'hv',
     '\xc3\x8c': 'I',
     '\xc3\x8d': 'I',
     '\xc3\x8e': 'I',
     '\xc3\x8f': 'I',
     '\xc4\xa8': 'I',
     '\xc4\xaa': 'I',
     '\xc4\xac': 'I',
     '\xc4\xae': 'I',
     '\xc4\xb0': 'I',
     '\xc7\x8f': 'I',
     '\xc8\x88': 'I',
     '\xc8\x8a': 'I',
     '\xe1\xb8\xac': 'I',
     '\xe1\xb8\xae': 'I',
     '\xe1\xbb\x88': 'I',
     '\xe1\xbb\x8a': 'I',
     '\xc3\xac': 'i',
     '\xc3\xad': 'i',
     '\xc3\xae': 'i',
     '\xc3\xaf': 'i',
     '\xc4\xa9': 'i',
     '\xc4\xab': 'i',
     '\xc4\xad': 'i',
     '\xc4\xaf': 'i',
     '\xc4\xb1': 'i',
     '\xc7\x90': 'i',
     '\xc8\x89': 'i',
     '\xc8\x8b': 'i',
     '\xe1\xb8\xad': 'i',
     '\xe1\xb8\xaf': 'i',
     '\xe1\xbb\x89': 'i',
     '\xe1\xbb\x8b': 'i',
     '\xc4\xb2': 'IJ',
     '\xc4\xb3': 'ij',
     '\xc4\xb4': 'J',
     '\xc4\xb5': 'j',
     '\xc7\xb0': 'j',
     '\xc9\xa9': 'j',
     '\xca\x9d': 'j',
     '\xc4\xb6': 'K',
     '\xc6\x98': 'K',
     '\xc7\xa8': 'K',
     '\xe1\xb8\xb0': 'K',
     '\xe1\xb8\xb2': 'K',
     '\xe1\xb8\xb4': 'K',
     '\xc4\xb7': 'k',
     '\xc4\xb8': 'k',
     '\xc6\x99': 'k',
     '\xc7\xa9': 'k',
     '\xca\x9e': 'k',
     '\xe1\xb8\xb1': 'k',
     '\xe1\xb8\xb3': 'k',
     '\xe1\xb8\xb5': 'k',
     '\xc4\xb9': 'L',
     '\xc4\xbb': 'L',
     '\xc4\xbd': 'L',
     '\xc4\xbf': 'L',
     '\xc5\x81': 'L',
     '\xe1\xb8\xb6': 'L',
     '\xe1\xb8\xb8': 'L',
     '\xe1\xb8\xba': 'L',
     '\xe1\xb8\xbc': 'L',
     '\xc4\xba': 'l',
     '\xc4\xbc': 'l',
     '\xc4\xbe': 'l',
     '\xc5\x80': 'l',
     '\xc5\x82': 'l',
     '\xc9\xad': 'l',
     '\xe1\xb8\xb7': 'l',
     '\xe1\xb8\xb9': 'l',
     '\xe1\xb8\xbb': 'l',
     '\xe1\xb8\xbd': 'l',
     '\xc7\x87': 'LJ',
     '\xc7\x88': 'Lj',
     '\xc7\x89': 'lj',
     '\xe1\xb8\xbe': 'M',
     '\xe1\xb9\x80': 'M',
     '\xe1\xb9\x82': 'M',
     '\xe1\xb8\xbf': 'm',
     '\xe1\xb9\x81': 'm',
     '\xe1\xb9\x83': 'm',
     '\xc3\x91': 'N',
     '\xc5\x83': 'N',
     '\xc5\x85': 'N',
     '\xc5\x87': 'N',
     '\xc6\x9d': 'N',
     '\xc9\xb4': 'N',
     '\xe1\xb9\x84': 'N',
     '\xe1\xb9\x86': 'N',
     '\xe1\xb9\x88': 'N',
     '\xe1\xb9\x8a': 'N',
     '\xc5\x8a': 'N',
     '\xc3\xb1': 'n',
     '\xc5\x84': 'n',
     '\xc5\x86': 'n',
     '\xc5\x88': 'n',
     '\xc5\x89': 'n',
     '\xc5\x8b': 'n',
     '\xc6\x9e': 'n',
     '\xc9\xb2': 'n',
     '\xc9\xb3': 'n',
     '\xe1\xb9\x85': 'n',
     '\xe1\xb9\x87': 'n',
     '\xe1\xb9\x89': 'n',
     '\xe1\xb9\x8b': 'n',
     '\xc7\x8a': 'NJ',
     '\xc7\x8b': 'Nj',
     '\xc3\x92': 'O',
     '\xc3\x93': 'O',
     '\xc3\x94': 'O',
     '\xc3\x95': 'O',
     '\xc6\x9f': 'O',
     '\xc6\xa0': 'O',
     '\xc7\x91': 'O',
     '\xc7\xaa': 'O',
     '\xc7\xac': 'O',
     '\xe1\xbb\x8c': 'O',
     '\xe1\xbb\x8e': 'O',
     '\xe1\xbb\x90': 'O',
     '\xe1\xbb\x92': 'O',
     '\xe1\xbb\x94': 'O',
     '\xe1\xbb\x96': 'O',
     '\xe1\xbb\x98': 'O',
     '\xe1\xbb\x9a': 'O',
     '\xe1\xbb\x9c': 'O',
     '\xe1\xbb\x9e': 'O',
     '\xe1\xbb\xa0': 'O',
     '\xe1\xbb\xa2': 'O',
     '\xc3\xb2': 'o',
     '\xc3\xb3': 'o',
     '\xc3\xb4': 'o',
     '\xc3\xb5': 'o',
     '\xc6\xa1': 'o',
     '\xc7\x92': 'o',
     '\xc7\xab': 'o',
     '\xc7\xad': 'o',
     '\xc8\x8f': 'o',
     '\xc9\xb5': 'o',
     '\xe1\xb9\x8d': 'o',
     '\xe1\xbb\x8d': 'o',
     '\xe1\xbb\x8f': 'o',
     '\xe1\xbb\x91': 'o',
     '\xe1\xbb\x93': 'o',
     '\xe1\xbb\x95': 'o',
     '\xe1\xbb\x97': 'o',
     '\xe1\xbb\x99': 'o',
     '\xe1\xbb\x9b': 'o',
     '\xe1\xbb\x9d': 'o',
     '\xe1\xbb\x9f': 'o',
     '\xe1\xbb\xa1': 'o',
     '\xe1\xbb\xa3': 'o',
     '\xc5\x8c': chr(162),
     '\xc5\x8e': chr(162),
     '\xc8\x8e': chr(162),
     '\xe1\xb9\x8c': chr(162),
     '\xe1\xb9\x8e': chr(162),
     '\xe1\xb9\x90': chr(162),
     '\xe1\xb9\x92': chr(162),
     '\xc3\x96': chr(162),
     '\xc5\x90': chr(162),
     '\xc8\x8c': chr(162),
     '\xc3\xb6': chr(165),
     '\xc5\x8d': chr(165),
     '\xc5\x8f': chr(165),
     '\xe1\xb9\x8f': chr(165),
     '\xe1\xb9\x91': chr(165),
     '\xe1\xb9\x93': chr(165),
     '\xc5\x91': chr(165),
     '\xc8\x8d': chr(165),
     '\xc5\x92': 'OE',
     '\xc5\x93': 'oe',
     '\xc9\xb6': 'oe',
     '\xc6\xa2': 'Oi',
     '\xc6\xa3': 'oi',
     '\xe1\xb9\x94': 'P',
     '\xe1\xb9\x96': 'P',
     '\xe1\xb9\x95': 'p',
     '\xe1\xb9\x97': 'p',
     '\xc5\x94': 'R',
     '\xc5\x96': 'R',
     '\xc5\x98': 'R',
     '\xc6\xa6': 'R',
     '\xc8\x90': 'R',
     '\xc8\x92': 'R',
     '\xca\x80': 'R',
     '\xca\x81': 'R',
     '\xe1\xb9\x98': 'R',
     '\xe1\xb9\x9a': 'R',
     '\xe1\xb9\x9c': 'R',
     '\xe1\xb9\x9e': 'R',
     '\xc5\x95': 'r',
     '\xc5\x97': 'r',
     '\xc5\x99': 'r',
     '\xc8\x91': 'r',
     '\xc8\x93': 'r',
     '\xc9\xb9': 'r',
     '\xc9\xba': 'r',
     '\xc9\xbb': 'r',
     '\xc9\xbc': 'r',
     '\xc9\xbd': 'r',
     '\xc9\xbe': 'r',
     '\xc9\xbf': 'r',
     '\xe1\xb9\x99': 'r',
     '\xe1\xb9\x9b': 'r',
     '\xe1\xb9\x9d': 'r',
     '\xe1\xb9\x9f': 'r',
     '\xc5\x9a': 'S',
     '\xc5\x9c': 'S',
     '\xc5\x9e': 'S',
     '\xc5\xa0': 'S',
     '\xc6\xa7': 'S',
     '\xe1\xb9\xa0': 'S',
     '\xe1\xb9\xa2': 'S',
     '\xe1\xb9\xa4': 'S',
     '\xe1\xb9\xa6': 'S',
     '\xe1\xb9\xa8': 'S',
     '\xc5\x9b': 's',
     '\xc5\x9d': 's',
     '\xc5\x9f': 's',
     '\xc5\xa1': 's',
     '\xc6\xa8': 's',
     '\xca\x82': 's',
     '\xe1\xb9\xa1': 's',
     '\xe1\xb9\xa3': 's',
     '\xe1\xb9\xa5': 's',
     '\xe1\xb9\xa7': 's',
     '\xe1\xb9\xa9': 's',
     '\xc5\xa2': 'T',
     '\xc5\xa4': 'T',
     '\xc5\xa6': 'T',
     '\xc6\xac': 'T',
     '\xc6\xae': 'T',
     '\xe1\xb9\xaa': 'T',
     '\xe1\xb9\xac': 'T',
     '\xe1\xb9\xae': 'T',
     '\xe1\xb9\xb0': 'T',
     '\xc5\xa3': 't',
     '\xc5\xa5': 't',
     '\xc5\xa7': 't',
     '\xc6\xab': 't',
     '\xc6\xad': 't',
     '\xca\x87': 't',
     '\xca\x88': 't',
     '\xe1\xb9\xab': 't',
     '\xe1\xb9\xad': 't',
     '\xe1\xb9\xaf': 't',
     '\xe1\xb9\xb1': 't',
     '\xe1\xba\x97': 't',
     '\xca\xa8': 'te',
     '\xca\xa7': 'tf',
     '\xca\xa6': 'ts',
     '\xc3\x99': 'U',
     '\xc3\x9a': 'U',
     '\xc3\x9b': 'U',
     '\xc5\xa8': 'U',
     '\xc5\xaa': 'U',
     '\xc5\xac': 'U',
     '\xc5\xae': 'U',
     '\xc5\xb2': 'U',
     '\xc6\xaf': 'U',
     '\xc6\xb1': 'U',
     '\xc7\x93': 'U',
     '\xc7\x95': 'U',
     '\xc7\x97': 'U',
     '\xc7\x99': 'U',
     '\xc7\x9b': 'U',
     '\xc8\x96': 'U',
     '\xe1\xb9\xb2': 'U',
     '\xe1\xb9\xb4': 'U',
     '\xe1\xb9\xb6': 'U',
     '\xe1\xbb\xa4': 'U',
     '\xe1\xbb\xa6': 'U',
     '\xe1\xbb\xa8': 'U',
     '\xe1\xbb\xaa': 'U',
     '\xe1\xbb\xac': 'U',
     '\xe1\xbb\xae': 'U',
     '\xe1\xbb\xb0': 'U',
     '\xc3\xb9': 'u',
     '\xc3\xba': 'u',
     '\xc3\xbb': 'u',
     '\xc5\xa9': 'u',
     '\xc5\xab': 'u',
     '\xc5\xad': 'u',
     '\xc5\xaf': 'u',
     '\xc5\xb3': 'u',
     '\xc6\xb0': 'u',
     '\xc7\x94': 'u',
     '\xc7\x96': 'u',
     '\xc7\x98': 'u',
     '\xc7\x9a': 'u',
     '\xc7\x9c': 'u',
     '\xc8\x97': 'u',
     '\xca\x89': 'u',
     '\xca\x8a': 'u',
     '\xe1\xb9\xb3': 'u',
     '\xe1\xb9\xb5': 'u',
     '\xe1\xb9\xb7': 'u',
     '\xe1\xb9\xb9': 'u',
     '\xe1\xb9\xbb': 'u',
     '\xe1\xbb\xa5': 'u',
     '\xe1\xbb\xa7': 'u',
     '\xe1\xbb\xa9': 'u',
     '\xe1\xbb\xab': 'u',
     '\xe1\xbb\xad': 'u',
     '\xe1\xbb\xaf': 'u',
     '\xe1\xbb\xb1': 'u',
     '\xc3\x9c': chr(163),
     '\xc5\xb0': chr(163),
     '\xc8\x94': chr(163),
     '\xc3\xbc': chr(166),
     '\xc5\xb1': chr(166),
     '\xc8\x95': chr(166),
     '\xe1\xb9\xbc': 'V',
     '\xe1\xb9\xbe': 'V',
     '\xc6\xb2': 'V',
     '\xca\x8b': 'v',
     '\xca\x8c': 'v',
     '\xe1\xb9\xbd': 'v',
     '\xe1\xb9\xbf': 'v',
     '\xc5\xb4': 'W',
     '\xca\x8d': 'W',
     '\xe1\xba\x80': 'W',
     '\xe1\xba\x82': 'W',
     '\xe1\xba\x84': 'W',
     '\xe1\xba\x86': 'W',
     '\xe1\xba\x88': 'W',
     '\xc5\xb5': 'w',
     '\xe1\xba\x81': 'w',
     '\xe1\xba\x83': 'w',
     '\xe1\xba\x85': 'w',
     '\xe1\xba\x87': 'w',
     '\xe1\xba\x89': 'w',
     '\xe1\xba\x98': 'w',
     '\xe1\xba\x8a': 'X',
     '\xe1\xba\x8c': 'X',
     '\xe1\xba\x8b': 'x',
     '\xe1\xba\x8d': 'x',
     '\xc3\x9d': 'Y',
     '\xc5\xb6': 'Y',
     '\xc5\xb8': 'Y',
     '\xc6\xb3': 'Y',
     '\xc6\x94': 'Y',
     '\xca\x8f': 'Y',
     '\xe1\xba\x8e': 'Y',
     '\xe1\xbb\xb2': 'Y',
     '\xe1\xbb\xb4': 'Y',
     '\xe1\xbb\xb6': 'Y',
     '\xe1\xbb\xb8': 'Y',
     '\xc3\xbd': 'y',
     '\xc3\xbf': 'y',
     '\xc5\xb7': 'y',
     '\xc6\xb4': 'y',
     '\xc9\xa3': 'y',
     '\xe1\xba\x8f': 'y',
     '\xe1\xba\x99': 'y',
     '\xe1\xbb\xb3': 'y',
     '\xe1\xbb\xb5': 'y',
     '\xe1\xbb\xb7': 'y',
     '\xe1\xbb\xb9': 'y',
     '\xc5\xb9': 'Z',
     '\xc5\xbb': 'Z',
     '\xc5\xbd': 'Z',
     '\xc6\xb5': 'Z',
     '\xc6\xb7': 'Z',
     '\xc6\xb8': 'Z',
     '\xc7\xae': 'Z',
     '\xe1\xba\x90': 'Z',
     '\xe1\xba\x92': 'Z',
     '\xe1\xba\x94': 'Z',
     '\xc5\xba': 'z',
     '\xc5\xbc': 'z',
     '\xc5\xbe': 'z',
     '\xc6\xb6': 'z',
     '\xc6\xb9': 'z',
     '\xc6\xba': 'z',
     '\xc7\xaf': 'z',
     '\xca\x90': 'z',
     '\xca\x91': 'z',
     '\xca\x92': 'z',
     '\xca\x93': 'z',
     '\xe1\xba\x91': 'z',
     '\xe1\xba\x93': 'z',
     '\xe1\xba\x95': 'z'}
    for l in letters:
        text = text.replace(l, letters[l])

    return text


def _decode_ibus_chars(text):
    letters = {chr(160): '\xc3\x9f',
     chr(223): '\xc3\x9f',
     chr(161): '\xc3\x84',
     chr(196): '\xc3\x84',
     chr(162): '\xc3\x96',
     chr(214): '\xc3\x96',
     chr(163): '\xc3\x9c',
     chr(220): '\xc3\x9c',
     chr(164): '\xc3\xa4',
     chr(228): '\xc3\xa4',
     chr(165): '\xc3\xb6',
     chr(166): '\xc3\xbc',
     chr(168): '\xc2\xb0',
     chr(39): '\xc2\xb4',
     chr(0): ''}
    for l in letters:
        text = text.replace(l, letters[l])

    text = text.decode('iso-8859-1').encode('latin1')
    return text


def translate(value, leftMin, leftMax, rightMin, rightMax):
    leftSpan = leftMax - leftMin
    rightSpan = rightMax - rightMin
    valueScaled = float(value - leftMin) / float(leftSpan)
    result = rightMin + valueScaled * rightSpan
    if result < rightMin:
        result = rightMin
    if result > rightMax:
        result = rightMax
    return result


def addon_skin_path():
    current_skin_name = xbmc.getSkinDir()
    if os.path.exists(os.path.join(ADDON_PATH, 'resources', 'skins', current_skin_name)):
        return '%s' % current_skin_name
    else:
        return 'Default'


def time_now_in_range(time1, time2):
    try:
        now = datetime.datetime.now()
        time_now = datetime.datetime.strptime('%s:%s' % (now.hour, now.minute), '%H:%M')
        if 'AM' in time1.upper() or 'PM' in time1.upper():
            time_start = datetime.datetime.strptime(time1, '%I:%M %p')
        else:
            time_start = datetime.datetime.strptime(time1, '%H:%M')
        if 'AM' in time2.upper() or 'PM' in time2.upper():
            time_end = datetime.datetime.strptime(time2, '%I:%M %p')
        else:
            time_end = datetime.datetime.strptime(time2, '%H:%M')
        if time_start == time_end:
            return False
        if time_start < time_end:
            if time_start <= time_now < time_end:
                return True
            else:
                return False
        else:
            if time_now >= time_start or time_now < time_end:
                return True
            return False
    except:
        log('time 1 or 2 error')
        return False


def rename__existing_logfile():
    dateprefix = datetime.datetime.fromtimestamp(os.path.getctime(EXTLOGFILEPATH)).strftime('%Y%m%d_%H%M%S')
    EXTLOGFILEPATH_NEW = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data', ADDON_ID, 'logfiles', '%s_info.log' % dateprefix)
    EXTERNIBUSLOGFILEFULLPATH_NEW = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data', ADDON_ID, 'logfiles', '%s_data.log' % dateprefix)
    os.rename(EXTLOGFILEPATH, EXTLOGFILEPATH_NEW)
    os.rename(EXTERNIBUSLOGFILEFULLPATH, EXTERNIBUSLOGFILEFULLPATH_NEW)


def get_pin_pos_img(value, value_range, start_angle, end_angle, min_angle = None, max_angle = None):
    if not min_angle:
        min_angle = start_angle
    if not max_angle:
        max_angle = end_angle
    angle = start_angle + value * (end_angle - start_angle) / value_range
    if angle <= min_angle:
        angle = min_angle
    elif angle >= max_angle:
        angle = max_angle
    angle = '%s' % angle
    while len(angle) < 3:
        angle = '0%s' % angle

    return os.path.join(ADDON_MEDIA_GAUGE_PATH, 'grad', 'IBusOBCGAUGE_pin_%s.png' % angle)


def handle_extern_events():
    serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    serversocket.bind(('0.0.0.0', EVENT.tcp_port))
    serversocket.listen(1)
    serversocket.setblocking(1)
    serversocket.settimeout(1)
    while not xbmc.abortRequested:
        try:
            connection, address = serversocket.accept()
            connection.setblocking(1)
        except socket.timeout:
            if EVENT.cancel_read_thread:
                break
            continue

        message = connection.recv(100)
        message = message.upper()
        given_args = message.split(';')
        if given_args[0] == 'OBC' and given_args[1] == 'OPENGUI':
            connection.send('OK\n\n')
            log('TCP %s: RECV >%s<' % (EVENT.tcp_port, message))
            thread = Thread(target=EVENT.obc_gui_open)
            thread.daemon = True
            thread.start()
        elif given_args[0] == 'OBC' and given_args[1] == 'GET':
            log('TCP %s: RECV >%s<' % (EVENT.tcp_port, message))
            if given_args[2] == 'ODOMETER':
                value = EVENT.obc_odometer
                connection.send('%s' % value)
        elif given_args[0] == 'NAV' and given_args[1] == 'GMAPSURL':
            log('TCP %s: RECV >%s<' % (EVENT.tcp_port, message))
            position = EVENT.nav_position_get()
            if position:
                connection.send('https://www.google.de/maps/place/%s,%s\n' % (position[0], position[1]))
                log('TCP %s: SENT >%s<' % (EVENT.tcp_port, 'https://www.google.de/maps/place/%s,%s\n' % (position[0], position[1])))
            else:
                connection.send('NO_POSITION\n')
        elif given_args[0] == 'SET_TIME':
            connection.send('OK\n\n')
            log('TCP %s: RECV >SET_TIME<' % EVENT.tcp_port)
            thread = Thread(target=EVENT.ike_set_time)
            thread.daemon = True
            thread.start()
        elif given_args[0] == 'SET_DATE':
            connection.send('OK\n\n')
            log('TCP %s: RECV >SET_DATE<' % EVENT.tcp_port)
            thread = Thread(target=EVENT.ike_set_date)
            thread.daemon = True
            thread.start()
        elif given_args[0] == 'GET_LCM_OILTEMP':
            connection.send('OK\n\n')
            log('TCP %s: RECV >GET_LCM_OILTEMP<' % EVENT.tcp_port)
            thread = Thread(target=EVENT.obc_oiltemp_req)
            thread.daemon = True
            thread.start()
        elif given_args[0] == 'CODE_US_SIDEMARK':
            connection.send('OK\n\n')
            log('TCP %s: RECV >CODE_US_SIDEMARK<' % EVENT.tcp_port)
            thread = Thread(target=EVENT.lcm_us_req)
            thread.daemon = True
            thread.start()
        elif given_args[0] == 'CODE_PWM_PARK':
            connection.send('OK\n\n')
            log('TCP %s: RECV >CODE_PWM_PARK<' % EVENT.tcp_port)
            thread = Thread(target=EVENT.lcm_pwm_park_req())
            thread.daemon = True
            thread.start()
        elif given_args[0] == 'SENDIBUS':
            if EVENT.tcp_send_ibus:
                try:
                    IBUS.write_hex_message(given_args[1])
                    connection.send('IBUSCOMMUNICATOR: >%s< sent to IBus\n\n' % given_args[1])
                    log('TCP %s: >%s< sent to IBus' % (EVENT.tcp_port, given_args[1]))
                    note('Sent IBus-Message from TCP Port', '%s' % given_args[1], len(given_args[1]) * 100)
                except:
                    connection.send('IBUSCOMMUNICATOR: >%s< ERROR not sent to IBus\n\n' % given_args[1])
                    log('TCP %s: >%s< not sent to IBus' % (EVENT.tcp_port, given_args[1]))

            else:
                connection.send('IBUSCOMMUNICATOR: send to IBus not enabled\n\n')
                log('TCP %s: send to IBus not enabled' % EVENT.tcp_port)
        elif given_args[0] == 'SIMULATEIBUS':
            EVENT.simulate_ibus_packages(given_args[1])
            connection.send('IBUSCOMMUNICATOR: >%s< simulate\n\n' % given_args[1])
            log('TCP %s: >%s< simulate' % (EVENT.tcp_port, given_args[1]))
            note('Simulate IBus Message from TCP Port', '%s' % given_args[1], len(given_args[1]) * 100)
        else:
            connection.send('IBUSCOMMUNICATOR: unknown Command >%s< recieved\n\n' % message)
            log('TCP %s: unknown Command >%s< recieved' % (EVENT.tcp_port, message))
        connection.close()
        time.sleep(0.05)

    serversocket.shutdown(socket.SHUT_RDWR)
    serversocket.close()
    log('TCP 8089: CLOSED')


def load_settings(settings_changed = False):
    cdc_emu_tmp = EVENT.cdc_emu
    gpio_ntsc_tmp = EVENT.gpio_ntsc
    gpio_rearcam_tmp = EVENT.gpio_rearcam
    gpio_gear_shift_tmp = EVENT.gpio_gear_shift
    gpio_gear_shift_up_tmp = EVENT.gpio_gear_shift_up
    gpio_gear_shift_down_tmp = EVENT.gpio_gear_shift_down
    log_to_kodi_tmp = KODI.log_to_kodi
    drl_light_tmp = EVENT.drl_light
    KODI.log_to_kodi = KODI.get_addon_setting('log_to_kodi')
    if log_to_kodi_tmp != KODI.log_to_kodi:
        if not KODI.log_to_kodi:
            KODI.ibuslogger = Logger(EXTLOGFILEPATH)
            KODI.ibusdatalogger = Logger(EXTERNIBUSLOGFILEFULLPATH)
    log('SETTINGS: LOAD: LOG_TO_KODI=%s' % KODI.log_to_kodi)
    EVENT.develop = KODI.get_addon_setting('develop')
    log('SETTINGS: LOAD: DEVELOP=%s' % EVENT.develop)
    if PLATFORM == 'Windows':
        EVENT.device_path = KODI.get_addon_setting('ser_dev_win')
    else:
        EVENT.device_path = KODI.get_addon_setting('ser_dev')
    log('SETTINGS: LOAD: DEVICE_PATH=%s' % EVENT.device_path)
    EVENT.cdc_emu = KODI.get_addon_setting('cdc_emu')
    piaudiomode = KODI.get_addon_setting('audio_mode')
    EVENT.modefm = False
    EVENT.modecd = False
    EVENT.modecd53 = False
    EVENT.modetape = False
    EVENT.modeaux = False
    EVENT.modecis = False
    EVENT.modealways = False
    EVENT.cdc_disc = 7
    EVENT.cdc_loaded = 64
    if piaudiomode == 'CD':
        EVENT.modecd = True
        EVENT.cdc_emu = True
        log('SETTINGS: LOAD: AUDIOMODE=CD')
    elif piaudiomode == 'TAPE':
        EVENT.modetape = True
        log('SETTINGS: LOAD: AUDIOMODE=TAPE')
    elif piaudiomode == 'AUX':
        EVENT.modeaux = True
        log('SETTINGS: LOAD: AUDIOMODE=AUX')
    elif piaudiomode == 'CIS':
        EVENT.modecis = True
        EVENT.cdc_emu = False
        log('SETTINGS: LOAD: AUDIOMODE=CIS')
    elif piaudiomode == 'ALWAYS':
        EVENT.modealways = True
        log('SETTINGS: LOAD: AUDIOMODE=ALWAYS')
    elif piaudiomode == 'CD53':
        EVENT.modecd53 = True
        EVENT.cdc_emu = True
        EVENT.cdc_disc = 6
        EVENT.cdc_loaded = 32
        log('SETTINGS: LOAD: AUDIOMODE=CD53')
    elif piaudiomode == 'NONE':
        log('SETTINGS: LOAD: AUDIOMODE=NONE')
    log('SETTINGS: LOAD: CDC_EMU=%s' % EVENT.cdc_emu)
    car_model = KODI.get_addon_setting('car_model')
    log('SETTINGS: LOAD: CAR_MODEL=%s' % car_model)
    car_model = car_model.split('/')
    if car_model[0] in ('E38', 'E39', 'E53'):
        EVENT.car_model = 'E39'
        log('SETTINGS: LOAD: CAR_MODEL-LIGHTMODUL=LCM')
    elif car_model[0] in ('E46', 'E83', 'E85'):
        EVENT.car_model = 'E46'
        log('SETTINGS: LOAD: CAR_MODEL-LIGHTMODUL=LSZ')
    else:
        EVENT.car_model = 'E39'
    try:
        EVENT.gm_mode = int(car_model[1])
    except IndexError:
        EVENT.gm_mode = 0

    log('SETTINGS: LOAD: CAR_MODEL-GM_MODE=%s' % EVENT.gm_mode)
    EVENT.engine_type = int(KODI.get_addon_setting('engine_type'))
    if EVENT.engine_type == 0:
        log('SETTINGS: LOAD: ENGINE_TYPE=PETROL')
    if EVENT.engine_type == 1:
        log('SETTINGS: LOAD: ENGINE_TYPE=DIESEL')
    EVENT.tcp_port = int(KODI.get_addon_setting('tcp_port'))
    log('SETTINGS: LOAD: TCP_PORT=%s' % EVENT.tcp_port)
    EVENT.tcp_send_ibus = KODI.get_addon_setting('tcp_send_ibus')
    log('SETTINGS: LOAD: TCP_SEND_IBUS=%s' % EVENT.tcp_send_ibus)
    EVENT.dsp_cd = KODI.get_addon_setting('dsp_cd')
    EVENT.dsp_tuner = KODI.get_addon_setting('dsp_tuner')
    if EVENT.dsp_tuner:
        EVENT.dsp_cd = False
    if not EVENT.modecd:
        EVENT.dsp_tuner = False
    log('SETTINGS: LOAD: DSP_CD=%s' % EVENT.dsp_cd)
    log('SETTINGS: LOAD: DSP_TUNER=%s' % EVENT.dsp_tuner)
    EVENT.mir_unfold = KODI.get_addon_setting('mir_unfold')
    log('SETTINGS: LOAD: MIR_UNFOLD=%s' % EVENT.mir_unfold)
    EVENT.mir_unfold_ign = KODI.get_addon_setting('mir_unfold_ign')
    log('SETTINGS: LOAD: MIR_UNFOLD_IGN=%s' % EVENT.mir_unfold_ign)
    EVENT.mir_fold = KODI.get_addon_setting('mir_fold')
    log('SETTINGS: LOAD: MIR_FOLD=%s' % EVENT.mir_fold)
    EVENT.mir_fold_hold = KODI.get_addon_setting('mir_fold_hold')
    log('SETTINGS: LOAD: MIR_FOLD_HOLD=%s' % EVENT.mir_fold_hold)
    EVENT.welcome_on_boot = KODI.get_addon_setting('welcome_on_boot')
    log('SETTINGS: LOAD: WELCOME_ON_BOOT=%s' % EVENT.welcome_on_boot)
    EVENT.wel_light = KODI.get_addon_setting('wel_light')
    log('SETTINGS: LOAD: WEL_LIGHT=%s' % EVENT.wel_light)
    EVENT.wel_light_time = int(KODI.get_addon_setting('wel_light_time'))
    log('SETTINGS: LOAD: WEL_LIGHT_TIME=%s' % EVENT.wel_light_time)
    EVENT.lev_light = KODI.get_addon_setting('lev_light')
    log('SETTINGS: LOAD: LEV_LIGHT=%s' % EVENT.lev_light)
    EVENT.lev_light_time = int(KODI.get_addon_setting('lev_light_time'))
    log('SETTINGS: LOAD: LEV_LIGHT_TIME=%s' % EVENT.lev_light_time)
    EVENT.keyin_off = KODI.get_addon_setting('keyin_off')
    log('SETTINGS: LOAD: KEYIN_OFF=%s' % EVENT.keyin_off)
    EVENT.lev_light_ign_off = KODI.get_addon_setting('lev_light_ign_off')
    log('SETTINGS: LOAD: LEV_LIGHT_IGN_OFF=%s' % EVENT.lev_light_ign_off)
    EVENT.doors_off = KODI.get_addon_setting('doors_off')
    log('SETTINGS: LOAD: DOORS_OFF=%s' % EVENT.doors_off)
    EVENT.day_time = KODI.get_addon_setting('day_time')
    log('SETTINGS: LOAD: DAY_TIME=%s' % EVENT.day_time)
    EVENT.day_time_start = KODI.get_addon_setting('day_time_start')
    log('SETTINGS: LOAD: DAY_TIME_START=%s' % EVENT.day_time_start)
    EVENT.day_time_end = KODI.get_addon_setting('day_time_end')
    log('SETTINGS: LOAD: DAY_TIME_END=%s' % EVENT.day_time_end)
    EVENT.wel_light_park = KODI.get_addon_setting('wel_light_park')
    log('SETTINGS: LOAD: WEL_LIGHT_PARK=%s' % EVENT.wel_light_park)
    EVENT.wel_light_low = KODI.get_addon_setting('wel_light_low')
    log('SETTINGS: LOAD: WEL_LIGHT_LOW=%s' % EVENT.wel_light_low)
    EVENT.wel_light_fog = KODI.get_addon_setting('wel_light_fog')
    log('SETTINGS: LOAD: WEL_LIGHT_FOG=%s' % EVENT.wel_light_fog)
    EVENT.wel_light_nbrplate = KODI.get_addon_setting('wel_light_nbrplate')
    log('SETTINGS: LOAD: WEL_LIGHT_NBRPLATE=%s' % EVENT.wel_light_nbrplate)
    EVENT.wel_light_turn_front = KODI.get_addon_setting('wel_light_turn_front')
    log('SETTINGS: LOAD: WEL_LIGHT_TURN_FRONT=%s' % EVENT.wel_light_turn_front)
    EVENT.wel_light_turn_back = KODI.get_addon_setting('wel_light_turn_back')
    log('SETTINGS: LOAD: WEL_LIGHT_TURN_BACK=%s' % EVENT.wel_light_turn_back)
    EVENT.drl_light = KODI.get_addon_setting('drl_light')
    log('SETTINGS: LOAD: DRL_LIGHT=%s' % EVENT.drl_light)
    EVENT.drl_light_park = KODI.get_addon_setting('drl_light_park')
    EVENT.drl_light_fog = KODI.get_addon_setting('drl_light_fog')
    if not EVENT.drl_light:
        EVENT.drl_light_park = False
        EVENT.drl_light_fog = False
    log('SETTINGS: LOAD: DRL_LIGHT_PARK=%s' % EVENT.drl_light_park)
    log('SETTINGS: LOAD: DRL_LIGHT_FOG=%s' % EVENT.drl_light_fog)
    EVENT.ike_display = KODI.get_addon_setting('ike_disp')
    log('SETTINGS: LOAD: IKE_DISP=%s' % EVENT.ike_display)
    EVENT.ike_track = KODI.get_addon_setting('ike_track')
    log('SETTINGS: LOAD: IKE_TRACK=%s' % EVENT.ike_track)
    EVENT.wel_ike = KODI.get_addon_setting('wel_ike')
    log('SETTINGS: LOAD: WEL_IKE=%s' % EVENT.wel_ike)
    EVENT.wel_iketxt = KODI.get_addon_setting('wel_iketxt')
    log('SETTINGS: LOAD: WEL_IKETXT=%s' % EVENT.wel_iketxt)
    EVENT.wel_iketxt_hold = KODI.get_addon_setting('wel_iketxt_hold')
    log('SETTINGS: LOAD: WEL_IKETXT_HOLD=%s' % EVENT.wel_iketxt_hold)
    EVENT.text_scrollspeed = int(KODI.get_addon_setting('text_scrollspeed'))
    log('SETTINGS: LOAD: TEXT_SCROLLSPEED=%s' % EVENT.text_scrollspeed)
    EVENT.seek_sec = int(float(KODI.get_addon_setting('seek_sec')) * 1000)
    log('SETTINGS: LOAD: SEEK_SEC=%s' % EVENT.seek_sec)
    EVENT.seek_max = int(KODI.get_addon_setting('seek_max'))
    log('SETTINGS: LOAD: SEEK_MAX=%s' % EVENT.seek_max)
    EVENT.navhold_event = KODI.get_addon_setting('navhold_event')
    log('SETTINGS: LOAD: NAVHOLD_EVENT=%s' % EVENT.navhold_event)
    EVENT.inv_navturnbtn = KODI.get_addon_setting('inv_navturnbtn')
    log('SETTINGS: LOAD: INV_NAVTURNBTN=%s' % EVENT.inv_navturnbtn)
    setting = int(KODI.get_addon_setting('stw_rt_event'))
    if setting == 2:
        EVENT.use_stw_nav = True
        EVENT.nav_toggle_map = False
    elif setting == 1:
        EVENT.use_stw_nav = False
        EVENT.nav_toggle_map = True
    else:
        EVENT.use_stw_nav = False
        EVENT.nav_toggle_map = False
    log('SETTINGS: LOAD: USE_STW_NAV=%s' % EVENT.use_stw_nav)
    if not EVENT.use_stw_nav:
        EVENT.stw_nav = False
    log('SETTINGS: LOAD: NAV_TOGGLE_MAP=%s' % EVENT.nav_toggle_map)
    EVENT.gpio_ntsc = KODI.get_addon_setting('gpio_ntsc')
    log('SETTINGS: LOAD: GPIO_NTSC=%s' % EVENT.gpio_ntsc)
    EVENT.gpio_ntsc_on = int(KODI.get_addon_setting('gpio_ntsc_on'))
    log('SETTINGS: LOAD: GPIO_NTSC_ON=%s' % EVENT.gpio_ntsc_on)
    EVENT.gpio_gear_shift = int(KODI.get_addon_setting('gpio_gear_shift'))
    log('SETTINGS: LOAD: GPIO_GEAR_SHIFT=%s' % EVENT.gpio_gear_shift)
    EVENT.gpio_gear_shift_trigger_time = float(KODI.get_addon_setting('gpio_gear_shift_trigger_time')) / 1000
    log('SETTINGS: LOAD: GPIO_GEAR_SHIFT_TRIGGER_TIME=%s' % EVENT.gpio_gear_shift_trigger_time)
    EVENT.gpio_gear_shift_up = int(KODI.get_addon_setting('gpio_gear_shift_up'))
    log('SETTINGS: LOAD: GPIO_GEAR_SHIFT_UP=%s' % EVENT.gpio_gear_shift_up)
    EVENT.gpio_gear_shift_down = int(KODI.get_addon_setting('gpio_gear_shift_down'))
    log('SETTINGS: LOAD: GPIO_GEAR_SHIFT_DOWN=%s' % EVENT.gpio_gear_shift_down)
    EVENT.gpio_rearcam = KODI.get_addon_setting('gpio_rearcam')
    log('SETTINGS: LOAD: GPIO_REARCAM=%s' % EVENT.gpio_rearcam)
    EVENT.gpio_rearcam_on = int(KODI.get_addon_setting('gpio_rearcam_on'))
    log('SETTINGS: LOAD: GPIO_REARCAM_ON=%s' % EVENT.gpio_rearcam_on)
    EVENT.gpio_rearcam_off = int(KODI.get_addon_setting('gpio_rearcam_off'))
    log('SETTINGS: LOAD: GPIO_REARCAM_OFF=%s' % EVENT.gpio_rearcam_off)
    EVENT.gpio_rearcam_timeout = int(KODI.get_addon_setting('gpio_rearcam_timeout'))
    log('SETTINGS: LOAD: GPIO_REARCAM_TIMEOUT=%s' % EVENT.gpio_rearcam_timeout)
    EVENT.gpio_rearcam_speed = int(KODI.get_addon_setting('gpio_rearcam_speed'))
    log('SETTINGS: LOAD: GPIO_REARCAM_SPEED=%s' % EVENT.gpio_rearcam_speed)
    EVENT.comfort_blink = KODI.get_addon_setting('comfort_blink')
    log('SETTINGS: LOAD: COMFORT_BLINK=%s' % EVENT.comfort_blink)
    EVENT.comfort_blink_time = int(KODI.get_addon_setting('comfort_blink_time')) * 490
    log('SETTINGS: LOAD: COMFORT_BLINK_TIME=%s' % EVENT.comfort_blink_time)
    EVENT.turn_light = KODI.get_addon_setting('turn_light')
    log('SETTINGS: LOAD: TURN_LIGHT=%s' % EVENT.turn_light)
    EVENT.turn_light_time = int(KODI.get_addon_setting('turn_light_time')) * 1000
    log('SETTINGS: LOAD: TURN_LIGHT_TIME=%s' % EVENT.turn_light_time)
    EVENT.turn_light_max_speed = int(KODI.get_addon_setting('turn_light_max_speed'))
    log('SETTINGS: LOAD: TURN_LIGHT_MAX_SPEED=%s' % EVENT.turn_light_max_speed)
    EVENT.volume_sink_r = KODI.get_addon_setting('volume_sink_r')
    log('SETTINGS: LOAD: VOLUME_SINK_R=%s' % EVENT.volume_sink_r)
    EVENT.volume_sink_r_ibus = KODI.get_addon_setting('volume_sink_r_ibus')
    log('SETTINGS: LOAD: VOLUME_SINK_R_IBUS=%s' % EVENT.volume_sink_r_ibus)
    EVENT.volume_sink_r_value = int(KODI.get_addon_setting('volume_sink_r_value'))
    log('SETTINGS: LOAD: VOLUME_SINK_R_VALUE=%s' % EVENT.volume_sink_r_value)
    EVENT.volume_sink_r_value_ibus = int(KODI.get_addon_setting('volume_sink_r_value_ibus'))
    log('SETTINGS: LOAD: VOLUME_SINK_R_VALUE_IBUS=%s' % EVENT.volume_sink_r_value_ibus)
    EVENT.volume_sink_r_delay = int(KODI.get_addon_setting('volume_sink_r_delay'))
    log('SETTINGS: LOAD: VOLUME_SINK_R_DELAY=%s' % EVENT.volume_sink_r_delay)
    EVENT.volume_sink_r_speed = int(KODI.get_addon_setting('volume_sink_r_speed'))
    log('SETTINGS: LOAD: VOLUME_SINK_R_SPEED=%s' % EVENT.volume_sink_r_speed)
    EVENT.lcd_brightness = KODI.get_addon_setting('lcd_brightness')
    log('SETTINGS: LOAD: LCD_BRIGHTNESS=%s' % EVENT.lcd_brightness)
    EVENT.lcd_brightness_value_on = int(KODI.get_addon_setting('lcd_brightness_value_on'))
    log('SETTINGS: LOAD: LCD_BRIGHTNESS_VALUE_ON=%s' % EVENT.lcd_brightness_value_on)
    EVENT.lcd_brightness_value_off = int(KODI.get_addon_setting('lcd_brightness_value_off'))
    log('SETTINGS: LOAD: LCD_BRIGHTNESS_VALUE_OFF=%s' % EVENT.lcd_brightness_value_off)
    EVENT.pdc_on = KODI.get_addon_setting('pdc_on')
    log('SETTINGS: LOAD: PDC_ON=%s' % EVENT.pdc_on)
    EVENT.pdc_interval = float(KODI.get_addon_setting('pdc_interval')) / 1000
    log('SETTINGS: LOAD: PDC_INTERVAL=%s' % EVENT.pdc_interval)
    EVENT.pdc_type = int(KODI.get_addon_setting('pdc_type'))
    log('SETTINGS: LOAD: PDC_TYPE=%s' % ('REAR' if EVENT.pdc_type else 'FRONT + REAR'))
    EVENT.pdc_timeout = float(KODI.get_addon_setting('pdc_timeout'))
    log('SETTINGS: LOAD: PDC_TIMEOUT=%s' % EVENT.pdc_timeout)
    EVENT.pdc_timeout_off = KODI.get_addon_setting('pdc_timeout_off')
    log('SETTINGS: LOAD: PDC_TIMEOUT_OFF=%s' % EVENT.pdc_timeout_off)
    EVENT.pdc_bg = KODI.get_addon_setting('pdc_bg')
    log('SETTINGS: LOAD: PDC_BG=%s' % os.path.split(EVENT.pdc_bg)[1])
    KODI.set_property('pdc_bg', os.path.splitext(os.path.basename(EVENT.pdc_bg))[0])
    EVENT.zv_auto_lock = KODI.get_addon_setting('zv_auto_lock')
    log('SETTINGS: LOAD: ZV_AUTO_LOCK=%s' % EVENT.zv_auto_lock)
    EVENT.zv_selective = KODI.get_addon_setting('zv_selective')
    log('SETTINGS: LOAD: ZV_SELECTIVE=%s' % EVENT.zv_selective)
    EVENT.zv_auto_lock_speed = int(KODI.get_addon_setting('zv_auto_lock_speed'))
    log('SETTINGS: LOAD: ZV_AUTO_LOCK_SPEED=%s' % EVENT.zv_auto_lock_speed)
    EVENT.zv_auto_unlock_handbrake = KODI.get_addon_setting('zv_auto_unlock_handbrake')
    log('SETTINGS: LOAD: ZV_AUTO_UNLOCK_HANDBRAKE=%s' % EVENT.zv_auto_unlock_handbrake)
    EVENT.zv_auto_unlock_ign1 = KODI.get_addon_setting('zv_auto_unlock_ign1')
    log('SETTINGS: LOAD: ZV_AUTO_UNLOCK_IGN1=%s' % EVENT.zv_auto_unlock_ign1)
    EVENT.zv_auto_unlock_gear_p = KODI.get_addon_setting('zv_auto_unlock_gear_p')
    log('SETTINGS: LOAD: ZV_AUTO_UNLOCK_GEAR_P=%s' % EVENT.zv_auto_unlock_gear_p)
    EVENT.zv_auto_unlock_door_open = KODI.get_addon_setting('zv_auto_unlock_door_open')
    log('SETTINGS: LOAD: ZV_AUTO_UNLOCK_DOOR_OPEN=%s' % EVENT.zv_auto_unlock_door_open)
    EVENT.map_auto_zoom = KODI.get_addon_setting('map_auto_zoom')
    log('SETTINGS: LOAD: MAP_AUTO_ZOOM=%s' % EVENT.map_auto_zoom)
    EVENT.map_auto_zoom_200 = int(KODI.get_addon_setting('map_auto_zoom_200'))
    log('SETTINGS: LOAD: MAP_AUTO_ZOOM_200=%s' % EVENT.map_auto_zoom_200)
    EVENT.map_auto_zoom_500 = int(KODI.get_addon_setting('map_auto_zoom_500'))
    log('SETTINGS: LOAD: MAP_AUTO_ZOOM_500=%s' % EVENT.map_auto_zoom_500)
    EVENT.map_auto_zoom_1000 = int(KODI.get_addon_setting('map_auto_zoom_1000'))
    log('SETTINGS: LOAD: MAP_AUTO_ZOOM_1000=%s' % EVENT.map_auto_zoom_1000)
    EVENT.map_auto_zoom_2000 = int(KODI.get_addon_setting('map_auto_zoom_2000'))
    log('SETTINGS: LOAD: MAP_AUTO_ZOOM_2000=%s' % EVENT.map_auto_zoom_2000)
    EVENT.map_auto_zoom_5000 = int(KODI.get_addon_setting('map_auto_zoom_5000'))
    log('SETTINGS: LOAD: MAP_AUTO_ZOOM_5000=%s' % EVENT.map_auto_zoom_5000)
    EVENT.flash_to_pass = KODI.get_addon_setting('flash_to_pass')
    log('SETTINGS: LOAD: FLASH_TO_PASS=%s' % EVENT.flash_to_pass)
    EVENT.flash_to_pass_low_beam = KODI.get_addon_setting('flash_to_pass_low_beam')
    log('SETTINGS: LOAD: FLASH_TO_PASS_LOW_BEAM=%s' % EVENT.flash_to_pass_low_beam)
    EVENT.flash_to_pass_fog = KODI.get_addon_setting('flash_to_pass_fog')
    log('SETTINGS: LOAD: FLASH_TO_PASS_FOG=%s' % EVENT.flash_to_pass_fog)
    EVENT.bm_sensor = KODI.get_addon_setting('bm_sensor')
    log('SETTINGS: LOAD: BM_SENSOR=%s' % EVENT.bm_sensor)
    EVENT.bm_sensor_level = int(KODI.get_addon_setting('bm_sensor_level'))
    log('SETTINGS: LOAD: BM_SENSOR_LEVEL=%s' % EVENT.bm_sensor_level)
    EVENT.shutdown_timer_enable = KODI.get_addon_setting('shutdown_timer_enable')
    log('SETTINGS: LOAD: SHUTDOWN_TIMER_ENABLE=%s' % EVENT.shutdown_timer_enable)
    EVENT.shutdown_timer_time = int(KODI.get_addon_setting('shutdown_timer_time'))
    log('SETTINGS: LOAD: SHUTDOWN_TIMER_TIME=%s' % EVENT.shutdown_timer_time)
    EVENT.aux_heat_zv_lock_hold = KODI.get_addon_setting('aux_heat_zv_lock_hold')
    log('SETTINGS: LOAD: AUX_HEAT_ZV_LOCK_HOLD=%s' % EVENT.aux_heat_zv_lock_hold)
    EVENT.engine_cold_warning = KODI.get_addon_setting('engine_temp_cold_warning')
    log('SETTINGS: LOAD: ENGINE_TEMP_COLD_WARNING=%s' % EVENT.engine_cold_warning)
    EVENT.engine_cold_warning_text = KODI.get_addon_setting('engine_temp_cold_warning_text')
    log('SETTINGS: LOAD: ENGINE_TEMP_COLD_WARNING_TEXT=%s' % EVENT.engine_cold_warning_text)
    EVENT.engine_overheat_warning = KODI.get_addon_setting('engine_temp_overheat_warning')
    log('SETTINGS: LOAD: ENGINE_TEMP_OVERHEAT_WARNING=%s' % EVENT.engine_overheat_warning)
    EVENT.engine_overheat_temp = int(KODI.get_addon_setting('engine_temp_overheat_value'))
    log('SETTINGS: LOAD: ENGINE_TEMP_OVERHEAT_VALUE=%s' % EVENT.engine_overheat_temp)
    EVENT.engine_overheat_warning_text = KODI.get_addon_setting('engine_temp_overheat_warning_text')
    log('SETTINGS: LOAD: ENGINE_TEMP_OVERHEAT_WARNING_TEXT=%s' % EVENT.engine_overheat_warning_text)
    loglevel = int(KODI.get_addon_setting('log_lvl'))
    log('SETTINGS: LOAD: LOGLVL=%s' % loglevel, 0)
    KODI.log_level = loglevel
    if settings_changed:
        EVENT.radio_mode_get()
        EVENT.obc_coolant_req()
        EVENT.obc_outtemp_req()
        EVENT.lcm_state_req()
        if EVENT.gpio_ntsc and not gpio_ntsc_tmp:
            GPIO_NTSC.open(7, off_level=True)
            IBUS.ntsc = False
        elif not EVENT.gpio_ntsc:
            GPIO_NTSC.close()
        if EVENT.gpio_rearcam and not gpio_rearcam_tmp:
            GPIO_REARCAM.open(EVENT.gpio_rearcam_on, off_level=True)
        elif not EVENT.gpio_rearcam:
            GPIO_REARCAM.close()
        if EVENT.gpio_gear_shift > 0 and not gpio_gear_shift_tmp:
            GPIO_GEAR_SHIFT_UP.open(EVENT.gpio_gear_shift_up, off_level=True)
            GPIO_GEAR_SHIFT_DOWN.open(EVENT.gpio_gear_shift_down, off_level=True)
        if EVENT.gpio_gear_shift > 0 and gpio_gear_shift_tmp and EVENT.gpio_gear_shift_up != gpio_gear_shift_up_tmp:
            GPIO_GEAR_SHIFT_UP.open(EVENT.gpio_gear_shift_up, off_level=True)
        if EVENT.gpio_gear_shift > 0 and gpio_gear_shift_tmp and EVENT.gpio_gear_shift_down != gpio_gear_shift_down_tmp:
            GPIO_GEAR_SHIFT_DOWN.open(EVENT.gpio_gear_shift_down, off_level=True)
        if EVENT.cdc_emu and not cdc_emu_tmp:
            EVENT.cdch_init()
        if EVENT.drl_light:
            EVENT.lcm_drl_on()
        else:
            EVENT.lcm_drl_off()


def delete_object(object):
    xbmc.log('IBUSCOMMUNICATOR: Objectcount: %s' % sys.getrefcount(object), xbmc.LOGNOTICE)
    try:
        while sys.getrefcount(object) >= 0:
            del object

    except NameError:
        pass


KODI = Kodi()
KODI.log_to_kodi = KODI.get_addon_setting('log_to_kodi')
if not KODI.log_to_kodi:
    KODI.ibuslogger = Logger(EXTLOGFILEPATH)
    KODI.ibusdatalogger = Logger(EXTERNIBUSLOGFILEFULLPATH)
PLAYER = PlayerClass()
MONITOR = MonitorClass()
IBUS = IBusFace()
EVENT = EventClass()
GPIO_NTSC = GPIOClass()
GPIO_GEAR_SHIFT_UP = GPIOClass()
GPIO_GEAR_SHIFT_DOWN = GPIOClass()
GPIO_REARCAM = GPIOClass()
DOUBLECLICKDELAY = 0.3
DBL_NEXT = Clicker(DOUBLECLICKDELAY, KODI.right, KODI.track_next)
DBL_PREV = Clicker(DOUBLECLICKDELAY, KODI.left, KODI.track_prev)
DBL_STW_SPEAK = Clicker(DOUBLECLICKDELAY, KODI.select, KODI.back)

def main():
    xbmc.log('IBUSCOMMUNICATOR: Service Started', xbmc.LOGNOTICE)
    log('STARTUP: IBUSCOMMUNICATOR VERSION: %s' % ADDON_VERSION)
    if not xbmcvfs.exists(ADDON_USER_PATH):
        xbmcvfs.mkdir(ADDON_USER_PATH)
        log('STARTUP: ADDON_USER_PATH "%s" created' % ADDON_USER_PATH)
    KODI.set_property('IBUS_RADIO_MODE', '---')
    log('STARTUP: LOAD SETTINGS...')
    load_settings()
    if EVENT.gpio_gear_shift > 0:
        GPIO_GEAR_SHIFT_UP.open(EVENT.gpio_gear_shift_up, off_level=True)
        GPIO_GEAR_SHIFT_UP.reset()
        GPIO_GEAR_SHIFT_DOWN.open(EVENT.gpio_gear_shift_down, off_level=True)
        GPIO_GEAR_SHIFT_DOWN.reset()
    if EVENT.gpio_ntsc:
        GPIO_NTSC.open(7, off_level=True)
        GPIO_NTSC.reset()
    if EVENT.gpio_rearcam:
        GPIO_REARCAM.open(EVENT.gpio_rearcam_on, off_level=True)
        GPIO_REARCAM.reset()
    tcp_server = Thread(target=handle_extern_events)
    tcp_server.daemon = True
    ibus_st = Thread(target=EVENT.read_ibus_packages)
    ibus_st.daemon = True
    log('STARTUP: IBUS: Connecting...')
    try:
        IBUS.set_port(EVENT.device_path)
        IBUS.connect(EVENT.manage)
    except:
        note(language('IBUS: Error'), language('IBus Connection failed'))
        time.sleep(2)
        if not EVENT.develop:
            raise

    tcp_server.start()
    if EVENT.develop:
        note(heading='[COLOR FFFF7E00]%s[/COLOR]' % language('Development Mode'), message='[B]%s[/B]' % language('Continue without IBus Connection'))
    else:
        note(language('IBus Connected'))
    if EVENT.wel_ike:
        EVENT.ike_send_text(EVENT.wel_iketxt, True, EVENT.wel_iketxt_hold)
        time.sleep(0.2)
    EVENT.mid_fond_ike_ready_req()
    for counter in range(5, 0, -1):
        if EVENT.ike_states['ign_mode'] >= 0:
            break
        log('STARTUP: WAIT FOR IGNITION STATE %s' % counter)
        EVENT.ign_state_get()
        time.sleep(0.2)

    for counter in range(5, 0, -1):
        if EVENT.obc_time[0]:
            break
        log('STARTUP: GET OBC TIME %s' % counter)
        EVENT.obc_time_req()
        time.sleep(0.2)

    if EVENT.modealways:
        EVENT.pi_on()
        EVENT.pass_bm_buttons = True
    else:
        log('STARTUP: INITIATE CD-CHANGER')
        EVENT.cdch_init()
    for counter in range(5, 0, -1):
        if EVENT.gm_states['run_once']:
            break
        log('STARTUP: GET 1ST GM STATES %s' % counter)
        EVENT.gm_state_req()
        time.sleep(0.2)

    for counter in range(5, 0, -1):
        if EVENT.lcm_states['run_once']:
            break
        log('STARTUP: GET 1ST LCM STATES %s' % counter)
        EVENT.lcm_state_req()
        time.sleep(0.2)

    for counter in range(5, 0, -1):
        if EVENT.ike_states['run_once']:
            break
        log('STARTUP: GET 1ST IKE STATES %s' % counter)
        EVENT.ike_get_state()
        time.sleep(0.2)

    if EVENT.wel_light and EVENT.welcome_on_boot:
        log('STARTUP: LCM: turn lights on', 3)
        EVENT.lcm_welcome_on(EVENT.wel_light_time)
        log('STARTUP: LCM: lights should turned on', 3)
    log('STARTUP: GET KEY')
    EVENT.ews_key_req()
    time.sleep(0.2)
    if EVENT.mir_unfold and EVENT.welcome_on_boot and not EVENT.gm_states['zvlockstate']:
        log('STARTUP: UNFOLD MIRRORS')
        EVENT.gm_mirror_unfold()
    if not EVENT.modealways:
        log('STARTUP: GET RADIO MODE')
        EVENT.radio_mode_get()
    EVENT.startup_done = True
    log('STARTUP: FINISHED :)')
    EVENT.obc_req()
    EVENT.lcm_drl_on()
    if MONITOR.waitForAbort():
        log('Service Shutdown.....')
        EVENT.lcm_drl_off()
        EVENT.cancel_read_thread = True
        EVENT.cancel_ike_text = True
        tcp_server.join()
        log('IBUS: Disconnecting')
        IBUS.disconnect()
        log('IBUS: Disconnected')
        GPIO_NTSC.close()
        GPIO_GEAR_SHIFT_UP.close()
        GPIO_GEAR_SHIFT_DOWN.close()
        GPIO_REARCAM.close()
        DBL_NEXT.close()
        DBL_PREV.close()
        DBL_STW_SPEAK.close()
        time.sleep(1)
    xbmc.log('IBUSCOMMUNICATOR: Service Stopped', xbmc.LOGNOTICE)


if __name__ == '__main__':
    main()
log('Refcount IBUS: %s' % sys.getrefcount(IBUS))
log('Free Memory....')
xbmc.log('ClEAR: PLAYER', xbmc.LOGNOTICE)
delete_object(PLAYER)
xbmc.log('ClEAR: MONITOR', xbmc.LOGNOTICE)
delete_object(MONITOR)
xbmc.log('ClEAR: EVENT', xbmc.LOGNOTICE)
delete_object(EVENT)
xbmc.log('ClEAR: GPIO_NTSC', xbmc.LOGNOTICE)
delete_object(GPIO_NTSC)
xbmc.log('ClEAR: GPIO_GEAR_SHIFT_UP', xbmc.LOGNOTICE)
delete_object(GPIO_GEAR_SHIFT_UP)
xbmc.log('ClEAR: GPIO_GEAR_SHIFT_DOWN', xbmc.LOGNOTICE)
delete_object(GPIO_GEAR_SHIFT_DOWN)
xbmc.log('ClEAR: GPIO_REARCAM', xbmc.LOGNOTICE)
delete_object(GPIO_REARCAM)
xbmc.log('ClEAR: DBL_NEXT', xbmc.LOGNOTICE)
delete_object(DBL_NEXT)
xbmc.log('ClEAR: DBL_PREV', xbmc.LOGNOTICE)
delete_object(DBL_PREV)
xbmc.log('ClEAR: DBL_STW_SPEAK', xbmc.LOGNOTICE)
delete_object(DBL_STW_SPEAK)
xbmc.log('ClEAR: IBUS', xbmc.LOGNOTICE)
delete_object(IBUS)
xbmc.log('ClEAR: KODI', xbmc.LOGNOTICE)
delete_object(KODI)
xbmc.log('ClEAR: SYS_MODULES', xbmc.LOGNOTICE)
for m in sys.modules.keys():
    if not m == '__main__':
        del sys.modules[m]

xbmc.log('SERVICE COMPLETELY CLOSED', xbmc.LOGNOTICE)
sys.exit(0)
