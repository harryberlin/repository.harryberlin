# Embedded file name: default.py
import os
import sys
from datetime import datetime
import xbmc, xbmcgui, xbmcaddon, xbmcvfs
__author__ = 'harryberlin'
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_PDC_BG_PATH = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'pdc', 'bgs', 'default.png')
KODILOGFILE = '/home/osmc/.kodi/temp/kodi.log'
BACKUPLOGFILEPATH = '/boot/ibuscommunicator'
KODI_ACTIONS = ['Action(Playlist)',
 'Action(Screenshot)',
 'Action(Mute)',
 'Action(Info)',
 'Action(FullScreen)',
 'Action(StepForward)',
 'Action(StepBack)',
 'Action(OSD)',
 'Action(ShowSubtitles)',
 'Action(ShowVideoMenu)',
 'ActivateWindow(Home)',
 'ActivateWindow(Music)',
 'ActivateWindow(1150)',
 'ActivateWindow(1135)',
 'PlayerControl(Repeat)',
 'PlayerControl(Random)',
 'RunAddon(plugin.script.ibuscommunicator)']

def log(string):
    return xbmc.log('IBUSCOMMUNICATOR: %s' % string)


def dialog_ok(label1, label2 = '', label3 = ''):
    return xbmcgui.Dialog().ok('IBusCommunicator', label1, label2, label3)


def copy_log_file():
    if not xbmcvfs.exists(BACKUPLOGFILEPATH):
        os.popen('sudo -s mkdir %s' % BACKUPLOGFILEPATH)
    file_name = datetime.now().strftime('%Y%m%d_%H%M%S_kodi.txt')
    BACKUPLOGFILE = os.path.join(BACKUPLOGFILEPATH, file_name)
    os.popen('sudo -s cp %s %s' % (KODILOGFILE, BACKUPLOGFILE))
    dialog_ok('logfile <%s>' % file_name, 'copied to:', BACKUPLOGFILEPATH)


def open_obcgui():
    xbmcaddon.Addon().openSettings()


def open_settings():
    xbmcaddon.Addon().openSettings()


def connect_ibus():
    pass


def disconnect_ibus():
    pass


def bm_set_button_event(button_nbr):
    log('Set Event for BM Button: %s' % button_nbr)
    favmusicpath = 'Favorite Music Path'
    custom = '-- CUSTOM --'
    reset = '---- RESET ---'
    KODI_ACTIONS.extend([favmusicpath, custom, reset])
    selected = xbmcgui.Dialog().select('Choose Kodi Function', KODI_ACTIONS)
    if selected != -1:
        if KODI_ACTIONS[selected] == reset:
            xbmcaddon.Addon().setSetting('bm_btn_%s' % button_nbr, '')
        elif KODI_ACTIONS[selected] == custom:
            response = xbmcgui.Dialog().input('Custom Kodi Function eingeben')
            if response == '':
                return
            xbmcaddon.Addon().setSetting('bm_btn_%s' % button_nbr, response)
        elif KODI_ACTIONS[selected] == favmusicpath:
            response = xbmcgui.Dialog().browseSingle(0, favmusicpath, 'files', '', False, False, '')
            if response == '':
                return
            xbmcaddon.Addon().setSetting('bm_btn_%s' % button_nbr, 'ActivateWindow(Music,%s)' % response)
        else:
            xbmcaddon.Addon().setSetting('bm_btn_%s' % button_nbr, KODI_ACTIONS[selected])
    xbmc.sleep(1000)


def pdc_bg():
    log('PDC: Set Model Type')
    default = xbmcaddon.Addon().getSetting('pdc_bg')
    selected = xbmcgui.Dialog().browse(2, 'Choose Kodi Function', 'files', '.png', True, False, default)
    if selected != default:
        xbmcaddon.Addon().setSetting('pdc_bg', selected)
        xbmcgui.Window(10000).setProperty('pdc_bg', os.path.splitext(os.path.basename(selected))[0])
    xbmc.sleep(1000)


def test():
    win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    current_control = win.getControl(win.getFocusId())


def music_tag():
    log('MUSIC TAG START')
    vObject = xbmc.Player().getVideoInfoTag()
    log(dir(vObject))
    log('MUSIC TAG ENDE')


def main():
    count = len(sys.argv) - 1
    if count > 0:
        given_args = sys.argv[1].split(';')
        if str(given_args[0]) == 'obc':
            open_obcgui()
        elif str(given_args[0]) == 'settings':
            open_settings()
        elif str(given_args[0]) == 'connect_ibus':
            connect_ibus()
        elif str(given_args[0]) == 'disconnect_ibus':
            disconnect_ibus()
        elif str(given_args[0]) == 'test':
            test()
        elif str(given_args[0]) == 'copy_logfile':
            copy_log_file()
        elif str(given_args[0]) == 'pdc_bg':
            pdc_bg()
        elif str(given_args[0]) == 'music_tag':
            music_tag()
        elif str(given_args[0]) == 'disconnect_ibus':
            try:
                pass
            except:
                pass

        elif str(given_args[0]) == 'bm_btn':
            bm_set_button_event(given_args[1])
    else:
        open_settings()


if __name__ == '__main__':
    main()