#!/usr/bin/env python
# -*- coding: utf-8 -*-

###### intall these pakets #####
# sudo apt-get install python-serial


import os
import time

import subprocess
from re import findall
from datetime import datetime
from threading import Thread, Lock, Event
import xbmc, xbmcgui, xbmcaddon, xbmcvfs
from Queue import PriorityQueue, Empty, Queue

__author__ = 'harryberlin'

ADDON = xbmcaddon.Addon()
ADDONNAME = ADDON.getAddonInfo('name')
ADDONID = ADDON.getAddonInfo('id')
ADDONPATH = ADDON.getAddonInfo('path')
ADDONVERSION = ADDON.getAddonInfo('version')

ICON = os.path.join(ADDONPATH, 'icon.png')

KODILOGFILE = '/home/osmc/.kodi/temp/kodi.log'
BACKUPLOGFILEPATH = '/boot/ibuscommunicator'

BIT = {0: 8, 1: 7, 2: 6, 3: 5, 4: 4, 5: 3, 6: 2, 7: 1}


##### XBMC Control Examples
# xbmc.executebuiltin('ActivateWindow(10000)')
# xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Up", "id": 1 }')
class Kodi(object):
    log_level = 1

    def __init__(self):
        pass

    def up(self, steps="01"):
        steps = int(steps, 16)
        if steps > 1:
            for i in range(1, steps):
                xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Up", "id": 1 }')
                # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.ExecuteAction","params": {"action": "up"},"id":1}')
                time.sleep(0.020)
        else:
            xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Up", "id": 1 }')

    def down(self, steps="01"):
        steps = int(steps, 16)
        if steps > 1:
            for i in range(1, steps):
                xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Down", "id": 1 }')
                # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.ExecuteAction","params": {"action": "down"},"id":1}')
                time.sleep(0.020)
        else:
            xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Down", "id": 1 }')

    def left(self):
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Left", "id": 1 }')

    def right(self):
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Right", "id": 1 }')

    def back(self):
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Back", "id": 1 }')

    def select(self):
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Select", "id": 1 }')

    def home(self):
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Home", "id": 1 }')

    def track_play(self):
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Player.SetSpeed","params":{"playerid":%s,"speed":1 },"id":1}' % self.player_id())

    def track_pause(self):
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Player.PlayPause","params":{"playerid":%s,"play":false},"id":1}' % self.player_id())

    def track_seek(self, SPEED):
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Player.SetSpeed","params":{"playerid":%s,"speed":%s },"id":1}' % (self.player_id(), SPEED))

    def track_next(self):
        xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.GoTo", "params": { "playerid": %s, "to": "next" }, "id": 1}' % self.player_id())

    def track_prev(self):
        xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.GoTo", "params": { "playerid": %s, "to": "previous" }, "id": 1}' % self.player_id())

    def track_pos(self, milliseconds):
        xbmc.Player().seekTime(milliseconds)

    def track_title(self):
        log('get song', 3)
        if xbmc.Player().isPlayingAudio():
            log('music', 3)
            artist = xbmc.getInfoLabel('MusicPlayer.Artist')
            title = xbmc.getInfoLabel('MusicPlayer.Title')
            # sArtist = xbmc.Player().getMusicInfoTag().getArtist()
            # sTitle = xbmc.Player().getMusicInfoTag().getTitle()
            log('SONG MUSIC: "%s" - "%s"' % (artist, title), 2)
            if artist == title: return '%s' % artist
            if artist == '': return '%s' % (title)
            if title == '': return '%s' % (artist)
            return '%s - %s' % (artist, title)
        elif xbmc.Player().isPlayingVideo():
            log('video', 3)
            title = xbmc.getInfoLabel('VideoPlayer.Title')
            # sTitle = xbmc.Player().getVideoInfoTag().getTitle()
            file = xbmc.Player().getVideoInfoTag().getFile()
            log('SONG VIDEO: "%s"' % title, 2)
            if title != '':
                return '%s' % title
            else:
                return '%s' % file

        else:
            log('SONG: empty')
            return ''

    def action(self, action_event):
        if EVENT.modeaux:
            return note(heading='No Function in AUX-Mode', message='Key 1-6 sets Volumelevel', time=2000)
        if action_event == '':
            return note('No Function for this Button set', time=2000)

        log('KODI ACTION EVENT: %s' % action_event)

        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.ExecuteAction","params": {"action": "%s"},"id":1}' % action_event)
        xbmc.executebuiltin('%s' % action_event)

    def player_id(self):
        response = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.GetActivePlayers","id": 1}')
        log("JSONREPLY: " + response, 3)
        try:
            playerID_tmp = findall('"playerid":(.*?),"', response)
            log("PLAYERID: %s" % playerID_tmp[0], 3)
            return playerID_tmp[0]
        except:
            log("PLAYERID: -1", 3)
            return '-1'

    def get_current_listlabel(self, old_label=''):
        wait = 5
        while old_label == xbmc.getInfoLabel("ListItem.Label") and wait > 0:
            time.sleep(0.100)
            wait += -1
        new_label = xbmc.getInfoLabel("ListItem.Label")
        return new_label if new_label != '' else 'Kodi Control'

    def copy_log_file(self):
        if not xbmcvfs.exists(BACKUPLOGFILEPATH):
            os.popen('sudo -s mkdir %s' % BACKUPLOGFILEPATH)

        BACKUPLOGFILE = os.path.join(BACKUPLOGFILEPATH, datetime.now().strftime('%Y%m%d_%H%M%S_kodi.txt'))
        os.popen('sudo -s cp %s %s' % (KODILOGFILE, BACKUPLOGFILE))

    @staticmethod
    def get_addon_setting(id):
        setting = xbmcaddon.Addon().getSetting(id)
        # setting = __addon__.getSetting(id)
        if setting.upper() == 'TRUE': return True
        if setting.upper() == 'FALSE': return False
        return '%s' % setting

    @staticmethod
    def set_property(property, value, id=10000):
        xbmcgui.Window(id).setProperty(property, value)
        # xbmc.executebuiltin('SetProperty(%s,%s,%s)' % (property, value, id))

    @staticmethod
    def get_property(property, id=10000):
        value = xbmcgui.Window(id).getProperty(property)
        return value

    def set_log_level(self, level):
        self.log_level = level

    def log(self, string, lvl=1):
        if lvl <= self.log_level <= 3 or self.log_level == 5 and lvl == 5:
            return xbmc.log('IBUSCOMMUNICATOR: %s' % string)

    def note(self, heading, message=" ", time=5000):
        xbmcgui.Dialog().notification(heading=' %s' % heading, message=' %s' % message, icon=ICON, time=time)
        log('NOTIFICATION: ' + heading + ' - ' + message)

    def dialog_ok(label1, label2='', label3=''):
        return xbmcgui.Dialog().ok('IBusCommunicator', label1, label2, label3)


class Clicker:
    def __init__(self, double_click_interval, single_func, double_func):
        self._queue = Queue()
        latch = Event()

        def handle_clicks():
            latch.set()
            while not EVENT.cancel_read_thread:
                self._queue.get()
                if EVENT.cancel_read_thread:
                    break
                try:
                    self._queue.get(True, double_click_interval)
                except Empty:
                    single_func()
                else:
                    double_func()


        thread = Thread(target=handle_clicks)
        thread.daemon = True
        thread.start()
        latch.wait()

    def click(self):
        self._queue.put(None)


class PlayerClass(xbmc.Player):
    def __init__(self):
        self.RESUMEONCE = False
        xbmc.Player.__init__(self)

    def onQueueNextItem(self):
        # note('Next')
        pass

    def onPlayBackStarted(self):
        # self.RESUMEONCE = True
        # xbmc.sleep(2000)
        # print ('PLAYERTIME: ' + str(xbmc.Player().getTime()))

        # print ('PLAYERTIME: ' + str(xbmc.Player().getTime()))
        EVENT.send_song_to_ike()
        EVENT.kodi_said_play()
        # note('Started')
        pass

    def onPlayBackEnded(self):
        # note('Ended')
        pass

    def onPlayBackStopped(self):
        # note('Stopped')
        pass

    def onPlayBackPaused(self):
        # note('Pause')
        pass

    def onPlayBackResumed(self):
        if not self.RESUMEONCE:
            if EVENT.is_pi_active(): self.RESUMEONCE = True
            EVENT.send_song_to_ike()
        # xbmc.executebuiltin("Notification(Resumed,,250)")
        EVENT.kodi_said_play()
        pass

    def onPlayBackSeek(self, time, seekOffset):
        # xbmc.executebuiltin("Notification(Seek," + str(time) + ",250)")
        pass


class MonitorClass(xbmc.Monitor):
    def __init__(self):
        xbmc.Monitor.__init__(self)

    def onSettingsChanged(self):
        # log('SETTINGS: ################ CHANGED ###############',0)
        time.sleep(0.6)
        note('Settings changed')
        load_settings(True)


class MFLDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, xmlFilename, scriptPath, defaultSkin, defaultRes):
        log("Initializing MFL Dialog...")
        self.Action = {
            1: 'Left',
            2: 'Right',
            3: 'Up',
            4: 'Down',
            7: 'Select',
            92: 'Back',
            # 14: 'SkipNext',
            # 15: 'SkipPrevious',
            117: 'ContextMenu'
        }

    def onInit(self):
        pass

    def onFocus(self, controlId):
        pass

    def onAction(self, action):
        curWinID = xbmcgui.getCurrentWindowId()
        curDlgID = xbmcgui.getCurrentWindowDialogId()
        log('curWinID: %s' % curWinID)
        log('curDlgID: %s' % curDlgID)
        # curWin = xbmcgui.Window(curWinID)
        # curWin.onAction(action=action)
        # log('ActionID: %s' % action.getId())
        xbmc.executebuiltin('Action(%s,%s)' % (self.Action[action.getId()], curWinID))

    def onStop(self):
        pass


class GPIOClass:
    isOpen = False

    def init(self, pinnumber, mode='out', level=False):
        if pinnumber not in [0, 1, 4, 7, 8, 9, 10, 11, 14, 15, 17, 18, 21, 22, 23, 24, 25]:
            raise ValueError('%s is no valid GPIO' % pinnumber)
        self.pinnumber = pinnumber
        #self._call('sudo echo "%s" > /sys/class/gpio/export' % self.pinnumber)
        #self._call('sudo echo "%s" > /sys/class/gpio/gpio%s/direction' % (mode, self.pinnumber))
        os.popen('sudo chmod 222 /sys/class/gpio/export /sys/class/gpio/unexport')
        os.popen('sudo echo %s >/sys/class/gpio/export' % self.pinnumber)
        os.popen('sudo chmod 222 /sys/class/gpio/gpio%s/direction'  % self.pinnumber)
        os.popen('sudo chmod 222 /sys/class/gpio/gpio%s/value'  % self.pinnumber)
        #os.popen('sudo echo "%s" > /sys/class/gpio/gpio%s/direction' % (mode, self.pinnumber))
        if mode == 'out':
            if level:
                self.set()
            else:
                self.reset()
        elif mode == 'in':
            pass
        self.isOpen = True

    def _call(self, command):
        try:
            try:
                output = subprocess.check_output(command, stderr=subprocess.STDOUT)
            except subprocess.CalledProcessError as error:
                output = error.output
                return error.returncode
            else:
                return output
        finally:
            pass

    def close(self):
        if self.isOpen:
            #self._call('sudo echo "%s" > /sys/class/gpio/unexport' % self.pinnumber)
            os.popen('sudo echo %s > /sys/class/gpio/unexport' % self.pinnumber)

    def set(self):
        if self.isOpen:
            #self._call('sudo echo "1" > /sys/class/gpio/gpio%s/value' % self.pinnumber)
            os.popen('sudo echo high >/sys/class/gpio/gpio%s/direction' % self.pinnumber)

    def reset(self):
        if self.isOpen:
            #self._call('sudo echo "0" > /sys/class/gpio/gpio%s/value' % self.pinnumber)
            os.popen('sudo echo low >/sys/class/gpio/gpio%s/direction' % self.pinnumber)

    def toggle(self):
        if self.isOpen:
            #pin_level = self._call('sudo cat /sys/class/gpio/gpio%s/value' % self.pinnumber)
            pin_level = bool(os.popen('sudo cat /sys/class/gpio/gpio%s/value' % self.pinnumber))
            if pin_level:
                self.reset()
            else:
                self.set()

    def trigger(self, holdtime=0.2):
        if self.isOpen:
            self.set()
            while holdtime > 0:
                holdtime -= 0.001
                time.sleep(0.001)
            self.reset()

    def get(self):
        if self.isOpen:
            #value = self._call('sudo cat /sys/class/gpio/gpio%s/value' % self.pinnumber)
            value = bool(os.popen('sudo cat /sys/class/gpio/gpio%s/value' % self.pinnumber))
            return value


class IBusFace(object):
    def __init__(self):
        self.serial_port = serial.Serial()
        self.serial_port.baudrate = 9600
        self.serial_port.bytesize = serial.EIGHTBITS
        self.serial_port.parity = serial.PARITY_EVEN
        self.serial_port.stopbits = serial.STOPBITS_ONE
        self.serial_port.timeout = 0.5

        self.rts_state = False

        self.read_error_counter = 0  # counter for read errors
        KODI.set_property('msgerr_cnt', '0')

        self.read_buffer = []
        self.read_lock = Lock()

        # Reading Thread
        self.cancel_read_thread = False
        self.read_thread = Thread(target=self._reading)
        self.read_thread.setDaemon(True)

        self.write_buffer = PriorityQueue()
        self.write_counter = 0

        # Writing Thread
        self.cancel_write_thread = False
        self.write_thread = Thread(target=self._writing)
        self.write_thread.setDaemon(True)

    @staticmethod
    def _calculate_checksum(packet):
        result = 0
        for value in packet:
            result ^= value
        return result

    def _cut_read_buffer(self, offset=1):
        with self.read_lock:
            self.read_buffer = self.read_buffer[offset:]

    def _wait_free_bus(self, waiting=17, timeout=1000):
        cts_counter = 0
        while cts_counter < waiting:
            if self.serial_port.getCTS():
                cts_counter += 1
                if not timeout > 0:
                    return False
                timeout -= 1
            else:
                cts_counter = 0
                if not timeout > 0:
                    return False
                timeout -= 1
            time.sleep(0.001)
        return True

    def _reading(self):
        while not self.cancel_read_thread:
            self._read_char()
            time.sleep(0.001)
        log('IBUS: Read Thread finished', 2)

    def _read_char(self):
        try:
            while self.serial_port.inWaiting() > 0:
                if self.cancel_read_thread:
                    return
                with self.read_lock:
                    self.read_buffer.append(ord(self.serial_port.read()))
        except:
            log('IBUS: Hit a serialException')
            return

    def _writing(self):
        cts_count = 0
        while not self.cancel_write_thread:
            if self.serial_port.getCTS():
                cts_count += 1
            else:
                cts_count = 0
            if cts_count > 17:
                try:
                    prio, write_counter, data = self.write_buffer.get(timeout=0.001)
                    self.serial_port.write(data)
                    self.serial_port.flush()
                    cts_count = 0
                    log('IBUS-SENT: %s' % ' '.join(['%02X' % ord(i) for i in data]), 2)
                except Empty:
                    pass
            else:
                time.sleep(0.001)
        log('IBUS: Write Thread finished', 2)

    def set_port(self, device_path):
        self.serial_port.port = device_path

    def connect(self):
        # try:
        self.serial_port.open()
        # self.serial_port.setRTS(False)
        self.serial_port.setRTS(False)

        if not self._wait_free_bus(120, 2000):
            log('IBUS: Can not locate free Bus')
            return False

        self.serial_port.flushInput()

        # start reading
        self.read_thread.start()
        self.write_thread.start()
        return True
        # except:
        #    return False

    def disconnect(self):
        self.cancel_write_thread = True
        self.cancel_read_thread = True

        time.sleep(0.600)

        # if self.serial_port.is_open():
        self.serial_port.close()
        # time.sleep(1)

    def flush_input(self):
        self.serial_port.flushInput()

    @property
    def ntsc(self):
        return self.rts_state

    @ntsc.setter
    def ntsc(self, value):
        self.rts_state = value
        self.serial_port.setRTS(value)

    def read_bus_packet(self):
        if self.cancel_read_thread:
            raise RuntimeError('<read_thread> was canceled')
        try:
            data_length = self.read_buffer[1]
        except:
            raise RuntimeError('<read_buffer> list is not big enough')

        if data_length < 3 or data_length > 37:
            # log('IBUS: Length of +37 found (%s), %s' % (data_length, self.read_buffer), 2)
            # log('IBUS: Length of +37 found (%s)' % data_length)
            self._cut_read_buffer()
            self.read_error_counter += 1
            KODI.set_property('msgerr_cnt', '%s' % self.read_error_counter)
            raise ValueError('IBUS: Length of < 3 or > 37 found (%s)' % data_length)
        else:
            buffer_len = len(self.read_buffer)
            if buffer_len < 5 or buffer_len < data_length + 2:
                raise RuntimeError('<read_buffer> list < %s to get input values' % (data_length + 2))
            message = self.read_buffer[:data_length + 2]

            if self._calculate_checksum(message) == 0:
                log('IBUS-READ: %s' % ' '.join(['%02X' % i for i in message]), 5)
                self._cut_read_buffer(data_length + 2)
                return {
                    'src': '%02X' % message[0],
                    'len': '%02X' % data_length,  # message[1]
                    'dst': '%02X' % message[2],
                    'data': ['%02X' % i for i in message[3:data_length + 1]],
                    'xor': '%02X' % message[-1],
                }
            else:
                # log('IBUS: Corrupt packet found (%s), %s' % (data_length, self.read_buffer), 2)
                self._cut_read_buffer()
                raise ValueError('IBUS: Corrupt packet found')

    def write_bus_packet(self, src, dst, data, highprio=False):
        packet = [int(src, 16), len(data) + 2, int(dst, 16)]
        packet.extend([int(s, 16) for s in data])

        packet.append(self._calculate_checksum(packet))

        # log(' '.join([str(i) for i in packet]))

        self.write_buffer.put((0 if highprio else 1, self.write_counter, ''.join(['%c' % i for i in packet])))
        self.write_counter += 1

    def write_hex_message(self, hexstring):
        hexstring_tmp = hexstring.split(' ')
        src = hexstring_tmp[0]
        dst = hexstring_tmp[2]
        data = hexstring_tmp[3:-1]
        self.write_bus_packet(src, dst, data)


class EventClass(object):
    TUNER_MODES = [  # BM24
        ['A5', '62', '01', '01', '20', '46', '4D', '44'],  # FMD
        ['A5', '62', '01', '01', '20', '20', '46', '4D'],  # FM
        ['A5', '62', '01', '01', '20', '20', '4D', '57'],  # MW
        ['A5', '62', '01', '01', '20', '4D', '57', '41'],  # MWA
        ['A5', '62', '01', '01', '20', '20', '4C', '57'],  # LW
        ['A5', '62', '01', '01', '20', '4C', '57', '41'],  # LWA
        ['A5', '62', '01', '01', '20', '20', '53', '57'],  # SW
        ['A5', '62', '01', '01', '20', '53', '57', '41'],  # SWA
        # BM54 I
        ['A5', '62', '01', '41', '20', '20', '46', '4D', '20'],  # FM
        ['A5', '62', '01', '41', '20', '46', '4D', '44', '20'],  # FMD
        ['A5', '62', '01', '41', '20', '4D', '57', '20', '20'],  # MW
        ['A5', '62', '01', '41', '20', '4D', '57', '41', '20'],  # MWA
        ['A5', '62', '01', '41', '20', '4C', '57', '20', '20'],  # LW
        ['A5', '62', '01', '41', '20', '4C', '57', '41', '20'],  # LWA
        ['A5', '62', '01', '41', '20', '53', '57', '20', '20'],  # SW
        ['A5', '62', '01', '41', '20', '53', '57', '41', '20'],  # SWA
        # BM54 II
        ['A5', '62', '01', '41', '46', '4D', '20'],  # FM
        ['A5', '62', '01', '41', '46', '4D', '44'],  # FMD
        ['A5', '62', '01', '41', '4D', '57', '20'],  # MW
        ['A5', '62', '01', '41', '4D', '57', '41'],  # MWA
        ['A5', '62', '01', '41', '4C', '57', '20'],  # LW
        ['A5', '62', '01', '41', '4C', '57', '41'],  # LWA
        ['A5', '62', '01', '41', '53', '57', '20'],  # SW
        ['A5', '62', '01', '41', '53', '57', '41'],  # SWA
    ]

    cancel_ike_thread = False
    cancel_pdc_thread = False
    cancel_read_thread = False

    gm_states = {'runonce': False,
                 'driverdoor': False,
                 'passangerdoor': False,
                 'driverreardoor': False,
                 'passangerreardoor': False,
                 'doorsopen': False,

                 'zvunlocked': False,
                 'zvlocked': False,
                 'zvlockstate': False,
                 'zvhardlocked': False,

                 'indoorlights': False,

                 'driverwindow': False,
                 'passengerwindow': False,
                 'driverrearwindow': False,
                 'passangerrearwindow': False,

                 'sunroof': False,
                 'trunk': False,
                 'bonnet': False,
                 'trunkbuttonpress': False}

    reverse_hold = False
    clock_hold = False
    bm_next_hold = False
    bm_prev_hold = False
    nav_hold = False
    select_hold = False
    stw_up_hold = False
    stw_dn_hold = False
    stw_rt_hold = False
    stw_speak_hold = False
    stw_nav = False

    btn_bcpres = False

    btnx_hold = {1: False, 2: False, 3: False, 4: False, 5: False, 6: False}

    ign_mode = -1
    lcm_on = 0
    lcm_delay = -1
    remote_state = 2
    remote_accept_cmd = True

    navmenu = False
    tonemenu = False
    selectmenu = False
    tpmenu = False
    piaktiv = False
    pass_bm_buttons = False  # BMBTN

    cancel_ike_text = False

    # cdc modes
    cdc_play = True
    cdc_pause = False
    cdc_scan = False
    cdc_seek = False
    cdc_rnd = False
    # cdc player
    cdc_track = '98'
    track_change_counter = 0
    cds_loaded = '40'

    phone_mute = False

    # Addon Settings
    audiomode = False  # True if audio mode found
    modefm = False
    modecd = False
    modetape = False
    modeaux = False
    modecis = False
    modealways = False

    device_path = None
    car_model = None
    cdc_emu = False  # enables cd-changer emulation
    gpio_ntsc = False  # use gpio 7 instead ntsc line of resler interface
    dsp_cd = False
    dsp_tuner = False
    ike_display = False  # enable/disable ike display for text information
    ike_track = False  # allows to show current track title on display
    wel_ike = False  # allows to show welcome message on ike display
    wel_iketxt = None  # text input as welcome message
    wel_iketxt_hold = False  # allows to show message on ignition off

    # Welcome / Leaving
    wel_light = False
    wel_light_time = 10
    lev_light = False
    lev_light_time = 10
    keyin_off = False
    doors_off = False
    lev_light_ign_off = False

    day_time = False
    day_time_start = '00:00'
    day_time_end = '00:00'

    mir_unfold = False
    mir_fold = False

    seek_sec = 3000
    seek_max = 32
    use_stw_nav = False  # allow to control kodi with STW
    navhold_event = False
    inv_navturnbtn = False

    gpio_gear_shift = False
    gpio_gear_shift_trigger_time = 500
    gpio_gear_shift_up = GPIOClass()
    gpio_gear_shift_down = GPIOClass()

    ### OBC ###
    obc_time = [None, None]
    obc_date = [None, None]
    obc_cons1 = '--- L/100KM'
    obc_cons2 = '--- L/100KM'
    obc_range = '--- KM'
    obc_dist = '--- KM'
    obc_arr = '--:--'
    obc_limit = '--- KM/H'
    obc_avg = '--- KM/H'
    obc_stpwtch = '----'

    obc_tmr1 = '--:--'
    obc_tmr1ind = False
    obc_tmr2 = '--:--'
    obc_tmr2ind = False
    obc_limitind = False
    obc_memoind = False
    obc_outtemp = '--.-�C'
    obc_fuel = '-- L'
    obc_speed = '---'
    obc_rpm = '----'
    obc_coolant = '--�C'
    obc_auxheat = False
    obc_auxvent = False

    obc_req_runs = False
    obc_settime = 0
    obc_req_runonce = False
    obc_req_delay = 130

    ### PDC ###

    def __init__(self):
        pass

    def read_ibus_packages(self):
        while not self.cancel_read_thread:
            try:
                packet = IBUS.read_bus_packet()
            except IndexError:
                pass
            except RuntimeError:
                pass
            except ValueError:
                log(ValueError.args)
            else:
                thread = Thread(target=self.manage, args=(packet['src'], packet['dst'], packet['data']))
                thread.setDaemon(True)
                thread.start()
                # log('%s %s %s %s %s' % (packet['src'],
                #                        packet['len'],
                #                        packet['dst'],
                #                        ' '.join(packet['data']),
                #                        packet['xor']))
            time.sleep(0.001)

    def manage(self, src, dst, dat):
        # CDC EMU
        if dst == '18':  # CDC
            if dat == ['01']:
                self.cdch_alive()
                log('MANAGE: RAD ASKED FOR CDC ALIVE')
                return

            if dat == ['38', '00', '00']:
                self.cdch_state()
                log('MANAGE: RAD ASKED FOR CDC STATE')
                return

            if dat == ['38', '03', '00']:
                self.cdch_play()
                log('MANAGE: RAD SAID PLAY')
                return

            if dat == ['38', '02', '00']:
                self.cdch_pause()
                log('MANAGE: RAD SAID PAUSE')
                return

            if dat == ['38', '07', '00']:
                self.cdch_scan(False)
                log('MANAGE: RAD SAID SCAN OFF')
                return

            if dat == ['38', '07', '01']:
                self.cdch_scan(True)
                log('MANAGE: RAD SAID SCAN ON')
                return

            if dat == ['38', '01', '00']:
                self.cdch_stop()
                log('MANAGE: RAD SAID STOP')
                return

            if dat == ['38', '04', '01']:
                self.cdch_ffwd()
                log('MANAGE: RAD SAID FFWD')
                return

            if dat == ['38', '04', '00']:
                self.cdch_frwd()
                log('MANAGE: RAD SAID FRWD')
                return

            if dat == ['38', '0A', '00']:
                self.cdch_next()
                log('MANAGE: RAD SAID NEXT')
                return

            if dat == ['38', '0A', '01']:
                self.cdch_prev()
                log('MANAGE: RAD SAID PREV')
                return

            if dat == ['38', '08', '00']:
                self.cdch_rnd(False)
                log('MANAGE: RAD SAID RANDOM OFF')
                return

            if dat == ['38', '08', '01']:
                self.cdch_rnd(True)
                log('MANAGE: RAD SAID RANDOM ON')
                return

        if dst in ['BF', '68']:
            if dat == ['02', '00', '03']:
                self.cdch_state()
                log("MANAGE: RAD SAID I'M READY")  # 68 05 BF 02 00 03 D3
                return

                # if dst == 'BF':
            # IGNITION KEY POS
            if dat[0] == '11':
                if dat[1] == '00':
                    log('MANAGE: IGN_OFF')
                    self.ign_off()
                    return
                elif dat[1] == '01':
                    log('MANAGE: IGN_RAD')  # ACC
                    self.ign_acc()
                    return
                elif dat[1] == '03':
                    log('MANAGE: IGN_ON')
                    self.ign_on()
                    return
                elif dat[1] == '07':
                    log('MANAGE: IGN_START')
                    self.ign_start()
                    return

            # REMOTE KEY
            if dat[0] == '72':
                log('MANAGE: REMOTE KEY', 2)
                self.remote_key(dat)
                return

            # OBC Extra
            if dat[:1] == ['19']:
                self.obc_set_coolant(dat)

        if src == '00':
            if dat[0] == '7A':
                log('MANAGE: GM STATE', 2)
                self.gm_state(dat)

        if dst == '68':
            # BORDMONITOR
            if dat == ['48', '40']:
                log('MANAGE: BM_NEXT_HOLD')
                self.btn_bm_next_hold()
                return
            if dat == ['48', '80']:
                log('MANAGE: BM_NEXT_REL')
                self.btn_bm_next_rel()
                return
            if dat == ['48', '50']:
                log('MANAGE: BM_PREV_HOLD')
                self.btn_bm_prev_hold()
                return
            if dat == ['48', '90']:
                log('MANAGE: BM_PREV_REL')
                self.btn_bm_prev_rel()
                return
            if dat == ['48', '54']:
                log('MANAGE: BM_REVERSE_HOLD')
                self.btn_bm_reverse_hold()
                return
            if dat == ['48', '94']:
                log('MANAGE: BM_REVERSE_REL')
                self.btn_bm_reverse_rel()
                return
            if dat == ['48', '84']:
                log('MANAGE: BM_TONE_REL')
                self.btn_bm_tone_rel()
                return

            # Buttons 1
            if dat == ['48', '51']:
                log('MANAGE: BM_BTN1_HOLD')
                self.btn_bm_x_hold(7)
                return

            if dat == ['48', '91']:
                log('MANAGE: BM_BTN1_REL')
                self.btn_bm_x_rel(1)
                return

            # Button 2
            if dat == ['48', '41']:
                log('MANAGE: BM_BTN2_HOLD')
                self.btn_bm_x_hold(8)
                return

            if dat == ['48', '81']:
                log('MANAGE: BM_BTN2_REL')
                self.btn_bm_x_rel(2)
                return

            # Button 3
            if dat == ['48', '52']:
                log('MANAGE: BM_BTN3_HOLD')
                self.btn_bm_x_hold(9)
                return

            if dat == ['48', '92']:
                log('MANAGE: BM_BTN3_REL')
                self.btn_bm_x_rel(3)
                return

            # Button 4
            if dat == ['48', '42']:
                log('MANAGE: BM_BTN4_HOLD')
                self.btn_bm_x_hold(10)
                return

            if dat == ['48', '82']:
                log('MANAGE: BM_BTN4_REL')
                self.btn_bm_x_rel(4)
                return

            # Button 5
            if dat == ['48', '53']:
                log('MANAGE: BM_BTN5_HOLD')
                self.btn_bm_x_hold(11)
                return

            if dat == ['48', '93']:
                log('MANAGE: BM_BTN5_REL')
                self.btn_bm_x_rel(5)
                return

            # Button 6
            if dat == ['48', '43']:
                log('MANAGE: BM_BTN6_HOLD')
                self.btn_bm_x_hold(12)
                return

            if dat == ['48', '83']:
                log('MANAGE: BM_BTN6_REL')
                self.btn_bm_x_rel(6)
                return

        if src == '50':
            # STW/MFL BUTTONS
            if dat == ['3B', '11']:
                log('MANAGE: STW_UP_HOLD')
                self.btn_stw_up_hold()
                return
            if dat == ['3B', '21']:
                log('MANAGE: STW_UP_REL')
                self.btn_stw_up_rel()
                return
            if dat == ['3B', '18']:
                log('MANAGE: STW_DN_HOLD')
                self.btn_stw_down_hold()
                return
            if dat == ['3B', '28']:
                log('MANAGE: STW_DN_REL')
                self.btn_stw_down_rel()
                return

            if dat == ['3B', '12']:
                log('MANAGE: STW_R/T_HOLD')
                self.btn_stw_rt_hold()
                return

            if dat == ['3B', '22']:
                log('MANAGE: STW_R/T_REL')
                self.btn_stw_rt_rel()
                return

            if dat == ['3B', '40']:
                log('MANAGE: STW_R/T_ON with Phone')
                self.btn_bc_pres()  # to cancel scrolling texts
                self.btn_stw_rt_on()
                return

            if dat == ['3B', '00']:
                log('MANAGE: STW_R/T_OFF with Phone')
                # btnBCPres()
                self.btn_stw_rt_off()
                return

            if dat == ['3B', 'A0']:
                log('MANAGE: STW_SPEAK_HOLD with Phone')
                self.btn_stw_speak_rel()
                return

        if dst == '80':
            if dat[:11] == ['23', '41', '30', '20', '20', '20', '54', '52', '03', '20', '39']:
                self.clear_ike(100)
                log("MANAGE: Clear IKE Track Message in IKE")  # 68 17 80 23 41 30 20 20 20 54 52 03 20 39 38 20 20 20 20 20 04 20 20 20 AD
                return
            if dat[:16] == ['23', '41', '30', '20', '20', '20', '20', '20', '03', '43', '44', '43', '20', '37', '2D', '39']:
                self.clear_ike(100)
                log("MANAGE: Clear IKE Track Message in IKE")  # 68 17 80 23 41 30 20 20 20 20 20 03 43 44 43 20 37 2D 39 38 04 20 20 20 D5
                return
            if dat[:16] == ['23', '62', '30', '07', '20', '20', '20', '20', '20', '08', '43', '44', '20', '37', '2D', '39']:
                self.clear_ike(100)
                log("MANAGE: Clear IKE Track Message in IKE")  # 68 17 80 23 41 30 20 20 20 20 20 03 43 44 43 20 37 2D 39 38 04 20 20 20 D5
                return

        ### BM54 Radio begin
        if dst == '3B':
            # 68 0B 3B A5 62 01 41 43 44 20 20 20 CK - E39
            # 68 08 3B A5 62 01 41 43 44 DB - Z4

            if dat == ['A5', '62', '01', '41', '43', '44', '37']:
                self.gt_mode_cd()
                log('MANAGE: TEXT: CD7')
                return
            # 68 0B 3B A5 62 01 41 43 44 37 20 20 EF
            elif dat[:7] == ['A5', '62', '01', '41', '43', '44', '37']:
                self.gt_mode_cd()
                log('MANAGE: TEXT: CD7')
                return
            # 68 0B 3B A5 62 01 41 43 44 36 20 20 EE
            elif dat[:7] == ['A5', '62', '01', '41', '43', '44', '36']:
                self.gt_mode_cis()
                log('MANAGE: TEXT: CD6 CIS')
                return
            elif dat == ['A5', '62', '01', '41', '43', '44']:
                self.gt_mode_tape()
                log('MANAGE: TEXT: CD')
                return
            elif dat[:3] == ['23', '62', '10']:
                '''
                if dat[3:7] == ['54', '52', '20', '39']:
                    log('MANAGE: TEXT: TR 9...')
                    gtModeCd()
                    return
                '''
                if dat[3:7] == ['54', '52', '20', '20']:
                    self.gt_mode_cd()
                    self.cdch_play()
                    log('MANAGE: TEXT: TR ...')
                    return

                elif dat[3:6] == ['43', '44', '43']:
                    self.gt_mode_cd()
                    log('MANAGE: TEXT: CDC...')
                    return
                elif dat[3:10] == ['4E', '4F', '20', '44', '49', '53', '43'] or dat[3:10] == ['4E', '6F', '20', '44', '69', '73', '63']:
                    log('MANAGE: TEXT: NO DISC')
                    # self.gt_mode_cd()
                    # self.cdch_state()
                    return
                elif dat[3:7] == ['54', '41', '50', '45']:
                    self.gt_mode_tape()
                    log('MANAGE: TEXT: TAPE...')
                    return
                elif dat[3:10] == ['4E', '4F', '20', '54', '41', '50', '45']:
                    self.gt_mode_tape()
                    log('MANAGE: TEXT: NO TAPE')
                    return
                elif dat[3:6] == ['43', '44', '20']:
                    self.gt_mode_tape()
                    log('MANAGE: TEXT: CD / E46 CD Screen')
                    return
                elif dat[3:6] == ['41', '55', '58']:
                    self.gt_mode_aux()
                    log('MANAGE: TEXT: AUX ')
                    return
                '''
                else:
                    log('MANAGE: TEXT: what ever')
                    gtModeRadio()
                    self.cdch_state()
                    return
                '''
            ### BM54 Radio end

            ### BM24 Radio begin
            if dat[:9] == ['23', 'C4', '20', '43', '44', '20', '37', '2D', '39']:
                self.gt_mode_cd()
                log('MANAGE: TEXT: CD 7-9...')
                return
            elif dat[:7] == ['23', '50', '20', '54', '41', '50', '45']:
                self.gt_mode_tape()
                log('MANAGE: TEXT: TAPE')
                return
            elif dat[:10] == ['23', '50', '20', '4E', '4F', '20', '54', '41', '50', '45']:
                self.gt_mode_tape()
                log('MANAGE: TEXT: NO TAPE')
                return
            elif dat[:3] == ['23', '40', '20'] or dat[:3] == ['23', '50', '20']:
                self.gt_mode_radio()
                self.cdch_state()
                log('MANAGE: TEXT: what ever')
                return
            ### BM24 Radio end

            # 68 17 3B 23 62 30 20 20 07 20 20 20 20 20 08 43 44 20 37 2D 39 38 20 20 26
            ### BM24 Radio OLD begin
            if dat[:18] == ['23', '62', '30', '20', '20', '07', '20', '20', '20', '20', '20', '08', '43', '44', '20', '37', '2D', '39']:
                self.gt_mode_cd()
                log('MANAGE: TEXT: CD 7-9...')
                return
            elif dat[:16] == ['23', '62', '30', '20', '20', '07', '20', '20', '20', '20', '20', '08', '54', '41', '50', '45']:
                self.gt_mode_tape()
                log('MANAGE: TEXT: TAPE')
                return
            elif dat[:19] == ['23', '62', '30', '20', '20', '07', '20', '20', '20', '20', '20', '08', '4E', '4F', '20', '54', '41', '50', '45']:
                self.gt_mode_tape()
                log('MANAGE: TEXT: NO TAPE')
                return
            ### BM24 Radio OLD end

            ### ALL RADIOS
            elif dat in self.TUNER_MODES:
                self.gt_mode_radio()
                self.cdch_state()
                log('MANAGE: TEXT: FMD')
                return

            if dat == ['46', '01']:
                self.gt_nav_menu_on()
                log('MANAGE: NAV MENU ON')
                return
            if dat == ['46', '02']:
                self.gt_radio_menu_off()
                log('MANAGE: RADIO MENU OFF')
                return
            if dat == ['46', '04']:
                log('MANAGE: SELECT MENU OFF')
                # gtSelectMenuOff()
                return
            if dat == ['46', '08']:
                self.gt_tone_menu_off()
                log('MANAGE: TONE MENU OFF')
                return
            if dat == ['46', '0C']:
                self.gt_select_tone_menu_off()
                # gtToneMenuOff()
                log('MANAGE: TONE + SELECT MENU OFF')
                return

            if dat[:8] == ['21', '60', '00', '40', '54', '50', '20', '20']:
                log('MANAGE: TP MENU ON')  # "TP  " top left P1
                # gtTPMenu()
                # btnInfoPres()
                return

            if dat[:4] == ['A5', '62', '01', '41']:
                # gtNewFld1()
                return

            if dat == ['21', '60', '00', '07', '50', '36', '3A', '20', '4E', '4F', '20', '44', '49', '53', '43', '20', '20', '20', '06', '06', '06']:
                self.gt_select_tone_menu_off()
                # gtClearCdlist()
                log('MANAGE: Bottom Right " P6: NO DISC   "')  # bottom right P6
                return

            # Buttons
            if ' '.join(dat)[:4] == '49 8':
                steps = ' '.join(dat)[-1]
                log('MANAGE: BM_NAV_KNOB_RIGHT -steps: %s' % int(steps, 16))
                self.btn_bm_nav_right(steps)
                return
            if ' '.join(dat)[:4] == '49 0':
                steps = ' '.join(dat)[-1]
                log('MANAGE: BM_NAV_KNOB_LEFT -steps: %s' % int(steps, 16))
                self.btn_bm_nav_left(steps)
                return
            if dat == ['48', '85']:
                log('MANAGE: BM_NAV_KNOB_REL')
                self.btn_bm_nav_rel()
                return
            if dat == ['48', '45']:
                log('MANAGE: BM_NAV_KNOB_HOLD')
                self.btn_bm_nav_hold()
                return

        if dst == 'C8':  # PHONE
            if dat == ['3B', '90']:
                log('MANAGE: STW_SPEAK_HOLD')
                self.btn_stw_speak_hold()
                return

            if dat == ['3B', 'A0']:
                log('MANAGE: STW_SPEAK_REL')
                self.btn_stw_speak_rel()
                return

        if dst == 'F0':
            if dat == ['4A', 'FF']:
                self.radio_led_on()
                log('MANAGE: RADIO LED TURNED ON')
                return
            if dat == ['4A', '00']:
                self.radio_led_off()
                log('MANAGE: RADIO LED TURNED OFF')
                return

        # OBC Reply
        if dst in ['E7', 'FF']:
            if dat[:2] == ['24', '01']:
                log('OBC: TIME', 2)
                self.obc_set_time(dat)
                return
            if dat[:2] == ['24', '02']:
                log('OBC: DATE', 2)
                self.obc_set_date(dat)
                return

            if dat[:2] == ['24', '03']:
                log('OBC: OUTTEMP', 2)
                self.obc_set_outtemp(dat)
                return

            if dat[:2] == ['24', '04']:
                log('OBC: CONS1', 2)
                self.obc_set_cons1(dat)
                return

            if dat[:2] == ['24', '05']:
                log('OBC: CONS2', 2)
                self.obc_set_cons2(dat)
                return

            if dat[:2] == ['24', '06']:
                log('OBC: RANGE', 2)
                self.obc_set_range(dat)
                return

            if dat[:2] == ['24', '07']:
                log('OBC: DIST', 2)
                self.obc_set_dist(dat)
                return

            if dat[:2] == ['24', '08']:
                log('OBC: ARR', 2)
                self.obc_set_arr(dat)
                return

            if dat[:2] == ['24', '09']:
                log('OBC: LIMIT', 2)
                self.obc_set_limit(dat)
                return

            if dat[:2] == ['24', '0A']:
                log('OBC: AVG', 2)
                self.obc_set_avg(dat)
                return

            if dat[:2] == ['24', '0E']:
                log('OBC: STPWTCH', 2)
                self.obc_set_stpwtch(dat)
                return

            if dat[:2] == ['24', '0F']:
                log('OBC: TMR1', 2)
                self.obc_set_tmr1(dat)
                return

            if dat[:2] == ['24', '10']:
                log('OBC: TMR2', 2)
                self.obc_set_tmr2(dat)
                return

            # Phone
            if src == 'C8' and dat[:1] == ['2B']:
                log('PHONE: STATE')
                self.phone_state(dat)
                return

                # if dst == 'FF':
            if dat == ['47', '00', '4F']:
                log('MANAGE: BM_SEL_HOLD')
                self.btn_bm_select_hold()
                return
            if dat == ['47', '00', '8F']:
                log('MANAGE: BM_SEL_REL')
                self.btn_bm_select_rel()
                return
            if dat == ['47', '00', '38']:
                log('MANAGE: BM_INFO_PRES')
                self.btn_bm_info_pres()
                return
            if dat == ['47', '00', 'B8']:
                log('MANAGE: BM_INFO_REL')
                # btnInfoRel()
                return
            if dat == ['48', '47']:
                log('MANAGE: BM_CLK_HOLD')
                self.btn_bm_clock_hold()
                return
            if dat == ['48', '87']:
                log('MANAGE: BM_CLK_REL')
                self.btn_bm_clock_rel()
                return
            if dat == ['48', 'B0']:
                log('MANAGE: BM_SCREEN_REL')
                self.btn_bm_screen_rel()
                return
            if dat == ['57', '02']:
                log('MANAGE: IKE_BC_PRES')  # 80 04 FF 57 02 2E    : IKE BC Pressed
                self.btn_bc_pres()
                return

        if src == '44':
            if dat[0] == '74':
                log('MANAGE: EWS_KEY')  # 44 05 BF 74 04 00 8E
                self.ews_key(dat)
                return

        # // DSP MODES //
        # RAD  --> DSP        : Audio_control
        # Source = Off        : 68 04 6A 36 AF 9F :
        # Source = Tuner/Tape : 68 04 6A 36 A1 91
        # Source = CD         : 68 04 6A 36 A0 90
        if dst == '6A':
            if dat == ['36', 'A0']:
                if self.dsp_tuner:
                    self.dsp_set_tuner()

        # log('IBUS-READ: ' + src + ' ' + len + ' ' + dst + ' ' + ' '.join(dat) + ' ' + xor, 5)
        pass

    ### CD Changer
    def cdch_init(self):
        if not self.cdc_emu:
            return
        IBUS.write_bus_packet('18', 'FF', ['02', '01'], True)  # CDC_INIT: 18 04 FF 02 01 E0
        xbmc.sleep(50)
        IBUS.write_bus_packet('18', 'FF', ['02', '00'], True)  # CDC_ALIVE: 18 04 FF 02 00 E1
        xbmc.sleep(100)
        IBUS.write_bus_packet('18', '68', ['39', '02', '09', '00', self.cds_loaded, '00', '07', '99'], True)  # CD_RAD_PLAY: 18 0A 68 39 02 09 00 40 00 07 99 F7
        pass

    def cdch_alive(self):
        if not self.cdc_emu:
            return
        IBUS.write_bus_packet('18', 'FF', ['02', '00'], True)  # CDC_ALIVE: 18 04 FF 02 00 E1
        pass

    def cdch_state(self):
        if not self.cdc_emu:
            return

        if self.track_change_counter < 20:
            self.cdc_track = '98'
        if self.track_change_counter >= 20:
            self.cdc_track = '97'
        if self.track_change_counter > 40: self.track_change_counter = 0
        self.track_change_counter += 1

        if self.cdc_scan:
            IBUS.write_bus_packet('18', '68', ['39', '07', '99', '00', self.cds_loaded, '00', '07', self.cdc_track], True)
            return
        if self.cdc_seek:
            IBUS.write_bus_packet('18', '68', ['39', '02', '89', '00', self.cds_loaded, '00', '07', self.cdc_track], True)
            return
        if self.cdc_rnd:
            IBUS.write_bus_packet('18', '68', ['39', '02', 'A9', '00', self.cds_loaded, '00', '07', self.cdc_track], True)
            return
        if self.cdc_play:
            IBUS.write_bus_packet('18', '68', ['39', '02', '00', '00', self.cds_loaded, '00', '07', self.cdc_track], True)
            # IBUS.write_bus_packet('18', '68', ['39', '02', '02', '00', '40', '00', '07', self.cdc_track], True)
        elif self.cdc_pause:
            IBUS.write_bus_packet('18', '68', ['39', '01', '00', '00', self.cds_loaded, '00', '07', self.cdc_track], True)  # CD_RAD_PAUSE: 18 0A 68 39 01 09 00 40 00 07 99 95
        else:
            IBUS.write_bus_packet('18', '68', ['39', '00', '8C', '00', self.cds_loaded, '00', '07', self.cdc_track], True)  # CD_RAD_STOP: 18 0A 68 39 00 02 00 40 00 07 99 FE

        pass

    def cdch_play(self):
        if not self.cdc_emu:
            return
        if self.cdc_seek:
            IBUS.write_bus_packet('18', '68', ['39', '02', '89', '00', self.cds_loaded, '00', '07', self.cdc_track], True)
            self.cdc_seek = False
        if self.cdc_rnd:
            IBUS.write_bus_packet('18', '68', ['39', '02', 'A9', '00', self.cds_loaded, '00', '07', self.cdc_track], True)
            self.cdc_rnd = False
        if self.cdc_scan:
            IBUS.write_bus_packet('18', '68', ['39', '02', '99', '00', self.cds_loaded, '00', '07', self.cdc_track], True)
        else:
            IBUS.write_bus_packet('18', '68', ['39', '02', '02', '00', self.cds_loaded, '00', '07', self.cdc_track], True)  # CD_RAD_PLAY: 18 0A 68 39 02 09 00 40 00 07 99 F7
        self.cdc_play = True
        self.cdc_pause = False
        pass

    def cdch_pause(self):
        if not self.cdc_emu:
            return

        IBUS.write_bus_packet('18', '68', ['39', '01', '00', '00', self.cds_loaded, '00', '07', self.cdc_track], True)  # CD_RAD_PAUSE: 18 0A 68 39 01 09 00 40 00 07 99 95
        self.cdc_play = False
        pass

    def cdch_stop(self):
        if not self.cdc_emu:
            return

        IBUS.write_bus_packet('18', '68', ['39', '00', '8C', '00', self.cds_loaded, '00', '07', self.cdc_track], True)  # CD_RAD_STOP: 18 0A 68 39 00 02 00 40 00 07 99 FE
        self.cdc_play = False
        self.cdc_scan = False
        self.cdc_seek = False
        self.cdc_rnd = False
        self.cdc_pause = True
        pass

    def cdch_scan(self, enabled):
        if not self.cdc_emu:
            return
        xbmc.sleep(250)
        if enabled:
            self.cdc_scan = True
            IBUS.write_bus_packet('18', '68', ['39', '07', '99', '00', self.cds_loaded, '00', '07', self.cdc_track], True)
        else:
            IBUS.write_bus_packet('18', '68', ['39', '02', '89', '00', self.cds_loaded, '00', '07', self.cdc_track], True)  # CD_RAD_M7F1: 18 0A 68 39 07 98 00 40 00 07 99 CK
            self.cdc_scan = False
        pass

    def cdch_rnd(self, enabled):
        if not self.cdc_emu:
            return
        xbmc.sleep(250)
        if enabled:
            self.cdc_rnd = True
            IBUS.write_bus_packet('18', '68', ['39', '02', 'A9', '00', self.cds_loaded, '00', '07', self.cdc_track], True)
        else:
            IBUS.write_bus_packet('18', '68', ['39', '02', '89', '00', self.cds_loaded, '00', '07', self.cdc_track], True)  # CD_RAD_M7F1: 18 0A 68 39 07 98 00 40 00 07 99 CK
            self.cdc_rnd = False
        pass

    def cdch_ffwd(self):
        if not self.cdc_emu:
            return
        xbmc.sleep(250)
        self.cdc_seek = True
        IBUS.write_bus_packet('18', '68', ['39', '03', '89', '00', self.cds_loaded, '00', '07', self.cdc_track], True)  # CD_RAD_PLAY: 18 0A 68 39 02 09 00 40 00 07 99 F7
        pass

    def cdch_frwd(self):
        if not self.cdc_emu:
            return
        xbmc.sleep(250)
        self.cdc_seek = True
        IBUS.write_bus_packet('18', '68', ['39', '04', '89', '00', self.cds_loaded, '00', '07', self.cdc_track], True)  # CD_RAD_PLAY: 18 0A 68 39 02 09 00 40 00 07 99 F7
        pass

    def cdch_next(self):
        if not self.cdc_emu:
            return
        time.sleep(0.350)
        IBUS.write_bus_packet('18', '68', ['39', '02', '09', '00', self.cds_loaded, '00', '07', '99'], True)  # CD_RAD_PLAY: 18 0A 68 39 02 09 00 40 00 07 99 F7

    def cdch_prev(self):
        if not self.cdc_emu:
            return
        time.sleep(0.350)
        IBUS.write_bus_packet('18', '68', ['39', '02', '09', '00', self.cds_loaded, '00', '07', '95'], True)  # CD_RAD_PLAY: 18 0A 68 39 02 09 00 40 00 07 99 F7

    #### BM Nav Button ####
    ## Turn Right
    def btn_bm_nav_right(self, steps='1'):
        if self.pass_bm_buttons:
            KODI.down(steps) if self.inv_navturnbtn else KODI.up(steps)
        pass

    ## Turn Left
    def btn_bm_nav_left(self, steps='1'):
        if self.pass_bm_buttons:
            KODI.up(steps) if self.inv_navturnbtn else KODI.down(steps)
        pass

    ## Hold
    def btn_bm_nav_hold(self):
        if self.pass_bm_buttons:
            self.nav_hold = True
            if self.navhold_event != ' ':
                xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.%s", "id": 1 }' % self.navhold_event)
        pass

    ## Release
    def btn_bm_nav_rel(self):
        if self.pass_bm_buttons:
            if self.nav_hold:
                if self.navhold_event == ' ':
                    KODI.select()
            else:
                KODI.select()
            self.nav_hold = False
        pass

    #### BM Next Button ####
    ## Hold
    def btn_bm_next_hold(self):
        if not self.pass_bm_buttons: return
        log('state next hold: %s' % self.bm_next_hold)
        if self.bm_next_hold: return
        self.bm_next_hold = True
        speed = 4
        ticker = self.seek_sec
        while self.bm_next_hold:
            if ticker >= self.seek_sec:
                KODI.track_seek(speed)
                speed *= 2
                if speed > self.seek_max: speed = self.seek_max
                ticker = 0
            # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Player.SetSpeed","params":{"playerid":1,"speed":%s },"id":1}' % SPEED)
            xbmc.sleep(1)
            ticker += 1
        pass

    ## Release
    def btn_bm_next_rel(self):
        self.bm_prev_hold = False
        if not self.pass_bm_buttons: return
        if self.bm_next_hold:
            self.bm_next_hold = False
            KODI.track_play()
            # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Player.SetSpeed","params":{"playerid":%s,"speed":1 },"id":1}' % playerID())
            # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Player.SetSpeed","params":{"playerid":1,"speed":1 },"id":1}')
        else:
            DBL_NEXT.click()
            # xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Right", "id": 1 }')
        pass

    #### BM Prev Button ####
    ## Hold
    def btn_bm_prev_hold(self):
        if not self.pass_bm_buttons: return
        if self.bm_prev_hold: return
        self.bm_prev_hold = True
        speed = -4
        ticker = self.seek_sec
        while self.bm_prev_hold:
            if ticker >= self.seek_sec:
                KODI.track_seek(speed)
                speed *= 2
                if speed > self.seek_max: speed = self.seek_max
                ticker = 0
            xbmc.sleep(1)
            ticker += 1
        pass

    ## Release
    def btn_bm_prev_rel(self):
        self.bm_next_hold = False
        if not self.pass_bm_buttons: return
        if self.bm_prev_hold:
            self.bm_prev_hold = False
            KODI.track_play()
            # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Player.SetSpeed","params":{"playerid":%s,"speed":1 },"id":1}' % playerID())
        else:
            DBL_PREV.click()
            # xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Left", "id": 1 }')
        pass

    #### BM Reverse Button ####
    ## Hold
    def btn_bm_reverse_hold(self):
        if self.pass_bm_buttons:
            self.reverse_hold = True
            KODI.home()

    ## Release
    def btn_bm_reverse_rel(self):
        if self.pass_bm_buttons:
            if self.reverse_hold:
                pass
            else:
                KODI.back()
            self.reverse_hold = False

    #### BM Number Buttons ####
    def btn_bm_x_hold(self, button_number):
        if not self.pass_bm_buttons: return
        if not self.cdc_emu and not self.modecis: return
        self.btnx_hold[button_number - 6] = True
        KODI.action(KODI.get_addon_setting('bm_btn_%s' % button_number))

    def btn_bm_x_rel(self, button_number):
        if not self.pass_bm_buttons: return
        if not self.cdc_emu: return
        if self.btnx_hold[button_number]:
            pass
        else:
            KODI.action(KODI.get_addon_setting('bm_btn_%s' % button_number))
        self.btnx_hold[button_number] = False

    #### BM Tone Button ####
    ## Release
    def btn_bm_tone_rel(self):
        self.gt_tone_menu()

    #### BM Select Button ####
    ## Hold
    def btn_bm_select_hold(self):
        if self.pass_bm_buttons:
            self.select_hold = True

    ## Release
    def btn_bm_select_rel(self):
        if self.pass_bm_buttons:
            if self.select_hold:
                pass
            else:
                xbmc.executebuiltin('Action(ContextMenu)')
            self.select_hold = False
        else:
            self.gt_select_menu()

    def btn_bm_info_pres(self):
        self.tpmenu = True
        self.gt_hide_pi()

    def btn_bm_info_rel(self):
        pass

    #### BM Clock Button ####
    ## Hold
    def btn_bm_clock_hold(self):
        self.clock_hold = True
        self.set_ntsc(False)
        ticker = 0
        while self.clock_hold:
            if ticker >= 3000:
                self.bm_led('green')
                xbmc.sleep(500)
                self.bm_led('red')
                xbmc.sleep(500)
                self.bm_led('yellow')
                f = os.popen("reboot")  # sudo shutdown -r now
                xbmc.sleep(1000)
                self.bm_led('off')
                self.clock_hold = False
            xbmc.sleep(1)
            ticker += 1

    ## Release
    def btn_bm_clock_rel(self):
        if self.clock_hold:
            pass
        else:
            self.set_ntsc(True)
        self.clock_hold = False

    #### BM Screen Button ####
    ## Release
    def btn_bm_screen_rel(self):
        if self.piaktiv:
            self.gt_show_pi()

    #### STW Next Button ###### Hold
    def btn_stw_up_hold(self):
        if self.gpio_gear_shift:
            return
        if self.stw_up_hold:
            return
        self.stw_up_hold = True
        if self.stw_nav:
            # old_label = xbmc.getInfoLabel("ListItem.Label")
            KODI.select()
            # send_to_ike(KODI.get_current_listlabel(old_label)[:20],False,True)
        else:
            speed = 4
            ticker = self.seek_sec
            while (self.stw_up_hold):
                if ticker >= self.seek_sec:
                    KODI.track_seek(speed)
                    speed = speed * 2
                    if speed > self.seek_max: speed = self.seek_max
                    ticker = 0
                xbmc.sleep(1)
                ticker += 1

    #### STW Next Button ###### Release
    def btn_stw_up_rel(self):
        if self.gpio_gear_shift:
            GPIO_GEAR_SHIFT_UP.trigger(self.gpio_gear_shift_trigger_time)
        if self.stw_nav:
            if self.stw_up_hold:
                self.stw_up_hold = False
            else:
                # old_label = xbmc.getInfoLabel("ListItem.Label")
                KODI.up()
                # send_to_ike(KODI.get_current_listlabel(old_label)[:20],False,True)
        else:
            self.stw_dn_hold = False
            if self.stw_up_hold:
                self.stw_up_hold = False
                KODI.track_play()
            else:
                KODI.track_next()
                # xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.GoTo", "params": { "playerid": %s, "to": "next" }, "id": 1}' % playerID())

    #### STW Prev Button ###### Hold
    def btn_stw_down_hold(self):
        if self.gpio_gear_shift:
            return
        if self.stw_dn_hold:
            return
        self.stw_dn_hold = True
        if self.stw_nav:
            # old_label = xbmc.getInfoLabel("ListItem.Label")
            KODI.back()
            # send_to_ike(KODI.get_current_listlabel(old_label)[:20],False,True)
        else:
            speed = -4
            ticker = self.seek_sec
            while (self.stw_dn_hold):
                if ticker >= self.seek_sec:
                    KODI.track_seek(speed)
                    speed = speed * 2
                    if speed > self.seek_max: speed = self.seek_max
                    ticker = 0
                xbmc.sleep(1)
                ticker += 1

    #### STW Prev Button ###### Release
    def btn_stw_down_rel(self):
        if self.gpio_gear_shift:
            GPIO_GEAR_SHIFT_DOWN.trigger(self.gpio_gear_shift_trigger_time)
        if self.stw_nav:
            if self.stw_dn_hold:
                self.stw_dn_hold = False
            else:
                # old_label = xbmc.getInfoLabel("ListItem.Label")
                KODI.down()
                # send_to_ike(KODI.get_current_listlabel(old_label)[:20],False,True)
        else:
            self.stw_up_hold = False
            if self.stw_dn_hold:
                self.stw_dn_hold = False
                KODI.track_play()
            else:
                try:
                    if xbmc.Player().getTime() <= 3:
                        KODI.track_prev()
                        # xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.GoTo", "params": { "playerid": %s, "to": "previous" }, "id": 1}' % playerID())
                    else:
                        KODI.track_pos(0)
                except:
                    pass

    def btn_stw_rt_hold(self):
        if self.stw_rt_hold: return
        self.stw_rt_hold = True

    def btn_stw_rt_rel(self):
        self.btn_stw_rt_on()
        return

        if self.stw_rt_hold:
            pass
        else:
            if self.use_stw_nav: self.stw_nav = False if self.stw_nav else True
        self.stw_rt_hold = False

    def btn_stw_rt_on(self):
        if self.stw_rt_hold:
            pass
        else:
            if self.use_stw_nav:
                if self.stw_nav:
                    self.stw_nav = False
                    MFL.close()
                    self.clear_ike(0, True)
                    log('Disable MFL Control for Kodi')
                else:
                    if self.pass_bm_buttons:
                        self.stw_nav = True
                        MFL.show()
                        self.send_to_ike('KODI CONTROL', True, True)
                        log('Enable MFL Control for Kodi')
        self.stw_rt_hold = False

    def btn_stw_rt_off(self):
        if self.stw_rt_hold:
            pass
        else:
            self.stw_nav = False
            MFL.close()
            self.clear_ike(0, True)

            log('Disable MFL Control for Kodi')
        self.stw_rt_hold = False

    def btn_stw_speak_hold(self):
        if self.stw_speak_hold: return
        self.stw_speak_hold = True
        if self.stw_nav: KODI.back()

    def btn_stw_speak_rel(self):
        if self.stw_speak_hold:
            pass
        else:
            if self.stw_nav: DBL_STW_SPEAK.click()
        self.stw_speak_hold = False

    def btn_bc_pres(self):
        self.cancel_ike_text = True
        xbmc.sleep(120)
        self.cancel_ike_text = False

    #### BM LEDS ####
    ## Radio
    def radio_led_on(self):
        self.ask_radio_mode()
        self.cdch_stop()

    def radio_led_off(self):
        self.pi_off()

    #### IGNITION ####
    ##
    def ask_ign_state(self):
        IBUS.write_bus_packet('5B', '80', ['10'])  # IGN REQ   : 5B 03 80 10 CK

    def ign_off(self):
        self.audiomode = False
        self.stw_nav = False
        self.pi_off()
        if self.ign_mode > 0:
            self.ign_mode = 0
            if self.lev_light_ign_off:
                thread = Thread(target=self.lcm_lights_on, args=self.lev_light_time)
                thread.setDaemon(True)
                thread.start()
            KODI.copy_log_file()
        self.obc_req_runonce = False
        self.ign_mode = 0
        log('IGN == 0')

    def ign_acc(self):
        if not self.audiomode: self.ask_radio_mode()
        if self.cdc_emu:
            # cdcInit()
            self.cdch_play()
        self.lcm_lights_off()
        while self.lcm_on:
            time.sleep(0.5)
        if self.ign_mode < 1: self.obc_req(True)
        self.ign_mode = 1
        log('IGN == 1')

    def ign_on(self):
        if self.ign_mode < 2: self.obc_req(True)
        self.ign_mode = 2
        log('IGN == 2')

    def ign_start(self):
        self.ign_mode = 3
        log('IGN == 3')

    ##### AUDIO MODE HANDLING ####
    #
    def ask_radio_mode(self):
        if self.ign_mode < 1: return
        IBUS.write_bus_packet('3B', '68', ['45', '00'])  # 3B LL 68 45 00 CK

    def gt_mode_radio(self):
        self.audiomode = True
        self.pi_off()

    def gt_mode_cd(self):
        self.audiomode = True
        self.navmenu = False
        if not self.cdc_play: self.cdch_play()
        # cdcPlay()

        if self.modecd:
            if self.piaktiv:
                self.gt_show_pi()
            else:
                self.pi_on()
        else:
            self.pi_off()

    def gt_mode_tape(self):
        self.audiomode = True
        self.navmenu = False
        if self.modetape:
            if self.piaktiv:
                self.gt_show_pi()
            else:
                self.pi_on()
        else:
            self.pi_off()

    def gt_mode_aux(self):
        self.audiomode = True
        self.navmenu = False
        if self.modeaux:
            if self.piaktiv:
                self.gt_show_pi()
            else:
                self.pi_on()
        else:
            self.pi_off()

    def gt_mode_cis(self):
        self.audiomode = True
        self.navmenu = False

        if self.modecis:
            if self.piaktiv:
                self.gt_show_pi()
            else:
                self.pi_on()
        else:
            self.pi_off()

    # only for cd screen
    def gt_clear_cd_list(self):
        if self.modecd:
            xbmc.sleep(200)
            IBUS.write_bus_packet('68', '3B', ['46', '0C'])  # LCD Clear: 68 04 3B 46 0C 1D
            # gtShowPi()

    def gt_nav_menu_on(self):
        self.navmenu = True
        self.tonemenu = False
        self.tpmenu = False
        self.gt_hide_pi()

    def gt_radio_menu_off(self):
        self.tpmenu = False
        self.tonemenu = False
        self.navmenu = True
        self.gt_hide_pi()

    def gt_tp_menu(self):
        self.tpmenu = True
        self.tonemenu = False
        self.gt_hide_pi()

    def gt_tone_menu(self):
        self.tonemenu = True
        self.tpmenu = False
        self.navmenu = False
        self.gt_hide_pi()

    def gt_select_menu(self):
        self.tonemenu = False
        self.tpmenu = False
        self.navmenu = False
        self.gt_show_pi()

    def gt_tone_menu_off(self):
        self.tonemenu = False
        self.gt_show_pi()

    def gt_select_tone_menu_off(self):
        self.tpmenu = False
        self.gt_show_pi()

    def gt_new_field1(self):
        self.gt_show_pi()

    def phone_state(self, dat):
        dat = ''.join(dat)[2:4]
        if get_bit_from_hex(dat, BIT[4]) == 1:
            if self.piaktiv: KODI.track_pause()
            self.phone_mute = True
        elif get_bit_from_hex(dat, BIT[4]) == 0:
            self.phone_mute = False
            if self.piaktiv: KODI.track_play()

    ### Remote Key
    def remote_key(self, dat):
        dat = ''.join(dat)[2:3]
        if dat == '1':
            self._remote_key_lock()
            self.remote_state = 1
        elif dat == '2':
            self._remote_key_unlock()
            self.remote_state = 2
        elif dat == '4':
            self._remote_key_boot()
        elif dat == '0':
            self._remote_key_release()

    def _remote_key_lock(self):
        log('REMOTE LOCK')
        if not self.remote_accept_cmd: return
        self.remote_accept_cmd = False
        if self.lev_light:
            if self.lcm_on:
                if self.remote_state == 1:
                    self.lcm_lights_off()
                else:
                    self.lcm_delay = self.lev_light_time

            else:
                thread = Thread(target=self.lcm_lights_on, args=self.lev_light_time)
                thread.setDaemon(True)
                thread.start()
        else:
            if self.lcm_on: self.lcm_lights_off()
        time.sleep(0.100)
        if self.mir_fold and self.remote_state == 2:
            log('FOLD MIRROS')
            self.mirror_fold()

    def _remote_key_unlock(self):
        log('REMOTE UNLOCK')
        if not self.remote_accept_cmd:
            return
        self.remote_accept_cmd = False
        if self.wel_light:
            if self.lcm_on:
                if self.remote_state == 2:
                    self.lcm_lights_off()
                else:
                    self.lcm_delay = self.wel_light_time
            else:
                thread = Thread(target=self.lcm_lights_on, args=self.wel_light_time)
                thread.setDaemon(True)
                thread.start()
        else:
            if self.lcm_on: self.lcm_lights_off()
        time.sleep(0.100)
        if self.remote_state == 1:
            if self.wel_ike:
                self.send_to_ike(self.wel_iketxt, True, self.wel_iketxt_hold)
            if self.mir_unfold:
                log('UNFOLD MIRROS')
                self.mirror_unfold()

    def _remote_key_boot(self):
        log('REMOTE TRUNK')
        if not self.remote_accept_cmd: return
        self.remote_accept_cmd = False

    def _remote_key_release(self):
        self.remote_accept_cmd = True
        log('REMOTE REL')

    def ews_key(self, dat):
        if dat[1] == '00':
            log('MANAGE: EWS_KEY_OUT')
        elif dat[1] != '00' and dat[2] == 'FF':
            log('MANAGE: EWS_KEY_OUT')
        elif dat[1] != '00' and dat[2] != 'FF':
            log('MANAGE: EWS_KEY_IN: %s' % dat[2])
            if self.keyin_off:
                self.lcm_lights_off()
                while self.lcm_on:
                    time.sleep(0.5)

    def ask_gm_state(self):
        IBUS.write_bus_packet('BF', '00', ['79'])

    def gm_state(self, dat):
        '''
        REQ: BF LL 00 79 CK
        RPL: 00 05 BF 7A AA BB CK
        AA
        0000 0001 - Driver Door open
        0000 0010 - Passenger Door open
        0000 0100 - DriverRear Door open
        0000 1000 - PassengerRear Door open

        0001 0000 - ZV Unlocked
        0010 0000 - ZV Locked
        0100 0000 - Indoor Lights on
        1000 0000 - ???

        0011 0000 - ZV hardlocked

        BB
        0000 0001 - Driver Window open
        0000 0010 - Passenger Window open
        0000 0100 - DriverRear Window open
        0000 1000 - PassengerRear Window open

        0001 0000 - ZV Unlocked
        0010 0000 - Trunk open
        0100 0000 - Bonnet open
        1000 0000 - Button to open Trunk pressed
        '''
        aa = dat[1]
        bb = dat[2]
        driverdoor = get_bit_from_hex(aa, BIT[0])
        passangerdoor = get_bit_from_hex(aa, BIT[1])
        driverreardoor = get_bit_from_hex(aa, BIT[2])
        passangerreardoor = get_bit_from_hex(aa, BIT[3])
        if driverdoor or passangerdoor or driverreardoor or passangerreardoor:
            doorsopen = True
        else:
            doorsopen = False

        zvunlocked = get_bit_from_hex(aa, BIT[4])
        zvlocked = get_bit_from_hex(aa, BIT[5])
        zvhardlocked = True if zvunlocked and zvlocked else False
        zvlockstate = zvlocked

        indoorlights = get_bit_from_hex(aa, BIT[6])

        driverwindow = get_bit_from_hex(bb, BIT[0])
        passengerwindow = get_bit_from_hex(bb, BIT[1])
        driverrearwindow = get_bit_from_hex(bb, BIT[2])
        passangerrearwindow = get_bit_from_hex(bb, BIT[3])
        sunroof = get_bit_from_hex(bb, BIT[4])
        trunk = get_bit_from_hex(bb, BIT[5])
        bonnet = get_bit_from_hex(bb, BIT[6])
        trunkbuttonpress = get_bit_from_hex(bb, BIT[7])

        notemsg = [None, None]
        notetime = 50

        if self.gm_states['runonce']:
            if self.gm_states['driverdoor'] != driverdoor:
                notemsg[0] = 'Driver Door'
                notemsg[1] = 'opened' if driverdoor else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['passangerdoor'] != passangerdoor:
                notemsg[0] = 'Passanger Door'
                notemsg[1] = 'opened' if passangerdoor else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['driverreardoor'] != driverreardoor:
                notemsg[0] = 'Driver Rear Door'
                notemsg[1] = 'opened' if driverreardoor else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['passangerreardoor'] != passangerreardoor:
                notemsg[0] = 'Passanger Rear Door'
                notemsg[1] = 'opened' if passangerreardoor else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['doorsopen'] != doorsopen:
                if doorsopen and self.doors_off: self.lcm_lights_off()

            if self.gm_states['zvlockstate'] != zvlockstate:
                notemsg[0] = 'Central Locksystem'
                notemsg[1] = 'locked' if zvlockstate else 'unlocked'
                if zvhardlocked:
                    notemsg[1] = 'hard locked'
                else:
                    notemsg[1] = 'locked' if zvlockstate else 'unlocked'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['indoorlights'] != indoorlights:
                notemsg[0] = 'Indoor Lights turned'
                notemsg[1] = 'ON' if indoorlights else 'OFF'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['driverwindow'] != driverwindow:
                notemsg[0] = 'Driver Window'
                notemsg[1] = 'opened' if driverwindow else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['passengerwindow'] != passengerwindow:
                notemsg[0] = 'Passenger Window'
                notemsg[1] = 'opened' if passengerwindow else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['driverrearwindow'] != driverrearwindow:
                notemsg[0] = 'Driver Rear Window'
                notemsg[1] = 'opened' if driverrearwindow else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['passangerrearwindow'] != passangerrearwindow:
                notemsg[0] = 'Passanger Rear Window'
                notemsg[1] = 'opened' if passangerrearwindow else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['sunroof'] != sunroof:
                notemsg[0] = 'Sunroof'
                notemsg[1] = 'opened' if sunroof else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['trunk'] != trunk:
                notemsg[0] = 'Trunk'
                notemsg[1] = 'opened' if trunk else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['bonnet'] != bonnet:
                notemsg[0] = 'Bonnet'
                notemsg[1] = 'opened' if bonnet else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['trunkbuttonpress'] != trunkbuttonpress:
                notemsg[0] = 'Trunk Button'
                notemsg[1] = 'pressed' if trunkbuttonpress else 'released'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)

        self.gm_states['driverdoor'] = driverdoor
        self.gm_states['passangerdoor'] = passangerdoor
        self.gm_states['driverreardoor'] = driverreardoor
        self.gm_states['passangerreardoor'] = passangerreardoor
        self.gm_states['doorsopen'] = doorsopen
        self.gm_states['zvunlocked'] = zvunlocked
        self.gm_states['zvlocked'] = zvlocked
        self.gm_states['zvlockstate'] = zvlockstate
        self.gm_states['zvhardlocked'] = zvhardlocked
        self.gm_states['indoorlights'] = indoorlights
        self.gm_states['driverwindow'] = driverwindow
        self.gm_states['passengerwindow'] = passengerwindow
        self.gm_states['driverrearwindow'] = driverrearwindow
        self.gm_states['passangerrearwindow'] = passangerrearwindow
        self.gm_states['sunroof'] = sunroof
        self.gm_states['trunk'] = trunk
        self.gm_states['bonnet'] = bonnet
        self.gm_states['trunkbuttonpress'] = trunkbuttonpress

        self.gm_states['runonce'] = True

    ######################### Pi Modus and RTS ##################
    ##
    def pi_on(self):
        self.piaktiv = True
        log('RASPBERRY: ACTIVATE PI')
        self.gt_show_pi()
        if self.dsp_cd:
            self.dsp_set_cd()
        KODI.track_seek(1)  # set player to normal speed
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Player.SetSpeed","params":{"playerid":1,"speed":%s },"id":1}' % SPEED)

    def pi_off(self):
        self.piaktiv = False
        log('RASPBERRY: DEACTIVATE PI')
        self.gt_hide_pi()
        if self.dsp_cd:
            self.dsp_set_tuner()
        KODI.track_pause()
        # KODI.track_seek(0)
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Player.PlayPause","params":{"playerid":1,"play":false},"id":1}')

    def gt_show_pi(self):
        if self.navmenu or self.tpmenu or self.tonemenu or not self.piaktiv:
            return
        self.pass_bm_buttons = True
        log('RASPBERRY: SHOW PI')
        self.set_ntsc(True)

    def gt_hide_pi(self):
        self.pass_bm_buttons = False
        log('RASPBERRY: HIDE PI')
        self.set_ntsc(False)

    def is_pi_active(self):
        return self.piaktiv

    def set_ntsc(self, ntscstate):
        if self.gpio_ntsc:
            if ntscstate:
                GPIO_NTSC.reset()
            else:
                GPIO_NTSC.set()
                # if NTSCState:
                #    GPIO.set('LOW')
                # else:
                #    GPIO.set('HIGH')
        else:
            IBUS.ntsc = ntscstate

    def dsp_set_tuner(self):
        IBUS.write_bus_packet('68', '6A', ['36', 'A1'])  # 68 04 6A 36 A1 91 DSP Source Tuner
        log('RASPBERRY: DSP SOURCE TUNER')

    def dsp_set_cd(self):
        IBUS.write_bus_packet('68', '6A', ['36', 'A0'])  # 68 04 6A 36 A0 90 DSP Source CD
        log('RASPBERRY: DSP SOURCE CD')

    ############ Kodi Commands
    def kodi_said_play(self):
        if not self.piaktiv or self.phone_mute:
            KODI.track_pause()

    ############ Special Events
    ## LCM
    # 3F 0F D0 0C 00 00 00 00 00 03 28 18 00 B8 04 00 63 Parkrlights
    # 3F 0F D0 0C 00 00 20 00 00 00 00 00 00 B8 04 00 70 Parklight Switch
    #            AA BB CC DD EE FF GG HH II JJ KK LL CK
    # AA = '00'
    # BB = '00'
    # CC = '00'
    # DD = '00'
    # EE = '00'
    # FF = '03'
    # GG = '28'
    # HH = '18'
    # II = '00'
    # JJ = '00'
    # KK = '00'
    # LL = '00'

    def lcm_lights_on(self, timedelay=10):
        if self.day_time and time_now_in_range(self.day_time_start, self.day_time_end):
            return
        self.lcm_delay = timedelay
        if self.ign_mode > 0:
            log('Skip Welcomelight, IGN is turned ON')
            return
        sendcount = 10
        self.lcm_on = True
        while self.lcm_delay > 0 and self.lcm_on:
            if self.ign_mode > 0: break
            if sendcount >= 10:
                sendcount = 0  # E46 - 3f 0b d0 0c 00 00 00 00 60 06 01 06 CK
                # Turn Lights on   E39 -          0C 00 00 00 00 10 01 28 10 00
                # IBUS.write_bus_packet('3F', 'D0',['0C','00','00','00','00','00','03','28','18', '00'], True)  # 3F 0C D0 0C 00 00 00 00 10 01 28 10 00 CK  : park lights
                # IBUS.write_bus_packet('3F', 'D0', ['0C', AA, BB, CC, DD, EE, FF, GG, HH, II], True)
                if self.car_model == 'E39':
                    IBUS.write_bus_packet('3F', 'D0', ['0C', '00', '00', '00', '00', '00', '03', '28', '18', '00'], True)
                elif self.car_model == 'E46':
                    IBUS.write_bus_packet('3F', 'D0', ['0C', '00', '00', '00', 'C0', '60', '00', '01', '06'], True)
                # 0c 00 00 00 c0 60 00 01 06 0c 00 00 00 c0 60 00 01 06
                # IBUS.write_bus_packet('3F', 'D0', ['0C', AA,  BB,  CC,  DD,  EE,  FF,  GG,  HH, II, JJ, KK, LL], True)
                log('LIGHTS ON - Turn OFF in %ss' % self.lcm_delay)
                # IBUS.write_bus_packet('3F', 'D0', ['0C', '00', '00', '00', '00', '12', '45', 'E8', '52', '00'])  # 3F 0C D0 0C 00 00 00 00 12 45 E8 52 00 02 : Lights ON
            sendcount += 1
            self.lcm_delay += -1
            if self.ign_mode < 0:
                self.ask_ign_state()
            time.sleep(1)

        if self.lcm_on: self.lcm_lights_off()

    def lcm_lights_off(self):
        # Turn all Lights off
        # if not LCM_ON: return
        self.lcm_delay = -1
        if self.lcm_on:
            log('LIGHTS OFF')
            if self.car_model == 'E39':
                IBUS.write_bus_packet('3F', 'D0', ['0C', '00', '00', '00', '00', '00', '00', '00', '00', '00'], True)  # 3F 0C D0 0C 00 00 00 00 00 00 00 00 00 EF : Lights OFF
            elif self.car_model == 'E46':
                IBUS.write_bus_packet('3F', 'D0', ['0C', '00', '00', '00', '00', '00', '00', '00', '00'], True)
        # IBUS.write_bus_packet('3F', 'D0', ['0C', '00', '00', '00', '00', '00', '00', '00', '00', '00'], True)
        self.lcm_on = False

    '''

    MRL_01=3F 05 00 0C 01 31 CK
    MRR_01=3F 05 00 0C 02 31 CK

    MRL_00=3F 05 00 0C 01 30 CK
    MRR_00=3F 05 00 0C 02 30 CK

    '''

    def mirror_unfold(self):
        IBUS.write_bus_packet('3F', '00', ['0C', '01', '30'])
        time.sleep(0.100)
        IBUS.write_bus_packet('3F', '00', ['0C', '02', '30'])

    def mirror_fold(self):
        IBUS.write_bus_packet('3F', '00', ['0C', '01', '31'])
        time.sleep(0.100)
        IBUS.write_bus_packet('3F', '00', ['0C', '02', '31'])

    def send_song_to_ike(self):
        if not self.ike_display:
            return
        if not self.ike_track:
            return
        thread = Thread(target=self._send_song_to_ike_thread)
        thread.setDaemon(True)
        thread.start()

    def _send_song_to_ike_thread(self):
        try:
            while int(xbmc.Player().getTime()) > 0.2:
                xbmc.sleep(1)
            while not xbmc.Player().isPlaying():
                xbmc.sleep(1)
            while int(xbmc.Player().getTime()) < 0.5:
                xbmc.sleep(1)
            Song = KODI.track_title()
            if Song == '': return
            log('SEND SONG: "%s" to IKE Display' % Song, 2)
            self._send_to_ike_thread(Song)
        except:
            log('Kodi has an error with playing or -> not playing <- media.')

    def send_to_ike(self, Text, when_pi_is_inactiv=False, when_ign_off=False):
        if not self.ike_display:
            return
        thread = Thread(target=self._send_to_ike_thread, args=(Text, when_pi_is_inactiv, when_ign_off))
        thread.setDaemon(True)
        thread.start()

    def _send_to_ike_thread(self, Text, when_pi_is_inactiv=False, when_ign_off=False):
        # reset running texts
        self.cancel_ike_text = True
        time.sleep(0.400)  # every scrolltext should stop now
        self.cancel_ike_text = False

        scrollspeed = 250

        # check addon setting
        if not self.ike_display:
            return

        if not self.piaktiv and not when_pi_is_inactiv:
            return

        # check text len
        if len(Text) <= 20:
            dat = ['1A', '35', '00'] if when_ign_off else ['23', '62', '30']
            dat.extend(asc_to_hex(Text.center(20)))

            IBUS.write_bus_packet('C8', '80', dat)  #
        else:
            Text_tmp = Text[:20]
            dat = ['1A', '35', '00'] if when_ign_off else ['23', '62', '30']
            dat.extend(asc_to_hex(Text_tmp))

            IBUS.write_bus_packet('C8', '80', dat)  #

            ticker = 1
            while ticker <= 1500:
                if self.cancel_ike_text:
                    return
                ticker += 1
                time.sleep(0.001)

            # forward loop
            cnt = len(Text)
            cnt_tmp = 0
            ticker = 1
            while cnt_tmp + 20 <= cnt:
                if self.cancel_ike_text:
                    return
                if ticker == scrollspeed:
                    if not self.piaktiv and not when_pi_is_inactiv:
                        self.clear_ike(0)
                        return

                    # prepare text
                    Text_tmp = Text[cnt_tmp:20 + cnt_tmp]

                    # prepare telegram
                    dat = ['1A', '35', '00'] if when_ign_off else ['23', '62', '30']
                    dat.extend(asc_to_hex(Text_tmp))

                    IBUS.write_bus_packet('C8', '80', dat)  #

                    cnt_tmp += 1
                    ticker = 1
                else:
                    ticker += 1
                time.sleep(0.001)

            # wait loop
            ticker = 1
            while ticker < 1000:
                if self.cancel_ike_text:
                    return
                ticker += 1
                time.sleep(0.001)

            # rewind loop
            ticker = 1
            cnt_tmp = len(Text) - 20
            while cnt_tmp + 20 >= 20:
                if self.cancel_ike_text:
                    return
                if ticker == scrollspeed:
                    if not self.piaktiv and not when_pi_is_inactiv:
                        self.clear_ike(0)
                        return

                    # prepare text
                    Text_tmp = Text[cnt_tmp:20 + cnt_tmp]

                    # prepare telegram
                    dat = ['1A', '35', '00'] if when_ign_off else ['23', '62', '30']
                    dat.extend(asc_to_hex(Text_tmp))

                    IBUS.write_bus_packet('C8', '80', dat)  #

                    cnt_tmp += - 1
                    ticker = 1
                else:
                    ticker += 1
                time.sleep(0.001)

        if not when_ign_off:
            self.clear_ike()
        pass

    def clear_ike(self, wait=3000, when_ign_off=False):
        if not self.ike_display:
            return
        ticker = 1
        while ticker < wait:
            time.sleep(0.001)
            if self.cancel_ike_text:
                return
            ticker += 1
        if when_ign_off:
            IBUS.write_bus_packet('30', '80', ['1A', '30', '00'])  # 68 05 80 23 40 30 BE
        else:
            IBUS.write_bus_packet('C8', '80', ['23', '40', '30'])  # 68 05 80 23 40 30 BE

    def bm_led(self, color, state=False):
        # c8 04 e7 2b xx chk
        # xx ist eine Bitmaske 7 6 5 4 3 2 1 0 	Bit 0 = rot, Bit 1 = rot+blinken, Bit 2 = orange, Bit 3 = orange+blinken, Bit 4 = grün, Bit 5 = grün+blinken
        if color.lower() == 'red':
            IBUS.write_bus_packet('C8', 'F0', ['2B', '01'])  # RED
        if color.lower() == 'yellow':
            IBUS.write_bus_packet('C8', 'F0', ['2B', '04'])  # YELLOW
        if color.lower() == 'green':
            IBUS.write_bus_packet('C8', 'F0', ['2B', '10'])  # GREEN
        if color.lower() == 'off':
            IBUS.write_bus_packet('C8', 'F0', ['2B', '00'])  # ALL OFF

    ### OBC Requests ###
    def obc_req(self, resetrunonce=False):
        if resetrunonce: self.obc_req_runonce = False
        if not self.obc_req_runonce:
            thread = Thread(target=self._obc_req_thread)
            thread.setDaemon(True)
            thread.start()
        self.obc_req_runonce = True
        pass

    def _obc_req_thread(self):
        if self.obc_req_runs:
            return
        self.obc_req_runs = True
        xbmc.sleep(350)
        self.obc_req_time()
        xbmc.sleep(self.obc_req_delay)
        self.obc_req_date()
        xbmc.sleep(self.obc_req_delay)
        self.obc_req_outtemp()
        xbmc.sleep(self.obc_req_delay)
        self.obc_req_cons1()
        xbmc.sleep(self.obc_req_delay)
        self.obc_req_cons2()
        xbmc.sleep(self.obc_req_delay)
        self.obc_req_range()
        xbmc.sleep(self.obc_req_delay)
        self.obc_req_dist()
        xbmc.sleep(self.obc_req_delay)
        self.obc_req_arr()
        xbmc.sleep(self.obc_req_delay)
        self.obc_req_limit()
        xbmc.sleep(self.obc_req_delay)
        self.obc_req_avg()
        xbmc.sleep(self.obc_req_delay)
        self.obc_req_stpwtch()
        xbmc.sleep(self.obc_req_delay)
        self.obc_req_tmr1()
        xbmc.sleep(self.obc_req_delay)
        self.obc_req_tmr2()
        xbmc.sleep(self.obc_req_delay)
        self.obc_req_coolant()
        self.obc_req_runs = False

    def obc_req_time(self):
        IBUS.write_bus_packet('3B', '80', ['41', '01', '01'])  # 3B 05 80 41 01 01 FF
        pass

    def obc_req_date(self):
        IBUS.write_bus_packet('3B', '80', ['41', '02', '01'])  # 3B 05 80 41 02 01 FC
        pass

    def obc_req_outtemp(self):
        IBUS.write_bus_packet('3B', '80', ['41', '03', '01'])  # 3B 05 80 41 03 01 CK
        pass

    def obc_req_cons1(self):
        IBUS.write_bus_packet('3B', '80', ['41', '04', '01'])  # 3B 05 80 41 04 01 CK
        pass

    def obc_req_cons2(self):
        IBUS.write_bus_packet('3B', '80', ['41', '05', '01'])  # 3B 05 80 41 05 01 CK
        pass

    def obc_req_range(self):
        IBUS.write_bus_packet('3B', '80', ['41', '06', '01'])  # 3B 05 80 41 06 01 CK
        pass

    def obc_req_dist(self):
        IBUS.write_bus_packet('3B', '80', ['41', '07', '01'])  # 3B 05 80 41 07 01 CK
        pass

    def obc_req_arr(self):
        IBUS.write_bus_packet('3B', '80', ['41', '08', '01'])  # 3B 05 80 41 08 01 CK
        pass

    def obc_req_limit(self):
        IBUS.write_bus_packet('3B', '80', ['41', '09', '01'])  # 3B 05 80 41 09 01 CK
        pass

    def obc_req_avg(self):
        IBUS.write_bus_packet('3B', '80', ['41', '0A', '01'])  # 3B 05 80 41 0A 01 CK
        pass

    def obc_req_memo(self):
        IBUS.write_bus_packet('3B', '80', ['41', '0C', '01'])  # 3B 05 80 41 0C 01 CK
        pass

    def obc_req_stpwtch(self):
        IBUS.write_bus_packet('3B', '80', ['41', '0E', '01'])  # 3B 05 80 41 0E 01 CK
        pass

    def obc_req_tmr1(self):
        IBUS.write_bus_packet('3B', '80', ['41', '0F', '01'])  # 3B 05 80 41 0F 01 CK
        pass

    def obc_req_tmr2(self):
        IBUS.write_bus_packet('3B', '80', ['41', '10', '01'])  # 3B 05 80 41 10 01 CK
        pass

    def obcReqInd(self):
        IBUS.write_bus_packet('3B', '80', ['41', '09', '02'])  # 3B 05 80 41 09 02 F4" 'LIMIT/MEMO VALUE REQ for Indicator
        pass

    def obc_req_coolant(self):
        IBUS.write_bus_packet('5B', '80', ['1D'])  # 5B 03 80 1D CK

    ### OBC Sets ###
    # OBC CLOCK     : 80 0C E7 24 01 XX XX XX XX XX XX XX XX CK - (AM/PM in 12h Format)
    # OBC DATE      : 80 0F E7 24 02 XX XX XX XX XX XX XX XX XX XX XX CK
    # OBC A.TEMP    : 80 0C E7 24 03 XX XX XX XX XX XX XX XX CK
    # OBC CONS1     : 80 0F E7 24 04 XX XX XX XX XX XX XX XX XX XX XX CK
    # OBC CONS2     : 80 0F E7 24 05 XX XX XX XX XX XX XX XX XX XX XX CK
    # OBC RANGE     : 80 0C E7 24 06 XX XX XX XX XX XX XX XX CK
    # OBC DIST      : 80 0D E7 24 07 XX XX XX XX XX XX XX XX XX CK
    # OBC ARR       : 80 0C E7 24 08 XX XX XX XX XX XX XX XX CK
    # OBC LIMIT     : 80 0D E7 24 09 XX XX XX XX XX XX XX XX XX CK
    # OBC AVG       : 80 0E E7 24 0A XX XX XX XX XX XX XX XX XX XX CK
    # OBC STPWTCH   : 80 0E E7 24 0E XX XX XX XX XX XX XX XX XX XX CK
    # OBC TIMER1    : 80 0C E7 24 0F XX XX XX XX XX XX XX XX CK
    # OBC TIMER2    : 80 0C E7 24 10 XX XX XX XX XX XX XX XX CK

    # ODOMETER      : 80 0A BF 17 AA BB CC DD EE FF GG CK -> CCBBAA Hex to Dec konvertieren

    def obc_set_time(self, dat, UTC=False):
        self.obc_settime += 1
        hexstring = dat  # .split(' ')
        # 80 0C E7 24 01 02 31 33 3A 34 30 20 20 CK
        #          0  1  2  3  4  5  6  7  8  9
        # 80 0C E7 24 01 02 XX XX XX XX XX XX XX CK
        clock = ''
        if hexstring[3] == '20':
            clock = '0'
        else:
            clock = chr(int(hexstring[3], 16))  # get H
        clock = clock + chr(int(hexstring[4], 16)) + chr(int(hexstring[5], 16)) + chr(int(hexstring[6], 16)) + chr(int(hexstring[7], 16))  # get H:MM
        clock = clock + ':00'  # add seconds
        if hexstring[8] != '20': clock = clock + chr(int(hexstring[8], 16)) + chr(int(hexstring[9], 16))  # add AM/PM

        curhh, curmm, curss = os.popen("date +%T").readline().strip().split(':')
        newhh, newmm, newss = clock.split(':')
        log('OBC CUR HH: %s' % curhh, 3)
        log('OBC NEW HH: %s' % newhh, 3)
        log('OBC CUR MM: %s' % curmm, 3)
        log('OBC NEW HH: %s' % newmm, 3)
        if self.obc_settime > 2 \
                and curhh == newhh and abs(int(curmm) - int(newmm)) < 2 \
                and self.obc_time[1] == (chr(int(hexstring[8], 16)) + chr(int(hexstring[9], 16))):
            self.obc_settime = 3
            log('OBC: TIME: ' + clock + ' - no update requiered')
            return

        # check values
        if newhh == '--' or newmm == '--':
            log('OBC: BAD TIME: ' + clock)
            return

        log('OBC: SET SYSTEM TIME: ' + clock)
        f = os.popen('sudo date +%T%p -s "' + clock + '"')
        self.obc_time = [clock, chr(int(hexstring[8], 16)) + chr(int(hexstring[9], 16))]
        xbmc.sleep(100)

        # sudo date +%T%p -s "08:10:00PM"
        # sudo date +%T -s "20:10:00"
        # sudo date +%T%p -s "08:10:00PM" --utc
        pass

    def obc_set_date(self, dat):
        #          0  1  2  3  4  5  6  7  8  9 10 11 12
        # 80 0C E7 24 02 02 30 33 2E 30 34 2E 32 30 31 35 4D
        dat = ' '.join(dat)
        hexstring = dat[9:]  # 38
        if self.obc_date[1] == hexstring:
            log('OBC: DATE: ' + self.obc_date[0] + ' - no update requiered')
            return
        curtime = os.popen("date +%T").readline().strip()
        datestring = hex_to_asc(hexstring)
        if datestring.find(".") > 0:
            day, month, year = datestring.split('.')
        else:
            month, day, year = datestring.split('/')

        newdate = year + month + day  # "20150830"

        # check values
        if day == '--' or month == '--' or year == '----':
            log('OBC: BAD DATE: ' + newdate)
            return

        log('OBC: SET SYSTEM DATE: ' + newdate)
        f = os.popen('sudo date +%Y%m%d -s "' + newdate + '"')
        time.sleep(0.300)
        if self.obc_time[0]:
            f = os.popen('sudo date +%T -s "' + self.obc_time[0] + '"')
        time.sleep(0.100)

        self.obc_date = [datestring, hexstring]
        # sudo date +%Y%m%d -s "20081128"
        # os.popen("date +%T %s" % curtime)
        pass

    def obc_set_outtemp(self, dat):
        #          0  1  2  3  4  5  6  7  8  9
        # 80 0C E7 24 03 XX XX XX XX XX XX XX XX CK
        dat = ' '.join(dat)
        hexstring = dat[9:]  # 29

        convstring = hex_to_asc(hexstring)
        log('OBC: SET OUT TEMP: ' + convstring)
        if KODI.get_addon_setting('home_temp') == "OBC Outtemp":
            KODI.set_property('OBC_OUTTEMP', convstring)
        self.obc_outtemp = convstring

    def obc_set_cons1(self, dat):
        #          0  1  2  3  4  5  6  7  8  9 10 11 12
        # 80 0F E7 24 04 XX XX XX XX XX XX XX XX XX XX XX CK
        dat = ' '.join(dat)
        hexstring = dat[9:]  # 38

        convstring = hex_to_asc(hexstring)
        log('OBC: SET CONS1: ' + convstring)
        KODI.set_property('OBC_CONS1', convstring)
        self.obc_cons1 = convstring

    def obc_set_cons2(self, dat):
        #          0  1  2  3  4  5  6  7  8  9 10 11 12
        # 80 0F E7 24 05 XX XX XX XX XX XX XX XX XX XX XX CK
        dat = ' '.join(dat)
        hexstring = dat[9:]  # 38

        convstring = hex_to_asc(hexstring)
        log('OBC: SET CONS2: ' + convstring)
        KODI.set_property('OBC_CONS2', convstring)
        self.obc_cons2 = convstring

    def obc_set_range(self, dat):
        #          0  1  2  3  4  5  6  7  8  9
        # 80 0C E7 24 06 XX XX XX XX XX XX XX XX CK
        dat = ' '.join(dat)
        hexstring = dat[9:]

        convstring = hex_to_asc(hexstring)
        log('OBC: SET RANGE: ' + convstring)
        KODI.set_property('OBC_RANGE', convstring)
        self.obc_range = convstring

    def obc_set_dist(self, dat):
        #          0  1  2  3  4  5  6  7  8  9 10
        # 80 0D E7 24 07 XX XX XX XX XX XX XX XX XX CK
        dat = ' '.join(dat)
        hexstring = dat[9:]

        convstring = hex_to_asc(hexstring)
        log('OBC: SET DIST: ' + convstring)
        KODI.set_property('OBC_DIST', convstring)
        self.obc_dist = convstring

    def obc_set_arr(self, dat):
        #          0  1  2  3  4  5  6  7  8  9
        # 80 0C E7 24 08 XX XX XX XX XX XX XX XX CK
        dat = ' '.join(dat)
        hexstring = dat[9:]

        convstring = hex_to_asc(hexstring)
        log('OBC: SET ARR: ' + convstring)
        KODI.set_property('OBC_ARRIV', convstring)
        self.obc_arr = convstring

    def obc_set_limit(self, dat):
        #          0  1  2  3  4  5  6  7  8  9 10
        # 80 0D E7 24 09 XX XX XX XX XX XX XX XX XX CK
        dat = ' '.join(dat)
        hexstring = dat[9:]

        convstring = hex_to_asc(hexstring)
        log('OBC: SET LIMIT: ' + convstring)
        KODI.set_property('OBC_LIMIT', convstring)
        self.obc_limit = convstring

    def obc_set_avg(self, dat):
        #          0  1  2  3  4  5  6  7  8  9 10 11
        # 80 0E E7 24 0A XX XX XX XX XX XX XX XX XX XX CK
        dat = ' '.join(dat)
        hexstring = dat[9:]

        convstring = hex_to_asc(hexstring)
        log('OBC: SET AVG: ' + convstring)
        KODI.set_property('OBC_AVGSPEED', convstring)
        self.obc_avg = convstring

    def obc_set_stpwtch(self, dat):
        #          0  1  2  3  4  5  6  7  8  9 10 11
        # 80 0E E7 24 0E XX XX XX XX XX XX XX XX XX XX CK
        dat = ' '.join(dat)
        hexstring = dat[9:]

        convstring = hex_to_asc(hexstring)
        log('OBC: SET STPWTCH: ' + convstring)
        KODI.set_property('OBC_STPWTCH', convstring)
        self.obc_stpwtch = convstring

    def obc_set_tmr1(self, dat):
        #          0  1  2  3  4  5  6  7  8  9
        # 80 0C E7 24 0F XX XX XX XX XX XX XX XX CK
        dat = ' '.join(dat)
        hexstring = dat[9:]

        convstring = hex_to_asc(hexstring)
        log('OBC: SET TMR1: ' + convstring)
        KODI.set_property('OBC_TMR1', convstring)
        self.obc_tmr1 = convstring

    def obc_set_tmr2(self, dat):
        #          0  1  2  3  4  5  6  7  8  9
        # 80 0C E7 24 10 XX XX XX XX XX XX XX XX CK
        dat = ' '.join(dat)
        hexstring = dat[9:]

        convstring = hex_to_asc(hexstring)
        log('OBC: SET TMR2: ' + convstring)
        KODI.set_property('OBC_TMR2', convstring)
        self.obc_tmr2 = convstring
        pass

    def obc_set_coolant(self, dat):
        # 80 06 BF [19 XX YY 00] CK
        # XX OUTTEMP
        # YY COOLANTTEMP
        tmp = int(dat[2], 16)
        if tmp > 128:  # negative values
            coolanttemp = '%s°C' % (tmp - 256)
        else:  # positive values
            coolanttemp = '+%s°C' % tmp
        log('OBC: SET COOLANT TEMP: %s' % coolanttemp)
        if KODI.get_addon_setting('home_temp') == "Coolant Temp":
            KODI.set_property('OBC_OUTTEMP', coolanttemp)
        KODI.set_property('OBC_COOLANTTEMP', coolanttemp)
        self.obc_coolant = coolanttemp

        tmp = int(dat[1], 16)

        if tmp > 128:  # negative values
            outtemp = '%s°C' % (tmp - 256)
        else:  # positive values
            outtemp = '+%s°C' % tmp

        log('OBC: SET IKE OUT TEMP: %s' % outtemp)
        if KODI.get_addon_setting('home_temp') == "IKE Outtemp": KODI.set_property('OBC_OUTTEMP', outtemp)
        KODI.set_property('OBC_IKE_OUTTEMP', coolanttemp)


def log(string, lvl=1):
    if KODI.log_level < 1: return
    thread = Thread(target=KODI.log, args=(string, lvl))
    thread.setDaemon(True)
    thread.start()


def note(heading, message=" ", time=5000):
    thread = Thread(target=KODI.note, args=(heading, message, time))
    thread.setDaemon(True)
    thread.start()


def dialog_ok(label1, label2='', label3=''):
    thread = Thread(target=KODI.dialog_ok, args=(label1, label2, label3))
    thread.setDaemon(True)
    thread.start()


def get_bit_from_hex(hexstring, bit):
    output = bin(int(hexstring, 16))[2:].zfill(8)
    return True if int(output[bit - 1:bit]) == 1 else False


def set_bit_in_hex(hexstring, bit, value):
    temp = bin(int(hexstring, 16))[2:].zfill(8)
    output = list(temp)
    output[bit] = str(value)
    return ''.join(output)
    # hex(int(bin(int('AB', 16))[2:].zfill(8),2)).replace('0x','').upper().zfill(2)


def asc_to_hex(text):
    text = _encode_ibus_chars(text)
    return [l.encode("hex") for l in text]


def hex_to_asc(hexstring):
    in_hex = hexstring.split()
    out_hex = [chr(int(l, 16)) for l in in_hex]
    return _decode_ibus_chars(''.join(out_hex).strip())


def _encode_ibus_chars(text):
    # change special characters for ibus ascii table
    text = text.replace("ß", chr(160))
    text = text.replace("Ä", chr(161))
    text = text.replace("Ö", chr(162))
    text = text.replace("Ü", chr(163))
    text = text.replace("ä", chr(164))
    text = text.replace("ö", chr(165))
    text = text.replace("ü", chr(166))
    text = text.replace("°", chr(168))
    text = text.replace("´", chr(39))
    return text


def _decode_ibus_chars(text):
    # change special characters from ibus ascii table
    text = text.replace(chr(160), "ß")
    text = text.replace(chr(161), "Ä")
    text = text.replace(chr(162), "Ö")
    text = text.replace(chr(163), "Ü")
    text = text.replace(chr(164), "ä")
    text = text.replace(chr(165), "ö")
    text = text.replace(chr(166), "ü")
    text = text.replace(chr(168), '°')
    text = text.replace(chr(39), "´")
    return text


def time_now_in_range(time1, time2):
    try:
        now = datetime.datetime.now()

        time_now = datetime.datetime.strptime('%s:%s' % (now.hour, now.minute), '%H:%M')
        if 'AM' in time1.upper() or 'PM' in time1.upper():
            time_start = datetime.datetime.strptime(time1, '%I:%M %p')
        else:
            time_start = datetime.datetime.strptime(time1, '%H:%M')

        if 'AM' in time2.upper() or 'PM' in time2.upper():
            time_end = datetime.datetime.strptime(time2, '%I:%M %p')
        else:
            time_end = datetime.datetime.strptime(time2, '%H:%M')

        if time_start == time_end:
            return False
        elif time_start < time_end:
            if time_start <= time_now < time_end:
                return True
            else:
                return False
        else:
            if time_now >= time_start or time_now < time_end:
                return True
            else:
                return False
    except:
        log('time 1 or 2 error')
        return False


def syscheck():
    try:
        import serial
        # dlgInfoOk('pySerial is already installed')
        return True
    except:
        pb = xbmcgui.DialogProgress()
        pb.create('IBusCommunicator')
        pb.update(25, 'Try to install requiered Modules')
        xbmc.sleep(300)

        # xbmcgui.Dialog().ok('IBusCommunicator', 'No pySerial Modul found')
        try:
            pb.update(35, 'Update Package Libary...')

            f = subprocess.Popen("sudo apt-get update", shell=True, stdout=subprocess.PIPE).stdout.read()

            pb.update(50, 'Installation python-serial...')

            f = subprocess.Popen("echo -e 'y' | sudo apt-get install python-serial", shell=True, stdout=subprocess.PIPE).stdout.read()

            pb.update(60, 'Installation python-serial......')

            xbmc.sleep(300)

            # match = f.find('Setting up python-serial')

            pb.update(100, 'Finished')
            xbmc.sleep(300)
            pb.close()
            # if f.find('Setting up python-zmq') > 0:
            #    pass
            if f.find('Setting up python-serial') > 0:
                # if match > 0:
                log('IBUSCOMMUNICATOR: python-serial successfully  installed')
                dialog_ok('pySerial successfully  installed')
                return True
            else:
                log('IBUSCOMMUNICATOR: python-serial not installed')
                dialog_ok('pySerial was not successfully installed')
                return False

        except:
            pb.close()
            log('IBUSCOMMUNICATOR: python-serial not installed')
            dialog_ok('pySerial could not successfull installed')
            return False
        pass


def load_settings(settings_changed=False):
    cdc_emu_tmp = EVENT.cdc_emu
    gpio_ntsc_tmp = EVENT.gpio_ntsc

    loglevel = int(KODI.get_addon_setting('log_lvl')[-1:])
    log('SETTINGS: LOAD: LOGLVL=%s' % loglevel, 0)
    # xbmc.log('IBUSCOMMUNICATOR: SETTINGS: LOAD: LOGLVL=%s' % loglevel)
    KODI.log_level = loglevel

    EVENT.device_path = KODI.get_addon_setting('ser_dev')
    log('SETTINGS: LOAD: DEVICE_PATH=%s' % EVENT.device_path)

    EVENT.cdc_emu = KODI.get_addon_setting('cdc_emu')

    piaudiomode = KODI.get_addon_setting('audio_mode')
    EVENT.modefm = False
    EVENT.modecd = False
    EVENT.modetape = False
    EVENT.modeaux = False
    EVENT.modecis = False
    EVENT.modealways = False

    if piaudiomode == 'CD':
        EVENT.modecd = True
        EVENT.cdc_emu = True
        log('SETTINGS: LOAD: AUDIOMODE=CD')
    elif piaudiomode == 'TAPE':
        EVENT.modetape = True
        log('SETTINGS: LOAD: AUDIOMODE=TAPE')
    elif piaudiomode == 'AUX':
        EVENT.modeaux = True
        log('SETTINGS: LOAD: AUDIOMODE=AUX')
    elif piaudiomode == 'CIS':
        EVENT.modecis = True
        EVENT.cdc_emu = False
        log('SETTINGS: LOAD: AUDIOMODE=CIS')
    elif piaudiomode == 'ALWAYS':
        EVENT.modealways = True
        log('SETTINGS: LOAD: AUDIOMODE=ALWAYS')
    log('SETTINGS: LOAD: CDC_EMU=%s' % EVENT.cdc_emu)

    EVENT.car_model = KODI.get_addon_setting('car_model')
    log('SETTINGS: LOAD: CAR_MODEL=%s' % EVENT.car_model)

    EVENT.dsp_cd = KODI.get_addon_setting('dsp_cd')
    EVENT.dsp_tuner = KODI.get_addon_setting('dsp_tuner')
    if EVENT.dsp_tuner:
        EVENT.dsp_cd = False
    if not EVENT.modecd:
        EVENT.dsp_tuner = False
    log('SETTINGS: LOAD: DSP_CD=%s' % EVENT.dsp_cd)
    log('SETTINGS: LOAD: DSP_TUNER=%s' % EVENT.dsp_tuner)

    EVENT.gpio_ntsc = KODI.get_addon_setting('use_gpio')
    log('SETTINGS: LOAD: USE_GPIO=%s' % EVENT.gpio_ntsc)

    EVENT.wel_light = KODI.get_addon_setting('wel_light')
    log('SETTINGS: LOAD: WEL_LIGHT=%s' % EVENT.wel_light)

    EVENT.wel_light_time = int(KODI.get_addon_setting('wel_light_time'))
    log('SETTINGS: LOAD: WEL_LIGHT_TIME=%s' % EVENT.wel_light_time)

    EVENT.lev_light = KODI.get_addon_setting('lev_light')
    log('SETTINGS: LOAD: LEV_LIGHT=%s' % EVENT.lev_light)

    EVENT.lev_light_time = int(KODI.get_addon_setting('lev_light_time'))
    log('SETTINGS: LOAD: LEV_LIGHT_TIME=%s' % EVENT.lev_light_time)

    EVENT.keyin_off = KODI.get_addon_setting('keyin_off')
    log('SETTINGS: LOAD: KEYIN_OFF=%s' % EVENT.keyin_off)

    EVENT.lev_light_ign_off = KODI.get_addon_setting('lev_light_ign_off')
    log('SETTINGS: LOAD: LEV_LIGHT_IGN_OFF=%s' % EVENT.lev_light_ign_off)

    EVENT.doors_off = KODI.get_addon_setting('doors_off')
    log('SETTINGS: LOAD: DOORS_OFF=%s' % EVENT.doors_off)

    EVENT.day_time = KODI.get_addon_setting('day_time')
    log('SETTINGS: LOAD: DAY_TIME=%s' % EVENT.day_time)

    EVENT.day_time_start = KODI.get_addon_setting('day_time_start')
    log('SETTINGS: LOAD: DAY_TIME_START=%s' % EVENT.day_time_start)

    EVENT.day_time_end = KODI.get_addon_setting('day_time_end')
    log('SETTINGS: LOAD: DAY_TIME_END=%s' % EVENT.day_time_end)

    EVENT.mir_unfold = KODI.get_addon_setting('mir_unfold')
    log('SETTINGS: LOAD: MIR_UNFOLD=%s' % EVENT.mir_unfold)

    EVENT.mir_fold = KODI.get_addon_setting('mir_fold')
    log('SETTINGS: LOAD: MIR_FOLD=%s' % EVENT.mir_fold)

    EVENT.ike_display = KODI.get_addon_setting('ike_disp')
    log('SETTINGS: LOAD: IKE_DISP=%s' % EVENT.ike_display)

    EVENT.ike_track = KODI.get_addon_setting('ike_track')
    log('SETTINGS: LOAD: IKE_TRACK=%s' % EVENT.ike_track)

    EVENT.wel_ike = KODI.get_addon_setting('wel_ike')
    log('SETTINGS: LOAD: WEL_IKE=%s' % EVENT.wel_ike)

    EVENT.wel_iketxt = KODI.get_addon_setting('wel_iketxt')
    log('SETTINGS: LOAD: WEL_IKETXT=%s' % EVENT.wel_iketxt)

    EVENT.wel_iketxt_hold = KODI.get_addon_setting('wel_iketxt_hold')
    log('SETTINGS: LOAD: WEL_IKETXT_HOLD=%s' % EVENT.wel_iketxt_hold)

    EVENT.seek_sec = int(float(KODI.get_addon_setting('seek_sec')) * 1000)
    log('SETTINGS: LOAD: SEEK_SEC=%s' % EVENT.seek_sec)

    EVENT.seek_max = int(KODI.get_addon_setting('seek_max'))
    log('SETTINGS: LOAD: SEEK_MAX=%s' % EVENT.seek_max)

    EVENT.navhold_event = KODI.get_addon_setting('navhold_event')
    log('SETTINGS: LOAD: NAVHOLD_EVENT=%s' % EVENT.navhold_event)

    EVENT.inv_navturnbtn = KODI.get_addon_setting('inv_navturnbtn')
    log('SETTINGS: LOAD: INV_NAVTURNBTN=%s' % EVENT.inv_navturnbtn)

    EVENT.use_stw_nav = KODI.get_addon_setting('use_stw_nav')
    log('SETTINGS: LOAD: USE_STW_NAV=%s' % EVENT.use_stw_nav)
    if not EVENT.use_stw_nav:
        EVENT.stw_nav = False

    EVENT.gpio_gear_shift = KODI.get_addon_setting('gpio_gear_shift')
    log('SETTINGS: LOAD: GPIO_GEAR_SHIFT=%s' % EVENT.gpio_gear_shift)

    EVENT.gpio_gear_shift_trigger_time = float(KODI.get_addon_setting('gpio_gear_shift_trigger_time')) / 1000
    log('SETTINGS: LOAD: GPIO_GEAR_SHIFT_TRIGGER_TIME=%s' % EVENT.gpio_gear_shift_trigger_time)

    EVENT.gpio_gear_shift_up = int(KODI.get_addon_setting('gpio_gear_shift_up'))
    log('SETTINGS: LOAD: GPIO_GEAR_SHIFT_UP=%s' % EVENT.gpio_gear_shift_up)

    EVENT.gpio_gear_shift_down = int(KODI.get_addon_setting('gpio_gear_shift_down'))
    log('SETTINGS: LOAD: GPIO_GEAR_SHIFT_DOWN=%s' % EVENT.gpio_gear_shift_down)

    if settings_changed:
        EVENT.ask_radio_mode()
        EVENT.obc_req_coolant()
        EVENT.obc_req_outtemp()
        if EVENT.gpio_ntsc and not gpio_ntsc_tmp:
            GPIO_NTSC.init(7)
            IBUS.ntsc = False
        else:
            GPIO_NTSC.close()
        if EVENT.cdc_emu and not cdc_emu_tmp:
            EVENT.cdch_init()

    pass


if not syscheck():
    dialog_ok('some modules are missing', 'try to install manually:', 'python-serial')
    quit()

import serial

KODI = Kodi()
PLAYER = PlayerClass()
MONITOR = MonitorClass()
IBUS = IBusFace()
EVENT = EventClass()
GPIO_NTSC = GPIOClass()
GPIO_GEAR_SHIFT_UP = GPIOClass()
GPIO_GEAR_SHIFT_DOWN = GPIOClass()

# For Double Click
DOUBLECLICKDELAY = 0.3
DBL_NEXT = Clicker(DOUBLECLICKDELAY, KODI.right, KODI.track_next)
DBL_PREV = Clicker(DOUBLECLICKDELAY, KODI.left, KODI.track_prev)
DBL_STW_SPEAK = Clicker(DOUBLECLICKDELAY, KODI.select, KODI.back)

MFL = MFLDialog("DialogMFL.xml", ADDONPATH, 'Default', '720p')


def main():
    log('VERSION: %s' % ADDONVERSION)

    load_settings()
    if EVENT.gpio_gear_shift:
        GPIO_GEAR_SHIFT_UP.init(EVENT.gpio_gear_shift_up)
        GPIO_GEAR_SHIFT_UP.reset()
        GPIO_GEAR_SHIFT_DOWN.init(EVENT.gpio_gear_shift_down)
        GPIO_GEAR_SHIFT_DOWN.reset()

    if EVENT.gpio_ntsc:
        GPIO_NTSC.init(7)
        GPIO_NTSC.set()

    IBUS.set_port(EVENT.device_path)
    # init gpios

    log('IBUS: Connecting')
    if not IBUS.connect():
        note('IBUS: Error', 'Can not open serial device')
        return

    note('IBus Connected')

    thread = Thread(target=EVENT.read_ibus_packages)
    thread.setDaemon(True)
    thread.start()

    # IBUS.waitClearBus() # Wait for the iBus to clear, then send some initialization signals
    # IBUS.write_bus_packet('3F', '00', ['0C', '4E', '01']) # Turn on the 'clown nose' for 3 seconds

    # timerRadio() #startTimer('radioEvent', None, 5)

    # xbmc.sleep(50)
    if EVENT.wel_ike:
        EVENT.send_to_ike(EVENT.wel_iketxt, True, EVENT.wel_iketxt_hold)
    xbmc.sleep(200)
    # askIgnState()
    # IBUS.write_bus_packet('18', '18', ['01'])

    log('WAIT FOR IGNITION STATE')
    wait_counter = 10
    while wait_counter > 0:
        wait_counter -= 1
        if EVENT.ign_mode >= 0:
            break
        EVENT.ask_ign_state()
        xbmc.sleep(100)

    log('WAIT FOR IBUS TIME')
    wait_counter = 10
    while wait_counter > 0:
        wait_counter -= 1
        if EVENT.obc_time[0]:
            break
        EVENT.obc_req_time()
        xbmc.sleep(100)

    log('Get GM States')
    EVENT.ask_gm_state()

    if EVENT.wel_light:
        # as_thread(lcm_lights_on, WEL_LIGHT_TIME)  # welcomelight
        thread = Thread(target=EVENT.lcm_lights_on, args=EVENT.wel_light_time)
        thread.setDaemon(True)
        thread.start()

    # gong '30', '80', ['1A', '30', '04'
    # IBUS.write_bus_packet('68', '80', ['23', '40', '30', '52', '61', '73', '70', '7F', '7E', '49', '42', '75', '73', '20', '63', '6F', '6E', '6E', '65', '63', '74', '65', '64']) # IKE Welcome MSG "Rasp<>IBus connected"
    # as_thread(clear_ike)
    time.sleep(0.200)
    if EVENT.mir_unfold:
        EVENT.mirror_unfold()
    # xbmc.sleep(50)
    EVENT.cdch_init()
    time.sleep(0.500)
    EVENT.ask_radio_mode()

    if MONITOR.waitForAbort():
        # if xbmc.abortRequested:
        EVENT.cancel_read_thread = True
        EVENT.cancel_ike_text = True
        GPIO_NTSC.close()
        GPIO_GEAR_SHIFT_UP.close()
        GPIO_GEAR_SHIFT_DOWN.close()
        #just click to put last one in queue
        DBL_NEXT.click()
        DBL_PREV.click()
        DBL_STW_SPEAK.click()

        log("IBUS: Disconnecting")
        IBUS.disconnect()
        log("IBUS: Disconnected")



if __name__ == '__main__':
    main()

log('SERVICE COMPLETELY CLOSED')

'''
del KODI
del PLAYER
del MONITOR
del IBUS
del EVENT
del GPIO_NTSC
del GPIO_GEAR_SHIFT_UP
del GPIO_GEAR_SHIFT_DOWN
del DBL_NEXT
del DBL_PREV
del DBL_STW_SPEAK
del MFL
'''