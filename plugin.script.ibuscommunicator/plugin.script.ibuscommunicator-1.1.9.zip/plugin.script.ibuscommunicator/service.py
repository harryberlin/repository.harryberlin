#Embedded file name: C:/Users/Christian/VBOXTRANSFER/BMW/BMW Rasp OSMC Files/Addons/plugin.script.ibuscommunicator2\develop\service.py
import os
import time
import serial
import socket
import subprocess
from re import findall
from datetime import datetime
from functools import partial
from threading import Thread, Lock, Event
import xbmc, xbmcgui, xbmcaddon
from Queue import PriorityQueue, Empty, Queue
__author__ = 'harryberlin'
ADDON = xbmcaddon.Addon()
ADDONNAME = ADDON.getAddonInfo('name')
ADDONID = ADDON.getAddonInfo('id')
ADDONPATH = ADDON.getAddonInfo('path')
ADDONVERSION = ADDON.getAddonInfo('version')
ADDONMEDIAPATH = os.path.join(ADDONPATH, 'resources', 'skins', 'Default', 'media')
ADDONPDCPATH = os.path.join(ADDONPATH, 'resources', 'skins', 'Default', 'media', 'pdc')
ADDONGAUGEPATH = os.path.join(ADDONPATH, 'resources', 'skins', 'Default', 'media', 'gauges')
ICON = os.path.join(ADDONPATH, 'icon.png')
KODILOGFILE = '/home/osmc/.kodi/temp/kodi.log'
BACKUPLOGFILEPATH = '/boot/ibuscommunicator'
BIT = {0: 8,
 1: 7,
 2: 6,
 3: 5,
 4: 4,
 5: 3,
 6: 2,
 7: 1}

class Enum(object):
    current = 0
    min = 0
    max = 0

    def __init__(self, tupleList):
        self.tupleList = tupleList
        self.min = self.tupleList.index(min(self.tupleList))
        self.max = len(self.tupleList) - 1

    def __getattr__(self, name):
        return self.tupleList.index(name)


class RepeatTimer(Thread):

    def __init__(self, interval, function, iterations = 0, args = [], kwargs = {}):
        Thread.__init__(self)
        self.interval = interval
        self.function = function
        self.iterations = iterations
        self.args = args
        self.kwargs = kwargs
        self.finished = Event()

    def run(self):
        count = 0
        while not self.finished.isSet() and (self.iterations <= 0 or count < self.iterations):
            self.finished.wait(self.interval)
            if not self.finished.isSet():
                self.function(*self.args, **self.kwargs)
                count += 1

    def cancel(self):
        self.finished.set()


class TimerClass(Thread):

    def __init__(self, interval, function, args = [], kwargs = {}, loop = False):
        Thread.__init__(self)
        self.interval = interval
        self.counter = interval
        self.function = function
        self.args = args
        self.kwargs = kwargs
        self.loop = loop
        self.cancelTimer = False
        self.pauseTimer = False
        self.finished = Event()

    def run(self):
        while not self.cancelTimer:
            if self.cancelTimer:
                break
            if not self.finished.isSet():
                if self.counter <= 0:
                    self.function(*self.args, **self.kwargs)
                    if self.loop:
                        self.counter = self.interval
                    else:
                        break
                elif not self.pauseTimer:
                    self.counter -= 1

        self.finished.set()
        self.cancelTimer = False
        self.finished.set()

    def cancel(self):
        self.cancelTimer = True

    def restart(self):
        self.counter = self.interval

    def pause(self):
        self.pauseTimer = True

    def resume(self):
        self.pauseTimer = False

    def isPause(self):
        return self.pauseTimer


class ObcGuiClass(xbmcgui.WindowXML):
    isActive = False
    ACTION_PARENT_DIR = 9
    ACTION_PREVIOUS_MENU = 10
    ACTION_CLOSE_DIALOG = 51
    ACTION_SELECT_ITEM = 7
    ACTION_MOVE_LEFT = 1
    ACTION_MOVE_RIGHT = 2
    ACTION_MOVE_UP = 3
    ACTION_MOVE_DOWN = 4
    ACTION_NAV_BACK = 92
    ACTION_BACKSPACE = 110

    def __init__(self, xmlFilename, scriptPath, defaultSkin, defaultRes):
        log('Initializing OBC Gui...')

    def onInit(self):
        self.MAINLABEL = {-1: None,
         0: ['ON-BOARD', True, True],
         1: ['ON-BOARD', True, True],
         2: ['INFORMATION', True, True],
         3: ['GAUGES', True, True]}
        self.BUTTON1 = {-1: None,
         0: ['Verbrauch 1', True, True],
         1: ['Geschwindigkeit', True, True],
         2: ['Under Construction', True, True],
         3: [' ', False, False]}
        self.BUTTON2 = {-1: None,
         0: ['Verbrauch 2', True, True],
         1: ['Limit', True, True],
         2: [' ', False, False],
         3: [' ', False, False]}
        self.BUTTON3 = {-1: None,
         0: ['- Reichweite', True, False],
         1: ['Memo', True, True],
         2: [' ', False, False],
         3: [' ', False, False]}
        self.BUTTON4 = {-1: None,
         0: ['Distanz', True, True],
         1: ['Timer 1', True, True],
         2: [' ', False, False],
         3: [' ', False, False]}
        self.BUTTON5 = {-1: None,
         0: ['- Ankunft', True, False],
         1: ['Timer 2', True, True],
         2: [' ', False, False],
         3: [' ', False, False]}
        self.BUTTON6 = {-1: None,
         0: ['- Drehzahl', True, False],
         1: ['- Tankinhalt', True, False],
         2: [' ', False, False],
         3: [' ', False, False]}
        self.BUTTON7 = {-1: None,
         0: ['- Akt. Geschwindigkeit', True, False],
         1: ['- Stopuhr', True, False],
         2: [' ', False, False],
         3: [' ', False, False]}
        self.BUTTON8 = {-1: None,
         0: ['- K\xc3\xbchlwassertemperatur', True, False],
         1: ['- Bordspannung', True, False],
         2: [' ', False, False],
         3: [' ', False, False]}
        self.LABEL1 = {-1: None,
         0: [partial(EVENT.obc_cons1_get),
             True,
             True,
             ['RESET'],
             [partial(EVENT.obc_cons1_reset)]],
         1: [partial(EVENT.obc_avg_get),
             True,
             True,
             ['RESET'],
             [partial(EVENT.obc_avg_reset)]],
         2: [' ',
             False,
             False,
             [],
             []],
         3: [' ',
             False,
             False,
             [],
             []]}
        self.LABEL2 = {-1: None,
         0: [partial(EVENT.obc_cons2_get),
             True,
             True,
             ['RESET'],
             [partial(EVENT.obc_cons2_reset)]],
         1: [partial(EVENT.obc_limit_get),
             True,
             True,
             ['SET',
              'SPEED',
              'RESET',
              'ACTIVATE',
              'DEACTIVATE'],
             [partial(note, 'Under Construction'),
              partial(EVENT.obc_limit_set),
              partial(EVENT.obc_limit_reset),
              partial(EVENT.obc_limit_enable, True),
              partial(EVENT.obc_limit_enable, False)]],
         2: [' ',
             False,
             False,
             [],
             []],
         3: [' ',
             False,
             False,
             [],
             []]}
        self.LABEL3 = {-1: None,
         0: [partial(EVENT.obc_range_get),
             True,
             True,
             [],
             []],
         1: [' ',
             True,
             True,
             ['ACTIVATE', 'DEACTIVATE'],
             [partial(EVENT.obc_memo_enable, True), partial(EVENT.obc_memo_enable, False)]],
         2: [' ',
             False,
             False,
             [],
             []],
         3: [' ',
             False,
             False,
             [],
             []]}
        self.LABEL4 = {-1: None,
         0: [partial(EVENT.obc_dist_get),
             True,
             True,
             ['SET', 'RESET'],
             [partial(note, 'Under Construction'), partial(EVENT.obc_dist_reset)]],
         1: [partial(EVENT.obc_tmr1_get),
             True,
             True,
             ['SET',
              'RESET',
              'ACTIVATE',
              'DEACTIVATE'],
             [partial(note, 'Under Construction'),
              partial(EVENT.obc_tmr1_reset),
              partial(EVENT.obc_tmr1_enable, True),
              partial(EVENT.obc_tmr1_enable, False)]],
         2: [' ',
             False,
             False,
             [],
             []],
         3: [' ',
             False,
             False,
             [],
             []]}
        self.LABEL5 = {-1: None,
         0: [partial(EVENT.obc_arr_get),
             True,
             True,
             [],
             []],
         1: [partial(EVENT.obc_tmr2_get),
             True,
             True,
             ['SET',
              'RESET',
              'ACTIVATE',
              'DEACTIVATE'],
             [partial(note, 'Under Construction'),
              partial(EVENT.obc_tmr2_reset),
              partial(EVENT.obc_tmr2_enable, True),
              partial(EVENT.obc_tmr2_enable, False)]],
         2: [' ',
             False,
             False,
             [],
             []],
         3: [' ',
             False,
             False,
             []]}
        self.LABEL6 = {-1: None,
         0: [partial(EVENT.obc_rpm_get),
             True,
             True,
             [],
             []],
         1: [partial(EVENT.obc_fuellevel_get),
             True,
             True,
             [],
             []],
         2: [' ',
             False,
             False,
             [],
             []],
         3: [' ',
             False,
             False,
             [],
             []]}
        self.LABEL7 = {-1: None,
         0: [partial(EVENT.obc_speed_get),
             True,
             True,
             [],
             []],
         1: [partial(EVENT.obc_stpwtch_get),
             True,
             True,
             [],
             []],
         2: [' ',
             False,
             False,
             [],
             []],
         3: [' ',
             False,
             False,
             [],
             []]}
        self.LABEL8 = {-1: None,
         0: [partial(EVENT.obc_coolant_get),
             True,
             True,
             [],
             []],
         1: [partial(EVENT.obc_voltage_get),
             True,
             True,
             [],
             []],
         2: [' ',
             False,
             False,
             [],
             []],
         3: [' ',
             False,
             False,
             [],
             []]}
        self.IMAGE1 = {-1: None,
         0: [],
         1: [],
         2: [],
         3: []}
        self.IMAGE2 = {-1: None,
         0: [],
         1: [EVENT.obc_limit_get_ind],
         2: [],
         3: []}
        self.IMAGE3 = {-1: None,
         0: [],
         1: [EVENT.obc_memo_get_ind],
         2: [],
         3: []}
        self.IMAGE4 = {-1: None,
         0: [],
         1: [EVENT.obc_tmr1_get_ind],
         2: [],
         3: []}
        self.IMAGE5 = {-1: None,
         0: [],
         1: [EVENT.obc_tmr2_get_ind],
         2: [],
         3: []}
        self.IMAGE6 = {-1: None,
         0: [],
         1: [],
         2: [],
         3: []}
        self.IMAGE7 = {-1: None,
         0: [],
         1: [],
         2: [],
         3: []}
        self.IMAGE8 = {-1: None,
         0: [],
         1: [],
         2: [],
         3: []}
        log('OBC: GUI Opening')
        self.selectedButton = -1
        self.selectedSubButton = -1
        self.timeoutSubMenu = 2000
        self.obc_screen_min = 0
        self.obc_screen_max = len(self.MAINLABEL) - 2
        self.obc_screen_next = False
        self.isActive = True
        self.MAINLABEL[-1] = self.getControl(200)
        self.mainleft = self.getControl(201)
        self.mainright = self.getControl(202)
        self.IMAGE1[-1] = self.getControl(101)
        self.IMAGE2[-1] = self.getControl(102)
        self.IMAGE3[-1] = self.getControl(103)
        self.IMAGE4[-1] = self.getControl(104)
        self.IMAGE5[-1] = self.getControl(105)
        self.IMAGE6[-1] = self.getControl(106)
        self.IMAGE7[-1] = self.getControl(107)
        self.IMAGE8[-1] = self.getControl(108)
        self.BUTTON1[-1] = self.getControl(111)
        self.BUTTON2[-1] = self.getControl(112)
        self.BUTTON3[-1] = self.getControl(113)
        self.BUTTON4[-1] = self.getControl(114)
        self.BUTTON5[-1] = self.getControl(115)
        self.BUTTON6[-1] = self.getControl(116)
        self.BUTTON7[-1] = self.getControl(117)
        self.BUTTON8[-1] = self.getControl(118)
        self.LABEL1[-1] = self.getControl(121)
        self.LABEL2[-1] = self.getControl(122)
        self.LABEL3[-1] = self.getControl(123)
        self.LABEL4[-1] = self.getControl(124)
        self.LABEL5[-1] = self.getControl(125)
        self.LABEL6[-1] = self.getControl(126)
        self.LABEL7[-1] = self.getControl(127)
        self.LABEL8[-1] = self.getControl(128)
        while not self.IMAGE8[-1]:
            time.sleep(0.05)

        self.gauge_left = self.getControl(203)
        self.gauge_mid = self.getControl(204)
        self.gauge_right = self.getControl(205)
        self.update(startup=True)
        self.set_default_navigation()
        self.updateTimer = RepeatTimer(0.1, self.update)
        self.updateTimer.start()
        self.some_obc_req()
        self.updateObc = RepeatTimer(1, self.some_obc_req)
        self.updateObc.start()

    def onAction(self, Action):
        if Action in [self.ACTION_PREVIOUS_MENU,
         self.ACTION_CLOSE_DIALOG,
         self.ACTION_NAV_BACK,
         self.ACTION_BACKSPACE]:
            self.onStop()
        log('OBCGUI ACTION ID: %s' % Action.getId(), 3)
        log('OBCGUI FOCUS ID: %s' % self.getFocusId(), 3)
        if Action == self.ACTION_MOVE_LEFT and EVENT.obc_screen > self.obc_screen_min:
            self.obc_screen_next = True
            if EVENT.obc_screen == self.obc_screen_max:
                KODI.set_property('IBUSCOMMUNICATOR_OBC_Gauges', '0')
            else:
                KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', 'right_out')
            EVENT.obc_screen -= 1
            time.sleep(0.5)
            self.obc_screen_next = False
            self.reset_submenu()
            KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', 'left_in')
            self.setFocus(self.BUTTON1[-1])
        elif Action == self.ACTION_MOVE_RIGHT and EVENT.obc_screen < self.obc_screen_max:
            self.obc_screen_next = True
            KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', 'left_out')
            EVENT.obc_screen += 1
            time.sleep(0.5)
            self.obc_screen_next = False
            self.reset_submenu()
            if EVENT.obc_screen == self.obc_screen_max:
                KODI.set_property('IBUSCOMMUNICATOR_OBC_Gauges', '1')
            else:
                KODI.set_property('IBUSCOMMUNICATOR_OBC_SLIDE', 'right_in')
                self.setFocus(self.BUTTON1[-1])
        elif Action == self.ACTION_SELECT_ITEM:
            if self.selectedButton < 0:
                if self.set_submenu(0):
                    self.counter_submenu()
            else:
                log('submenu selected')
                log('obc screen %s' % EVENT.obc_screen)
                log('Button %s' % self.selectedButton)
                log('SubButton %s' % self.selectedSubButton)
                self.onSubmenuSelected(EVENT.obc_screen, self.selectedButton, self.selectedSubButton)
                self.timeoutSubMenu = 0
        elif Action == self.ACTION_MOVE_UP:
            if self.selectedButton > 0:
                self.set_submenu(self.selectedSubButton - 1)
                self.timeoutSubMenu = 2000
        elif Action == self.ACTION_MOVE_DOWN:
            if self.selectedButton > 0:
                self.set_submenu(self.selectedSubButton + 1)
                self.timeoutSubMenu = 2000
        log('OBCGUI FOCUSED ID: %s' % self.getFocusId(), 3)

    def onFocus(self, controlId):
        pass

    def onStop(self):
        log('OBC: GUI Closing')
        self.close()
        self.isActive = False
        self.updateObc.cancel()
        self.updateTimer.cancel()

    def set_default_navigation(self):
        self.BUTTON1[-1].setNavigation(self.BUTTON1[-1], self.BUTTON2[-1], self.BUTTON1[-1], self.BUTTON1[-1])
        self.BUTTON2[-1].setNavigation(self.BUTTON1[-1], self.BUTTON3[-1], self.BUTTON2[-1], self.BUTTON2[-1])
        self.BUTTON3[-1].setNavigation(self.BUTTON2[-1], self.BUTTON4[-1], self.BUTTON3[-1], self.BUTTON3[-1])
        self.BUTTON4[-1].setNavigation(self.BUTTON3[-1], self.BUTTON5[-1], self.BUTTON4[-1], self.BUTTON4[-1])
        self.BUTTON5[-1].setNavigation(self.BUTTON4[-1], self.BUTTON6[-1], self.BUTTON5[-1], self.BUTTON5[-1])
        self.BUTTON6[-1].setNavigation(self.BUTTON5[-1], self.BUTTON7[-1], self.BUTTON6[-1], self.BUTTON6[-1])
        self.BUTTON7[-1].setNavigation(self.BUTTON6[-1], self.BUTTON8[-1], self.BUTTON7[-1], self.BUTTON7[-1])
        self.BUTTON8[-1].setNavigation(self.BUTTON7[-1], self.BUTTON8[-1], self.BUTTON8[-1], self.BUTTON8[-1])

    def set_submenu(self, menu_pos):
        if self.getFocusId() == 111:
            label_textlist = self.LABEL1
            label_control = self.LABEL1[-1]
            self.selectedButton = 1
            button_control = self.BUTTON1[-1]
        elif self.getFocusId() == 112:
            label_textlist = self.LABEL2
            label_control = self.LABEL2[-1]
            self.selectedButton = 2
            button_control = self.BUTTON2[-1]
        elif self.getFocusId() == 113:
            label_textlist = self.LABEL3
            label_control = self.LABEL3[-1]
            self.selectedButton = 3
            button_control = self.BUTTON3[-1]
        elif self.getFocusId() == 114:
            label_textlist = self.LABEL4
            label_control = self.LABEL4[-1]
            self.selectedButton = 4
            button_control = self.BUTTON4[-1]
        elif self.getFocusId() == 115:
            label_textlist = self.LABEL5
            label_control = self.LABEL5[-1]
            self.selectedButton = 5
            button_control = self.BUTTON5[-1]
        elif self.getFocusId() == 116:
            label_textlist = self.LABEL6
            label_control = self.LABEL6[-1]
            self.selectedButton = 6
            button_control = self.BUTTON6[-1]
        elif self.getFocusId() == 117:
            label_textlist = self.LABEL7
            label_control = self.LABEL7[-1]
            self.selectedButton = 7
            button_control = self.BUTTON7[-1]
        elif self.getFocusId() == 118:
            label_textlist = self.LABEL8
            label_control = self.LABEL8[-1]
            self.selectedButton = 8
            button_control = self.BUTTON8[-1]
        else:
            return False
        if not len(label_textlist[EVENT.obc_screen][3]) > 0:
            self.selectedButton = -1
            self.selectedSubButton = -1
            return False
        else:
            if menu_pos < 0:
                menu_pos = len(label_textlist[EVENT.obc_screen][3]) - 1
            elif menu_pos > len(label_textlist[EVENT.obc_screen][3]) - 1:
                menu_pos = 0
            if label_textlist[EVENT.obc_screen][3][menu_pos]:
                label_control.setLabel(' ')
                time.sleep(0.1)
                color = 'FFFF7E00'
                label_control.setLabel('[COLOR %s]- %s -[/COLOR]' % (color, label_textlist[EVENT.obc_screen][3][menu_pos]))
                self.selectedSubButton = menu_pos
                button_control.setNavigation(button_control, button_control, button_control, button_control)
                return True
            self.selectedButton = -1
            self.selectedSubButton = -1
            return False

    def reset_submenu(self):
        self.selectedButton = -1
        self.selectedSubButton = -1
        self.update()
        self.set_default_navigation()

    def onSubmenuSelected(self, obc_screen, button, sub_button):
        if button == 1:
            obc_event = self.LABEL1[obc_screen][4]
        elif button == 2:
            obc_event = self.LABEL2[obc_screen][4]
        elif button == 3:
            obc_event = self.LABEL3[obc_screen][4]
        elif button == 4:
            obc_event = self.LABEL4[obc_screen][4]
        elif button == 5:
            obc_event = self.LABEL5[obc_screen][4]
        elif button == 6:
            obc_event = self.LABEL6[obc_screen][4]
        elif button == 7:
            obc_event = self.LABEL7[obc_screen][4]
        elif button == 8:
            obc_event = self.LABEL8[obc_screen][4]
        else:
            return
        obc_event[sub_button]()

    def counter_submenu(self):
        self.timeoutSubMenu = 2000
        thread = Thread(target=self._counter_submenu)
        thread.setDaemon(True)
        thread.start()

    def _counter_submenu(self):
        while self.timeoutSubMenu > 0:
            self.timeoutSubMenu -= 1
            time.sleep(0.001)

        self.reset_submenu()

    def some_obc_req(self):
        if self.obc_screen_next or EVENT.obc_screen == self.obc_screen_max:
            return
        log('OBCGUI: SOME REQUEST TICK', 3)
        EVENT.obc_voltage_req()
        time.sleep(0.2)
        EVENT.ike_get_state()
        time.sleep(0.2)
        EVENT.obc_coolant_req()

    def update(self, startup = False):

        def set_button_control(control, obc_screen):
            control[-1].setLabel(control[obc_screen][0])
            control[-1].setVisible(control[obc_screen][1])
            control[-1].setEnabled(control[obc_screen][2])

        def set_label_control(control, obc_screen):
            if control[obc_screen][0] != ' ':
                control[-1].setLabel(control[obc_screen][0]())
            else:
                control[-1].setLabel(' ')
            control[-1].setVisible(control[obc_screen][1])
            control[-1].setEnabled(control[obc_screen][2])

        def set_img_control(control, obc_screen):
            if len(control[obc_screen]) > 0:
                control[-1].setVisible(control[obc_screen][0]())
            else:
                control[-1].setVisible(False)

        set_button_control(self.MAINLABEL, EVENT.obc_screen)
        if EVENT.obc_screen == self.obc_screen_max:
            self.mainright.setVisible(False)
        else:
            self.mainright.setVisible(True)
        if EVENT.obc_screen == self.obc_screen_min:
            self.mainleft.setVisible(False)
        else:
            self.mainleft.setVisible(True)
        if not startup:
            if self.obc_screen_next or EVENT.obc_screen == self.obc_screen_max:
                return
        if self.selectedButton != 1:
            set_button_control(self.BUTTON1, EVENT.obc_screen)
            set_label_control(self.LABEL1, EVENT.obc_screen)
            set_img_control(self.IMAGE1, EVENT.obc_screen)
        if self.selectedButton != 2:
            set_button_control(self.BUTTON2, EVENT.obc_screen)
            set_label_control(self.LABEL2, EVENT.obc_screen)
            set_img_control(self.IMAGE2, EVENT.obc_screen)
        if self.selectedButton != 3:
            set_button_control(self.BUTTON3, EVENT.obc_screen)
            set_label_control(self.LABEL3, EVENT.obc_screen)
            set_img_control(self.IMAGE3, EVENT.obc_screen)
        if self.selectedButton != 4:
            set_button_control(self.BUTTON4, EVENT.obc_screen)
            set_label_control(self.LABEL4, EVENT.obc_screen)
            set_img_control(self.IMAGE4, EVENT.obc_screen)
        if self.selectedButton != 5:
            set_button_control(self.BUTTON5, EVENT.obc_screen)
            set_label_control(self.LABEL5, EVENT.obc_screen)
            set_img_control(self.IMAGE5, EVENT.obc_screen)
        if self.selectedButton != 6:
            set_button_control(self.BUTTON6, EVENT.obc_screen)
            set_label_control(self.LABEL6, EVENT.obc_screen)
            set_img_control(self.IMAGE6, EVENT.obc_screen)
        if self.selectedButton != 7:
            set_button_control(self.BUTTON7, EVENT.obc_screen)
            set_label_control(self.LABEL7, EVENT.obc_screen)
            set_img_control(self.IMAGE7, EVENT.obc_screen)
        if self.selectedButton != 8:
            set_button_control(self.BUTTON8, EVENT.obc_screen)
            set_label_control(self.LABEL8, EVENT.obc_screen)
            set_img_control(self.IMAGE8, EVENT.obc_screen)


class Kodi(object):
    log_level = 1

    def __init__(self):
        self.circle = ['\\', '/', '-']
        self.circle_counter = 0

    def up(self, steps = '01'):
        steps = int(steps, 16)
        while steps > 0:
            xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Up", "id": 1 }')
            steps -= 1
            time.sleep(0.02)

    def down(self, steps = '01'):
        steps = int(steps, 16)
        while steps > 0:
            xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Down", "id": 1 }')
            steps -= 1
            time.sleep(0.02)

    def left(self):
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Left", "id": 1 }')

    def right(self):
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Right", "id": 1 }')

    def back(self):
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Back", "id": 1 }')

    def select(self):
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Select", "id": 1 }')

    def home(self):
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Home", "id": 1 }')

    def track_play(self):
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Player.SetSpeed","params":{"playerid":%s,"speed":1 },"id":1}' % self.player_id())

    def track_pause(self):
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Player.PlayPause","params":{"playerid":%s,"play":false},"id":1}' % self.player_id())

    def track_seek(self, SPEED):
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Player.SetSpeed","params":{"playerid":%s,"speed":%s },"id":1}' % (self.player_id(), SPEED))

    def track_next(self):
        xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.GoTo", "params": { "playerid": %s, "to": "next" }, "id": 1}' % self.player_id())

    def track_prev(self):
        xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.GoTo", "params": { "playerid": %s, "to": "previous" }, "id": 1}' % self.player_id())

    def track_pos(self, milliseconds):
        xbmc.Player().seekTime(milliseconds)

    def track_title(self):
        log('get song', 3)
        if xbmc.Player().isPlayingAudio():
            log('music', 3)
            artist = xbmc.getInfoLabel('MusicPlayer.Artist')
            title = xbmc.getInfoLabel('MusicPlayer.Title')
            log('SONG MUSIC: "%s" - "%s"' % (artist, title), 2)
            if artist == title:
                return '%s' % artist
            if artist == '':
                return '%s' % title
            if title == '':
                return '%s' % artist
            return '%s - %s' % (artist, title)
        if xbmc.Player().isPlayingVideo():
            log('video', 3)
            title = xbmc.getInfoLabel('VideoPlayer.Title')
            file = xbmc.Player().getVideoInfoTag().getFile()
            log('SONG VIDEO: "%s"' % title, 2)
            if title != '':
                return '%s' % title
            else:
                return '%s' % file
        else:
            log('SONG: empty')
            return ''

    def action(self, action_event):
        if EVENT.modeaux:
            return note(heading='No Function in AUX-Mode', message='Key 1-6 sets Volumelevel', time=2000)
        if action_event == '':
            return note('No Function for this Button set', time=2000)
        log('KODI ACTION EVENT: %s' % action_event)
        xbmc.executebuiltin('%s' % action_event)

    def player_id(self):
        response = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.GetActivePlayers","id": 1}')
        log('JSONREPLY: ' + response, 3)
        try:
            playerID_tmp = findall('"playerid":(.*?),"', response)
            log('PLAYERID: %s' % playerID_tmp[0], 3)
            return playerID_tmp[0]
        except:
            log('PLAYERID: -1', 3)
            return '-1'

    def get_current_listlabel(self, old_label = ''):
        wait = 5
        while old_label == xbmc.getInfoLabel('ListItem.Label') and wait > 0:
            time.sleep(0.1)
            wait += -1

        new_label = xbmc.getInfoLabel('ListItem.Label')
        if new_label != '':
            return new_label
        return 'Kodi Control'

    def copy_log_file(self):
        from default import copy_log_file
        copy_log_file()

    @staticmethod
    def get_addon_setting(id):
        setting = ADDON.getSetting(id)
        if setting.upper() == 'TRUE':
            return True
        if setting.upper() == 'FALSE':
            return False
        return '%s' % setting

    @staticmethod
    def set_addon_setting(id, value):
        if type(value) == 'bool':
            ADDON.setSetting(id, 'true' if value else 'false')
        else:
            ADDON.setSetting(id, '%s' % value)

    @staticmethod
    def get_property(property, id = 10000):
        value = xbmcgui.Window(id).getProperty(property)
        return value

    @staticmethod
    def set_property(property, value, id = 10000):
        xbmcgui.Window(id).setProperty(property, value)

    @staticmethod
    def clear_property(property, id = 10000):
        value = xbmcgui.Window(id).clearProperty(property)

    def set_log_level(self, level):
        self.log_level = level

    def log(self, string, lvl = 1):
        if self.log_level < 1 and lvl > 0:
            return
        if lvl <= self.log_level <= 3 or self.log_level == 5 and lvl == 5:
            xbmc.log('IBUSCOMMUNICATOR: %s %s' % (self.circle[self.circle_counter], string), xbmc.LOGNOTICE)
            self.circle_counter += 1
            if self.circle_counter == 3:
                self.circle_counter = 0

    def note(self, heading, message = None, time = 5000):
        xbmcgui.Dialog().notification(heading='%s' % heading, message='%s' % message if message else '', icon=ICON, time=time)
        log('NOTIFICATION: "%s%s"' % (heading, ' - %s' % message if message else ''))

    def dialog_ok(label1, label2 = None, label3 = None):
        log('DIALOG_OK: "%s%s%s"' % (label1, ' - %s' % label2 if label2 else '', ' - %s' % label3 if label3 else ''))
        xbmcgui.Dialog().ok('IBusCommunicator', label1, label2, label3)


class Clicker():

    def __init__(self, double_click_interval, single_func, double_func, single_args = (), double_args = ()):
        self._queue = Queue()
        latch = Event()

        def handle_clicks():
            latch.set()
            while not EVENT.cancel_read_thread:
                self._queue.get()
                if EVENT.cancel_read_thread:
                    break
                try:
                    self._queue.get(True, double_click_interval)
                except Empty:
                    single_func(*single_args)
                else:
                    double_func(*double_args)

        thread = Thread(target=handle_clicks)
        thread.daemon = True
        thread.start()
        latch.wait()

    def click(self):
        self._queue.put(None)


class PlayerClass(xbmc.Player):

    def __init__(self):
        self.RESUMEONCE = False
        xbmc.Player.__init__(self)

    def onQueueNextItem(self):
        pass

    def onPlayBackStarted(self):
        EVENT.send_song_to_ike()
        EVENT.kodi_said_play()

    def onPlayBackEnded(self):
        pass

    def onPlayBackStopped(self):
        pass

    def onPlayBackPaused(self):
        pass

    def onPlayBackResumed(self):
        EVENT.kodi_said_play()

    def onPlayBackSeek(self, time, seekOffset):
        pass


class MonitorClass(xbmc.Monitor):

    def __init__(self):
        xbmc.Monitor.__init__(self)

    def onSettingsChanged(self):
        time.sleep(0.6)
        note('Settings changed')
        load_settings(True)


class GPIOClass(object):
    isOpen = False

    def open(self, pinnumber, mode = 'out', level = False, off_level = False):
        if pinnumber not in (0, 1, 4, 7, 8, 9, 10, 11, 14, 15, 17, 18, 21, 22, 23, 24, 25):
            raise ValueError('%s is not a valid GPIO' % pinnumber)
        self.pinnumber = pinnumber
        self.invert_signal = off_level
        os.popen('sudo chmod 222 /sys/class/gpio/export /sys/class/gpio/unexport')
        os.popen('sudo echo %s >/sys/class/gpio/export' % self.pinnumber)
        os.popen('sudo chmod 222 /sys/class/gpio/gpio%s/direction' % self.pinnumber)
        os.popen('sudo chmod 222 /sys/class/gpio/gpio%s/value' % self.pinnumber)
        os.popen('sudo echo %s >/sys/class/gpio/gpio%s/direction' % ('high' if self.invert_signal else 'low', self.pinnumber))
        if mode == 'out':
            if level:
                self.set()
            else:
                self.reset()
        elif mode == 'in':
            pass
        self.isOpen = True

    def _call(self, command):
        try:
            try:
                output = subprocess.check_output(command, stderr=subprocess.STDOUT)
            except subprocess.CalledProcessError as error:
                output = error.output
                return error.returncode

            return output
        finally:
            pass

    def close(self):
        if self.isOpen:
            os.popen('sudo echo %s > /sys/class/gpio/unexport' % self.pinnumber)

    def set(self):
        if self.isOpen:
            if self.invert_signal:
                os.popen('sudo echo "0" > /sys/class/gpio/gpio%s/value' % self.pinnumber)
            else:
                os.popen('sudo echo "1" > /sys/class/gpio/gpio%s/value' % self.pinnumber)

    def reset(self):
        if self.isOpen:
            if self.invert_signal:
                os.popen('sudo echo "1" > /sys/class/gpio/gpio%s/value' % self.pinnumber)
            else:
                os.popen('sudo echo "0" > /sys/class/gpio/gpio%s/value' % self.pinnumber)

    def toggle(self):
        if self.isOpen:
            pin_level = bool(os.popen('sudo cat /sys/class/gpio/gpio%s/value' % self.pinnumber))
            if pin_level:
                self.reset()
            else:
                self.set()

    def trigger(self, holdtime = 0.2):
        if self.isOpen:
            self.set()
            while holdtime > 0:
                holdtime -= 0.001
                time.sleep(0.001)

            self.reset()

    def get(self):
        if self.isOpen:
            value = bool(os.popen('sudo cat /sys/class/gpio/gpio%s/value' % self.pinnumber))
            return value


class IBusFace(object):

    def __init__(self):
        log('SERIAL_VERSION: %s' % serial.VERSION)
        self.serial_port = serial.Serial()
        self.serial_port.baudrate = 9600
        self.serial_port.bytesize = serial.EIGHTBITS
        self.serial_port.parity = serial.PARITY_EVEN
        self.serial_port.stopbits = serial.STOPBITS_ONE
        self.rts_state = False
        self.read_buffer = []
        self.read_counter = 2
        self.read_lock = Lock()
        self.read_error_counter = 0
        self.read_error_container = []
        KODI.set_property('msgerr_cnt', '0')
        self.cancel_read_thread = False
        self.read_thread = Thread(target=self._reading)
        self.read_thread.setDaemon(True)
        self.cts_thread = Thread(target=self._cts_watcher)
        self.cts_thread.setDaemon(True)
        self.cts_ok = False
        self.cts_counter = 0.0
        self.write_buffer = PriorityQueue()
        self.write_counter = 0
        self.write_counter_high = 0
        self.write_in_progress = False
        self.cancel_write_thread = False
        self.write_thread = Thread(target=self._writing)
        self.write_thread.setDaemon(True)

    @staticmethod
    def _calculate_checksum(packet):
        result = 0
        for value in packet:
            result ^= value

        return result

    def _cut_read_buffer(self, offset = 1):
        with self.read_lock:
            self.read_buffer = self.read_buffer[offset:]

    def _wait_free_bus(self, waiting = 17, timeout = 1000):
        cts_counter = 0
        while cts_counter < waiting:
            if self.serial_port.getCTS():
                cts_counter += 1
                if not timeout > 0:
                    return False
                timeout -= 1
            else:
                cts_counter = 0
                if not timeout > 0:
                    return False
                timeout -= 1
            time.sleep(0.001)

        return True

    def _reading(self):
        while not self.cancel_read_thread:
            while self.serial_port.inWaiting() > 0:
                self._read_char()
                time.sleep(0.0001)

        log('IBUS: Read/Write Thread finished', 2)

    def _writing(self):
        while not self.cancel_read_thread:
            try:
                prio, write_counter, data = self.write_buffer.get(timeout=0.0001)
                try:
                    while self.cts_counter < 5.0 or 11.0 < self.cts_counter < 17.5:
                        time.sleep(0.0001)

                    self.serial_port.write(data)
                    self.serial_port.flush()
                    self.cts_counter = 0.0
                except serial.SerialException:
                    self.write_buffer.put((prio, write_counter, data))

            except Empty:
                pass

    def _cts_watcher(self):
        while not self.cancel_read_thread:
            if self.serial_port.getCTS():
                self.cts_counter += 0.1
                time.sleep(0.0001)
            else:
                self.cts_counter = 0.0

        log('IBUS: CTS Thread finished', 2)

    def _read_char(self):
        try:
            with self.read_lock:
                self.read_buffer.append(ord(self.serial_port.read()))
        except:
            log('IBUS: Hit a serialException')
            return

    def set_port(self, device_path):
        self.serial_port.port = device_path

    def connect(self):
        self.serial_port.open()
        self.serial_port.setDTR(1)
        self.serial_port.setRTS(0)
        if not self._wait_free_bus(120, 3000):
            log('IBUS: Can not locate free Bus')
            return False
        self.serial_port.flushInput()
        self.read_thread.start()
        self.cts_thread.start()
        self.write_thread.start()
        return True

    def disconnect(self):
        self.cancel_write_thread = True
        self.cancel_read_thread = True
        time.sleep(0.6)
        self.serial_port.close()

    @property
    def ntsc(self):
        return self.rts_state

    @ntsc.setter
    def ntsc(self, value):
        if self.rts_state == value:
            return
        self.serial_port.setRTS(value)
        self.rts_state = value

    def read_bus_packet(self):
        if self.cancel_read_thread:
            raise RuntimeError('<read_thread> was canceled')
        try:
            data_length = self.read_buffer[1]
        except:
            raise RuntimeError('<read_buffer> list is not big enough')

        if data_length < 3 or data_length > 37:
            self.read_error_container.append(self.read_buffer[0])
            self._cut_read_buffer()
            raise ValueError('IBUS: Length of < 3 or > 37 found (%s)' % data_length)
        else:
            buffer_len = len(self.read_buffer)
            if buffer_len < 5 or buffer_len < data_length + 2:
                raise RuntimeError('<read_buffer> list < %s to get input values' % (data_length + 2))
            message = self.read_buffer[:data_length + 2]
            if self._calculate_checksum(message) == 0:
                if len(self.read_error_container) > 0:
                    error_hex_string = ' '.join([ '%02X' % i for i in self.read_error_container ])
                    if self.read_error_container in [[4,
                      4,
                      191,
                      255], [128, 4, 239], [128,
                      4,
                      191,
                      255]]:
                        log('# IBUS: READ-ERR: %s (no counter increase)' % error_hex_string, 5)
                    else:
                        log('# IBUS: READ-ERR: %s' % error_hex_string, 5)
                        self.read_error_counter += len(self.read_error_container)
                        KODI.set_property('msgerr_cnt', '%s' % self.read_error_counter)
                    self.read_error_container = []
                log('IBUS-READ: %s' % ' '.join([ '%02X' % i for i in message ]), 5)
                self._cut_read_buffer(data_length + 2)
                self.read_counter += 1
                return {'src': message[0],
                 'len': data_length,
                 'dst': message[2],
                 'data': message[3:data_length + 1],
                 'xor': message[-1]}
            self.read_error_container.append(self.read_buffer[0])
            self._cut_read_buffer()
            raise ValueError('IBUS: Corrupt packet found')

    def write_bus_packet(self, src, dst, data, highprio = False, veryhighprio = False, repeat = 1):
        try:
            packet = [src, len(data) + 2, dst]
            packet.extend(data)
        except:
            packet = [int(src, 16), len(data) + 2, int(dst, 16)]
            packet.extend([ int(s, 16) for s in data ])

        packet.append(self._calculate_checksum(packet))
        while repeat > 0:
            repeat -= 1
            if veryhighprio:
                self.write_buffer.put_nowait((0, 0, ''.join([ '%c' % i for i in packet ])))
            else:
                self.write_buffer.put_nowait((0 if highprio else 1, self.write_counter, ''.join([ '%c' % i for i in packet ])))
            self.write_counter += 1

    def write_hex_message(self, hexstring):
        hexstring_tmp = hexstring.split(' ')
        src = hexstring_tmp[0]
        dst = hexstring_tmp[2]
        data = hexstring_tmp[3:-1]
        self.write_bus_packet(src, dst, data)


class EventClass(object):
    TUNER_MODES = [[165,
      98,
      1,
      1,
      32,
      70,
      77,
      68],
     [165,
      98,
      1,
      1,
      32,
      32,
      70,
      77],
     [165,
      98,
      1,
      1,
      32,
      32,
      77,
      87],
     [165,
      98,
      1,
      1,
      32,
      77,
      87,
      65],
     [165,
      98,
      1,
      1,
      32,
      32,
      76,
      87],
     [165,
      98,
      1,
      1,
      32,
      76,
      87,
      65],
     [165,
      98,
      1,
      1,
      32,
      32,
      83,
      87],
     [165,
      98,
      1,
      1,
      32,
      83,
      87,
      65],
     [165,
      98,
      1,
      65,
      32,
      32,
      70,
      77,
      32],
     [165,
      98,
      1,
      65,
      32,
      70,
      77,
      68,
      32],
     [165,
      98,
      1,
      65,
      32,
      77,
      87,
      32,
      32],
     [165,
      98,
      1,
      65,
      32,
      77,
      87,
      65,
      32],
     [165,
      98,
      1,
      65,
      32,
      76,
      87,
      32,
      32],
     [165,
      98,
      1,
      65,
      32,
      76,
      87,
      65,
      32],
     [165,
      98,
      1,
      65,
      32,
      83,
      87,
      32,
      32],
     [165,
      98,
      1,
      65,
      32,
      83,
      87,
      65,
      32],
     [165,
      98,
      1,
      65,
      70,
      77,
      32],
     [165,
      98,
      1,
      65,
      70,
      77,
      68],
     [165,
      98,
      1,
      65,
      77,
      87,
      32],
     [165,
      98,
      1,
      65,
      77,
      87,
      65],
     [165,
      98,
      1,
      65,
      76,
      87,
      32],
     [165,
      98,
      1,
      65,
      76,
      87,
      65],
     [165,
      98,
      1,
      65,
      83,
      87,
      32],
     [165,
      98,
      1,
      65,
      83,
      87,
      65]]
    cancel_ike_thread = False
    cancel_pdc_thread = False
    cancel_read_thread = False
    ike_states = {'run_once': False,
     'handbrake': False,
     'motor_running': False,
     'vehicle_driving': False,
     'gear_pos': 'X',
     'aux_heat': False,
     'aux_vent': False}
    gm_states = {'run_once': False,
     'driverdoor': False,
     'passangerdoor': False,
     'driverreardoor': False,
     'passangerreardoor': False,
     'doorsopen': False,
     'zvunlocked': False,
     'zvlocked': False,
     'zvlockstate': False,
     'zvhardlocked': False,
     'zvtoggled': False,
     'indoorlights': False,
     'driverwindow': False,
     'passengerwindow': False,
     'driverrearwindow': False,
     'passangerrearwindow': False,
     'sunroof': False,
     'trunk': False,
     'bonnet': False,
     'trunkbuttonpress': False}
    lcm_states = {'run_once': False,
     'park': False,
     'low_beam': False,
     'high_beam': False,
     'fog_front': False,
     'fog_rear': False,
     'turn_left': False,
     'turn_right': False,
     'turn_fast_blink': False,
     'tail': False,
     'reverse': False,
     'hazard': False,
     'dim_level': 0,
     'diag_dim_level': 120}
    reverse_hold = False
    clock_hold = False
    bm_next_hold = False
    bm_prev_hold = False
    nav_hold = False
    select_hold = False
    stw_up_hold = False
    stw_dn_hold = False
    stw_rt_hold = False
    stw_speak_hold = False
    stw_nav = False
    btn_bcpres = False
    btnx_hold = {1: False,
     2: False,
     3: False,
     4: False,
     5: False,
     6: False}
    ign_mode = -1
    lcm_on = 0
    lcm_delay = -1
    remote_state = 2
    remote_accept_cmd = True
    navmenu = False
    tonemenu = False
    selectmenu = False
    tpmenu = False
    piaktiv = False
    pass_bm_buttons = False
    cancel_ike_text = False
    cdc_play = True
    cdc_pause = False
    cdc_scan = False
    cdc_seek = False
    cdc_rnd = False
    track_change_counter = 0
    cdc_track = 152
    cds_loaded = 64
    phone_mute = False
    got_audiomode = False
    modefm = False
    modecd = False
    modetape = False
    modeaux = False
    modecis = False
    modealways = False
    device_path = None
    car_model = None
    cdc_emu = False
    gpio_ntsc = False
    dsp_cd = False
    dsp_tuner = False
    ike_display = False
    ike_track = False
    wel_ike = False
    wel_iketxt = None
    wel_iketxt_hold = False
    text_scrollspeed = 220
    welcome_on_boot = True
    wel_light = False
    wel_light_time = 10
    lev_light = False
    lev_light_time = 10
    keyin_off = False
    doors_off = False
    lev_light_ign_off = False
    day_time = False
    day_time_start = '00:00'
    day_time_end = '00:00'
    mir_unfold = False
    mir_fold = False
    seek_sec = 3000
    seek_max = 32
    use_stw_nav = False
    navhold_event = False
    inv_navturnbtn = False
    gpio_gear_shift = False
    gpio_gear_shift_trigger_time = 500
    gpio_gear_shift_up = GPIOClass()
    gpio_gear_shift_down = GPIOClass()
    comfort_blink = False
    comfort_blink_time = 1500
    turn_light = False
    turn_light_time = 7000
    turn_light_max_speed = 50
    obc_screen = 0
    obc_time = [None, None]
    obc_date = [None, None]
    obc_cons1 = '---'
    obc_cons2 = '---'
    obc_range = '---'
    obc_dist = '---'
    obc_arr = '--:--'
    obc_limit = '---'
    obc_avg = '---'
    obc_stpwtch = '----'
    obc_tmr1 = '--:--'
    obc_tmr1ind = False
    obc_tmr2 = '--:--'
    obc_tmr2ind = False
    obc_limitind = False
    obc_memoind = False
    obc_outtemp = '--.-'
    obc_fuellevel = '--'
    obc_fuellevel_low = True
    obc_speed_kmh = 0
    obc_speed_mph = 0
    obc_rpm = 0
    obc_coolant = 0
    obc_auxheat = False
    obc_auxvent = False
    obc_voltage = None
    obc_req_runs = False
    obc_settime = 0
    obc_req_runonce = False
    pdc_on = False
    pdc_type = 0
    pdc_timeout = 30
    pdc_timeout_off = False
    pdc_bg = os.path.join(ADDONPDCPATH, 'bgs', 'default.png')
    zv_auto_lock = False
    zv_auto_lock_speed = 6
    zv_auto_unlock_handbrake = False
    zv_auto_unlock_ign1 = False
    zv_auto_unlock_gear_p = False
    zv_auto_unlock_door_open = False
    map_auto_zoom = False
    map_states = {'zoom_level': -1,
     'speed_old': -1,
     100: (176, 127, [170, 16, 1]),
     200: (176, 127, [170, 16, 2]),
     500: (176, 127, [170, 16, 4]),
     1000: (176, 127, [170, 16, 16]),
     2000: (176, 127, [170, 16, 17]),
     5000: (176, 127, [170, 16, 18])}
    nav_toggle_map = False
    flash_to_pass = False
    flash_to_pass_low_beam = False
    flash_to_pass_fog = False
    bm_sensor = False
    bm_sensor_level = 50

    def __init__(self):
        self.ike_text_scrolling = False
        self.cancel_turn_left = False
        self.turning_left = False
        self.turning_fog_left = False
        self.cancel_turn_right = False
        self.turning_right = False
        self.turning_fog_right = False
        self.pdc_req_cancel = False
        self.pdc_req_running = False
        self.pdc_counter = 30
        self.bm_sensor_brightness = None

    def read_ibus_packages(self):
        while not self.cancel_read_thread:
            try:
                packet = IBUS.read_bus_packet()
            except IndexError:
                pass
            except RuntimeError:
                pass
            except ValueError:
                pass
            else:
                thread = Thread(target=self.manage, args=(packet['src'], packet['dst'], packet['data']))
                thread.setDaemon(True)
                thread.start()

            time.sleep(0.001)

    def manage(self, src, dst, dat):
        if src == 208:
            if dat[0] == 91:
                self.lcm_state(dat)
                log('MANAGE: LCM STATE: %s' % ' '.join([ '%02X' % i for i in dat[1:] ]))
                return
            if dat[0] == 92:
                log('MANAGE: LCM DIM STATE')
                self.lcm_dim_level(dat)
                return
            if dst == 63 and dat[0] == 160:
                self.lcm_diag_state(dat)
                return
        if dst == 24:
            if dat == [1]:
                self.cdch_alive()
                log('MANAGE: RAD ASKED FOR CDC ALIVE')
                return
            if dat == [56, 0, 0]:
                self.cdch_state()
                log('MANAGE: RAD ASKED FOR CDC STATE')
                return
            if dat == [56, 3, 0]:
                self.cdch_play()
                log('MANAGE: RAD SAID PLAY')
                return
            if dat == [56, 2, 0]:
                self.cdch_pause()
                log('MANAGE: RAD SAID PAUSE')
                return
            if dat == [56, 7, 0]:
                self.cdch_scan(False)
                log('MANAGE: RAD SAID SCAN OFF')
                return
            if dat == [56, 7, 1]:
                self.cdch_scan(True)
                log('MANAGE: RAD SAID SCAN ON')
                return
            if dat == [56, 1, 0]:
                self.cdch_stop()
                log('MANAGE: RAD SAID STOP')
                return
            if dat == [56, 4, 1]:
                self.cdch_ffwd()
                log('MANAGE: RAD SAID FFWD')
                return
            if dat == [56, 4, 0]:
                self.cdch_frwd()
                log('MANAGE: RAD SAID FRWD')
                return
            if dat == [56, 10, 0]:
                self.cdch_next()
                log('MANAGE: RAD SAID NEXT')
                return
            if dat == [56, 10, 1]:
                self.cdch_prev()
                log('MANAGE: RAD SAID PREV')
                return
            if dat == [56, 8, 0]:
                self.cdch_rnd(False)
                log('MANAGE: RAD SAID RANDOM OFF')
                return
            if dat == [56, 8, 1]:
                self.cdch_rnd(True)
                log('MANAGE: RAD SAID RANDOM ON')
                return
        if dst in (191, 104):
            if dat == [2, 0, 3]:
                self.cdch_state()
                log("MANAGE: RAD SAID I'M READY")
                return
            if dat == [78, 1, 0]:
                self.gt_tv_on()
                log('MANAGE: GT TV ON')
                return
            if dat == [78, 0, 0]:
                self.gt_tv_off()
                log('MANAGE: GT TV OFF')
                return
            if dat[0] == 17:
                if dat[1] == 0:
                    log('MANAGE: IGN_OFF')
                    self.ign_off()
                    return
                if dat[1] == 1:
                    log('MANAGE: IGN_RAD')
                    self.ign_acc()
                    return
                if dat[1] == 3:
                    log('MANAGE: IGN_ON')
                    self.ign_on()
                    return
                if dat[1] == 7:
                    log('MANAGE: IGN_START')
                    self.ign_start()
                    return
            if dat[0] == 114:
                log('MANAGE: REMOTE KEY', 2)
                self.remote_key(dat)
                return
            if dat[0] == 25:
                self.obc_coolant_put(dat)
                return
            if dat[0] == 24:
                self.obc_speed_rpm_put(dat)
                return
            if dat[0] == 19:
                log('MANAGE: IKE STATE', 2)
                self.ike_state(dat)
                return
        if src == 96:
            if dat[0] == 90:
                log('MANAGE: PDC TURNED ON', 1)
                self.pdc_req_start()
            if dat[0] == 160:
                log('MANAGE: PDC VALUE REPLY', 2)
                self.pdc_set_state(dat)
        if src == 0:
            if dat[0] == 122:
                log('MANAGE: GM STATE', 2)
                self.gm_state(dat)
        if dst == 104:
            if dat == [72, 64]:
                log('MANAGE: BM_NEXT_HOLD')
                self.btn_bm_next_hold()
                return
            if dat == [72, 128]:
                log('MANAGE: BM_NEXT_REL')
                self.btn_bm_next_rel()
                return
            if dat == [72, 80]:
                log('MANAGE: BM_PREV_HOLD')
                self.btn_bm_prev_hold()
                return
            if dat == [72, 144]:
                log('MANAGE: BM_PREV_REL')
                self.btn_bm_prev_rel()
                return
            if dat == [72, 84]:
                log('MANAGE: BM_REVERSE_HOLD')
                self.btn_bm_reverse_hold()
                return
            if dat == [72, 148]:
                log('MANAGE: BM_REVERSE_REL')
                self.btn_bm_reverse_rel()
                return
            if dat == [72, 132]:
                log('MANAGE: BM_TONE_REL')
                self.btn_bm_tone_rel()
                return
            if dat == [72, 81]:
                log('MANAGE: BM_BTN1_HOLD')
                self.btn_bm_x_hold(7)
                return
            if dat == [72, 145]:
                log('MANAGE: BM_BTN1_REL')
                self.btn_bm_x_rel(1)
                return
            if dat == [72, 65]:
                log('MANAGE: BM_BTN2_HOLD')
                self.btn_bm_x_hold(8)
                return
            if dat == [72, 129]:
                log('MANAGE: BM_BTN2_REL')
                self.btn_bm_x_rel(2)
                return
            if dat == [72, 82]:
                log('MANAGE: BM_BTN3_HOLD')
                self.btn_bm_x_hold(9)
                return
            if dat == [72, 146]:
                log('MANAGE: BM_BTN3_REL')
                self.btn_bm_x_rel(3)
                return
            if dat == [72, 66]:
                log('MANAGE: BM_BTN4_HOLD')
                self.btn_bm_x_hold(10)
                return
            if dat == [72, 130]:
                log('MANAGE: BM_BTN4_REL')
                self.btn_bm_x_rel(4)
                return
            if dat == [72, 83]:
                log('MANAGE: BM_BTN5_HOLD')
                self.btn_bm_x_hold(11)
                return
            if dat == [72, 147]:
                log('MANAGE: BM_BTN5_REL')
                self.btn_bm_x_rel(5)
                return
            if dat == [72, 67]:
                log('MANAGE: BM_BTN6_HOLD')
                self.btn_bm_x_hold(12)
                return
            if dat == [72, 131]:
                log('MANAGE: BM_BTN6_REL')
                self.btn_bm_x_rel(6)
                return
        if src == 80:
            if dat == [50, 17]:
                log('MANAGE: STW_VOL_UP')
                self.btn_stw_vol_up()
                return
            if dat == [50, 16]:
                log('MANAGE: STW_VOL_DOWN')
                self.btn_stw_vol_down()
                return
            if dat == [59, 17]:
                log('MANAGE: STW_UP_HOLD')
                self.btn_stw_up_hold()
                return
            if dat == [59, 33]:
                log('MANAGE: STW_UP_REL')
                self.btn_stw_up_rel()
                return
            if dat == [59, 24]:
                log('MANAGE: STW_DN_HOLD')
                self.btn_stw_down_hold()
                return
            if dat == [59, 40]:
                log('MANAGE: STW_DN_REL')
                self.btn_stw_down_rel()
                return
            if dat == [59, 18]:
                log('MANAGE: STW_R/T_HOLD')
                self.btn_stw_rt_hold()
                return
            if dat in [[59, 34], [1]]:
                log('MANAGE: STW_R/T_REL')
                self.btn_stw_rt_rel()
                return
            if dat == [59, 64]:
                log('MANAGE: STW_R/T_ON with Phone')
                self.btn_bc_pres()
                self.btn_stw_rt_on()
                return
            if dat == [59, 0]:
                log('MANAGE: STW_R/T_OFF with Phone')
                self.btn_stw_rt_off()
                return
            if dat == [59, 128]:
                log('MANAGE: STW_SPEAK_PRES')
                return
            if dat == [59, 144]:
                log('MANAGE: STW_SPEAK_HOLD')
                self.btn_stw_speak_hold()
                return
            if dat == [59, 160]:
                log('MANAGE: STW_SPEAK_REL')
                self.btn_stw_speak_rel()
                return
        if dst == 128:
            if dat[:11] == [35,
             65,
             48,
             32,
             32,
             32,
             84,
             82,
             3,
             32,
             57]:
                self.clear_ike(100)
                log('MANAGE: Clear IKE Track Message in IKE')
                return
            if dat[:16] == [35,
             65,
             48,
             32,
             32,
             32,
             32,
             32,
             3,
             67,
             68,
             67,
             32,
             55,
             45,
             57]:
                self.clear_ike(100)
                log('MANAGE: Clear IKE Track Message in IKE')
                return
            if dat[:16] == [35,
             98,
             48,
             7,
             32,
             32,
             32,
             32,
             32,
             8,
             67,
             68,
             32,
             55,
             45,
             57]:
                self.clear_ike(100)
                log('MANAGE: Clear IKE Track Message in IKE')
                return
        if dst == 59:
            if dat == [165,
             98,
             1,
             65,
             67,
             68,
             55]:
                self.gt_mode_cd()
                log('MANAGE: TEXT: CD7')
                return
            if dat[:7] == [165,
             98,
             1,
             65,
             67,
             68,
             55]:
                self.gt_mode_cd()
                log('MANAGE: TEXT: CD7')
                return
            if dat[:7] == [165,
             98,
             1,
             65,
             67,
             68,
             54]:
                self.gt_mode_cis()
                log('MANAGE: TEXT: CD6 CIS')
                return
            if dat == [165,
             98,
             1,
             65,
             67,
             68]:
                self.gt_mode_tape()
                log('MANAGE: TEXT: CD E46 BM-CD')
                return
            if dat[:3] == [35, 98, 16]:
                if dat[3:7] == [84,
                 82,
                 32,
                 32]:
                    self.gt_mode_cd()
                    self.cdch_play()
                    log('MANAGE: TEXT: "TR  "')
                    return
                if dat[3:6] == [67, 68, 67]:
                    self.gt_mode_cd()
                    log('MANAGE: TEXT: CDC...')
                    return
                if dat[3:10] == [78,
                 79,
                 32,
                 68,
                 73,
                 83,
                 67] or dat[3:10] == [78,
                 111,
                 32,
                 68,
                 105,
                 115,
                 99]:
                    log('MANAGE: TEXT: NO DISC')
                    return
                if dat[3:7] == [84,
                 65,
                 80,
                 69]:
                    self.gt_mode_tape()
                    log('MANAGE: TEXT: TAPE...')
                    return
                if dat[3:10] == [78,
                 79,
                 32,
                 84,
                 65,
                 80,
                 69]:
                    self.gt_mode_tape()
                    log('MANAGE: TEXT: NO TAPE')
                    return
                if dat[3:6] == [67, 68, 32]:
                    self.gt_mode_tape()
                    log('MANAGE: TEXT: CD / E46 CD Screen')
                    return
                if dat[3:6] == [65, 85, 88]:
                    self.gt_mode_aux()
                    log('MANAGE: TEXT: AUX ')
                    return
            if dat[:9] == [35,
             196,
             32,
             67,
             68,
             32,
             55,
             45,
             57]:
                self.gt_mode_cd()
                log('MANAGE: TEXT: CD 7-9...')
                return
            if dat[:7] == [35,
             80,
             32,
             84,
             65,
             80,
             69]:
                self.gt_mode_tape()
                log('MANAGE: TEXT: TAPE')
                return
            if dat[:10] == [35,
             80,
             32,
             78,
             79,
             32,
             84,
             65,
             80,
             69]:
                self.gt_mode_tape()
                log('MANAGE: TEXT: NO TAPE')
                return
            if dat[:3] == [35, 64, 32] or dat[:3] == [35, 80, 32]:
                self.gt_mode_radio()
                self.cdch_state()
                log('MANAGE: TEXT: what ever')
                return
            if dat[:18] == [35,
             98,
             48,
             32,
             32,
             7,
             32,
             32,
             32,
             32,
             32,
             8,
             67,
             68,
             32,
             55,
             45,
             57]:
                self.gt_mode_cd()
                log('MANAGE: TEXT: CD 7-9...')
                return
            if dat[:16] == [35,
             98,
             48,
             32,
             32,
             7,
             32,
             32,
             32,
             32,
             32,
             8,
             84,
             65,
             80,
             69]:
                self.gt_mode_tape()
                log('MANAGE: TEXT: TAPE')
                return
            if dat[:19] == [35,
             98,
             48,
             32,
             32,
             7,
             32,
             32,
             32,
             32,
             32,
             8,
             78,
             79,
             32,
             84,
             65,
             80,
             69]:
                self.gt_mode_tape()
                log('MANAGE: TEXT: NO TAPE')
                return
            if dat in self.TUNER_MODES:
                self.gt_mode_radio()
                self.cdch_state()
                log('MANAGE: TEXT: FMD')
                return
            if dat == [70, 1]:
                self.gt_nav_menu_on()
                log('MANAGE: NAV MENU ON')
                return
            if dat == [70, 2]:
                self.gt_radio_menu_off()
                log('MANAGE: RADIO MENU OFF')
                return
            if dat == [70, 4]:
                log('MANAGE: SELECT MENU OFF')
                return
            if dat == [70, 8]:
                self.gt_tone_menu_off()
                log('MANAGE: TONE MENU OFF')
                return
            if dat == [70, 12]:
                self.gt_select_tone_menu_off()
                log('MANAGE: TONE + SELECT MENU OFF')
                return
            if dat[:8] == [33,
             96,
             0,
             64,
             84,
             80,
             32,
             32]:
                log('MANAGE: TP MENU ON')
                return
            if dat[:4] == [165,
             98,
             1,
             65]:
                return
            if dat == [33,
             96,
             0,
             7,
             80,
             54,
             58,
             32,
             78,
             79,
             32,
             68,
             73,
             83,
             67,
             32,
             32,
             32,
             6,
             6,
             6]:
                self.gt_select_tone_menu_off()
                log('MANAGE: Bottom Right " P6: NO DISC   "')
                return
            if dat[0] == 73 and ('%02X' % dat[1])[0] == '8':
                steps = ('%02X' % dat[1])[1]
                log('MANAGE: BM_NAV_KNOB_RIGHT -steps: %s' % int(steps, 16))
                self.btn_bm_nav_right(steps)
                return
            if dat[0] == 73 and ('%02X' % dat[1])[0] == '0':
                steps = ('%02X' % dat[1])[1]
                log('MANAGE: BM_NAV_KNOB_LEFT -steps: %s' % int(steps, 16))
                self.btn_bm_nav_left(steps)
                return
            if dat == [72, 133]:
                log('MANAGE: BM_NAV_KNOB_REL')
                self.btn_bm_nav_rel()
                return
            if dat == [72, 69]:
                log('MANAGE: BM_NAV_KNOB_HOLD')
                self.btn_bm_nav_hold()
                return
        if dst == 200:
            if dat == [59, 144]:
                log('MANAGE: STW_SPEAK_HOLD')
                self.btn_stw_speak_hold()
                return
            if dat == [59, 160]:
                log('MANAGE: STW_SPEAK_REL')
                self.btn_stw_speak_rel()
                return
        if dst == 240:
            if dat == [74, 255]:
                self.radio_led_on()
                log('MANAGE: RADIO LED TURNED ON')
                return
            if dat == [74, 0]:
                self.radio_led_off()
                log('MANAGE: RADIO LED TURNED OFF')
                return
        if dst in (231, 255):
            if dat[:2] == [36, 1]:
                log('OBC: TIME', 2)
                self.obc_time_put(dat)
                return
            if dat[:2] == [36, 2]:
                log('OBC: DATE', 2)
                self.obc_date_put(dat)
                return
            if dat[:2] == [36, 3]:
                log('OBC: OUTTEMP', 2)
                self.obc_outtemp_put(dat)
                return
            if dat[:2] == [36, 4]:
                log('OBC: CONS1', 2)
                self.obc_cons1_put(dat)
                return
            if dat[:2] == [36, 5]:
                log('OBC: CONS2', 2)
                self.obc_cons2_put(dat)
                return
            if dat[:2] == [36, 6]:
                log('OBC: RANGE', 2)
                self.obc_range_put(dat)
                return
            if dat[:2] == [36, 7]:
                log('OBC: DIST', 2)
                self.obc_dist_put(dat)
                return
            if dat[:2] == [36, 8]:
                log('OBC: ARR', 2)
                self.obc_arr_put(dat)
                return
            if dat[:2] == [36, 9]:
                log('OBC: LIMIT', 2)
                self.obc_limit_put(dat)
                return
            if dat[:2] == [36, 10]:
                log('OBC: AVG', 2)
                self.obc_avg_put(dat)
                return
            if dat[:2] == [36, 14]:
                log('OBC: STPWTCH', 2)
                self.obc_stpwtch_put(dat)
                return
            if dat[:2] == [36, 15]:
                log('OBC: TMR1', 2)
                self.obc_tmr1_put(dat)
                return
            if dat[:2] == [36, 16]:
                log('OBC: TMR2', 2)
                self.obc_tmr2_put(dat)
                return
            if dat[0] == 42:
                log('OBC: IND', 2)
                self.obc_ind_put(dat)
            if src == 200 and dat[:1] == [43]:
                log('PHONE: STATE')
                self.phone_state(dat)
                return
            if dat == [71, 0, 79]:
                log('MANAGE: BM_SEL_HOLD')
                self.btn_bm_select_hold()
                return
            if dat == [71, 0, 143]:
                log('MANAGE: BM_SEL_REL')
                self.btn_bm_select_rel()
                return
            if dat == [71, 0, 56]:
                log('MANAGE: BM_INFO_PRES')
                self.btn_bm_info_pres()
                return
            if dat == [71, 0, 184]:
                log('MANAGE: BM_INFO_REL')
                return
            if dat == [72, 71]:
                log('MANAGE: BM_CLK_HOLD')
                self.btn_bm_clock_hold()
                return
            if dat == [72, 135]:
                log('MANAGE: BM_CLK_REL')
                self.btn_bm_clock_rel()
                return
            if dat == [72, 176]:
                log('MANAGE: BM_SCREEN_REL')
                self.btn_bm_screen_rel()
                return
            if dat == [87, 2]:
                log('MANAGE: IKE_BC_PRES')
                self.btn_bc_pres()
                return
        if src == 68:
            if dat[0] == 116:
                log('MANAGE: EWS_KEY')
                self.ews_key(dat)
                return
        if dst == 106:
            if dat == [54, 160]:
                if self.dsp_tuner:
                    self.dsp_set_tuner()
        if dst == 63:
            if src == 240 and dat[0] == 160:
                self.bm_set_state(dat)
                return
            if src == 127 and dat[0] == 160:
                self.obc_voltage_put(dat)
                return

    def cdch_init(self):
        if not self.cdc_emu:
            return
        IBUS.write_bus_packet(24, 255, [2, 1], True)
        xbmc.sleep(50)
        IBUS.write_bus_packet(24, 255, [2, 0], True)
        xbmc.sleep(100)
        IBUS.write_bus_packet(24, 104, [57,
         2,
         9,
         0,
         self.cds_loaded,
         0,
         7,
         153], True)

    def cdch_alive(self):
        if not self.cdc_emu:
            return
        IBUS.write_bus_packet(24, 255, [2, 0], True)

    def cdch_state(self):
        if self.modecis:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             9,
             0,
             32,
             0,
             6,
             153], True)
        if not self.cdc_emu:
            return
        if self.track_change_counter < 20:
            self.cdc_track = 152
        if self.track_change_counter >= 20:
            self.cdc_track = 151
        if self.track_change_counter > 40:
            self.track_change_counter = 0
        self.track_change_counter += 1
        if self.cdc_scan:
            IBUS.write_bus_packet(24, 104, [57,
             7,
             153,
             0,
             self.cds_loaded,
             0,
             7,
             self.cdc_track], True)
            return
        if self.cdc_seek:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             137,
             0,
             self.cds_loaded,
             0,
             7,
             self.cdc_track], True)
            return
        if self.cdc_rnd:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             169,
             0,
             self.cds_loaded,
             0,
             7,
             self.cdc_track], True)
            return
        if self.cdc_play:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             0,
             0,
             self.cds_loaded,
             0,
             7,
             self.cdc_track], True)
        elif self.cdc_pause:
            IBUS.write_bus_packet(24, 104, [57,
             1,
             0,
             0,
             self.cds_loaded,
             0,
             7,
             self.cdc_track], True)
        else:
            IBUS.write_bus_packet(24, 104, [57,
             0,
             140,
             0,
             self.cds_loaded,
             0,
             7,
             self.cdc_track], True)

    def cdch_play(self):
        if not self.cdc_emu:
            return
        if self.cdc_seek:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             137,
             0,
             self.cds_loaded,
             0,
             7,
             self.cdc_track], True)
            self.cdc_seek = False
        if self.cdc_rnd:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             169,
             0,
             self.cds_loaded,
             0,
             7,
             self.cdc_track], True)
            self.cdc_rnd = False
        if self.cdc_scan:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             153,
             0,
             self.cds_loaded,
             0,
             7,
             self.cdc_track], True)
        else:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             2,
             0,
             self.cds_loaded,
             0,
             7,
             self.cdc_track], True)
        self.cdc_play = True
        self.cdc_pause = False

    def cdch_pause(self):
        if not self.cdc_emu:
            return
        IBUS.write_bus_packet(24, 104, [57,
         1,
         0,
         0,
         self.cds_loaded,
         0,
         7,
         self.cdc_track], True)
        self.cdc_play = False

    def cdch_stop(self):
        if not self.cdc_emu:
            return
        IBUS.write_bus_packet(24, 104, [57,
         0,
         140,
         0,
         self.cds_loaded,
         0,
         7,
         self.cdc_track], True)
        self.cdc_play = False
        self.cdc_scan = False
        self.cdc_seek = False
        self.cdc_rnd = False
        self.cdc_pause = True

    def cdch_scan(self, enabled):
        if not self.cdc_emu:
            return
        xbmc.sleep(250)
        if enabled:
            self.cdc_scan = True
            IBUS.write_bus_packet(24, 104, [57,
             7,
             153,
             0,
             self.cds_loaded,
             0,
             7,
             self.cdc_track], True)
        else:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             137,
             0,
             self.cds_loaded,
             0,
             7,
             self.cdc_track], True)
            self.cdc_scan = False

    def cdch_rnd(self, enabled):
        if not self.cdc_emu:
            return
        xbmc.sleep(250)
        if enabled:
            self.cdc_rnd = True
            IBUS.write_bus_packet(24, 104, [57,
             2,
             169,
             0,
             self.cds_loaded,
             0,
             7,
             self.cdc_track], True)
        else:
            IBUS.write_bus_packet(24, 104, [57,
             2,
             137,
             0,
             self.cds_loaded,
             0,
             7,
             self.cdc_track], True)
            self.cdc_rnd = False

    def cdch_ffwd(self):
        if not self.cdc_emu:
            return
        xbmc.sleep(250)
        self.cdc_seek = True
        IBUS.write_bus_packet(24, 104, [57,
         3,
         137,
         0,
         self.cds_loaded,
         0,
         7,
         self.cdc_track], True)

    def cdch_frwd(self):
        if not self.cdc_emu:
            return
        xbmc.sleep(250)
        self.cdc_seek = True
        IBUS.write_bus_packet(24, 104, [57,
         4,
         137,
         0,
         self.cds_loaded,
         0,
         7,
         self.cdc_track], True)

    def cdch_next(self):
        if not self.cdc_emu:
            return
        time.sleep(0.65)
        IBUS.write_bus_packet(24, 104, [57,
         2,
         9,
         0,
         self.cds_loaded,
         0,
         7,
         153], True)

    def cdch_prev(self):
        if not self.cdc_emu:
            return
        time.sleep(0.65)
        IBUS.write_bus_packet(24, 104, [57,
         2,
         9,
         0,
         self.cds_loaded,
         0,
         7,
         149], True)

    def btn_bm_nav_right(self, steps = '1'):
        if self.pass_bm_buttons:
            KODI.down(steps) if self.inv_navturnbtn else KODI.up(steps)

    def btn_bm_nav_left(self, steps = '1'):
        if self.pass_bm_buttons:
            KODI.up(steps) if self.inv_navturnbtn else KODI.down(steps)

    def btn_bm_nav_hold(self):
        if self.pass_bm_buttons:
            self.nav_hold = True
            if self.navhold_event != ' ':
                xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.%s", "id": 1 }' % self.navhold_event)

    def btn_bm_nav_rel(self):
        if self.pass_bm_buttons:
            if self.nav_hold:
                if self.navhold_event == ' ':
                    KODI.select()
            else:
                KODI.select()
            self.nav_hold = False

    def btn_bm_next_hold(self):
        if not self.pass_bm_buttons:
            return
        log('state next hold: %s' % self.bm_next_hold)
        if self.bm_next_hold:
            return
        self.bm_next_hold = True
        speed = 4
        ticker = self.seek_sec
        while self.bm_next_hold:
            if ticker >= self.seek_sec:
                KODI.track_seek(speed)
                speed *= 2
                if speed > self.seek_max:
                    speed = self.seek_max
                ticker = 0
            xbmc.sleep(1)
            ticker += 1

    def btn_bm_next_rel(self):
        self.bm_prev_hold = False
        if not self.pass_bm_buttons:
            return
        if self.bm_next_hold:
            self.bm_next_hold = False
            KODI.track_play()
        else:
            DBL_NEXT.click()

    def btn_bm_prev_hold(self):
        if not self.pass_bm_buttons:
            return
        if self.bm_prev_hold:
            return
        self.bm_prev_hold = True
        speed = -4
        ticker = self.seek_sec
        while self.bm_prev_hold:
            if ticker >= self.seek_sec:
                KODI.track_seek(speed)
                speed *= 2
                if speed > self.seek_max:
                    speed = self.seek_max
                ticker = 0
            xbmc.sleep(1)
            ticker += 1

    def btn_bm_prev_rel(self):
        self.bm_next_hold = False
        if not self.pass_bm_buttons:
            return
        if self.bm_prev_hold:
            self.bm_prev_hold = False
            KODI.track_play()
        else:
            DBL_PREV.click()

    def btn_bm_reverse_hold(self):
        if self.pass_bm_buttons:
            self.reverse_hold = True
            KODI.home()

    def btn_bm_reverse_rel(self):
        if self.pass_bm_buttons:
            if self.reverse_hold:
                pass
            else:
                KODI.back()
            self.reverse_hold = False

    def btn_bm_x_hold(self, button_number):
        if not self.pass_bm_buttons:
            return
        if not self.modecd and not self.modecis:
            return
        self.btnx_hold[button_number - 6] = True
        KODI.action(KODI.get_addon_setting('bm_btn_%s' % button_number))

    def btn_bm_x_rel(self, button_number):
        if not self.pass_bm_buttons:
            return
        if not self.modecd and not self.modecis:
            return
        if self.btnx_hold[button_number]:
            pass
        else:
            KODI.action(KODI.get_addon_setting('bm_btn_%s' % button_number))
        self.btnx_hold[button_number] = False

    def btn_bm_tone_rel(self):
        self.gt_tone_menu()

    def btn_bm_select_hold(self):
        if self.pass_bm_buttons:
            self.select_hold = True

    def btn_bm_select_rel(self):
        if self.pass_bm_buttons:
            if self.select_hold:
                pass
            else:
                xbmc.executebuiltin('Action(ContextMenu)')
            self.select_hold = False
        else:
            self.gt_select_menu()

    def btn_bm_info_pres(self):
        self.tpmenu = True
        self.gt_hide_pi()

    def btn_bm_info_rel(self):
        pass

    def btn_bm_clock_hold(self):
        self.clock_hold = True
        self.set_rearcam_io(False)
        ticker = 0
        while self.clock_hold:
            if ticker >= 3000:
                self.bm_led('green')
                xbmc.sleep(500)
                self.bm_led('red')
                xbmc.sleep(500)
                self.bm_led('yellow')
                f = os.popen('reboot')
                xbmc.sleep(1000)
                self.bm_led('off')
                self.clock_hold = False
            xbmc.sleep(1)
            ticker += 1

    def btn_bm_clock_rel(self):
        if self.clock_hold:
            pass
        else:
            self.set_rearcam_io(True)
        self.clock_hold = False

    def btn_bm_screen_rel(self):
        if self.piaktiv:
            self.gt_show_pi()

    def btn_stw_vol_up(self):
        if self.gpio_gear_shift:
            GPIO_GEAR_SHIFT_UP.trigger(self.gpio_gear_shift_trigger_time)

    def btn_stw_vol_down(self):
        if self.gpio_gear_shift:
            GPIO_GEAR_SHIFT_DOWN.trigger(self.gpio_gear_shift_trigger_time)

    def btn_stw_up_hold(self):
        if self.stw_up_hold:
            return
        self.stw_up_hold = True
        if self.ike_text_scrolling:
            self.cancel_ike_text = True
        if self.stw_nav:
            KODI.select()
        else:
            speed = 4
            ticker = self.seek_sec
            while self.stw_up_hold:
                if ticker >= self.seek_sec:
                    KODI.track_seek(speed)
                    speed = speed * 2
                    if speed > self.seek_max:
                        speed = self.seek_max
                    ticker = 0
                xbmc.sleep(1)
                ticker += 1

    def btn_stw_up_rel(self):
        if self.stw_nav:
            if self.stw_up_hold:
                self.stw_up_hold = False
            else:
                KODI.up()
        else:
            self.stw_dn_hold = False
            if self.stw_up_hold:
                self.stw_up_hold = False
                KODI.track_play()
            else:
                KODI.track_next()

    def btn_stw_down_hold(self):
        if self.stw_dn_hold:
            return
        self.stw_dn_hold = True
        if self.ike_text_scrolling:
            self.cancel_ike_text = True
        if self.stw_nav:
            KODI.back()
        else:
            speed = -4
            ticker = self.seek_sec
            while self.stw_dn_hold:
                if ticker >= self.seek_sec:
                    KODI.track_seek(speed)
                    speed = speed * 2
                    if speed > self.seek_max:
                        speed = self.seek_max
                    ticker = 0
                xbmc.sleep(1)
                ticker += 1

    def btn_stw_down_rel(self):
        if self.stw_nav:
            if self.stw_dn_hold:
                self.stw_dn_hold = False
            else:
                KODI.down()
        else:
            self.stw_up_hold = False
            if self.stw_dn_hold:
                self.stw_dn_hold = False
                KODI.track_play()
            else:
                try:
                    if xbmc.Player().getTime() <= 3:
                        KODI.track_prev()
                    else:
                        KODI.track_pos(0)
                except:
                    pass

    def btn_stw_rt_hold(self):
        if self.stw_rt_hold:
            return
        self.stw_rt_hold = True

    def btn_stw_rt_rel(self):
        self.stw_rt_hold = False
        self.btn_stw_rt_on()

    def btn_stw_rt_on(self):
        if self.stw_rt_hold:
            pass
        elif self.use_stw_nav:
            if self.stw_nav:
                self.stw_nav = False
                KODI.set_property('IBUSCOMMUNICATOR_MFL_SHOW', '0')
                self.clear_ike(0, True)
                log('Disable MFL Control for Kodi')
            elif self.pass_bm_buttons:
                self.stw_nav = True
                KODI.set_property('IBUSCOMMUNICATOR_MFL_SHOW', '1')
                self.send_to_ike('KODI CONTROL', True, True)
                log('Enable MFL Control for Kodi')
        elif self.nav_toggle_map:
            if self.navmenu:
                self.radio_get_mode()
            else:
                self.nav_show_map()
        self.stw_rt_hold = False

    def btn_stw_rt_off(self):
        if self.stw_rt_hold:
            pass
        elif self.use_stw_nav:
            self.stw_nav = False
            KODI.set_property('IBUSCOMMUNICATOR_MFL_SHOW', '0')
            self.clear_ike(0, True)
            log('Disable MFL Control for Kodi')
        elif self.nav_toggle_map:
            if self.navmenu:
                self.radio_get_mode()
            else:
                self.nav_show_map()
        self.stw_rt_hold = False

    def btn_stw_speak_hold(self):
        if self.stw_speak_hold:
            return
        self.stw_speak_hold = True
        if self.stw_nav:
            KODI.back()

    def btn_stw_speak_rel(self):
        if self.stw_speak_hold:
            pass
        elif self.stw_nav:
            DBL_STW_SPEAK.click()
        self.stw_speak_hold = False

    def btn_bc_pres(self):
        if self.ike_text_scrolling:
            self.cancel_ike_text = True

    def radio_led_on(self):
        self.radio_get_mode()
        self.cdch_stop()

    def radio_led_off(self):
        self.pi_off()

    def ign_get_state(self):
        IBUS.write_bus_packet(91, 128, [16])

    def ign_off(self):
        self.got_audiomode = False
        self.stw_nav = False
        self.pi_off()
        if self.ign_mode > 0 and self.zv_auto_lock and self.zv_auto_unlock_ign1 and self.gm_states['zvlockstate']:
            self.gm_zv_unlock()
        if self.ign_mode > 0:
            self.ign_mode = 0
            if self.lev_light and self.lev_light_ign_off:
                self.lcm_lights_on(self.lev_light_time)
            KODI.copy_log_file()
        if OBCGUI.isActive:
            OBCGUI.onStop()
        self.obc_req_runonce = False
        self.ign_mode = 0
        log('IGN == 0')

    def ign_acc(self):
        time.sleep(0.25)
        if not self.got_audiomode:
            self.radio_get_mode()
        if self.cdc_emu:
            self.cdch_play()
        if self.ign_mode > 1 and self.zv_auto_lock and self.zv_auto_unlock_ign1 and self.gm_states['zvlockstate']:
            self.gm_zv_unlock()
        if self.ign_mode < 1:
            self.lcm_lights_off()
            while self.lcm_on:
                time.sleep(0.5)

            self.obc_req(True)
        self.ign_mode = 1
        log('IGN == 1')

    def ign_on(self):
        time.sleep(0.25)
        if self.ign_mode < 2:
            self.obc_req(True)
        self.ign_mode = 2
        log('IGN == 2')

    def ign_start(self):
        time.sleep(0.25)
        self.ign_mode = 3
        log('IGN == 3')

    def radio_get_mode(self):
        if self.ign_mode < 1:
            return
        IBUS.write_bus_packet(59, 104, [69, 0])

    def gt_mode_radio(self):
        self.got_audiomode = True
        self.navmenu = False
        self.pi_off()

    def gt_mode_cd(self):
        self.got_audiomode = True
        self.navmenu = False
        if not self.cdc_play:
            self.cdch_play()
        if self.modecd:
            if self.piaktiv:
                self.gt_show_pi()
            else:
                self.pi_on()
        else:
            self.pi_off()

    def gt_mode_tape(self):
        self.got_audiomode = True
        self.navmenu = False
        if self.modetape:
            if self.piaktiv:
                self.gt_show_pi()
            else:
                self.pi_on()
        else:
            self.pi_off()

    def gt_mode_aux(self):
        self.got_audiomode = True
        self.navmenu = False
        if self.modeaux:
            if self.piaktiv:
                self.gt_show_pi()
            else:
                self.pi_on()
        else:
            self.pi_off()

    def gt_mode_cis(self):
        self.got_audiomode = True
        self.navmenu = False
        if self.modecis:
            if self.piaktiv:
                self.gt_show_pi()
            else:
                self.pi_on()
        else:
            self.pi_off()

    def gt_clear_cd_list(self):
        if self.modecd:
            IBUS.write_bus_packet(104, 59, [70, 12])

    def gt_nav_menu_on(self):
        self.navmenu = True
        self.tonemenu = False
        self.tpmenu = False
        self.gt_hide_pi()

    def gt_radio_menu_off(self):
        self.tpmenu = False
        self.tonemenu = False
        self.navmenu = True
        self.gt_hide_pi()

    def gt_tp_menu(self):
        self.tpmenu = True
        self.tonemenu = False
        self.gt_hide_pi()

    def gt_tone_menu(self):
        self.tonemenu = True
        self.tpmenu = False
        self.navmenu = False
        self.gt_hide_pi()

    def gt_select_menu(self):
        self.tonemenu = False
        self.tpmenu = False
        self.navmenu = False
        self.gt_show_pi()

    def gt_tone_menu_off(self):
        self.tonemenu = False
        self.gt_show_pi()

    def gt_select_tone_menu_off(self):
        self.tpmenu = False
        self.gt_show_pi()

    def gt_tv_on(self):
        self.gt_hide_pi()
        KODI.track_pause()

    def gt_tv_off(self):
        if self.piaktiv:
            KODI.track_play()

    def gt_new_field1(self):
        self.gt_show_pi()

    def phone_state(self, dat):
        dat = dat[1]
        if get_bit_from_hex(dat, BIT[4]) == 1:
            if self.piaktiv:
                KODI.track_pause()
            self.phone_mute = True
        elif get_bit_from_hex(dat, BIT[4]) == 0:
            self.phone_mute = False
            if self.piaktiv:
                KODI.track_play()

    def remote_key(self, dat):
        dat = ('%02X' % dat[1])[0]
        time.sleep(0.25)
        if dat == '1':
            self._remote_key_lock()
            self.remote_state = 1
        elif dat == '2':
            self._remote_key_unlock()
            self.remote_state = 2
        elif dat == '4':
            self._remote_key_boot()
        elif dat == '0':
            self._remote_key_release()

    def _remote_key_lock(self):
        log('REMOTE LOCK')
        if not self.remote_accept_cmd:
            return
        self.remote_accept_cmd = False
        if self.lev_light:
            if self.lcm_on:
                if self.remote_state == 1:
                    self.lcm_lights_off()
                else:
                    self.lcm_delay = self.lev_light_time
            else:
                self.lcm_lights_on(self.lev_light_time)
        elif self.lcm_on:
            self.lcm_lights_off()
        time.sleep(0.1)
        if self.mir_fold and self.remote_state == 2:
            log('FOLD MIRROS')
            self.mirror_fold()

    def _remote_key_unlock(self):
        log('REMOTE UNLOCK')
        if not self.remote_accept_cmd:
            return
        self.remote_accept_cmd = False
        if self.wel_light:
            if self.lcm_on:
                if self.remote_state == 2:
                    self.lcm_lights_off()
                else:
                    self.lcm_delay = self.wel_light_time
            else:
                self.lcm_lights_on(self.wel_light_time)
        elif self.lcm_on:
            self.lcm_lights_off()
        time.sleep(0.1)
        if self.remote_state == 1:
            if self.wel_ike:
                self.send_to_ike(self.wel_iketxt, True, self.wel_iketxt_hold)
            if self.mir_unfold:
                log('UNFOLD MIRROS')
                self.mirror_unfold()

    def _remote_key_boot(self):
        log('REMOTE TRUNK')
        if not self.remote_accept_cmd:
            return
        self.remote_accept_cmd = False

    def _remote_key_release(self):
        self.remote_accept_cmd = True
        log('REMOTE REL')

    def ews_key(self, dat):
        if dat[1] == 0:
            log('MANAGE: EWS_KEY_OUT')
        elif dat[1] != 0 and dat[2] == 255:
            log('MANAGE: EWS_KEY_OUT')
        elif dat[1] != 0 and dat[2] != 255:
            log('MANAGE: EWS_KEY_IN: %s' % dat[2])
            if self.keyin_off:
                self.lcm_lights_off()
                while self.lcm_on:
                    time.sleep(0.5)

    def ike_get_state(self, timer = False):
        if timer:
            counter = 10000
            while not MONITOR.abortRequested():
                if counter == 10000:
                    IBUS.write_bus_packet(59, 128, [18])
                elif counter <= 0:
                    counter = 10000
                counter -= 1
                time.sleep(0.001)

        else:
            IBUS.write_bus_packet(59, 128, [18])

    def ike_get_state_timer(self):
        thread = Thread(target=self.ike_get_state, args=True)
        thread.setDaemon(True)
        thread.start()

    def ike_state(self, dat):
        """
        // IKE SENSOR //
        3B 03 80 12 CK : Request
        80 0A BF 13 AA BB CC DD EE FF GG CK : Answer
        -- AA --
        0000 0001 - Handbrake_On
        0000 0010 - Oil_Pressure_Low
        0000 0100 - Brake_Pads_Worn
        0000 1000 - ???
        
        0001 0000 - Trans_Emergency_Program
        0010 0000 - Trans_not_in_P
        0100 0000 - ???
        1000 0000 - ???
        
        
        -- BB --
             0001 - Motor_Running
             0010 - Vehicle_Driving
             0100 - Reverse_Not_Plausible
             1000 - ???
        
        Hex1      - Gear_R
        Hex2      - Gear_1
        Hex4      - Gear_2
        Hex6      - Gear_N
        Hex8      - Gear_D
        HexB      - Gear_P
        HexC      - Gear_4
        HexD      - Gear_3
        HexE      - Gear_5
        
        
        -- CC --
        0000 0001 - Alarm_Siren_On
        0000 0010 - Immobiliser_On
        0000 0100 - Aux_Heat_On
        0000 1000 - Aux_Vent_On
        
        0001 0000 - ???
        0010 0000 - ???
        0100 0000 - Temp_F
        1000 0000 - ???
        
        GG : Fuellevel in Hex / If left Value is 8 then Reserve is true. So just use right Value.
        """
        aa = dat[1]
        bb = dat[2]
        cc = dat[3]
        gg = dat[7]
        handbrake = get_bit_from_hex(aa, BIT[0])
        motor_running = get_bit_from_hex(bb, BIT[0])
        vehicle_driving = get_bit_from_hex(bb, BIT[1])
        if ('%02X' % bb)[0] == '1':
            gear_pos = 'R'
        elif ('%02X' % bb)[0] == '2':
            gear_pos = '1'
        elif ('%02X' % bb)[0] == '4':
            gear_pos = '2'
        elif ('%02X' % bb)[0] == '6':
            gear_pos = 'N'
        elif ('%02X' % bb)[0] == '8':
            gear_pos = 'D'
        elif ('%02X' % bb)[0] == 'B':
            gear_pos = 'P'
        elif ('%02X' % bb)[0] == 'C':
            gear_pos = '4'
        elif ('%02X' % bb)[0] == 'D':
            gear_pos = '3'
        elif ('%02X' % bb)[0] == 'E':
            gear_pos = '5'
        else:
            gear_pos = 'X'
        aux_heat = get_bit_from_hex(cc, BIT[2])
        aux_vent = get_bit_from_hex(cc, BIT[3])
        if ('%02X' % gg)[0] == '8':
            obc_fuellevel_low = True
            obc_fuellevel = int(('%02X' % gg)[1])
        else:
            obc_fuellevel_low = False
            obc_fuellevel = gg
        if self.ike_states['run_once']:
            if handbrake and self.zv_auto_lock and self.zv_auto_unlock_handbrake and self.gm_states['zvlockstate']:
                self.gm_zv_unlock()
            if handbrake != self.ike_states['handbrake']:
                self.ike_states['handbrake'] = handbrake
            if gear_pos == 'P' and self.zv_auto_lock and self.zv_auto_unlock_gear_p and self.gm_states['zvlockstate']:
                self.gm_zv_unlock()
            if gear_pos != self.ike_states['gear_pos']:
                self.ike_states['gear_pos'] = gear_pos
            if obc_fuellevel != self.obc_fuellevel:
                self.obc_fuellevel = obc_fuellevel
                self.obc_fuellevel_low = obc_fuellevel_low
                KODI.set_property('IBUSCOMMUNICATOR_OBC_FUELLEVEL', '%s%s L' % ('R ' if obc_fuellevel_low else '', obc_fuellevel))
            log('OBC: SET FUELLEVEL: %s' % obc_fuellevel)
        self.ike_states['run_once'] = True

    def gm_get_state(self):
        IBUS.write_bus_packet(191, 0, [121])

    def gm_state(self, dat):
        """
        REQ: BF LL 00 79 CK
        RPL: 00 05 BF 7A AA BB CK
        AA
        0000 0001 - Driver Door open
        0000 0010 - Passenger Door open
        0000 0100 - DriverRear Door open
        0000 1000 - PassengerRear Door open
        
        0001 0000 - ZV Unlocked
        0010 0000 - ZV Locked
        0100 0000 - Indoor Lights on
        1000 0000 - ???
        
        0011 0000 - ZV hardlocked
        
        BB
        0000 0001 - Driver Window open
        0000 0010 - Passenger Window open
        0000 0100 - DriverRear Window open
        0000 1000 - PassengerRear Window open
        
        0001 0000 - ZV Unlocked
        0010 0000 - Trunk open
        0100 0000 - Bonnet open
        1000 0000 - Button to open Trunk pressed
        """
        aa = dat[1]
        bb = dat[2]
        driverdoor = get_bit_from_hex(aa, BIT[0])
        passangerdoor = get_bit_from_hex(aa, BIT[1])
        driverreardoor = get_bit_from_hex(aa, BIT[2])
        passangerreardoor = get_bit_from_hex(aa, BIT[3])
        if driverdoor or passangerdoor or driverreardoor or passangerreardoor:
            doorsopen = True
        else:
            doorsopen = False
        zvunlocked = get_bit_from_hex(aa, BIT[4])
        zvlocked = get_bit_from_hex(aa, BIT[5])
        zvhardlocked = True if zvunlocked and zvlocked else False
        zvlockstate = zvlocked
        indoorlights = get_bit_from_hex(aa, BIT[6])
        driverwindow = get_bit_from_hex(bb, BIT[0])
        passengerwindow = get_bit_from_hex(bb, BIT[1])
        driverrearwindow = get_bit_from_hex(bb, BIT[2])
        passangerrearwindow = get_bit_from_hex(bb, BIT[3])
        sunroof = get_bit_from_hex(bb, BIT[4])
        trunk = get_bit_from_hex(bb, BIT[5])
        bonnet = get_bit_from_hex(bb, BIT[6])
        trunkbuttonpress = get_bit_from_hex(bb, BIT[7])
        notemsg = [None, None]
        notetime = 50
        if self.gm_states['run_once']:
            if self.gm_states['driverdoor'] != driverdoor:
                notemsg[0] = 'Driver Door'
                notemsg[1] = 'opened' if driverdoor else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['passangerdoor'] != passangerdoor:
                notemsg[0] = 'Passanger Door'
                notemsg[1] = 'opened' if passangerdoor else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['driverreardoor'] != driverreardoor:
                notemsg[0] = 'Driver Rear Door'
                notemsg[1] = 'opened' if driverreardoor else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['passangerreardoor'] != passangerreardoor:
                notemsg[0] = 'Passanger Rear Door'
                notemsg[1] = 'opened' if passangerreardoor else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['doorsopen'] != doorsopen:
                if doorsopen and self.doors_off:
                    self.lcm_lights_off()
            if self.gm_states['zvlockstate'] != zvlockstate:
                if self.gm_states['zvtoggled']:
                    self.gm_states['zvtoggled'] = False
                    self.gm_diag_off()
                notemsg[0] = 'Central Locksystem'
                notemsg[1] = 'locked' if zvlockstate else 'unlocked'
                if zvhardlocked:
                    notemsg[1] = 'hard locked'
                else:
                    notemsg[1] = 'locked' if zvlockstate else 'unlocked'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['indoorlights'] != indoorlights:
                notemsg[0] = 'Indoor Lights turned'
                notemsg[1] = 'ON' if indoorlights else 'OFF'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['driverwindow'] != driverwindow:
                notemsg[0] = 'Driver Window'
                notemsg[1] = 'opened' if driverwindow else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['passengerwindow'] != passengerwindow:
                notemsg[0] = 'Passenger Window'
                notemsg[1] = 'opened' if passengerwindow else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['driverrearwindow'] != driverrearwindow:
                notemsg[0] = 'Driver Rear Window'
                notemsg[1] = 'opened' if driverrearwindow else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['passangerrearwindow'] != passangerrearwindow:
                notemsg[0] = 'Passanger Rear Window'
                notemsg[1] = 'opened' if passangerrearwindow else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['sunroof'] != sunroof:
                notemsg[0] = 'Sunroof'
                notemsg[1] = 'opened' if sunroof else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['trunk'] != trunk:
                notemsg[0] = 'Trunk'
                notemsg[1] = 'opened' if trunk else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['bonnet'] != bonnet:
                notemsg[0] = 'Bonnet'
                notemsg[1] = 'opened' if bonnet else 'closed'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if self.gm_states['trunkbuttonpress'] != trunkbuttonpress:
                notemsg[0] = 'Trunk Button'
                notemsg[1] = 'pressed' if trunkbuttonpress else 'released'
                note(heading=notemsg[0], message='[COLOR FFFF7E00]%s[/COLOR]' % notemsg[1], time=notetime)
            if doorsopen and self.zv_auto_lock and self.zv_auto_unlock_door_open and self.gm_states['zvlockstate']:
                self.gm_zv_unlock()
        self.gm_states['driverdoor'] = driverdoor
        self.gm_states['passangerdoor'] = passangerdoor
        self.gm_states['driverreardoor'] = driverreardoor
        self.gm_states['passangerreardoor'] = passangerreardoor
        self.gm_states['doorsopen'] = doorsopen
        self.gm_states['zvunlocked'] = zvunlocked
        self.gm_states['zvlocked'] = zvlocked
        self.gm_states['zvlockstate'] = zvlockstate
        self.gm_states['zvhardlocked'] = zvhardlocked
        self.gm_states['indoorlights'] = indoorlights
        self.gm_states['driverwindow'] = driverwindow
        self.gm_states['passengerwindow'] = passengerwindow
        self.gm_states['driverrearwindow'] = driverrearwindow
        self.gm_states['passangerrearwindow'] = passangerrearwindow
        self.gm_states['sunroof'] = sunroof
        self.gm_states['trunk'] = trunk
        self.gm_states['bonnet'] = bonnet
        self.gm_states['trunkbuttonpress'] = trunkbuttonpress
        self.gm_states['run_once'] = True

    def gm_zv_lock(self):
        thread = Thread(target=self._gm_zv_lock())
        thread.setDaemon(True)
        thread.start()

    def gm_zv_unlock(self):
        thread = Thread(target=self._gm_zv_unlock())
        thread.setDaemon(True)
        thread.start()

    def _gm_zv_lock(self):
        if self.car_model == 'E39':
            IBUS.write_bus_packet(63, 0, [12,
             0,
             11,
             1])
        elif self.car_model == 'E46':
            IBUS.write_bus_packet(63, 0, [12,
             0,
             52,
             1])
        self.gm_states['zvtoggled'] = True
        log('CENTRAL-LOCK-SYSTEM: LOCK')

    def _gm_zv_unlock(self):
        if self.car_model == 'E39':
            IBUS.write_bus_packet(63, 0, [12,
             0,
             11,
             1])
        elif self.car_model == 'E46':
            IBUS.write_bus_packet(63, 0, [12,
             0,
             3,
             1])
        self.gm_states['zvtoggled'] = True
        log('CENTRAL-LOCK-SYSTEM: UNLOCK')

    def gm_diag_off(self):
        IBUS.write_bus_packet(63, 0, [159])
        log('GM: DIAG OFF')

    def pi_on(self):
        self.piaktiv = True
        log('RASPBERRY: ACTIVATE PI')
        self.gt_show_pi()
        if self.dsp_cd:
            self.dsp_set_cd()
        KODI.track_seek(1)

    def pi_off(self):
        self.piaktiv = False
        log('RASPBERRY: DEACTIVATE PI')
        self.gt_hide_pi()
        if self.dsp_cd:
            self.dsp_set_tuner()
        KODI.track_pause()

    def gt_show_pi(self):
        if self.navmenu or self.tpmenu or self.tonemenu or not self.piaktiv:
            return
        self.pass_bm_buttons = True
        log('RASPBERRY: SHOW PI')
        self.set_rearcam_io(True)

    def gt_hide_pi(self):
        self.pass_bm_buttons = False
        log('RASPBERRY: HIDE PI')
        self.set_rearcam_io(False)

    def set_rearcam_io(self, ntscstate):
        if self.gpio_ntsc:
            if ntscstate:
                GPIO_NTSC.set()
            else:
                GPIO_NTSC.reset()
        else:
            IBUS.ntsc = 1 if ntscstate else 0

    def dsp_set_tuner(self):
        IBUS.write_bus_packet(104, 106, [54, 161])
        log('RASPBERRY: DSP SOURCE TUNER')

    def dsp_set_cd(self):
        IBUS.write_bus_packet(104, 106, [54, 160])
        log('RASPBERRY: DSP SOURCE CD')

    def kodi_said_play(self):
        if not self.piaktiv or self.phone_mute:
            KODI.track_pause()

    def lcm_get_state(self):
        IBUS.write_bus_packet(191, 208, [90])
        time.sleep(0.2)
        IBUS.write_bus_packet(191, 208, [93])

    def lcm_state(self, dat):
        """
        // LCM LIGHT STATE //
        BF 03 D0 5A CK : ! PDC  --> LCM : Lamp status request
        
        D0 07 BF 5B AA BB CC DD CK    LCM3
        D0 08 BF 5B AA BB CC DD EE CK LCM4
        
        'AA                          'CC
        '0000 0001 = Park            '0000 0001 = unknown
        '0000 0010 = Low Beam        '0000 0010 = Brake
        '0000 0100 = High Beam       '0000 0100 = Indicator Sync
        '0000 1000 = Fog Front       '0000 1000 = Tail
        '0001 0000 = Fog Rear        '0001 0000 = Trailer
        '0010 0000 = Indicator Left  '0010 0000 = Reverse
        '0100 0000 = Indicator Right '0100 0000 = Trailer
        '1000 0000 = Indi.Fast Blink '1000 0000 = Hazard (WARN)?
        
        'BB - Faulty                  'DD - Faulty
        '0000 0001 = Park             '0000 0001 = Brake Right
        '0000 0010 = Low Beam         '0000 0010 = Brake Left
        '0000 0100 = High Beam        '0000 0100 = Tail Right
        '0000 1000 = Fog Front        '0000 1000 = Tail Left
        '0001 0000 = Fog Rear         '0001 0000 = Low Beam Right
        '0010 0000 = Indicator Left   '0010 0000 = Low Beam Left
        '0100 0000 = Indicator Right  '0100 0000 = unknown
        '1000 0000 = Number Plate     '1000 0000 = unknown
        
        'EE - unknown
        """
        aa = dat[1]
        cc = dat[3]
        park = get_bit_from_hex(aa, BIT[0])
        low_beam = get_bit_from_hex(aa, BIT[1])
        high_beam = get_bit_from_hex(aa, BIT[2])
        fog_front = get_bit_from_hex(aa, BIT[3])
        fog_rear = get_bit_from_hex(aa, BIT[4])
        turn_left = get_bit_from_hex(aa, BIT[5])
        turn_right = get_bit_from_hex(aa, BIT[6])
        turn_fast_blink = get_bit_from_hex(aa, BIT[7])
        tail = get_bit_from_hex(cc, BIT[3])
        reverse = get_bit_from_hex(cc, BIT[5])
        hazard = get_bit_from_hex(cc, BIT[7])
        if self.lcm_states['run_once']:
            if turn_left != self.lcm_states['turn_left'] and not turn_right:
                if turn_left:
                    self.lcm_turn_left()
            if turn_right != self.lcm_states['turn_right'] and not turn_left:
                if turn_right:
                    self.lcm_turn_right()
            if high_beam != self.lcm_states['high_beam']:
                self.lcm_flash_to_pass(high_beam)
        self.lcm_states['park'] = park
        self.lcm_states['low_beam'] = low_beam
        self.lcm_states['high_beam'] = high_beam
        self.lcm_states['fog_front'] = fog_front
        self.lcm_states['fog_rear'] = fog_rear
        self.lcm_states['turn_left'] = turn_left
        self.lcm_states['turn_right'] = turn_right
        self.lcm_states['turn_fast_blink'] = turn_fast_blink
        self.lcm_states['tail'] = tail
        self.lcm_states['reverse'] = reverse
        self.lcm_states['hazard'] = hazard
        self.lcm_states['run_once'] = True

    def lcm_diag_state(self, dat):
        if len(dat) < 2:
            return
        self.lcm_states['diag_dim_level'] = dat[16]
        log('LCM: Dim Diag Value = %s' % self.lcm_states['diag_dim_level'])

    def lcm_dim_level(self, dat):
        if self.lcm_states['dim_level'] != dat[1]:
            log('LCM: Dim Value = %s' % dat[1])
            self.lcm_states['dim_level'] = dat[1]
            IBUS.write_bus_packet(63, 208, [11])

    def lcm_lights_on(self, timedelay = 10):
        thread = Thread(target=self._lcm_lights_on, args=(timedelay,))
        thread.setDaemon(True)
        thread.start()

    def _lcm_lights_on(self, timedelay = 10):
        if self.day_time and time_now_in_range(self.day_time_start, self.day_time_end):
            return
        self.lcm_delay = timedelay
        if self.ign_mode > 0:
            log('LCM: Skip Welcomelight, IGN is turned ON')
            return
        sendcount = 10
        self.lcm_on = True
        while self.lcm_delay > 0 and self.lcm_on:
            if self.ign_mode > 0:
                break
            if sendcount >= 10:
                sendcount = 0
                if self.bm_sensor:
                    wait_counter = 5
                    while wait_counter > 0:
                        wait_counter -= 1
                        if self.bm_sensor_brightness:
                            break
                        self.bm_get_state()
                        time.sleep(0.2)

                    if self.bm_sensor_brightness:
                        if self.bm_sensor_brightness > self.bm_sensor_level:
                            break
                if self.car_model == 'E39':
                    IBUS.write_bus_packet(63, 208, [12,
                     0,
                     0,
                     0,
                     0,
                     0,
                     3,
                     40,
                     24,
                     0,
                     self.lcm_states['diag_dim_level'],
                     1,
                     0], True)
                elif self.car_model == 'E46':
                    IBUS.write_bus_packet(63, 208, [12,
                     0,
                     0,
                     0,
                     192,
                     96,
                     0,
                     1,
                     6], True)
                log('LCM: LIGHTS ON - Turn OFF in %ss' % self.lcm_delay)
            sendcount += 1
            self.lcm_delay += -1
            if self.ign_mode < 0:
                self.ign_get_state()
            time.sleep(1)

        if self.lcm_on:
            self.lcm_lights_off()

    def lcm_lights_off(self):
        self.lcm_delay = -1
        if self.lcm_on:
            IBUS.write_bus_packet(63, 208, [159], True, repeat=2)
            log('LCM: LIGHTS OFF')
        self.lcm_on = False
        self.bm_sensor_brightness = None

    def lcm_flash_to_pass(self, state):
        if True in [self.turning_left,
         self.turning_fog_left,
         self.turning_right,
         self.turning_fog_right,
         self.lcm_states['low_beam']]:
            return
        if state:
            if self.flash_to_pass and (self.flash_to_pass_low_beam or self.flash_to_pass_fog):
                if self.car_model == 'E39':
                    if self.flash_to_pass_low_beam and self.flash_to_pass_fog:
                        ff = 116
                    elif self.flash_to_pass_low_beam:
                        ff = 48
                    elif self.flash_to_pass_fog:
                        ff = 68
                    IBUS.write_bus_packet(63, 208, [12,
                     0,
                     0,
                     0,
                     0,
                     0,
                     ff,
                     0,
                     0,
                     0,
                     self.lcm_states['diag_dim_level'],
                     1,
                     0], veryhighprio=True)
                elif self.car_model == 'E46':
                    if self.flash_to_pass_low_beam and self.flash_to_pass_fog:
                        ff = 6
                        gg = 1
                    elif self.flash_to_pass_low_beam:
                        ff = 6
                        gg = 0
                    elif self.flash_to_pass_fog:
                        ff = 0
                        gg = 1
                    IBUS.write_bus_packet(63, 208, [12,
                     0,
                     0,
                     255,
                     0,
                     0,
                     ff,
                     gg,
                     0,
                     0,
                     self.lcm_states['diag_dim_level'],
                     0,
                     0,
                     0,
                     0,
                     0], veryhighprio=True)
        else:
            self._lcm_turn_off()

    def lcm_turn_left(self):
        if not self.turning_left:
            if self.comfort_blink or self.turn_light:
                if not self.turning_right and self.turning_fog_right:
                    self.cancel_turn_right = True
                elif self.turning_right:
                    self.cancel_turn_right = True
                    self._lcm_turn_off()
                    return
                while self.cancel_turn_right:
                    time.sleep(0.001)

                if self.turning_fog_left:
                    self.cancel_turn_left = True
                    while self.cancel_turn_left:
                        time.sleep(0.001)

            thread = Thread(target=self._lcm_turn_left_on)
            thread.setDaemon(True)
            thread.start()
        else:
            self.cancel_turn_left = True
            self._lcm_turn_off()

    def lcm_turn_right(self):
        if not self.turning_right:
            if self.comfort_blink or self.turn_light:
                if not self.turning_left and self.turning_fog_left:
                    self.cancel_turn_left = True
                elif self.turning_left:
                    self.cancel_turn_left = True
                    self._lcm_turn_off()
                    return
                while self.cancel_turn_left:
                    time.sleep(0.001)

                if self.turning_fog_right:
                    self.cancel_turn_right = True
                    while self.cancel_turn_right:
                        time.sleep(0.001)

            thread = Thread(target=self._lcm_turn_right_on)
            thread.setDaemon(True)
            thread.start()
        else:
            self.cancel_turn_left = True
            self._lcm_turn_off()

    def _lcm_turn_left_on(self):
        log('LCM: LIGHTS TURN LEFT')
        if self.comfort_blink:
            log('LCM: LIGHTS TURN LEFT FLASH')
            self.turning_left = True
            if self.car_model == 'E39':
                IBUS.write_bus_packet(63, 208, [12,
                 0,
                 0,
                 128,
                 0,
                 0,
                 4 if self.turn_light and self.lcm_states['park'] else 0,
                 0,
                 0,
                 0,
                 self.lcm_states['diag_dim_level'],
                 1,
                 0], veryhighprio=True)
            elif self.car_model == 'E46':
                IBUS.write_bus_packet(63, 208, [12,
                 0,
                 0,
                 255,
                 64,
                 0,
                 0,
                 0,
                 0,
                 0,
                 self.lcm_states['diag_dim_level'],
                 0,
                 0,
                 0,
                 0,
                 0], veryhighprio=True)
            counter = self.comfort_blink_time
            while counter > 0:
                if self.cancel_turn_left:
                    break
                counter -= 1
                time.sleep(0.001)

        if self.turn_light and self.lcm_states['park'] and self.car_model == 'E39' and not self.cancel_turn_left and self.obc_speed_kmh <= self.turn_light_max_speed:
            log('LCM: LIGHTS TURN LEFT FOG')
            self.turning_fog_left = True
            IBUS.write_bus_packet(63, 208, [12,
             0,
             0,
             0,
             0,
             0,
             4,
             0,
             0,
             0,
             self.lcm_states['diag_dim_level'],
             1,
             0], veryhighprio=True, repeat=2)
            self.turning_left = False
            counter = self.turn_light_time - (self.comfort_blink_time if self.comfort_blink else 0)
            light_counter = 10000
            while counter > 0:
                if self.cancel_turn_left or self.obc_speed_kmh > self.turn_light_max_speed or not self.lcm_states['park']:
                    break
                if self.lcm_states['turn_left']:
                    counter = self.turn_light_time / 2
                else:
                    counter -= 1
                light_counter -= 1
                if light_counter == 0:
                    light_counter = 10000
                    IBUS.write_bus_packet(63, 208, [12,
                     0,
                     0,
                     0,
                     0,
                     0,
                     4,
                     0,
                     0,
                     0,
                     self.lcm_states['diag_dim_level'],
                     1,
                     0], veryhighprio=True)
                time.sleep(0.001)

        if not self.cancel_turn_left:
            self._lcm_turn_off()
        self.turning_left = False
        self.turning_fog_left = False
        self.cancel_turn_left = False

    def _lcm_turn_right_on(self):
        log('LCM: LIGHTS TURN RIGHT')
        if self.comfort_blink:
            self.turning_right = True
            if self.car_model == 'E39':
                IBUS.write_bus_packet(63, 208, [12,
                 0,
                 0,
                 64 if self.comfort_blink else 0,
                 0,
                 0,
                 64 if self.turn_light and self.lcm_states['park'] else 0,
                 0,
                 0,
                 0,
                 self.lcm_states['diag_dim_level'],
                 1,
                 0], veryhighprio=True)
            elif self.car_model == 'E46':
                IBUS.write_bus_packet(63, 208, [12,
                 0,
                 0,
                 255,
                 128,
                 0,
                 0,
                 0,
                 0,
                 0,
                 self.lcm_states['diag_dim_level'],
                 0,
                 0,
                 0,
                 0,
                 0], veryhighprio=True)
            counter = self.comfort_blink_time
            while counter > 0:
                if self.cancel_turn_right:
                    break
                counter -= 1
                time.sleep(0.001)

        if self.turn_light and self.lcm_states['park'] and self.car_model == 'E39' and not self.cancel_turn_right and self.obc_speed_kmh <= self.turn_light_max_speed:
            log('LCM: LIGHTS TURN RIGHT FOG')
            self.turning_fog_right = True
            IBUS.write_bus_packet(63, 208, [12,
             0,
             0,
             0,
             0,
             0,
             64,
             0,
             0,
             0,
             self.lcm_states['diag_dim_level'],
             1,
             0], veryhighprio=True, repeat=2)
            self.turning_right = False
            counter = self.turn_light_time - (self.comfort_blink_time if self.comfort_blink else 0)
            light_counter = 10000
            while counter > 0:
                if self.cancel_turn_right or self.obc_speed_kmh > self.turn_light_max_speed or not self.lcm_states['park']:
                    break
                if self.lcm_states['turn_right']:
                    counter = self.turn_light_time / 2
                else:
                    counter -= 1
                light_counter -= 1
                if light_counter == 0:
                    light_counter = 10000
                    IBUS.write_bus_packet(63, 208, [12,
                     0,
                     0,
                     0,
                     0,
                     0,
                     64,
                     0,
                     0,
                     0,
                     self.lcm_states['diag_dim_level'],
                     1,
                     0], veryhighprio=True)
                time.sleep(0.001)

        if not self.cancel_turn_right:
            self._lcm_turn_off()
        self.cancel_turn_right = False
        self.turning_right = False
        self.turning_fog_right = False

    def _lcm_turn_off(self):
        """
        if self.car_model == 'E39':
            #IBUS.write_bus_packet('3F', 'D0', ['0C', '00', '00', '00', '00', '00', '00', '00', '00', '00'], veryhighprio=True)
            #IBUS.write_bus_packet('3F', 'D0', ['0C', '00', '00', '00', '00', '00', '00', '00', '00', '00'], veryhighprio=True)
            IBUS.write_bus_packet('3F', 'D0', ['0C', '00', '00', '00', '00', '00', '00', '00', '00', '00', self.lcm_states['diag_dim_level'], '01', '00'], veryhighprio=True)
            IBUS.write_bus_packet('3F', 'D0', ['0C', '00', '00', '00', '00', '00', '00', '00', '00', '00', self.lcm_states['diag_dim_level'], '01', '00'], veryhighprio=True)
        
            #IBUS.write_bus_packet('3F', 'D0', ['0C', '00', '00', '00', '00', '00', '00', '00', '00', '00', 'C2', '04', '00'], True)
            #time.sleep(0.4)
            #IBUS.write_bus_packet('3F', 'D0', ['00'], True)
        elif self.car_model == 'E46':
            IBUS.write_bus_packet('3F', 'D0', ['0C', '00', '00', '00', '00', '00', '00', '00', '00'], veryhighprio=True)
            IBUS.write_bus_packet('3F', 'D0', ['0C', '00', '00', '00', '00', '00', '00', '00', '00'], veryhighprio=True)
        """
        IBUS.write_bus_packet(63, 208, [159], veryhighprio=True)
        IBUS.write_bus_packet(63, 208, [159], veryhighprio=True)

    def mirror_unfold(self):
        IBUS.write_bus_packet(63, 0, [12, 1, 48])
        time.sleep(0.1)
        IBUS.write_bus_packet(63, 0, [12, 2, 48])

    def mirror_fold(self):
        IBUS.write_bus_packet(63, 0, [12, 1, 49])
        time.sleep(0.1)
        IBUS.write_bus_packet(63, 0, [12, 2, 49])

    def send_song_to_ike(self):
        if not self.ike_display:
            return
        if not self.ike_track:
            return
        thread = Thread(target=self._send_song_to_ike_thread)
        thread.setDaemon(True)
        thread.start()

    def _send_song_to_ike_thread(self):
        try:
            while int(xbmc.Player().getTime()) > 0.2:
                xbmc.sleep(1)

            while not xbmc.Player().isPlaying():
                xbmc.sleep(1)

            while int(xbmc.Player().getTime()) < 0.5:
                xbmc.sleep(1)

            Song = KODI.track_title()
            if Song == '':
                return
            log('SEND SONG: "%s" to IKE Display' % Song, 2)
            self._send_to_ike_thread(Song)
        except:
            log('Kodi has an error with playing or -> not playing <- media.')

    def send_to_ike(self, Text, when_pi_is_inactiv = False, when_ign_off = False):
        if not self.ike_display:
            return
        thread = Thread(target=self._send_to_ike_thread, args=(Text, when_pi_is_inactiv, when_ign_off))
        thread.setDaemon(True)
        thread.start()

    def _send_to_ike_thread(self, Text, when_pi_is_inactiv = False, when_ign_off = False):
        if not self.ike_display:
            return
        if not self.piaktiv and not when_pi_is_inactiv:
            return
        if self.ike_text_scrolling:
            self.cancel_ike_text = True
            while self.ike_text_scrolling:
                time.sleep(0.01)

        self.ike_text_scrolling = True
        scrollspeed = self.text_scrollspeed
        Text = _encode_ibus_chars(Text)
        if len(Text) <= 20:
            dat = [26, 53, 0] if when_ign_off else [35, 98, 48]
            dat.extend(asc_to_hex(Text.center(20)))
            if not self.cancel_ike_text:
                IBUS.write_bus_packet(200, 128, dat)
        else:
            Text_tmp = Text[:20]
            dat = [26, 53, 0] if when_ign_off else [35, 98, 48]
            dat.extend(asc_to_hex(Text_tmp))
            if not self.cancel_ike_text:
                IBUS.write_bus_packet(200, 128, dat)
            ticker = 1
            while ticker <= 1500:
                if self.cancel_ike_text:
                    break
                if not self.piaktiv and not when_pi_is_inactiv:
                    self.clear_ike(0)
                    break
                ticker += 1
                time.sleep(0.001)

            cnt = len(Text)
            cnt_tmp = 0
            ticker = 1
            while cnt_tmp + 20 <= cnt:
                if self.cancel_ike_text:
                    break
                if not self.piaktiv and not when_pi_is_inactiv:
                    self.clear_ike(0)
                    break
                if ticker == scrollspeed:
                    Text_tmp = Text[cnt_tmp:20 + cnt_tmp]
                    dat = [26, 53, 0] if when_ign_off else [35, 98, 48]
                    dat.extend(asc_to_hex(Text_tmp))
                    IBUS.write_bus_packet(200, 128, dat)
                    cnt_tmp += 1
                    ticker = 1
                else:
                    ticker += 1
                time.sleep(0.001)

            ticker = 1
            while ticker < 1000:
                if self.cancel_ike_text:
                    break
                if not self.piaktiv and not when_pi_is_inactiv:
                    self.clear_ike(0)
                    break
                ticker += 1
                time.sleep(0.001)

            ticker = 1
            cnt_tmp = len(Text) - 20
            while cnt_tmp + 20 >= 20:
                if self.cancel_ike_text:
                    break
                if not self.piaktiv and not when_pi_is_inactiv:
                    self.clear_ike(0)
                    break
                if ticker == scrollspeed:
                    if not self.piaktiv and not when_pi_is_inactiv:
                        self.clear_ike(0)
                        break
                    Text_tmp = Text[cnt_tmp:20 + cnt_tmp]
                    dat = [26, 53, 0] if when_ign_off else [35, 98, 48]
                    dat.extend(asc_to_hex(Text_tmp))
                    IBUS.write_bus_packet(200, 128, dat)
                    cnt_tmp += -1
                    ticker = 1
                else:
                    ticker += 1
                time.sleep(0.001)

        if not when_ign_off:
            self.clear_ike()
        self.ike_text_scrolling = False
        self.cancel_ike_text = False

    def clear_ike(self, wait = 3000, when_ign_off = False):
        if not self.ike_display:
            return
        ticker = 1
        while ticker < wait:
            time.sleep(0.001)
            if self.cancel_ike_text:
                return
            ticker += 1

        if when_ign_off:
            IBUS.write_bus_packet(48, 128, [26, 48, 0])
        else:
            IBUS.write_bus_packet(200, 128, [35, 64, 48])

    def bm_led(self, color, state = False):
        if color.lower() == 'red':
            IBUS.write_bus_packet(200, 240, [43, 1])
        if color.lower() == 'yellow':
            IBUS.write_bus_packet(200, 240, [43, 4])
        if color.lower() == 'green':
            IBUS.write_bus_packet(200, 240, [43, 16])
        if color.lower() == 'off':
            IBUS.write_bus_packet(200, 240, [43, 0])

    def bm_get_state(self):
        IBUS.write_bus_packet(63, 240, [11, 2])

    def bm_set_state(self, dat):
        if len(dat) < 2:
            return
        self.bm_sensor_brightness = dat[12]
        if self.bm_sensor_brightness == 0:
            self.bm_sensor_brightness = 1
        log('BMBT: Brightness = %s' % self.bm_sensor_brightness, 2)

    def nav_zoom(self, speed_kmh):
        """
        >= 30 km/h  -  200m B0 05 7F AA 10 02 72 (0xB0, 0x7F, [0xAA, 0x10, 0x02])
        >= 55 km/h  -  500m B0 05 7F AA 10 04 74 (0xB0, 0x7F, [0xAA, 0x10, 0x04])
        >= 80 km/h  - 1000m B0 05 7F AA 10 10 60 (0xB0, 0x7F, [0xAA, 0x10, 0x10])
        >= 120 km/h - 2000m B0 05 7F AA 10 11 61 (0xB0, 0x7F, [0xAA, 0x10, 0x11])
        >= 145 km/h - 5000m B0 05 7F AA 10 12 62 (0xB0, 0x7F, [0xAA, 0x10, 0x12])
        
        < 140 km/h - 2000m B0 05 7F AA 10 11 61 (0xB0, 0x7F, [0xAA, 0x10, 0x11])
        < 110 km/h - 1000m B0 05 7F AA 10 10 60 (0xB0, 0x7F, [0xAA, 0x10, 0x10])
        < 70 km/h  -  500m B0 05 7F AA 10 04 74 (0xB0, 0x7F, [0xAA, 0x10, 0x04])
        < 45 km/h  -  200m B0 05 7F AA 10 02 72 (0xB0, 0x7F, [0xAA, 0x10, 0x02])
        < 10 km/h  -  100m B0 05 7F AA 10 01 71 (0xB0, 0x7F, [0xAA, 0x10, 0x01])
        """
        if not self.map_auto_zoom:
            return
        zoom_level = -1
        if speed_kmh < 10:
            zoom_level = 100
        elif speed_kmh >= 145:
            zoom_level = 5000
        elif speed_kmh >= 120 and self.map_states['zoom_level'] < 2000:
            zoom_level = 2000
        elif speed_kmh >= 80 and self.map_states['zoom_level'] < 1000:
            zoom_level = 1000
        elif speed_kmh >= 55 and self.map_states['zoom_level'] < 500:
            zoom_level = 500
        elif speed_kmh >= 30 and self.map_states['zoom_level'] < 200:
            zoom_level = 200
        elif speed_kmh < 45 and self.map_states['zoom_level'] > 200:
            zoom_level = 200
        elif speed_kmh < 70 and self.map_states['zoom_level'] > 500:
            zoom_level = 500
        elif speed_kmh < 110 and self.map_states['zoom_level'] > 1000:
            zoom_level = 1000
        elif speed_kmh < 140 and self.map_states['zoom_level'] > 2000:
            zoom_level = 2000
        if zoom_level != self.map_states['zoom_level'] and zoom_level > -1:
            IBUS.write_bus_packet(*self.map_states[zoom_level])
            self.map_states['zoom_level'] = zoom_level
            log('NAVI: ZOOM LEVEL %sm on %skm/h' % (zoom_level, speed_kmh))

    def nav_show_map(self):
        IBUS.write_bus_packet(176, 127, [170, 4, 0])
        log('Show Navigation Map')

    def pdc_req_start(self):
        if not self.pdc_on:
            return
        if not self.pdc_req_running:
            self.pdc_on_value = None
            thread = Thread(target=self._pdc_req_start)
            thread.setDaemon(True)
            thread.start()

    def _pdc_req_start(self):
        log('PDC: Request Started')
        self.got_pdc_answer = True
        self.pdc_req_running = True
        self.pdc_counter = self.pdc_timeout
        no_answer_counter = 0
        while self.pdc_counter > 0:
            if self.pdc_req_cancel:
                break
            if self.got_pdc_answer or no_answer_counter >= 4:
                no_answer_counter = 0
                self.got_pdc_answer = False
                IBUS.write_bus_packet(63, 96, [27])
            no_answer_counter += 1
            self.pdc_counter -= 0.25
            time.sleep(0.25)

        self.pdc_req_running = False
        self.pdc_on_value = None
        log('PDC: Request Stoped')
        if not self.pass_bm_buttons:
            self.set_rearcam_io(False)
        KODI.set_property('IBUSCOMMUNICATOR_PDC_SHOW', '0')
        if not self.pdc_req_cancel and self.pdc_timeout_off:
            IBUS.write_bus_packet(63, 96, [12, 64])
        self.pdc_req_cancel = False

    def pdc_req_stop(self):
        self.pdc_req_cancel = True

    def pdc_set_state(self, dat):
        """
        DIAG REPLY:
                 00 01 02 03 04 05 06 07 08 09 10 11   <-- Stelle
        60 0E 3F A0 AA BB CC DD EE FF GG HH II JJ KK CK
        
        AA - ???
        BB - RLS
        CC - RRS
        DD - RLC
        EE - RRC
        FF - FLS
        GG - FRS
        HH - FLC
        II - FRC
        JJ - XXXX 0001 > PDC ON
        KK - ???
        """
        if not self.pdc_on:
            return
        if len(dat) < 2:
            return

        def pdc_image(value):
            log('input: %s' % value, 3)
            if value <= 7:
                return '20'
            if 7 <= value <= 75:
                result = '%s' % int(abs((float(value) - 77) / 73 * 20))
                if len(result) < 2:
                    return '%s'.zfill(3) % result
                return '%s' % result
            if value >= 76:
                return '00'

        def pdc_label(value):
            if value > 75:
                return '---'
            return '%s' % value

        self.got_pdc_answer = True
        rear_left_side = dat[2]
        rear_right_side = dat[3]
        rear_left_center = dat[4]
        rear_right_center = dat[5]
        front_left_side = dat[6]
        front_right_side = dat[7]
        front_left_center = dat[8]
        front_right_center = dat[9]
        on_value = get_bit_from_hex(dat[10], BIT[0])
        if rear_left_side + rear_right_side + rear_left_center + rear_right_center + front_left_side + front_right_side + front_left_center + front_right_center < 2040:
            self.pdc_counter = self.pdc_timeout
        KODI.set_property('IBUSCOMMUNICATOR_PDC_FLS', '%s' % pdc_label(front_left_side))
        KODI.set_property('IBUSCOMMUNICATOR_PDC_FLC', '%s' % pdc_label(front_left_center))
        KODI.set_property('IBUSCOMMUNICATOR_PDC_FRC', '%s' % pdc_label(front_right_center))
        KODI.set_property('IBUSCOMMUNICATOR_PDC_FRS', '%s' % pdc_label(front_right_side))
        KODI.set_property('IBUSCOMMUNICATOR_PDC_RLS', '%s' % pdc_label(rear_left_side))
        KODI.set_property('IBUSCOMMUNICATOR_PDC_RLC', '%s' % pdc_label(rear_left_center))
        KODI.set_property('IBUSCOMMUNICATOR_PDC_RRC', '%s' % pdc_label(rear_right_center))
        KODI.set_property('IBUSCOMMUNICATOR_PDC_RRS', '%s' % pdc_label(rear_right_side))
        log('PDC: Values\n                   %s - %s - %s - %s \n                   %s - %s - %s - %s ' % (front_left_side,
         front_left_center,
         front_right_center,
         front_right_side,
         rear_left_side,
         rear_left_center,
         rear_right_center,
         rear_right_side), 2)
        log('pic number - %s' % pdc_image(front_left_center), 3)
        KODI.set_property('IBUSCOMMUNICATOR_PDC_BG_IMG', '%s' % EVENT.pdc_bg)
        KODI.set_property('IBUSCOMMUNICATOR_PDC_FLS_IMG', '%s' % os.path.join(ADDONPDCPATH, 'side', 'SIDE%s.png' % pdc_image(front_left_side)))
        KODI.set_property('IBUSCOMMUNICATOR_PDC_FLC_IMG', '%s' % os.path.join(ADDONPDCPATH, 'mid', 'MID%s.png' % pdc_image(front_left_center)))
        KODI.set_property('IBUSCOMMUNICATOR_PDC_FRC_IMG', '%s' % os.path.join(ADDONPDCPATH, 'mid', 'MID%s.png' % pdc_image(front_right_center)))
        KODI.set_property('IBUSCOMMUNICATOR_PDC_FRS_IMG', '%s' % os.path.join(ADDONPDCPATH, 'side', 'SIDE%s.png' % pdc_image(front_right_side)))
        KODI.set_property('IBUSCOMMUNICATOR_PDC_RLS_IMG', '%s' % os.path.join(ADDONPDCPATH, 'side', 'SIDE%s.png' % pdc_image(rear_left_side)))
        KODI.set_property('IBUSCOMMUNICATOR_PDC_RLC_IMG', '%s' % os.path.join(ADDONPDCPATH, 'mid', 'MID%s.png' % pdc_image(rear_left_center)))
        KODI.set_property('IBUSCOMMUNICATOR_PDC_RRC_IMG', '%s' % os.path.join(ADDONPDCPATH, 'mid', 'MID%s.png' % pdc_image(rear_right_center)))
        KODI.set_property('IBUSCOMMUNICATOR_PDC_RRS_IMG', '%s' % os.path.join(ADDONPDCPATH, 'side', 'SIDE%s.png' % pdc_image(rear_right_side)))
        if self.pdc_on_value:
            if not on_value:
                self.pdc_req_stop()
        else:
            if self.pdc_req_running:
                KODI.set_property('IBUSCOMMUNICATOR_PDC_SHOW', '1')
                if not self.pass_bm_buttons:
                    self.set_rearcam_io(True)
            self.pdc_on_value = on_value

    def obc_req(self, resetrunonce = False):
        if self.obc_req_runs:
            return
        if resetrunonce:
            self.obc_req_runonce = False
        if not self.obc_req_runonce:
            thread = Thread(target=self._obc_req_thread)
            thread.setDaemon(True)
            thread.start()
        self.obc_req_runonce = True

    def _obc_req_thread(self):
        self.obc_req_runs = True
        obc_req_delay = 210
        xbmc.sleep(350)
        self.obc_time_req()
        xbmc.sleep(obc_req_delay)
        self.obc_date_req()
        xbmc.sleep(obc_req_delay)
        self.obc_outtemp_req()
        xbmc.sleep(obc_req_delay)
        self.obc_cons1_req()
        xbmc.sleep(obc_req_delay)
        self.obc_cons2_req()
        xbmc.sleep(obc_req_delay)
        self.obc_range_req()
        xbmc.sleep(obc_req_delay)
        self.obc_dist_req()
        xbmc.sleep(obc_req_delay)
        self.obc_arr_req()
        xbmc.sleep(obc_req_delay)
        self.obc_limit_req()
        xbmc.sleep(obc_req_delay)
        self.obc_avg_req()
        xbmc.sleep(obc_req_delay)
        self.obc_stpwtch_req()
        xbmc.sleep(obc_req_delay)
        self.obc_tmr1_req()
        xbmc.sleep(obc_req_delay)
        self.obc_tmr2_req()
        xbmc.sleep(obc_req_delay)
        self.obc_coolant_req()
        xbmc.sleep(obc_req_delay)
        self.obc_ind_req()
        xbmc.sleep(obc_req_delay)
        self.obc_voltage_req()
        self.obc_req_runs = False

    def obc_time_req(self):
        IBUS.write_bus_packet(59, 128, [65, 1, 1])

    def obc_time_put(self, dat, UTC = False):
        self.obc_settime += 1
        hexstring = dat
        clock = ''
        if hexstring[3] == 32:
            clock = '0'
        else:
            clock = chr(hexstring[3])
        clock = clock + chr(hexstring[4]) + chr(hexstring[5]) + chr(hexstring[6]) + chr(hexstring[7])
        clock = clock + ':00'
        if hexstring[8] != 32:
            clock = clock + chr(hexstring[8]) + chr(hexstring[9])
        curhh, curmm, curss = os.popen('date +%T').readline().strip().split(':')
        newhh, newmm, newss = clock.split(':')
        log('OBC CUR HH: %s' % curhh, 3)
        log('OBC NEW HH: %s' % newhh, 3)
        log('OBC CUR MM: %s' % curmm, 3)
        log('OBC NEW HH: %s' % newmm, 3)
        if self.obc_settime > 2 and curhh == newhh and abs(int(curmm) - int(newmm)) < 2 and self.obc_time[1] == chr(hexstring[8]) + chr(hexstring[9]):
            self.obc_settime = 3
            log('OBC: TIME: ' + clock + ' - no update requiered')
            return
        if newhh == '--' or newmm == '--':
            log('OBC: BAD TIME: ' + clock)
            return
        log('OBC: SET SYSTEM TIME: ' + clock)
        f = os.popen('sudo date +%T%p -s "' + clock + '"')
        self.obc_time = [clock, chr(hexstring[8]) + chr(hexstring[9])]
        xbmc.sleep(100)

    def obc_time_get(self):
        return self.obc_time[0]

    def obc_date_req(self):
        IBUS.write_bus_packet(59, 128, [65, 2, 1])

    def obc_date_put(self, dat):
        hexstring = dat[3:]
        if self.obc_date[1] == hexstring:
            log('OBC: DATE: ' + self.obc_date[0] + ' - no update requiered')
            return
        curtime = os.popen('date +%T').readline().strip()
        datestring = hex_to_asc(hexstring)
        if datestring.find('.') > 0:
            day, month, year = datestring.split('.')
        else:
            month, day, year = datestring.split('/')
        newdate = year + month + day
        if day == '--' or month == '--' or year == '----':
            log('OBC: BAD DATE: ' + newdate)
            return
        log('OBC: SET SYSTEM DATE: ' + newdate)
        f = os.popen('sudo date +%Y%m%d -s "' + newdate + '"')
        time.sleep(0.3)
        if self.obc_time[0]:
            f = os.popen('sudo date +%T -s "' + self.obc_time[0] + '"')
        time.sleep(0.1)
        self.obc_date = [datestring, hexstring]

    def obc_date_get(self):
        return self.obc_date[0]

    def obc_outtemp_req(self):
        IBUS.write_bus_packet(59, 128, [65, 3, 1])

    def obc_outtemp_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: SET OUT TEMP: ' + convstring)
        if KODI.get_addon_setting('home_temp') == 'OBC Outtemp':
            KODI.set_property('IBUSCOMMUNICATOR_OBC_OUTTEMP', convstring)
        self.obc_outtemp = convstring

    def obc_outtemp_get(self):
        return self.obc_outtemp

    def obc_cons1_req(self):
        IBUS.write_bus_packet(59, 128, [65, 4, 1])

    def obc_cons1_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: SET CONS1: ' + convstring)
        self.obc_cons1 = convstring

    def obc_cons1_reset(self):
        IBUS.write_bus_packet(59, 128, [65, 4, 16])

    def obc_cons1_get(self):
        return self.obc_cons1

    def obc_cons2_req(self):
        IBUS.write_bus_packet(59, 128, [65, 5, 1])

    def obc_cons2_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: SET CONS2: ' + convstring)
        self.obc_cons2 = convstring

    def obc_cons2_reset(self):
        IBUS.write_bus_packet(59, 128, [65, 5, 16])

    def obc_cons2_get(self):
        return self.obc_cons2

    def obc_range_req(self):
        IBUS.write_bus_packet(59, 128, [65, 6, 1])

    def obc_range_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: SET RANGE: ' + convstring)
        self.obc_range = convstring

    def obc_range_get(self):
        return self.obc_range

    def obc_dist_req(self):
        IBUS.write_bus_packet(59, 128, [65, 7, 1])

    def obc_dist_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: SET DIST: ' + convstring)
        self.obc_dist = convstring

    def obc_dist_set(self, value):

        def bytes(num):
            return [num >> 8, num & 255]

        value = bytes(value)
        IBUS.write_bus_packet(59, 128, [64,
         7,
         value[0],
         value[1]])

    def obc_dist_reset(self):
        IBUS.write_bus_packet(59, 128, [64,
         7,
         0,
         0])

    def obc_dist_get(self):
        return self.obc_dist

    def obc_arr_req(self):
        IBUS.write_bus_packet(59, 128, [65, 8, 1])

    def obc_arr_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: SET ARR: ' + convstring)
        self.obc_arr = convstring

    def obc_arr_get(self):
        return self.obc_arr

    def obc_avg_req(self):
        IBUS.write_bus_packet(59, 128, [65, 10, 1])

    def obc_avg_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: SET AVG: ' + convstring)
        self.obc_avg = convstring

    def obc_avg_reset(self):
        IBUS.write_bus_packet(59, 128, [65, 10, 16])

    def obc_avg_get(self):
        return self.obc_avg

    def obc_stpwtch_req(self):
        IBUS.write_bus_packet(59, 128, [65, 14, 1])

    def obc_stpwtch_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: SET STPWTCH: ' + convstring)
        self.obc_stpwtch = convstring

    def obc_stpwtch_reset(self):
        IBUS.write_bus_packet(59, 128, [65,
         14,
         16,
         16])

    def obc_stpwtch_get(self):
        return self.obc_stpwtch

    def obc_tmr1_req(self):
        IBUS.write_bus_packet(59, 128, [65, 15, 1])

    def obc_tmr1_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: SET TMR1: ' + convstring)
        self.obc_tmr1 = convstring

    def obc_tmr1_set(self, value):
        IBUS.write_bus_packet(59, 128, [65, 9, 1])

    def obc_tmr1_reset(self):
        if '--:--' not in self.obc_tmr1:
            IBUS.write_bus_packet(59, 128, [64,
             15,
             255,
             255])
            self.obc_tmr1_enable(False)

    def obc_tmr1_enable(self, state):
        if state:
            if '--:--' not in self.obc_tmr1:
                IBUS.write_bus_packet(59, 128, [65, 15, 4])
        else:
            IBUS.write_bus_packet(59, 128, [65, 15, 8])

    def obc_tmr1_get(self):
        return self.obc_tmr1

    def obc_tmr1_get_ind(self):
        return self.obc_tmr1ind

    def obc_tmr2_req(self):
        IBUS.write_bus_packet(59, 128, [65, 16, 1])

    def obc_tmr2_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: SET TMR2: ' + convstring)
        self.obc_tmr2 = convstring

    def obc_tmr2_set(self, value):
        IBUS.write_bus_packet(59, 128, [65, 9, 1])

    def obc_tmr2_reset(self):
        if '--:--' not in self.obc_tmr2:
            IBUS.write_bus_packet(59, 128, [64,
             16,
             255,
             255])
            self.obc_tmr2_enable(False)

    def obc_tmr2_enable(self, state):
        if state:
            if '--:--' not in self.obc_tmr2:
                IBUS.write_bus_packet(59, 128, [65, 16, 4])
        else:
            IBUS.write_bus_packet(59, 128, [65, 16, 8])

    def obc_tmr2_get(self):
        return self.obc_tmr2

    def obc_tmr2_get_ind(self):
        return self.obc_tmr2ind

    def obc_ind_req(self):
        IBUS.write_bus_packet(59, 128, [65, 9, 2])

    def obc_ind_put(self, dat):
        """
        BOOL LIMIT/MEMO/AUX HEAT/AUX VENT
        80 05 E7 2A XX YY CK
        Bit 7 -> 0
        
        XX Bit 7
        XX Bit 6
        XX Bit 5    MEMO
        XX Bit 4
        XX Bit 3
        XX Bit 2
        XX Bit 1    LIMIT
        XX Bit 0
        
        YY Bit 7
        YY Bit 6
        YY Bit 5    AUX-HEAT
        YY Bit 4    TIMER 2
        YY Bit 3    AUX-VENT
        YY Bit 2    TIMER 1
        YY Bit 1
        YY Bit 0
        """
        xx = dat[1]
        yy = dat[2]
        memoind = get_bit_from_hex(xx, BIT[5])
        limitind = get_bit_from_hex(xx, BIT[1])
        tmr1ind = get_bit_from_hex(yy, BIT[2])
        tmr2ind = get_bit_from_hex(yy, BIT[4])
        if self.obc_memoind != memoind:
            self.obc_memoind = memoind
            log('OBC: SET MEMO IND: %s' % memoind)
        if self.obc_limitind != limitind:
            self.obc_limitind = limitind
            log('OBC: SET LIMIT IND: %s' % limitind)
        if self.obc_tmr1ind != tmr1ind:
            self.obc_tmr1ind = tmr1ind
            log('OBC: SET TIMER1 IND: %s' % tmr1ind)
        if self.obc_tmr2ind != tmr2ind:
            self.obc_tmr2ind = tmr2ind
            log('OBC: SET TIMER2 IND: %s' % tmr2ind)

    def obc_limit_req(self):
        IBUS.write_bus_packet(59, 128, [65, 9, 1])

    def obc_limit_set(self, value = None):
        if not value:
            IBUS.write_bus_packet(59, 128, [65, 9, 32])
        else:

            def bytes(num):
                return [num >> 8, num & 255]

            value = bytes(value)
            IBUS.write_bus_packet(59, 128, [64,
             9,
             value[0],
             value[1]])

    def obc_limit_reset(self):
        IBUS.write_bus_packet(59, 128, [64,
         9,
         255,
         255])
        self.obc_limit_enable(False)

    def obc_limit_enable(self, state):
        if state:
            IBUS.write_bus_packet(59, 128, [65, 9, 4])
        else:
            IBUS.write_bus_packet(59, 128, [65, 9, 8])

    def obc_limit_put(self, dat):
        hexstring = dat[3:]
        convstring = hex_to_asc(hexstring)
        log('OBC: SET LIMIT: ' + convstring)
        self.obc_limit = convstring

    def obc_limit_get(self):
        return self.obc_limit

    def obc_limit_get_ind(self):
        return self.obc_limitind

    def obc_memo_req(self):
        IBUS.write_bus_packet(59, 128, [65, 12, 1])

    def obc_memo_enable(self, state):
        if state:
            IBUS.write_bus_packet(59, 128, [65, 12, 7])
        else:
            IBUS.write_bus_packet(59, 128, [65, 12, 8])

    def obc_memo_get_ind(self):
        return self.obc_memoind

    def obc_coolant_req(self):
        IBUS.write_bus_packet(91, 128, [29])

    def obc_coolant_put(self, dat):
        tmp = dat[2]
        if tmp > 128:
            coolanttemp = tmp - 256
        else:
            coolanttemp = tmp
        log('OBC: SET COOLANT TEMP: %s' % coolanttemp)
        if KODI.get_addon_setting('home_temp') == 'Coolant Temp':
            KODI.set_property('IBUSCOMMUNICATOR_OBC_OUTTEMP', '%s%s\xc2\xb0C' % ('+' if coolanttemp > 0 else '', coolanttemp))
        self.obc_coolant = coolanttemp
        tmp = dat[1]
        if tmp > 128:
            outtemp = tmp - 256
        else:
            outtemp = tmp
        log('OBC: SET IKE OUT TEMP: %s' % outtemp)
        if KODI.get_addon_setting('home_temp') == 'IKE Outtemp':
            KODI.set_property('IBUSCOMMUNICATOR_OBC_OUTTEMP', '%s%s\xc2\xb0C' % ('+' if coolanttemp > 0 else '', outtemp))
        if coolanttemp <= 40:
            angle = 101
        elif 40 < coolanttemp < 75:
            angle = 101 + (coolanttemp - 40) * 79 / 35
        elif 75 <= coolanttemp <= 100:
            angle = 180
        elif 100 < coolanttemp < 125:
            angle = 180 + (coolanttemp - 100) * 79 / 25
        elif coolanttemp >= 125:
            angle = 259
        angle = '%s' % angle
        while len(angle) < 3:
            angle = '0%s' % angle

    def obc_coolant_get(self):
        return '%s%s\xc2\xb0C' % ('+' if self.obc_coolant > 0 else '', self.obc_coolant)

    def obc_voltage_req(self):
        IBUS.write_bus_packet(63, 127, [11])

    def obc_voltage_put(self, dat):
        if len(dat) < 2:
            return
        voltage = round(float(dat[13] << 8 | dat[14]) / 1000, 1)
        if voltage != self.obc_voltage:
            self.obc_voltage = voltage
        log('OBC: SET VOLTAGE: %s' % voltage)

    def obc_voltage_get(self):
        return '%s V' % self.obc_voltage

    def obc_speed_rpm_put(self, dat):
        speed_kmh = dat[1] * 2
        speed_mph = int(speed_kmh * 0.6214)
        if speed_kmh >= self.zv_auto_lock_speed and self.zv_auto_lock and not self.gm_states['zvlockstate'] and not self.ike_states['handbrake']:
            self.gm_zv_lock()
        self.nav_zoom(speed_kmh)
        if speed_kmh != self.obc_speed_kmh:
            self.obc_speed_kmh = speed_kmh
            self.obc_speed_mph = speed_mph
        rpm = dat[2] * 100
        if rpm != self.obc_rpm:
            self.obc_rpm = rpm
        log('OBC: SET SPEED KMH - MPH: %s - %s' % (speed_kmh, speed_mph))
        log('OBC: SET SPEED rpm: %s' % rpm)

    def obc_speed_get(self, mph = False):
        if not mph:
            return '%s KM/H' % self.obc_speed_kmh
        else:
            return '%s MPH' % self.obc_speed_mph

    def obc_rpm_get(self):
        return '%s min\xcb\x89\xc2\xb9' % self.obc_rpm

    def obc_fuellevel_get(self):
        return '%s%s L' % ('R ' if self.obc_fuellevel_low else '', self.obc_fuellevel)

    def obc_open_gui(self):
        if OBCGUI.isActive and xbmcgui.getCurrentWindowId() == 13000:
            OBCGUI.onStop()
        elif OBCGUI.isActive:
            OBCGUI.onStop()
            OBCGUI.doModal()
        else:
            OBCGUI.doModal()


def log(string, lvl = 1):
    thread = Thread(target=KODI.log, args=(string, lvl))
    thread.setDaemon(True)
    thread.start()


def note(heading, message = None, time = 5000):
    thread = Thread(target=KODI.note, args=(heading, message, time))
    thread.setDaemon(True)
    thread.start()


def dialog_ok(label1, label2 = None, label3 = None):
    thread = Thread(target=KODI.dialog_ok, args=(label1, label2, label3))
    thread.setDaemon(True)
    thread.start()


def get_bit_from_hex(value, bit):
    output = bin(value)[2:].zfill(8)
    if int(output[bit - 1:bit]) == 1:
        return True
    return False


def set_bit_in_hex(hexstring, bit, value):
    temp = bin(int(hexstring, 16))[2:].zfill(8)
    output = list(temp)
    output[bit] = str(value)
    return ''.join(output)


def asc_to_hex(text):
    text = _encode_ibus_chars(text)
    return [ ord(l) for l in text ]


def hex_to_asc(in_hex):
    out_hex = [ chr(l) for l in in_hex ]
    return _decode_ibus_chars(''.join(out_hex).strip())


def _encode_ibus_chars(text):
    text = text.replace('\xc3\x9f', chr(160))
    text = text.replace('\xc3\x84', chr(161))
    text = text.replace('\xc3\x96', chr(162))
    text = text.replace('\xc3\x9c', chr(163))
    text = text.replace('\xc3\xa4', chr(164))
    text = text.replace('a\xcc\x88', chr(164))
    text = text.replace('\xc3\xb6', chr(165))
    text = text.replace('o\xcc\x88', chr(165))
    text = text.replace('\xc3\xbc', chr(166))
    text = text.replace('u\xcc\x88', chr(166))
    text = text.replace('\xc2\xb0', chr(168))
    text = text.replace('\xc2\xb4', chr(39))
    text = text.replace('\xc3\xba', 'u')
    return text


def _decode_ibus_chars(text):
    text = text.replace(chr(160), '\xc3\x9f')
    text = text.replace(chr(161), '\xc3\x84')
    text = text.replace(chr(162), '\xc3\x96')
    text = text.replace(chr(163), '\xc3\x9c')
    text = text.replace(chr(164), '\xc3\xa4')
    text = text.replace(chr(165), '\xc3\xb6')
    text = text.replace(chr(166), '\xc3\xbc')
    text = text.replace(chr(168), '\xc2\xb0')
    text = text.replace(chr(39), '\xc2\xb4')
    return text


def time_now_in_range(time1, time2):
    try:
        now = datetime.datetime.now()
        time_now = datetime.datetime.strptime('%s:%s' % (now.hour, now.minute), '%H:%M')
        if 'AM' in time1.upper() or 'PM' in time1.upper():
            time_start = datetime.datetime.strptime(time1, '%I:%M %p')
        else:
            time_start = datetime.datetime.strptime(time1, '%H:%M')
        if 'AM' in time2.upper() or 'PM' in time2.upper():
            time_end = datetime.datetime.strptime(time2, '%I:%M %p')
        else:
            time_end = datetime.datetime.strptime(time2, '%H:%M')
        if time_start == time_end:
            return False
        if time_start < time_end:
            if time_start <= time_now < time_end:
                return True
            else:
                return False
        else:
            if time_now >= time_start or time_now < time_end:
                return True
            return False
    except:
        log('time 1 or 2 error')
        return False


def get_pin_pos_img(value, value_range, start_angle, end_angle, min_angle = None, max_angle = None):
    if not min_angle:
        min_angle = start_angle
    if not max_angle:
        max_angle = end_angle
    angle = start_angle + value * (end_angle - start_angle) / value_range
    if angle <= min_angle:
        angle = min_angle
    elif angle >= max_angle:
        angle = max_angle
    angle = '%s' % angle
    while len(angle) < 3:
        angle = '0%s' % angle

    return os.path.join(ADDONGAUGEPATH, 'IBusOBCGAUGE_pin_%s.png' % angle)


def syscheck():
    try:
        import serial
        return True
    except:
        pb = xbmcgui.DialogProgress()
        pb.create('IBusCommunicator')
        pb.update(25, 'Try to install requiered Modules')
        xbmc.sleep(300)
        try:
            pb.update(35, 'Update Package Libary...')
            f = subprocess.Popen('sudo apt-get update', shell=True, stdout=subprocess.PIPE).stdout.read()
            pb.update(50, 'Installation python-serial...')
            f = subprocess.Popen("echo -e 'y' | sudo apt-get install python-serial", shell=True, stdout=subprocess.PIPE).stdout.read()
            pb.update(60, 'Installation python-serial......')
            xbmc.sleep(300)
            pb.update(100, 'Finished')
            xbmc.sleep(300)
            pb.close()
            if f.find('Setting up python-serial') > 0:
                log('IBUSCOMMUNICATOR: python-serial successfully  installed')
                dialog_ok('pySerial successfully  installed')
                return True
            log('IBUSCOMMUNICATOR: python-serial not installed')
            dialog_ok('pySerial was not successfully installed')
            return False
        except:
            pb.close()
            log('IBUSCOMMUNICATOR: python-serial not installed')
            dialog_ok('pySerial could not successfull installed')
            return False


def handle_extern_events():
    serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    serversocket.bind(('localhost', 8089))
    serversocket.listen(5)
    connection, address = serversocket.accept()
    connection.settimeout(0.1)
    message = connection.recv(10)
    if len(message) > 0:
        if message.upper() == 'OBC':
            log('RXTX: Receive >OBC<')
            thread = Thread(target=EVENT.obc_open_gui)
            thread.setDaemon(True)
            thread.start()


def load_settings(settings_changed = False):
    cdc_emu_tmp = EVENT.cdc_emu
    gpio_ntsc_tmp = EVENT.gpio_ntsc
    gpio_gear_shift_tmp = EVENT.gpio_gear_shift
    gpio_gear_shift_up_tmp = EVENT.gpio_gear_shift_up
    gpio_gear_shift_down_tmp = EVENT.gpio_gear_shift_down
    try:
        loglevel = int(KODI.get_addon_setting('log_lvl'))
    except:
        loglevel = int(KODI.get_addon_setting('log_lvl')[-1:])

    log('SETTINGS: LOAD: LOGLVL=%s' % loglevel, 0)
    KODI.log_level = loglevel
    EVENT.device_path = KODI.get_addon_setting('ser_dev')
    log('SETTINGS: LOAD: DEVICE_PATH=%s' % EVENT.device_path)
    EVENT.cdc_emu = KODI.get_addon_setting('cdc_emu')
    piaudiomode = KODI.get_addon_setting('audio_mode')
    EVENT.modefm = False
    EVENT.modecd = False
    EVENT.modetape = False
    EVENT.modeaux = False
    EVENT.modecis = False
    EVENT.modealways = False
    if piaudiomode == 'CD':
        EVENT.modecd = True
        EVENT.cdc_emu = True
        log('SETTINGS: LOAD: AUDIOMODE=CD')
    elif piaudiomode == 'TAPE':
        EVENT.modetape = True
        log('SETTINGS: LOAD: AUDIOMODE=TAPE')
    elif piaudiomode == 'AUX':
        EVENT.modeaux = True
        log('SETTINGS: LOAD: AUDIOMODE=AUX')
    elif piaudiomode == 'CIS':
        EVENT.modecis = True
        EVENT.cdc_emu = False
        log('SETTINGS: LOAD: AUDIOMODE=CIS')
    elif piaudiomode == 'ALWAYS':
        EVENT.modealways = True
        log('SETTINGS: LOAD: AUDIOMODE=ALWAYS')
    log('SETTINGS: LOAD: CDC_EMU=%s' % EVENT.cdc_emu)
    EVENT.car_model = KODI.get_addon_setting('car_model')
    log('SETTINGS: LOAD: CAR_MODEL=%s' % EVENT.car_model)
    EVENT.dsp_cd = KODI.get_addon_setting('dsp_cd')
    EVENT.dsp_tuner = KODI.get_addon_setting('dsp_tuner')
    if EVENT.dsp_tuner:
        EVENT.dsp_cd = False
    if not EVENT.modecd:
        EVENT.dsp_tuner = False
    log('SETTINGS: LOAD: DSP_CD=%s' % EVENT.dsp_cd)
    log('SETTINGS: LOAD: DSP_TUNER=%s' % EVENT.dsp_tuner)
    EVENT.gpio_ntsc = KODI.get_addon_setting('use_gpio')
    log('SETTINGS: LOAD: USE_GPIO=%s' % EVENT.gpio_ntsc)
    EVENT.welcome_on_boot = KODI.get_addon_setting('welcome_on_boot')
    log('SETTINGS: LOAD: WELCOME_ON_BOOT=%s' % EVENT.welcome_on_boot)
    EVENT.wel_light = KODI.get_addon_setting('wel_light')
    log('SETTINGS: LOAD: WEL_LIGHT=%s' % EVENT.wel_light)
    EVENT.wel_light_time = int(KODI.get_addon_setting('wel_light_time'))
    log('SETTINGS: LOAD: WEL_LIGHT_TIME=%s' % EVENT.wel_light_time)
    EVENT.lev_light = KODI.get_addon_setting('lev_light')
    log('SETTINGS: LOAD: LEV_LIGHT=%s' % EVENT.lev_light)
    EVENT.lev_light_time = int(KODI.get_addon_setting('lev_light_time'))
    log('SETTINGS: LOAD: LEV_LIGHT_TIME=%s' % EVENT.lev_light_time)
    EVENT.keyin_off = KODI.get_addon_setting('keyin_off')
    log('SETTINGS: LOAD: KEYIN_OFF=%s' % EVENT.keyin_off)
    EVENT.lev_light_ign_off = KODI.get_addon_setting('lev_light_ign_off')
    log('SETTINGS: LOAD: LEV_LIGHT_IGN_OFF=%s' % EVENT.lev_light_ign_off)
    EVENT.doors_off = KODI.get_addon_setting('doors_off')
    log('SETTINGS: LOAD: DOORS_OFF=%s' % EVENT.doors_off)
    EVENT.day_time = KODI.get_addon_setting('day_time')
    log('SETTINGS: LOAD: DAY_TIME=%s' % EVENT.day_time)
    EVENT.day_time_start = KODI.get_addon_setting('day_time_start')
    log('SETTINGS: LOAD: DAY_TIME_START=%s' % EVENT.day_time_start)
    EVENT.day_time_end = KODI.get_addon_setting('day_time_end')
    log('SETTINGS: LOAD: DAY_TIME_END=%s' % EVENT.day_time_end)
    EVENT.mir_unfold = KODI.get_addon_setting('mir_unfold')
    log('SETTINGS: LOAD: MIR_UNFOLD=%s' % EVENT.mir_unfold)
    EVENT.mir_fold = KODI.get_addon_setting('mir_fold')
    log('SETTINGS: LOAD: MIR_FOLD=%s' % EVENT.mir_fold)
    EVENT.ike_display = KODI.get_addon_setting('ike_disp')
    log('SETTINGS: LOAD: IKE_DISP=%s' % EVENT.ike_display)
    EVENT.ike_track = KODI.get_addon_setting('ike_track')
    log('SETTINGS: LOAD: IKE_TRACK=%s' % EVENT.ike_track)
    EVENT.wel_ike = KODI.get_addon_setting('wel_ike')
    log('SETTINGS: LOAD: WEL_IKE=%s' % EVENT.wel_ike)
    EVENT.wel_iketxt = KODI.get_addon_setting('wel_iketxt')
    log('SETTINGS: LOAD: WEL_IKETXT=%s' % EVENT.wel_iketxt)
    EVENT.wel_iketxt_hold = KODI.get_addon_setting('wel_iketxt_hold')
    log('SETTINGS: LOAD: WEL_IKETXT_HOLD=%s' % EVENT.wel_iketxt_hold)
    EVENT.text_scrollspeed = int(KODI.get_addon_setting('text_scrollspeed'))
    log('SETTINGS: LOAD: TEXT_SCROLLSPEED=%s' % EVENT.text_scrollspeed)
    EVENT.seek_sec = int(float(KODI.get_addon_setting('seek_sec')) * 1000)
    log('SETTINGS: LOAD: SEEK_SEC=%s' % EVENT.seek_sec)
    EVENT.seek_max = int(KODI.get_addon_setting('seek_max'))
    log('SETTINGS: LOAD: SEEK_MAX=%s' % EVENT.seek_max)
    EVENT.navhold_event = KODI.get_addon_setting('navhold_event')
    log('SETTINGS: LOAD: NAVHOLD_EVENT=%s' % EVENT.navhold_event)
    EVENT.inv_navturnbtn = KODI.get_addon_setting('inv_navturnbtn')
    log('SETTINGS: LOAD: INV_NAVTURNBTN=%s' % EVENT.inv_navturnbtn)
    setting = int(KODI.get_addon_setting('stw_rt_event'))
    if setting == 2:
        EVENT.use_stw_nav = True
        EVENT.nav_toggle_map = False
    elif setting == 1:
        EVENT.use_stw_nav = False
        EVENT.nav_toggle_map = True
    else:
        EVENT.use_stw_nav = False
        EVENT.nav_toggle_map = False
    log('SETTINGS: LOAD: USE_STW_NAV=%s' % EVENT.use_stw_nav)
    if not EVENT.use_stw_nav:
        EVENT.stw_nav = False
    log('SETTINGS: LOAD: NAV_TOGGLE_MAP=%s' % EVENT.nav_toggle_map)
    EVENT.gpio_gear_shift = KODI.get_addon_setting('gpio_gear_shift')
    log('SETTINGS: LOAD: GPIO_GEAR_SHIFT=%s' % EVENT.gpio_gear_shift)
    EVENT.gpio_gear_shift_trigger_time = float(KODI.get_addon_setting('gpio_gear_shift_trigger_time')) / 1000
    log('SETTINGS: LOAD: GPIO_GEAR_SHIFT_TRIGGER_TIME=%s' % EVENT.gpio_gear_shift_trigger_time)
    EVENT.gpio_gear_shift_up = int(KODI.get_addon_setting('gpio_gear_shift_up'))
    log('SETTINGS: LOAD: GPIO_GEAR_SHIFT_UP=%s' % EVENT.gpio_gear_shift_up)
    EVENT.gpio_gear_shift_down = int(KODI.get_addon_setting('gpio_gear_shift_down'))
    log('SETTINGS: LOAD: GPIO_GEAR_SHIFT_DOWN=%s' % EVENT.gpio_gear_shift_down)
    EVENT.comfort_blink = KODI.get_addon_setting('comfort_blink')
    log('SETTINGS: LOAD: COMFORT_BLINK=%s' % EVENT.comfort_blink)
    EVENT.comfort_blink_time = int(KODI.get_addon_setting('comfort_blink_time')) * 490
    log('SETTINGS: LOAD: COMFORT_BLINK_TIME=%s' % EVENT.comfort_blink_time)
    EVENT.turn_light = KODI.get_addon_setting('turn_light')
    log('SETTINGS: LOAD: TURN_LIGHT=%s' % EVENT.turn_light)
    EVENT.turn_light_time = int(KODI.get_addon_setting('turn_light_time')) * 1000
    log('SETTINGS: LOAD: TURN_LIGHT_TIME=%s' % EVENT.turn_light_time)
    EVENT.turn_light_max_speed = int(KODI.get_addon_setting('turn_light_max_speed'))
    log('SETTINGS: LOAD: TURN_LIGHT_MAX_SPEED=%s' % EVENT.turn_light_max_speed)
    EVENT.pdc_on = KODI.get_addon_setting('pdc_on')
    log('SETTINGS: LOAD: PDC_ON=%s' % EVENT.pdc_on)
    EVENT.pdc_type = int(KODI.get_addon_setting('pdc_type'))
    log('SETTINGS: LOAD: PDC_TYPE=%s' % ('REAR' if EVENT.pdc_type else 'FRONT + REAR'))
    EVENT.pdc_timeout = float(KODI.get_addon_setting('pdc_timeout'))
    log('SETTINGS: LOAD: PDC_TIMEOUT=%s' % EVENT.pdc_timeout)
    EVENT.pdc_timeout_off = KODI.get_addon_setting('pdc_timeout_off')
    log('SETTINGS: LOAD: PDC_TIMEOUT_OFF=%s' % EVENT.pdc_timeout_off)
    EVENT.pdc_bg = KODI.get_addon_setting('pdc_bg')
    log('SETTINGS: LOAD: PDC_BG=%s' % EVENT.pdc_bg)
    KODI.set_property('pdc_bg', os.path.splitext(os.path.basename(EVENT.pdc_bg))[0])
    EVENT.zv_auto_lock = KODI.get_addon_setting('zv_auto_lock')
    log('SETTINGS: LOAD: ZV_AUTO_LOCK=%s' % EVENT.zv_auto_lock)
    EVENT.zv_auto_lock_speed = int(KODI.get_addon_setting('zv_auto_lock_speed'))
    log('SETTINGS: LOAD: ZV_AUTO_LOCK_SPEED=%s' % EVENT.zv_auto_lock_speed)
    EVENT.zv_auto_unlock_handbrake = KODI.get_addon_setting('zv_auto_unlock_handbrake')
    log('SETTINGS: LOAD: ZV_AUTO_UNLOCK_HANDBRAKE=%s' % EVENT.zv_auto_unlock_handbrake)
    EVENT.zv_auto_unlock_ign1 = KODI.get_addon_setting('zv_auto_unlock_ign1')
    log('SETTINGS: LOAD: ZV_AUTO_UNLOCK_IGN1=%s' % EVENT.zv_auto_unlock_ign1)
    EVENT.zv_auto_unlock_gear_p = KODI.get_addon_setting('zv_auto_unlock_gear_p')
    log('SETTINGS: LOAD: ZV_AUTO_UNLOCK_GEAR_P=%s' % EVENT.zv_auto_unlock_gear_p)
    EVENT.zv_auto_unlock_door_open = KODI.get_addon_setting('zv_auto_unlock_door_open')
    log('SETTINGS: LOAD: ZV_AUTO_UNLOCK_DOOR_OPEN=%s' % EVENT.zv_auto_unlock_door_open)
    EVENT.map_auto_zoom = KODI.get_addon_setting('map_auto_zoom')
    log('SETTINGS: LOAD: MAP_AUTO_ZOOM=%s' % EVENT.map_auto_zoom)
    EVENT.flash_to_pass = KODI.get_addon_setting('flash_to_pass')
    log('SETTINGS: LOAD: FLASH_TO_PASS=%s' % EVENT.flash_to_pass)
    EVENT.flash_to_pass_low_beam = KODI.get_addon_setting('flash_to_pass_low_beam')
    log('SETTINGS: LOAD: FLASH_TO_PASS_LOW_BEAM=%s' % EVENT.flash_to_pass_low_beam)
    EVENT.flash_to_pass_fog = KODI.get_addon_setting('flash_to_pass_fog')
    log('SETTINGS: LOAD: FLASH_TO_PASS_FOG=%s' % EVENT.flash_to_pass_fog)
    EVENT.bm_sensor = KODI.get_addon_setting('bm_sensor')
    log('SETTINGS: LOAD: BM_SENSOR=%s' % EVENT.bm_sensor)
    EVENT.bm_sensor_level = int(KODI.get_addon_setting('bm_sensor_level'))
    log('SETTINGS: LOAD: BM_SENSOR_LEVEL=%s' % EVENT.bm_sensor_level)
    if settings_changed:
        EVENT.radio_get_mode()
        EVENT.obc_coolant_req()
        EVENT.obc_outtemp_req()
        EVENT.lcm_get_state()
        if EVENT.gpio_ntsc and not gpio_ntsc_tmp:
            GPIO_NTSC.open(7, off_level=True)
            IBUS.ntsc = False
        elif not EVENT.gpio_ntsc:
            GPIO_NTSC.close()
        if EVENT.gpio_gear_shift and gpio_gear_shift_tmp:
            GPIO_GEAR_SHIFT_UP.open(EVENT.gpio_gear_shift_up, off_level=True)
            GPIO_GEAR_SHIFT_DOWN.open(EVENT.gpio_gear_shift_down, off_level=True)
        if EVENT.gpio_gear_shift and EVENT.gpio_gear_shift_up != gpio_gear_shift_up_tmp:
            GPIO_GEAR_SHIFT_UP.open(EVENT.gpio_gear_shift_up, off_level=True)
        if EVENT.gpio_gear_shift and EVENT.gpio_gear_shift_down != gpio_gear_shift_down_tmp:
            GPIO_GEAR_SHIFT_DOWN.open(EVENT.gpio_gear_shift_down, off_level=True)
        if EVENT.cdc_emu and not cdc_emu_tmp:
            EVENT.cdch_init()


KODI = Kodi()
PLAYER = PlayerClass()
OBCGUI = ObcGuiClass('OBC_SKIN.xml', ADDONPATH, 'Default', '720p')
MONITOR = MonitorClass()
IBUS = IBusFace()
EVENT = EventClass()
GPIO_NTSC = GPIOClass()
GPIO_GEAR_SHIFT_UP = GPIOClass()
GPIO_GEAR_SHIFT_DOWN = GPIOClass()
DOUBLECLICKDELAY = 0.3
DBL_NEXT = Clicker(DOUBLECLICKDELAY, KODI.right, KODI.track_next)
DBL_PREV = Clicker(DOUBLECLICKDELAY, KODI.left, KODI.track_prev)
DBL_STW_SPEAK = Clicker(DOUBLECLICKDELAY, KODI.select, KODI.back)

def main():
    log('VERSION: %s' % ADDONVERSION)
    load_settings()
    if EVENT.gpio_gear_shift:
        GPIO_GEAR_SHIFT_UP.open(EVENT.gpio_gear_shift_up, off_level=True)
        GPIO_GEAR_SHIFT_UP.reset()
        GPIO_GEAR_SHIFT_DOWN.open(EVENT.gpio_gear_shift_down, off_level=True)
        GPIO_GEAR_SHIFT_DOWN.reset()
    if EVENT.gpio_ntsc:
        GPIO_NTSC.open(7, off_level=True)
        GPIO_NTSC.reset()
    IBUS.set_port(EVENT.device_path)
    log('IBUS: Connecting')
    if not IBUS.connect():
        note('IBUS: Error', 'Can not open serial device')
        return
    note('IBus Connected')
    KODI.set_property('IBUSCOMMUNICATOR_RXTX', 'None')
    ibus_rxtx = RepeatTimer(0.2, handle_extern_events)
    ibus_rxtx.start()
    thread = Thread(target=EVENT.read_ibus_packages)
    thread.setDaemon(True)
    thread.start()
    if EVENT.wel_ike:
        EVENT.send_to_ike(EVENT.wel_iketxt, True, EVENT.wel_iketxt_hold)
    xbmc.sleep(200)
    log('WAIT FOR IGNITION STATE')
    wait_counter = 5
    while wait_counter > 0:
        wait_counter -= 1
        if EVENT.ign_mode >= 0:
            break
        EVENT.ign_get_state()
        time.sleep(0.2)

    log('WAIT FOR IBUS TIME')
    wait_counter = 5
    while wait_counter > 0:
        wait_counter -= 1
        if EVENT.obc_time[0]:
            break
        EVENT.obc_time_req()
        time.sleep(0.2)

    log('Get 1st GM States')
    wait_counter = 5
    while wait_counter > 0:
        wait_counter -= 1
        if EVENT.gm_states['run_once']:
            break
        EVENT.gm_get_state()
        time.sleep(0.2)

    log('Get 1st LCM States')
    wait_counter = 5
    while wait_counter > 0:
        wait_counter -= 1
        if EVENT.lcm_states['run_once']:
            break
        EVENT.lcm_get_state()
        time.sleep(0.2)

    log('Get 1st IKE States')
    wait_counter = 5
    while wait_counter > 0:
        wait_counter -= 1
        if EVENT.ike_states['run_once']:
            break
        EVENT.ike_get_state()
        time.sleep(0.2)

    if EVENT.wel_light and EVENT.welcome_on_boot:
        log('LCM: turn lights on', 3)
        EVENT.lcm_lights_on(EVENT.wel_light_time)
        log('LCM: lights should turned on', 3)
    time.sleep(0.2)
    if EVENT.mir_unfold and EVENT.welcome_on_boot:
        EVENT.mirror_unfold()
    EVENT.cdch_init()
    time.sleep(0.5)
    EVENT.radio_get_mode()
    if MONITOR.waitForAbort():
        EVENT.cancel_read_thread = True
        EVENT.cancel_ike_text = True
        ibus_rxtx.cancel()
        GPIO_NTSC.close()
        GPIO_GEAR_SHIFT_UP.close()
        GPIO_GEAR_SHIFT_DOWN.close()
        DBL_NEXT.click()
        DBL_PREV.click()
        DBL_STW_SPEAK.click()
        log('IBUS: Disconnecting')
        IBUS.disconnect()
        log('IBUS: Disconnected')


if __name__ == '__main__':
    main()
log('SERVICE COMPLETELY CLOSED')
