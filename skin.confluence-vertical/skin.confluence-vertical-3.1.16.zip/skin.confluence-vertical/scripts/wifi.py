#!/usr/bin/env python

import os
import xbmc, xbmcgui, xbmcaddon
import sys, time

# -- for skin --
#Label:	$INFO[Window(1111).Property(tether_wifi)] / $INFO[Window(1111).Property(wifi_device)]
#Bool:	!IsEmpty(Window(1111).Property(tether_wifi))
#Bool:	StringCompare(Window(1111).Property(tether_wifi),1)

bDebug = False
bWifi = False
bWifiConnected = False
bWifiTether = False

#init
def wifi_state():

	global bDebug	
	global bWifi
	global bWifiConnected
	global bWifiTether

	f=os.popen("sudo connmanctl technologies")
	bWifiFound = False

	for i in f.readlines():
		#if bDebug: xbmc.executebuiltin("Notification(Tethering :" + str(i) + "," + str(len(i)) + ",2500)")
		#if bDebug: xbmcgui.Dialog().ok("connmanctl", str(i))

		if (bWifiFound and str(i).find("Type =") > 0): bWifiFound = False

		if str(i).find("Type = wifi") > 0: bWifiFound = True
		
		if (bWifiFound and str(i).find("Powered = True") > 0): bWifi = True
		if (bWifiFound and str(i).find("Powered = False") > 0): bWifi = False

		if (bWifiFound and str(i).find("Connected = True") > 0): bWifiConnected = True
		if (bWifiFound and str(i).find("Connected = False") > 0): bWifiConnected = False

		if (bWifiFound and str(i).find("Tethering = True") > 0): bWifiTether = True
		if (bWifiFound and str(i).find("Tethering = False") > 0): bWifiTether = False
		
		#get tether settings
		if (bWifiFound and str(i).find("TetheringIdentifier =") > 0): 
			iTetherSSID = 24
			sTetherSSID = str(i)[iTetherSSID:-1]
			if bDebug: xbmcgui.Dialog().ok("SSID", sTetherSSID)
			xbmc.executebuiltin('Skin.SetString(wifitetherssid,' + sTetherSSID + ')')

		if (bWifiFound and str(i).find("TetheringPassphrase =") > 0): 
			iTetherPW = 24
			sTetherPW = str(i)[iTetherPW:-1]
			if bDebug: xbmcgui.Dialog().ok("PW", sTetherPW)
			xbmc.executebuiltin('Skin.SetString(wifitetherpw,' + sTetherPW + ')')
		 

		
	win = xbmcgui.Window(11111)

	if bWifi:
		win.setProperty('wifi_device', '1')
		if bDebug: xbmcgui.Dialog().ok("connmanctl", 'set wifi indicator true')
	else:
		win.setProperty('wifi_device', '0')
		if bDebug: xbmcgui.Dialog().ok("connmanctl", 'set wifi indicator false')
			
	if bWifiTether:
		win.setProperty('tether_wifi', '1')
		if bDebug: xbmcgui.Dialog().ok("connmanctl", 'set tether indicator true')
	else:
		win.setProperty('tether_wifi', '0')
		if bDebug: xbmcgui.Dialog().ok("connmanctl", 'set tether indicator false')

def wifi_toggle():
	#xbmcgui.Dialog().ok("WiFi", "toggeling")
	busybox = xbmcgui.WindowXMLDialog('DialogBusy.xml', xbmcaddon.Addon(xbmc.getSkinDir()).getAddonInfo('path').decode('utf-8'), 'default', '720p')
	busybox.show()

	global bWifi
	global bWifiConnected	
	wifi_state()

	if bWifi:
		f=os.popen("connmanctl disable wifi")
		xbmc.sleep(500)
		wifi_state()
	else:		
		f=os.popen('connmanctl enable wifi')
		iBusyCnt = 60
		while not (bWifiConnected or bWifiTether):
			iBusyCnt = iBusyCnt - 1
			wifi_state()
			xbmc.sleep(300)
			if iBusyCnt < 0: break
		if not bWifiConnected and not bWifiTether: xbmcgui.Dialog().ok("WiFi Connection", "Not able to connect the Wifi Network")
	busybox.close()
	del busybox
		


def wifi_tether_toggle():
	#xbmcgui.Dialog().ok("WiFi Tethering", "toggeling")	
	global bWifiTether
	wifi_state()

	if bWifiTether:
		f=os.popen("sudo connmanctl tether wifi off")
		#xbmcgui.Dialog().ok("unknown arguments given", "wuerde jetzt deaktiv setzen")
		xbmc.sleep(300)
		wifi_state()
	else:
		#get values from skin
		wifitetherssid = xbmc.getInfoLabel('Skin.String(wifitetherssid)')
		wifitetherpw = xbmc.getInfoLabel('Skin.String(wifitetherpw)')
		#xbmcgui.Dialog().ok("unknown arguments given", "wuerde jetzt aktiv setzen")
		f=os.popen('connmanctl enable wifi')
		xbmc.sleep(1000)
		f=os.popen('sudo connmanctl tether wifi on \"' + wifitetherssid + '\" \"' + wifitetherpw + '\"')
		xbmc.sleep(300)
		wifi_state()
		if bWifiTether: xbmcgui.Dialog().ok('WiFi Hotspot ready for Connection', 'Name: ' + wifitetherssid, 'Password: ' + wifitetherpw)

def wifi_tether_ssid():

	global bWifiTether
	wifi_state()	
	
	if bWifiTether:
		xbmcgui.Dialog().ok("Set HotSpot SSID", "Disable Hotspot before")
		quit()
	
	#get values from skin
	kb = xbmc.Keyboard ('default', 'heading', True)
	kb.setDefault(xbmc.getInfoLabel('Skin.String(wifitetherssid)')) # optional
	kb.setHeading('Enter Hotspot SSID') # optional
	kb.setHiddenInput(False) # optional
	kb.doModal()
	if (kb.isConfirmed()):
		wifitetherssid = kb.getText()
		print wifitetherssid
	else:
		quit()

	wifitetherpw = xbmc.getInfoLabel('Skin.String(wifitetherpw)')
	
	#xbmcgui.Dialog().ok("unknown arguments given", "wuerde jetzt aktiv setzen")
	
	f=os.popen('sudo connmanctl tether wifi \"' + wifitetherssid + '\" \"' + wifitetherpw + '\"')

	xbmc.sleep(300)
	wifi_state()

def wifi_tether_pw():
	
	global bWifiTether	
	wifi_state()
	
	if bWifiTether:
		xbmcgui.Dialog().ok("Set HotSpot Password", "Disable Hotspot before")
		quit()
	
	#get values from skin
	wifitetherssid = xbmc.getInfoLabel('Skin.String(wifitetherssid)')

	kb = xbmc.Keyboard ('default', 'heading', True)
	kb.setDefault(xbmc.getInfoLabel('Skin.String(wifitetherpw)')) # optional
	kb.setHeading('Enter Hotspot Password') # optional
	kb.setHiddenInput(False) # optional
	kb.doModal()
	if (kb.isConfirmed()):
		wifitetherpw = kb.getText()
		print wifitetherpw
	else:
		quit()
		
	#xbmcgui.Dialog().ok("unknown arguments given", "wuerde jetzt aktiv setzen")
	
	f=os.popen('sudo connmanctl tether wifi \"' + wifitetherssid + '\" \"' + wifitetherpw + '\"')

	xbmc.sleep(300)
	wifi_state()


#programmcode

count = len(sys.argv) - 1
 
if count < 1:
	xbmcgui.Dialog().ok("No arguments given", "You must specify arguments to the script", "i.e. 'tether_toggle' - to toggle wifi tethering, etc")
else:
	if (sys.argv[1] == "state"):
		if bDebug: xbmcgui.Dialog().ok("WiFi", "only state")
		wifi_state()
	elif (sys.argv[1] == "wifi_toggle"):
		if bDebug: xbmcgui.Dialog().ok("WiFi", "toggle wifi")		
		wifi_toggle()
	elif (sys.argv[1] == "tether_toggle"):
		if bDebug: xbmcgui.Dialog().ok("WiFi", "toggle tether")
		wifi_tether_toggle()		
	elif (sys.argv[1] == "tether_ssid"):
		if bDebug: xbmcgui.Dialog().ok("WiFi", "set ssid")
		wifi_tether_ssid()
	elif (sys.argv[1] == "tether_pw"):
		if bDebug: xbmcgui.Dialog().ok("WiFi", "set pw")
		wifi_tether_pw()
	else:
		xbmcgui.Dialog().ok("unknown arguments given", sys.argv[1])

#xbmcgui.Dialog().ok("Code Ende", "test")
#xbmc.sleep(500)
#progress.close()


