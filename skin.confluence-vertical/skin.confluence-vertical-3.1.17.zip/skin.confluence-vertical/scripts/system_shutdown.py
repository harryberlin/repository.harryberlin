#!/usr/bin/env python

import os
import xbmc

f=os.popen("sudo service HelgeInterface stop")
xbmc.sleep(1000)
xbmc.executebuiltin('XBMC.Powerdown')

pass
