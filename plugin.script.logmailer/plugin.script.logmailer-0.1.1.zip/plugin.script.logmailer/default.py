#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
import time
import smtplib
import zipfile
import xbmc, xbmcgui, xbmcaddon
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email import encoders

__author__ = 'harryberlin'

ADDON = xbmcaddon.Addon()
ADDONNAME = ADDON.getAddonInfo('name')
ADDONID = ADDON.getAddonInfo('id')
ADDONPATH = ADDON.getAddonInfo('path')
ADDONVERSION = ADDON.getAddonInfo('version')

ICON = os.path.join(ADDONPATH, 'icon.png')


def log(message):
    xbmc.log('plugin.script.logmailer: %s' % message, xbmc.LOGNOTICE)


def note(heading, message=None, time=5000):
    xbmcgui.Dialog().notification(heading='%s' % heading, message='%s' % message if message else '', icon=ICON, time=time)
    log('NOTIFICATION: "%s%s"' % (heading, ' - %s' % message if message else ''))


def dialog_ok(label1, label2='', label3=''):
    xbmcgui.Dialog().ok('Log Mailer', label1, label2, label3)


def get_addon_setting(id):
    setting = xbmcaddon.Addon().getSetting(id)
    if setting.upper() == 'TRUE': return True
    if setting.upper() == 'FALSE': return False
    return '%s' % setting


def open_settings():
    if xbmcgui.getCurrentWindowDialogId() == 10140:
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Back", "id": 1 }')
    else:
        xbmcaddon.Addon().openSettings()


def send_logfile():
    msg = MIMEMultipart()

    # eMail-Adressen (Sender/Empfaenger)
    mailSender = get_addon_setting('mail_adress')
    log('Sender: %s' % mailSender)

    if get_addon_setting('mail_log_mode') == '0':
        Hostname = "BMWRaspControl"
        mailReceiver = 'net@net.net'
        full_file_path = ''
        msg['Subject'] = "BMWRaspControl LogFile-Export"
    elif get_addon_setting('mail_log_mode') == '1':
        Hostname = "IBusCommunicator"
        mailReceiver = 'debug.ibuscommunicator@gmx.de'
        full_file_path = '/home/osmc/.kodi/temp/kodi.log'
        msg['Subject'] = "IBusCommunicator LogFile-Export"
    else:
        return
    log('Receiver: %s' % mailReceiver)

    msg['From'] = mailSender
    msg['To'] = mailReceiver

    # SMTP-Ausgangsserver (Sender)
    smtpUser = get_addon_setting('mail_out_user')
    log('SMTP User: %s' % smtpUser)
    smtpPassword = get_addon_setting('mail_out_password')
    smtpHost = get_addon_setting('mail_out_server')
    log('SMTP Host: %s' % smtpHost)
    smtpPort = int(get_addon_setting('mail_out_port'))
    log('SMTP Port: %s' % smtpPort)

    ###############################################################################
    # Time/Date Recording for Filename
    fndate = "%04i%02i%02i" % (int(time.localtime()[0]), int(time.localtime()[1]), int(time.localtime()[2]))
    fntime = "%02i%02i%02i" % (int(time.localtime()[3]), int(time.localtime()[4]), int(time.localtime()[5]))

    server = smtplib.SMTP(smtpHost, smtpPort)
    server.ehlo_or_helo_if_needed()
    if get_addon_setting('mail_startttls'):
        server.starttls()  # If TLS authentication is not required set a hash at the beginning of this line
        log('SSL/TLS is True')

    server.ehlo_or_helo_if_needed()
    server.login(smtpUser, smtpPassword)
    log('Server connected')

    MailContent = "Die exportierten LogFiles befinden sich im Anhang dieser eMail. " + "\n" + "\n" + "__________________________" + "\n" + "Es handelt sich hierbei um eine automatisch generierte E-Mail, die von Ihrem Raspberry Pi (" + Hostname + ") gesendet worden ist."
    msg.attach(MIMEText(MailContent, 'plain'))

    filename = "Log-Export_" + Hostname + "_" + fndate + "_" + fntime + ".zip"

    log('create zip file')
    zip = zipfile.ZipFile(os.path.join(ADDONPATH, filename), 'w', zipfile.ZIP_DEFLATED)
    zip.write(full_file_path,os.path.split(full_file_path)[1])
    zip.close()


    log('open file for mail')
    attachment = open(os.path.join(ADDONPATH, filename), "rb")

    part = MIMEBase('application', 'octet-stream')
    log('read file %s' % filename)
    part.set_payload(attachment.read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', "attachment; filename= %s" % filename)

    msg.attach(part)
    #try:
    log('send mail')
    server.sendmail(mailSender, mailReceiver, msg.as_string())
    note('E-Mail sent successfull')
    #except:
    #    dialog_ok('Error: E-Mail not sent')
    server.quit()
    log('delete zip file')
    if os.path.isfile(os.path.join(ADDONPATH, filename)):
        os.remove(os.path.join(ADDONPATH, filename))


def main():
    count = len(sys.argv) - 1
    if count > 0:
        given_args = sys.argv[1].split(';')
        if str(given_args[0]) == "send_logfile":
            send_logfile()
        elif str(given_args[0]) == "settings":
            open_settings()
        else:
            print ('Unknown Arguments given!')

    else:
        open_settings()


if __name__ == '__main__':
    main()
