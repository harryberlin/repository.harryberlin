#!/usr/bin/python
# -*- coding: utf-8 -*-

import cv2
import time

camera_port = 0
#camera = cv2.VideoCapture(camera_port).release()
#camera.set(3, 640)
#camera.set(4, 480)
#camera.read()
time.sleep(0.2)
#camera.release()