#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import urllib
import time
import xbmc
import xbmcgui
import xbmcaddon
from threading import Thread
from xml.etree import ElementTree as etree

__author__ = 'harryberlin'
__addon__ = xbmcaddon.Addon()
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')
__icon__ = xbmc.translatePath(os.path.join(__addonpath__, 'icon.png').encode("utf-8")).decode("utf-8")
__busy__ = xbmc.translatePath(os.path.join(__addonpath__, 'resources', 'busy.gif').encode("utf-8")).decode("utf-8")

HICONFIGFILE = '/home/HelgeInterface/Config/helgeinterface.xml'


# TESTFILE = '/home/HelgeInterface/Config/helgeinterface_new.xml'


class Player(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)

    def onPlayBackStarted(self):
        #        try:
        while int(xbmc.Player().getTime()) > 0.2:
            xbmc.sleep(1)
        while not xbmc.Player().isPlaying():
            xbmc.sleep(1)
        while int(xbmc.Player().getTime()) < 0.5:
            xbmc.sleep(1)

        title = get_track()
        if title == '': return
        log('SEND SONG: "%s" to IKE Display' % title)

        SendSongInfoToHelgeInterface(title)

    #        except:
    #            log('Kodi has an error with playing or -> not playing <- media.')

    def onPlayBackResumed(self):
        pass

    def onPlayBackSeek(self, time, seekOffset):
        pass


class Monitor(xbmc.Monitor):
    def __init__(self):
        xbmc.Monitor.__init__(self)

    def onSettingsChanged(self):
        time.sleep(1)
        log('################ SETTINGS CHANGED ###############')
        load_settings()
        pass


class BusyBox(object):
    def show(self, showtime, finishmessage, notetime):
        thread = Thread(target=self._show_thread, args=[showtime, finishmessage, notetime])
        thread.setDaemon(True)
        thread.start()

    def _show_thread(self, showtime, finishmessage, notetime):
        xbmc.executebuiltin("ActivateWindow(busydialog)")
        time.sleep(showtime)
        self.hide()
        xbmcgui.Dialog().notification(finishmessage[0], finishmessage[1], icon=__icon__, time=notetime)

    def hide(self):
        xbmc.executebuiltin("Dialog.Close(busydialog)")


class XmlEditor(object):
    def __init__(self, filename):
        self.filename = filename
        self.tree = etree.parse(self.filename)

    def _get_element(self, paths):
        if isinstance(paths, basestring):
            paths = [paths]

        element = self.tree.getroot()
        for path in paths:
            element = element.find('.//' + path)
        return element

    def set_childnode(self, path_or_paths, value):
        if value == True:
            value = 'true'
        elif value == False:
            value = 'false'
        # else: use the string

        element = self._get_element(path_or_paths)
        element.clear()
        etree.SubElement(element, value)

    def set_string(self, path_or_paths, value):
        self._get_element(path_or_paths).text = value

    def save(self, filename=None):
        self.tree.write(
            filename if filename else self.filename,
            encoding='utf-8',
            xml_declaration=True
        )


def log(message):
    return xbmc.log('HelgeInterface: %s' % message, xbmc.LOGNOTICE)


def get_property(property, id=10000):
    value = xbmcgui.Window(id).getProperty(property)
    return value

def set_property(property, value, id=10000):
    xbmcgui.Window(id).setProperty(property, value)

def get_addon_setting(id):
    setting = __addon__.getSetting(id)
    if setting == 'true': return True
    if setting == 'false': return False
    return str(setting)


def SendSongInfoToHelgeInterface(info):
    if get_addon_setting('CarModel') in ['e46', 'e83']:
        return
    ip = '127.0.0.1'
    port = '44000'
    sClass_tmp = 'IKE'
    sMethod_tmp = 'DisplayText'
    sClassMethod_tmp = sClass_tmp + '.' + sMethod_tmp
    log(sClassMethod_tmp)
    log('SEND: http://' + ip + ':' + port + '/jsonrpc?request={"jsonrpc": "2.0", "method": "' + sClassMethod_tmp + '", "params": { "Property": ' + info + ' }, "id": 0}')
    try:
        urllib.urlopen('http://' + ip + ':' + port + '/jsonrpc?request={"jsonrpc": "2.0", "method": "' + sClassMethod_tmp + '", "params": { "Property": ' + info + ' }, "id": 0}')
    except:
        log('ERROR: got now answer')
    return


def get_track():
    log('get song')
    if xbmc.Player().isPlayingAudio():
        log('music')
        sArtist = xbmc.getInfoLabel('MusicPlayer.Artist')
        sTitle = xbmc.getInfoLabel('MusicPlayer.Title')
        log('SONG MUSIC: "%s" - "%s"' % (sArtist, sTitle))
        if sArtist == sTitle: return ('%s' % sArtist)
        if sArtist == '': return ('%s' % (sTitle))
        if sTitle == '': return ('%s' % (sArtist))
        return ('%s - %s' % (sArtist, sTitle))
    elif xbmc.Player().isPlayingVideo():
        log('video')
        sTitle = xbmc.getInfoLabel('VideoPlayer.Title')
        sFile = xbmc.Player().getVideoInfoTag().getFile()
        log('SONG VIDEO: "%s"' % (sTitle))
        if sTitle != '':
            return ('%s' % sTitle)
        else:
            return ('%s' % sFile)

    else:
        log('SONG: empty')
        return ''


def load_version():
    filepath = os.path.join('boot','ImageVersion')
    with open(filepath) as file:  # Use file to refer to the file object
        data = file.readline()
        # do something with data
        set_property('VER_IMG',data)


def load_settings():
    log('Load Settings')
    BusyBox().show(7, ["HelgeInterface", "Set Settings successfull, You may have to reactivate HelgeInterface by pressing 'Mode' "], 10000)

    childnodesList = []
    stringList = []

    childnodesList.append('LogLvl')
    childnodesList.append('CarModel')
    stringList.append('WelcomeMessage')
    stringList.append('Clock_HourOffset')

    childnodesList.append('CdChangerEmulatorActive')
    childnodesList.append('ActivatePiInTapeMode')
    childnodesList.append('ActivatePiInAuxMode')
    childnodesList.append('ShowPiStateByBoardMonitorLed')
    childnodesList.append('SetDspDigitalInputByPiAsSource')

    # LightShow
    childnodesList.append('LightShow_active')
    childnodesList.append('LightShow_OnCarClose')
    childnodesList.append('LightShow_OnCarOpen')
    stringList.append('LightShow_EnableTimeFactor')

    # Mirrors
    childnodesList.append('ExpandMirrors_active')
    childnodesList.append('ExpandMirrors_OnCarClose')
    childnodesList.append('ExpandMirrors_OnCarOpen')

    childnodesList.append('CollapseMirrors_active')
    childnodesList.append('CollapseMirrors_OnCarClose')
    childnodesList.append('CollapseMirrors_OnCarOpen')

    # PDC
    childnodesList.append('PDC_active')
    stringList.append('PDC_Threshold')
    stringList.append('PDC_TimeOut')

    # PreHeater
    childnodesList.append('PreHeater_active')

    # ConfortBlink
    childnodesList.append('ComfortBlink_active')
    stringList.append('ComfortBlink_BlinkinTime')
    stringList.append('ComfortBlink_CorneringTime')

    helgeinterface_config = XmlEditor(HICONFIGFILE)

    for Setting in childnodesList:
        try:
            helgeinterface_config.set_childnode(Setting.split('_'), get_addon_setting(Setting))
            log('CHANGED: %s = %s' % (Setting,get_addon_setting(Setting)))
        except:
            log('ERROR: %s = %s' % (Setting, get_addon_setting(Setting)))

    for Setting in stringList:
        try:
            helgeinterface_config.set_string(Setting.split('_'), get_addon_setting(Setting))
            log('CHANGED: %s = %s' % (Setting, get_addon_setting(Setting)))
        except:
            log('ERROR: %s = %s' % (Setting, get_addon_setting(Setting)))

    helgeinterface_config.save(HICONFIGFILE)

    # restart HelgeInterface
    os.system('sudo service HelgeInterface restart')


def main():
    log('Start Service')
    load_version()
    if monitor.waitForAbort():
        log('Close Service')


player = Player()
monitor = Monitor()

if __name__ == '__main__':
    main()

del player
del monitor
