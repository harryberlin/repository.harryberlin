#!/usr/bin/env python
# -*- coding: utf-8 -*-


import os
import sys
import time
import glob
import shutil
import urllib
import urllib2
import zipfile

from service import BusyBox
from threading import Event, Thread

import xbmc
import xbmcgui
import xbmcaddon

__author__ = 'harryberlin'
__addon__ = xbmcaddon.Addon()
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')
__icon__ = xbmc.translatePath(os.path.join(__addonpath__, 'icon.png').encode("utf-8")).decode("utf-8")

# add librarys and resource files into sys path
BASE_RESOURCE_PATH = xbmc.translatePath(os.path.join(__addonpath__, 'resources'))
BASE_LIB_PATH = xbmc.translatePath(os.path.join(__addonpath__, 'resources', 'lib'))
sys.path.append(BASE_RESOURCE_PATH)
sys.path.append(BASE_LIB_PATH)

NEWFILE = '/home/HelgeInterface/Update/HelgeInterface.zip'
URL_STABLE = 'http://bmwraspcontrol.de/software/HelgeInterface_last.zip'
URL_BETA = 'http://bmwraspcontrol.de/software/HelgeInterface_BETA.zip'
BACKUP_DIR = '/home/HelgeInterface/Update/BackUp'
BETA_V_PW = "hifb"

ACTION_PARENT_DIR = 9
ACTION_PREVIOUS_MENU = 10
ACTION_CLOSE_DIALOG = 51
ACTION_SELECT_ITEM = 7
ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4
ACTION_NAV_BACK = 92
ACTION_BACKSPACE = 110

WINDOW_DIALOG_ADDON_SETTINGS = 10140


class Update(object):
    # pseudo class to combine functions
    def download_file(self, url, dest):
        dp = xbmcgui.DialogProgress()
        dp.create('HelgeInterface Update', "Lade Datei", "BMW RaspControl HelgeInterface - Update")
        urllib.urlretrieve(url, dest, lambda nb, bs, fs, url=url: self._pbhook(nb, bs, fs, url, dp))

    def _pbhook(self, numblocks, blocksize, filesize, url=None, dp=None):
        try:
            percent = min((numblocks * blocksize * 100) / filesize, 100)
            log(percent)
            dp.update(percent)
        except:
            percent = 100
            dp.update(percent)
        if dp.iscanceled():
            log("Download Abgebrochen")
            dp.close()
            quit()

    def create_backup(self):
        backupfolder = BACKUP_DIR + "/" + time.strftime("%Y%m%d_%H:%M:%S")
        self.check_folder(backupfolder)

        files = glob.iglob(os.path.join("/home/HelgeInterface", "*elge*nterface*.*"))

        for file in files:
            if os.path.isfile(file):
                shutil.copy2(file, backupfolder)

        xbmcgui.Dialog().notification('HelgeInterface Update', 'Create BackUp to: %s' % backupfolder, icon=__icon__, time=7000)

    def install(self, file, dst):
        zip = zipfile.ZipFile(file, "r")
        for file in zip.namelist():
            if ("dll" not in file) and ("exe" not in file):
                continue
            log("copy  " + file + " to " + dst)
            zip.extract(file, dst)

    def check_internet(self):
        try:
            response = urllib2.urlopen('http://google.de', timeout=2)
            return True
        except urllib2.URLError as err:
            pass
        return False

    def check_folder(self, directory):
        if not os.path.exists(directory):
            os.makedirs(directory)


class ObcGuiClass(xbmcgui.WindowXML):
    isActive = False

    ACTION_PARENT_DIR = 9
    ACTION_PREVIOUS_MENU = 10
    ACTION_CLOSE_DIALOG = 51
    ACTION_SELECT_ITEM = 7
    ACTION_MOVE_LEFT = 1
    ACTION_MOVE_RIGHT = 2
    ACTION_MOVE_UP = 3
    ACTION_MOVE_DOWN = 4
    ACTION_NAV_BACK = 92
    ACTION_BACKSPACE = 110

    # Text, Visible, Enable
    MAINLABEL = {0: ['ON-BOARD 1', True, True], 1: ['ON-BOARD 2', True, True]}

    BUTTON1 = {0: ['Verbrauch 1', True, True],
               1: ['Geschwindigkeit', True, True]}
    BUTTON2 = {0: ['Verbrauch 2', True, True],
               1: ['Limit', True, True]}
    BUTTON3 = {0: ['Reichweite', True, True],
               1: ['Memo', True, True]}
    BUTTON4 = {0: ['Distanz', True, True],
               1: ['Tankinhalt', True, True]}
    BUTTON5 = {0: ['Ankunft', True, True],
               1: ['Timer 1', True, True]}
    BUTTON6 = {0: ['Drehzahl', True, True],
               1: ['Timer 2', True, True]}
    BUTTON7 = {0: ['Akt. Geschwindigkeit', True, True],
               1: ['Stopuhr', True, True]}
    BUTTON8 = {0: ['Kühlwassertemperatur', True, True],
               1: [' ', False, False]}

    LABEL1 = {0: ['$INFO[Window(10000).Property(OBC_CONS1)]', True, True],
              1: ['$INFO[Window(10000).Property(OBC_AVGSPEED)]', True, True]}
    LABEL2 = {0: ['$INFO[Window(10000).Property(OBC_CONS2)]', True, True],
              1: ['$INFO[Window(10000).Property(OBC_LIMIT)]', True, True]}
    LABEL3 = {0: ['$INFO[Window(10000).Property(OBC_RANGE)]', True, True],
              1: [' ', False, False]}
    LABEL4 = {0: ['$INFO[Window(10000).Property(OBC_DIST)]', True, True],
              1: ['$INFO[Window(10000).Property(OBC_FUELLEVEL)]', True, True]}
    LABEL5 = {0: ['$INFO[Window(10000).Property(OBC_ARRIV)]', True, True],
              1: ['$INFO[Window(10000).Property(OBC_TMR1)]', True, True]}
    LABEL6 = {0: ['$INFO[Window(10000).Property(OBC_RPM)]', True, True],
              1: ['$INFO[Window(10000).Property(OBC_TMR2)]', True, True]}
    LABEL7 = {0: ['$INFO[Window(10000).Property(OBC_SPEED_KMH)]', True, True],
              1: ['$INFO[Window(10000).Property(OBC_STPWTCH)]', True, True]}
    LABEL8 = {0: ['$INFO[Window(10000).Property(OBC_COOLANTTEMP)]', True, True],
              1: [' ', False, False]}

    def __init__(self, xmlFilename, scriptPath, defaultSkin, defaultRes):
        log("OBC: Initializing Gui...")
        self.selectedButton = -1
        self.selectedSubButton = 0
        self.nextUpdateLabel = 0
        self.obc_screen = 0
        self.obc_screen_min = 0
        self.obc_screen_max = 1
        # self.updateTimer = RepeatTimer(0.1, self.update)

    def onInit(self):
        log('OBC: GUI Opening')

        #xbmc.executebuiltin('RunScript("special://skin/scripts/Helgeinterface.py","OBC.Refresh","ALL")')

        self.isActive = True
        self.mainlabel = self.getControl(200)
        self.mainleft = self.getControl(201)
        self.mainright = self.getControl(202)

        self.image1 = self.getControl(101)
        self.image2 = self.getControl(102)
        self.image3 = self.getControl(103)
        self.image4 = self.getControl(104)
        self.image5 = self.getControl(105)
        self.image6 = self.getControl(106)
        self.image7 = self.getControl(107)
        self.image8 = self.getControl(108)

        self.button1 = self.getControl(111)
        self.button2 = self.getControl(112)
        self.button3 = self.getControl(113)
        self.button4 = self.getControl(114)
        self.button5 = self.getControl(115)
        self.button6 = self.getControl(116)
        self.button7 = self.getControl(117)
        self.button8 = self.getControl(118)

        self.label1 = self.getControl(121)
        self.label2 = self.getControl(122)
        self.label3 = self.getControl(123)
        self.label4 = self.getControl(124)
        self.label5 = self.getControl(125)
        self.label6 = self.getControl(126)
        self.label7 = self.getControl(127)
        self.label8 = self.getControl(128)

        self.update()

        self.set_default_navigation()
        # self.updateTimer.start()

    def set_default_navigation(self):
        self.button1.setNavigation(self.button1, self.button2, self.button1, self.button1)
        self.button2.setNavigation(self.button1, self.button3, self.button2, self.button2)
        self.button3.setNavigation(self.button2, self.button4, self.button3, self.button3)
        self.button4.setNavigation(self.button3, self.button5, self.button4, self.button4)
        self.button5.setNavigation(self.button4, self.button6, self.button5, self.button5)
        self.button6.setNavigation(self.button5, self.button7, self.button6, self.button6)
        self.button7.setNavigation(self.button6, self.button8, self.button7, self.button7)
        self.button8.setNavigation(self.button7, self.button8, self.button8, self.button8)

    def onAction(self, Action):
        if Action in [self.ACTION_PREVIOUS_MENU, self.ACTION_CLOSE_DIALOG, self.ACTION_NAV_BACK, self.ACTION_BACKSPACE]:
            self.onStop()

        elif Action.getId() == 1 and self.obc_screen > self.obc_screen_min:  # left
            set_kodi_prop('BMWRASPCONTROL_OBC_SLIDE', 'right_out')
            self.obc_screen -= 1
            time.sleep(0.5)
            self.update()
            set_kodi_prop('BMWRASPCONTROL_OBC_SLIDE', 'left_in')

        elif Action.getId() == 2 and self.obc_screen < self.obc_screen_max:  # right
            set_kodi_prop('BMWRASPCONTROL_OBC_SLIDE', 'left_out')
            self.obc_screen += 1
            time.sleep(0.5)
            self.update()
            set_kodi_prop('BMWRASPCONTROL_OBC_SLIDE', 'right_in')

    def onFocus(self, controlId):
        pass

    def onStop(self):
        log('OBC: GUI Closing')
        self.close()
        self.isActive = False
        # self.updateTimer.cancel()

    def update(self):
        # top label
        text, visible, enable = self.MAINLABEL[self.obc_screen]
        self.mainlabel.setLabel(text)
        self.mainlabel.setVisible(visible)
        self.mainlabel.setEnabled(enable)

        # left button labels
        text, visible, enable = self.BUTTON1[self.obc_screen]
        self.button1.setLabel(text)
        self.button1.setVisible(visible)
        self.button1.setEnabled(enable)

        text, visible, enable = self.BUTTON2[self.obc_screen]
        self.button2.setLabel(text)
        self.button2.setVisible(visible)
        self.button2.setEnabled(enable)

        text, visible, enable = self.BUTTON3[self.obc_screen]
        self.button3.setLabel(text)
        self.button3.setVisible(visible)
        self.button3.setEnabled(enable)

        text, visible, enable = self.BUTTON4[self.obc_screen]
        self.button4.setLabel(text)
        self.button4.setVisible(visible)
        self.button4.setEnabled(enable)

        text, visible, enable = self.BUTTON5[self.obc_screen]
        self.button5.setLabel(text)
        self.button5.setVisible(visible)
        self.button5.setEnabled(enable)

        text, visible, enable = self.BUTTON6[self.obc_screen]
        self.button6.setLabel(text)
        self.button6.setVisible(visible)
        self.button6.setEnabled(enable)

        text, visible, enable = self.BUTTON7[self.obc_screen]
        self.button7.setLabel(text)
        self.button7.setVisible(visible)
        self.button7.setEnabled(enable)

        text, visible, enable = self.BUTTON8[self.obc_screen]
        self.button8.setLabel(text)
        self.button8.setVisible(visible)
        self.button8.setEnabled(enable)

        # right labels
        text, visible, enable = self.LABEL1[self.obc_screen]
        self.label1.setLabel(text)
        self.label1.setVisible(visible)
        self.label1.setEnabled(enable)

        text, visible, enable = self.LABEL2[self.obc_screen]
        self.label2.setLabel(text)
        self.label2.setVisible(visible)
        self.label2.setEnabled(enable)

        text, visible, enable = self.LABEL3[self.obc_screen]
        self.label3.setLabel(text)
        self.label3.setVisible(visible)
        self.label3.setEnabled(enable)

        text, visible, enable = self.LABEL4[self.obc_screen]
        self.label4.setLabel(text)
        self.label4.setVisible(visible)
        self.label4.setEnabled(enable)

        text, visible, enable = self.LABEL5[self.obc_screen]
        self.label5.setLabel(text)
        self.label5.setVisible(visible)
        self.label5.setEnabled(enable)

        text, visible, enable = self.LABEL6[self.obc_screen]
        self.label6.setLabel(text)
        self.label6.setVisible(visible)
        self.label6.setEnabled(enable)

        text, visible, enable = self.LABEL7[self.obc_screen]
        self.label7.setLabel(text)
        self.label7.setVisible(visible)
        self.label7.setEnabled(enable)

        text, visible, enable = self.LABEL8[self.obc_screen]
        self.label8.setLabel(text)
        self.label8.setVisible(visible)
        self.label8.setEnabled(enable)

        # top arrows
        if self.obc_screen == self.obc_screen_min:
            self.mainleft.setVisible(False)
        else:
            self.mainleft.setVisible(True)
        if self.obc_screen == self.obc_screen_max:
            self.mainright.setVisible(False)
        else:
            self.mainright.setVisible(True)




class RepeatTimer(Thread):
    def __init__(self, interval, function, iterations=0, args=[], kwargs={}):
        Thread.__init__(self)
        self.interval = interval
        self.function = function
        self.iterations = iterations
        self.args = args
        self.kwargs = kwargs
        self.finished = Event()

    def run(self):
        count = 0
        while not self.finished.isSet() and (self.iterations <= 0 or count < self.iterations):
            self.finished.wait(self.interval)
            if not self.finished.isSet():
                self.function(*self.args, **self.kwargs)
                count += 1

    def cancel(self):
        self.finished.set()


# ---------------------
def log(string):
    xbmc.log('BMWRaspControl: %s' % string, level=xbmc.LOGNOTICE)


# ---------------------
def note(heading, message=" ", time=5000):
    xbmcgui.Dialog().notification(heading=' %s' % heading, message=' %s' % message, icon=__icon__, time=time)
    log('notification: %s - %s' % (heading, message))


# ---------------------
def set_kodi_prop(property, value, windowid=10000):
    xbmcgui.Window(windowid).setProperty(property, '%s' % value)


# ---------------------
def get_kodi_prop(property, windowid=10000):
    value = xbmcgui.Window(windowid).getProperty(property)
    # xbmc.log('get prop - %s : %s' % (property,value))
    return '%s' % value


# ---------------------
def open_obcgui():
    if xbmcgui.getCurrentWindowDialogId() == WINDOW_DIALOG_ADDON_SETTINGS:
        xbmc.executebuiltin('Action(Back)')
    obc = ObcGuiClass("OBC_SKIN.xml", __addonpath__, 'Default', '720p')
    obc.doModal()
    del obc


# ---------------------
def open_settings():
    xbmcaddon.Addon().openSettings()


# ---------------------
def delete_log_files():
    os.system('sudo rm -r /home/HelgeInterface/Log/*')
    note('Log Files deleted')


# ---------------------
def update_helgeinterface():
    betaversion = ''
    dialog = xbmcgui.Dialog()

    if dialog.yesno("BMWRaspControl", "Are you sure to update HelgeInterface?"):
        if Update().check_internet():
            Update().check_folder(BACKUP_DIR)

            if dialog.yesno("BMWRaspControl", "Choose HelgeInterface Version[CR]              TIMEOUT 10s", nolabel='Stable', yeslabel='Beta', autoclose=10000):
                kb = xbmc.Keyboard(heading="Enter Password for Beta-Version", hidden=False)
                kb.doModal()
                if kb.isConfirmed():
                    text = kb.getText()
                else:
                    return

                if text == BETA_V_PW:
                    betaversion = 'Beta '
                    url = URL_BETA
                else:
                    if dialog.yesno("BMWRaspControl", "Invalid Password", "Downloading Stable Version", yeslabel='OK', nolabel='CANCEL'):
                        url = URL_STABLE
                    else:
                        return
            else:
                url = URL_STABLE

            Update().create_backup()
            Update().download_file(url, NEWFILE)

            Update().install(NEWFILE, "/home/")

            BusyBox().show(7, ['HelgeInterface %sUpdate' % betaversion, "Update successfull, You may have to reactivate BMWRaspControl by pressing 'Mode'"], 10000)
            os.system('sudo service HelgeInterface restart')
        else:
            note('HelgeInterface Update', 'Connection Error!', time=800)


# ---------------------
def main():
    count = len(sys.argv) - 1
    if count > 0:
        given_args = sys.argv[1].split(';')
        if str(given_args[0]) == 'obc':
            open_obcgui()
        elif str(given_args[0]) == 'settings':
            open_settings()
        elif str(given_args[0]) == 'del_log':
            delete_log_files()
        elif str(given_args[0]) == 'update_helgeinterface':
            update_helgeinterface()
        else:
            log('Unknown Arguments given!')

    else:
        open_settings()


if __name__ == '__main__':
    main()
