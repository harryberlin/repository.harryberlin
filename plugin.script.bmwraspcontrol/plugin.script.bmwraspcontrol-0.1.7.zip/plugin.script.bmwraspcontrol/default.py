#!/usr/bin/env python
# -*- coding: utf-8 -*-


import os
import re
import sys
import glob
import time
import shutil
import urllib
import urllib2
import zipfile
from service import BusyBox
import xbmc
import xbmcgui
import xbmcaddon

__author__ = 'harryberlin'
__addon__ = xbmcaddon.Addon()
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')
__icon__ = xbmc.translatePath(os.path.join(__addonpath__, 'icon.png').encode("utf-8")).decode("utf-8")

NEWFILE = '/home/HelgeInterface/Update/HelgeInterface.zip'
URL_STABLE = 'http://bmwraspcontrol.de/software/HelgeInterface_last.zip'
URL_BETA = 'http://bmwraspcontrol.de/software/HelgeInterface_BETA.zip'
BACKUP_DIR = '/home/HelgeInterface/Update/BackUp'
BETA_V_PW = "hifb"


class Update:
    # pseudo class to combine functions
    def download_file(self, url, dest):
        dp = xbmcgui.DialogProgress()
        dp.create('HelgeInterface Update', "Lade Datei", "BMW RaspControl HelgeInterface - Update")
        urllib.urlretrieve(url, dest, lambda nb, bs, fs, url=url: self._pbhook(nb, bs, fs, url, dp))

    def _pbhook(self, numblocks, blocksize, filesize, url=None, dp=None):
        try:
            percent = min((numblocks * blocksize * 100) / filesize, 100)
            print percent
            dp.update(percent)
        except:
            percent = 100
            dp.update(percent)
        if dp.iscanceled():
            print "Download Abgebrochen"
            dp.close()
            quit()

    def create_backup(self):
        backupfolder = BACKUP_DIR + "/" + time.strftime("%Y%m%d_%H:%M:%S")
        self.check_folder(backupfolder)

        files = glob.iglob(os.path.join("/home/HelgeInterface", "*elge*nterface*.*"))

        for file in files:
            if os.path.isfile(file):
                shutil.copy2(file, backupfolder)

        xbmcgui.Dialog().notification('HelgeInterface Update', 'Create BackUp to: %s' % backupfolder, icon=__icon__, time=7000)

    def install(self, file, dst):
        zip = zipfile.ZipFile(file, "r")
        for file in zip.namelist():
            if ("dll" not in file) and ("exe" not in file):
                continue
            print("copy  " + file + " to " + dst)
            zip.extract(file, dst)

    def check_internet(self):
        try:
            response = urllib2.urlopen('http://google.de', timeout=2)
            return True
        except urllib2.URLError as err:
            pass
        return False

    def check_folder(self, directory):
        if not os.path.exists(directory):
            os.makedirs(directory)


def open_obcgui():
    pass


def open_settings():
    xbmcaddon.Addon().openSettings()


def update_helgeinterface():
    betaversion = ''
    dialog = xbmcgui.Dialog()

    if dialog.yesno("BMWRaspControl", "Are you sure to update HelgeInterface?"):
        if Update().check_internet():
            Update().check_folder(BACKUP_DIR)

            if dialog.yesno("BMWRaspControl", "Choose HelgeInterface Version[CR]              TIMEOUT 10s", nolabel='Stable', yeslabel='Beta', autoclose=10000):
                kb = xbmc.Keyboard(heading="Enter Password for Beta-Version", hidden=False)
                kb.doModal()
                if kb.isConfirmed():
                    text = kb.getText()
                else:
                    return

                if text == BETA_V_PW:
                    betaversion = 'Beta '
                    url = URL_BETA
                else:
                    if dialog.yesno("BMWRaspControl", "Invalid Password","Downloading Stable Version", yeslabel='OK', nolabel='CANCEL'):
                        url = URL_STABLE
                    else:
                        return
            else:
                url = URL_STABLE

            Update().create_backup()
            Update().download_file(url, NEWFILE)

            Update().install(NEWFILE, "/home/")

            busy = BusyBox()
            busy.show(7, ['HelgeInterface %sUpdate' % betaversion, "Update successfull, You may have to reactivate BMWRaspControl by pressing 'Mode'"], 10000)
            os.system('sudo service HelgeInterface restart')
        else:
            xbmcgui.Dialog().notification('HelgeInterface Update', 'Connection Error!', icon=xbmcgui.NOTIFICATION_ERROR, time=500)


def main():
    count = len(sys.argv) - 1
    if count > 0:
        given_args = sys.argv[1].split(';')
        if str(given_args[0]) == 'obc':
            open_obcgui()
        elif str(given_args[0]) == 'settings':
            open_settings()
        elif str(given_args[0]) == 'update_helgeinterface':
            update_helgeinterface()
        else:
            print ('BMWRaspControl: Unknown Arguments given!')

    else:
        open_settings()


if __name__ == '__main__':
    main()
