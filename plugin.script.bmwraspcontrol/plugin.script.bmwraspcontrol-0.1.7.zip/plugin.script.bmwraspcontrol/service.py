#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import time
import xbmc
import xbmcgui
import xbmcaddon
from threading import Thread
from xml.etree import ElementTree as etree

__author__ = 'harryberlin'
__addon__ = xbmcaddon.Addon()
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')
__icon__ = xbmc.translatePath(os.path.join(__addonpath__, 'icon.png').encode("utf-8")).decode("utf-8")
__busy__ = xbmc.translatePath(os.path.join(__addonpath__, 'resources','busy.gif').encode("utf-8")).decode("utf-8")

HICONFIGFILE = '/home/HelgeInterface/Config/helgeinterface.xml'
# TESTFILE = '/home/HelgeInterface/Config/helgeinterface_new.xml'


class Player(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)

    def onPlayBackStarted(self):
        pass

    def onPlayBackResumed(self):
        pass

    def onPlayBackSeek(self, time, seekOffset):
        pass


class Monitor(xbmc.Monitor):
    def __init__(self):
        xbmc.Monitor.__init__(self)

    def onSettingsChanged(self):
        print ('BMWRaspControl: ################ SETTINGS CHANGED ###############')
        load_settings()
        pass


class BusyBox(object):
    def __init__(self):
        self.busybox = xbmcgui.WindowXMLDialog('DialogBusy.xml', xbmcaddon.Addon(xbmc.getSkinDir()).getAddonInfo('path').decode('utf-8'), 'default', '720p')

    def show(self, showtime, finishmessage, notetime):
        thread = Thread(target=self._show_thread, args=[showtime, finishmessage, notetime])
        thread.setDaemon(True)
        thread.start()

    def _show_thread(self, showtime, finishmessage, notetime):
        self.busybox.show()
        time.sleep(showtime)
        self.hide()
        xbmcgui.Dialog().notification(finishmessage[0], finishmessage[1], icon=__icon__, time=notetime)

    def hide(self):
        self.busybox.close()


class XmlEditor(object):
    def __init__(self, filename):
        self.filename = filename
        self.tree = etree.parse(self.filename)

    def _get_element(self, paths):
        if isinstance(paths, basestring):
            paths = [paths]

        element = self.tree.getroot()
        for path in paths:
            element = element.find('.//' + path)
        return element

    def set_childnode(self, path_or_paths, value):
        if value == True:
            value = 'true'
        elif value == False:
            value = 'false'
        # else: use the string

        element = self._get_element(path_or_paths)
        element.clear()
        etree.SubElement(element, value)

    def set_string(self, path_or_paths, value):
        self._get_element(path_or_paths).text = value

    def save(self, filename=None):
        self.tree.write(
                filename if filename else self.filename,
                encoding='utf-8',
                xml_declaration=True
        )


def get_addon_setting(id):
    setting = xbmcaddon.Addon().getSetting(id)
    if setting == 'true': return True
    if setting == 'false': return False
    return str(setting)


def load_settings():
    print 'BMWRaspControl: Load Settings'
    busy = BusyBox()
    busy.show(7, ["BMWRaspControl", "Set Settings successfull, You may have to reactivate BMWRaspControl by pressing 'Mode' "], 10000)

    childnodesList = []
    stringList = []

    childnodesList.append('LogLvl')
    childnodesList.append('CarModel')
    stringList.append('WelcomeMessage')
    stringList.append('Clock_HourOffset')

    childnodesList.append('CdChangerEmulatorActive')
    childnodesList.append('ActivatePiInTapeMode')
    childnodesList.append('ActivatePiInAuxMode')
    childnodesList.append('SetDspDigitalInputByPiAsSource')

    # LightShow
    childnodesList.append('LightShow_active')
    childnodesList.append('LightShow_OnCarClose')
    childnodesList.append('LightShow_OnCarOpen')
    stringList.append('LightShow_EnableTimeFactor')

    # Mirrors
    childnodesList.append('ExpandMirrors_active')
    childnodesList.append('ExpandMirrors_OnCarClose')
    childnodesList.append('ExpandMirrors_OnCarOpen')

    childnodesList.append('CollapseMirrors_active')
    childnodesList.append('CollapseMirrors_OnCarClose')
    childnodesList.append('CollapseMirrors_OnCarOpen')

    # PDC
    childnodesList.append('PDC_active')
    stringList.append('PDC_Threshold')
    stringList.append('PDC_TimeOut')

    # PreHeater
    childnodesList.append('PreHeater_active')

    # ConfortBlink
    childnodesList.append('ComfortBlink_active')
    stringList.append('ComfortBlink_BlinkinTime')

    helgeinterface_config = XmlEditor(HICONFIGFILE)

    for Setting in childnodesList:
        try:
            helgeinterface_config.set_childnode(Setting.split('_'), get_addon_setting(Setting))
        except:
            print 'RASP ERROR: ' + Setting

    for Setting in stringList:
        try:
            helgeinterface_config.set_string(Setting.split('_'), get_addon_setting(Setting))
        except:
            print 'RASP ERROR: ' + Setting

    helgeinterface_config.save(HICONFIGFILE)

    # restart HelgeInterface
    os.system('sudo service HelgeInterface restart')


def main():
    print 'BMWRaspControl: Start Service'
    if monitor.waitForAbort():
        print 'BMWRaspControl: Close Service'


player = Player()
monitor = Monitor()

if __name__ == '__main__':
    main()

del player
del monitor
