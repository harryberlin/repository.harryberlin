#!/usr/bin/env python
# -*- coding: utf-8 -*-


import os
import sys
import time
import glob
import shutil
import urllib
import urllib2
import zipfile

from service import BusyBox
from threading import Event, Thread

import xbmc
import xbmcgui
import xbmcaddon

__author__ = 'harryberlin'
__addon__ = xbmcaddon.Addon()
__addonpath__ = __addon__.getAddonInfo('path').decode('utf-8')
__icon__ = xbmc.translatePath(os.path.join(__addonpath__, 'icon.png').encode("utf-8")).decode("utf-8")

# add librarys and resource files into sys path
BASE_RESOURCE_PATH = xbmc.translatePath(os.path.join(__addonpath__, 'resources'))
BASE_LIB_PATH = xbmc.translatePath(os.path.join(__addonpath__, 'resources', 'lib'))
sys.path.append(BASE_RESOURCE_PATH)
sys.path.append(BASE_LIB_PATH)

NEWFILE = '/home/HelgeInterface/Update/HelgeInterface.zip'
URL_STABLE = 'http://bmwraspcontrol.de/software/HelgeInterface_last.zip'
URL_BETA = 'http://bmwraspcontrol.de/software/HelgeInterface_BETA.zip'
BACKUP_DIR = '/home/HelgeInterface/Update/BackUp'
BETA_V_PW = "hifb"

ACTION_PARENT_DIR = 9
ACTION_PREVIOUS_MENU = 10
ACTION_CLOSE_DIALOG = 51
ACTION_SELECT_ITEM = 7
ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4
ACTION_NAV_BACK = 92
ACTION_BACKSPACE = 110

WINDOW_DIALOG_ADDON_SETTINGS = 10140

OBC_CONS1 = 0
OBC_CONS2 = 1
OBC_RANGE = 2
OBC_DIST = 3
OBC_ARRIV = 4
OBC_AVGSPEED = 5
OBC_LIMIT = 6
OBC_OUTTEMP = 7

# [Property, ButtonId, LabelId, ImageId]
OBC_ITEMS = [
    ['OBC_CONS1', 101, 201, None],
    ['OBC_CONS2', 102, 202, None],
    ['OBC_RANGE', 103, 203, None],
    ['OBC_DIST', 104, 204, None],
    ['OBC_ARRIV', 105, 205, None],
    ['OBC_AVGSPEED', 106, 206, None],
    ['OBC_LIMIT', 107, 207, 307],
    ['OBC_OUTTEMP', None, 208, None]
]


class Update(object):
    # pseudo class to combine functions
    def download_file(self, url, dest):
        dp = xbmcgui.DialogProgress()
        dp.create('HelgeInterface Update', "Lade Datei", "BMW RaspControl HelgeInterface - Update")
        urllib.urlretrieve(url, dest, lambda nb, bs, fs, url=url: self._pbhook(nb, bs, fs, url, dp))

    def _pbhook(self, numblocks, blocksize, filesize, url=None, dp=None):
        try:
            percent = min((numblocks * blocksize * 100) / filesize, 100)
            log(percent)
            dp.update(percent)
        except:
            percent = 100
            dp.update(percent)
        if dp.iscanceled():
            log("Download Abgebrochen")
            dp.close()
            quit()

    def create_backup(self):
        backupfolder = BACKUP_DIR + "/" + time.strftime("%Y%m%d_%H:%M:%S")
        self.check_folder(backupfolder)

        files = glob.iglob(os.path.join("/home/HelgeInterface", "*elge*nterface*.*"))

        for file in files:
            if os.path.isfile(file):
                shutil.copy2(file, backupfolder)

        xbmcgui.Dialog().notification('HelgeInterface Update', 'Create BackUp to: %s' % backupfolder, icon=__icon__, time=7000)

    def install(self, file, dst):
        zip = zipfile.ZipFile(file, "r")
        for file in zip.namelist():
            if ("dll" not in file) and ("exe" not in file):
                continue
            log("copy  " + file + " to " + dst)
            zip.extract(file, dst)

    def check_internet(self):
        try:
            response = urllib2.urlopen('http://google.de', timeout=2)
            return True
        except urllib2.URLError as err:
            pass
        return False

    def check_folder(self, directory):
        if not os.path.exists(directory):
            os.makedirs(directory)




class ObcGui(xbmcgui.WindowXML):
    class ObcControl(object):
        def __init__(self, gui, obcitem):
            self.gui = gui
            name, buttonid, labelid, imageid = obcitem
            log('init name %s - BtnId %s - LblId %s - ImgId %s' % (name, buttonid, labelid, imageid))

            if buttonid:
                self.buttonid = buttonid
                self.button = self.gui.getControl(self.buttonid)
            else:
                self.buttonid = None
                self.button = None

            if labelid:
                self.labelid = labelid
                self.label = gui.getControl(self.labelid)
            else:
                self.labelid = None
                self.label = None

            if imageid:
                self.imageid = imageid
                self.image = gui.getControl(self.imageid)
            else:
                self.imageid = None
                self.image = None

            self.name = name
            self.property = self.name
            self.action = True
            self.update = True

        def setLabel(self, text):
            self.update = False
            self.label.setLabel(text)

        def resetLabel(self):
            self.update = True

        def updateLabel(self):
            # log('update %s' % self.name)
            if self.update: self.label.setLabel(get_kodi_prop(self.property, 10000))

        def setNavigation(self, up=None, down=None, left=None, right=None):
            if up:
                try:
                    self.button.controlUp(up)
                except:
                    self.button.controlUp(self.buttonid)
            if down:
                try:
                    self.button.controlDown(down)
                except:
                    self.button.controlDown(self.buttonid)
            if left:
                try:
                    self.button.controlLeft(left)
                except:
                    self.button.controlLeft(self.buttonid)
            if right:
                try:
                    self.button.controlRight(right)
                except:
                    self.button.controlRight(self.buttonid)

    def __init__(self, xmlFilename, scriptPath, defaultSkin, defaultRes):
        log("Initializing OBC Gui...")
        self.selectedButton = -1
        self.selectedSubButton = 0
        self.nextUpdateLabel = 0
        self.updateTimer = RepeatTimer(0.1, self.update)
        self.obccontrols = []

    def onInit(self):

        for item in OBC_ITEMS:
            self.obccontrols.append(ObcGui.ObcControl(self, item))

        items = (len(self.obccontrols) - 1)
        # log(items)
        for i in range(0, items):
            if i == 0:
                self.obccontrols[i].setNavigation(down=self.obccontrols[i + 1].button)
            elif i > 0 and i < items:
                self.obccontrols[i].setNavigation(up=self.obccontrols[i - 1].button, down=self.obccontrols[i + 1].button)
            elif i == items:
                self.obccontrols[i].setNavigation(up=self.obccontrols[i - 1].button)

        self.updateTimer.start()

    def onAction(self, Action):
        if Action in [ACTION_PREVIOUS_MENU, ACTION_CLOSE_DIALOG, ACTION_NAV_BACK, ACTION_BACKSPACE]:
            self.onStop()

    def onFocus(self, controlId):
        pass

    def onStop(self):
        self.close()
        self.updateTimer.cancel()

    def update(self):
        for obccontrol in self.obccontrols:
            obccontrol.updateLabel()


class RepeatTimer(Thread):
    def __init__(self, interval, function, iterations=0, args=[], kwargs={}):
        Thread.__init__(self)
        self.interval = interval
        self.function = function
        self.iterations = iterations
        self.args = args
        self.kwargs = kwargs
        self.finished = Event()

    def run(self):
        count = 0
        while not self.finished.isSet() and (self.iterations <= 0 or count < self.iterations):
            self.finished.wait(self.interval)
            if not self.finished.isSet():
                self.function(*self.args, **self.kwargs)
                count += 1

    def cancel(self):
        self.finished.set()


# ---------------------
def log(string):
    xbmc.log('BMWRaspControl: %s' % string)

# ---------------------
def note(heading, message=" ",time=5000):
    xbmcgui.Dialog().notification(heading=' %s' % heading, message=' %s' % message, icon=__icon__, time=time)
    log('notification: %s - %s' % (heading, message))

# ---------------------
def set_kodi_prop(property, value, windowid=10000):
    # xbmc.log('set prop')
    xbmcgui.Window(windowid).setProperty(property, '%s' % value)


# ---------------------
def get_kodi_prop(property, windowid=10000):
    value = xbmcgui.Window(windowid).getProperty(property)
    # xbmc.log('get prop - %s : %s' % (property,value))
    return '%s' % value


# ---------------------
def open_obcgui():
    if xbmcgui.getCurrentWindowDialogId() == WINDOW_DIALOG_ADDON_SETTINGS:
        xbmc.executebuiltin('Action(Back)')
    obc = ObcGui("bc-skin.xml", __addonpath__, 'Default', '720p')
    obc.doModal()
    del obc


# ---------------------
def open_settings():
    xbmcaddon.Addon().openSettings()

# ---------------------
def delete_log_files():
    os.system('sudo rm -r /home/HelgeInterface/Log/*')
    note('Log Files deleted')

# ---------------------
def update_helgeinterface():
    betaversion = ''
    dialog = xbmcgui.Dialog()

    if dialog.yesno("BMWRaspControl", "Are you sure to update HelgeInterface?"):
        if Update().check_internet():
            Update().check_folder(BACKUP_DIR)

            if dialog.yesno("BMWRaspControl", "Choose HelgeInterface Version[CR]              TIMEOUT 10s", nolabel='Stable', yeslabel='Beta', autoclose=10000):
                kb = xbmc.Keyboard(heading="Enter Password for Beta-Version", hidden=False)
                kb.doModal()
                if kb.isConfirmed():
                    text = kb.getText()
                else:
                    return

                if text == BETA_V_PW:
                    betaversion = 'Beta '
                    url = URL_BETA
                else:
                    if dialog.yesno("BMWRaspControl", "Invalid Password", "Downloading Stable Version", yeslabel='OK', nolabel='CANCEL'):
                        url = URL_STABLE
                    else:
                        return
            else:
                url = URL_STABLE

            Update().create_backup()
            Update().download_file(url, NEWFILE)

            Update().install(NEWFILE, "/home/")

            BusyBox().show(7, ['HelgeInterface %sUpdate' % betaversion, "Update successfull, You may have to reactivate BMWRaspControl by pressing 'Mode'"], 10000)
            os.system('sudo service HelgeInterface restart')
        else:
            note('HelgeInterface Update', 'Connection Error!', time=800)


# ---------------------
def main():
    count = len(sys.argv) - 1
    if count > 0:
        given_args = sys.argv[1].split(';')
        if str(given_args[0]) == 'obc':
            open_obcgui()
        elif str(given_args[0]) == 'settings':
            open_settings()
        elif str(given_args[0]) == 'del_log':
            delete_log_files()
        elif str(given_args[0]) == 'update_helgeinterface':
            update_helgeinterface()
        else:
            log('Unknown Arguments given!')

    else:
        open_settings()


if __name__ == '__main__':
    main()
