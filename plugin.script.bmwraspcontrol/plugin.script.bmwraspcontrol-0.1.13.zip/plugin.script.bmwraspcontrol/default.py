#!/usr/bin/env python
# -*- coding: utf-8 -*-


import xbmcgui

__author__ = 'harryberlin'


# ---------------------
def main():
    xbmcgui.Dialog().ok('BMWRaspControl',  'Please install the new Addon', 'HelgeInterface', 'plugin.script.helgeinterface')


if __name__ == '__main__':
    main()
