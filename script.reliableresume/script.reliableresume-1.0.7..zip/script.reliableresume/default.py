#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'devkid/stanley87/harryberlin'

import sys


__all__ = ['PY2', 'py2_encode', 'py2_decode']

PY2 = sys.version_info[0] == 2

import os
import time

if PY2:
    import xbmc
    import xbmcgui
    import xbmcaddon
    import xbmcvfs
    from xbmc import translatePath as xbmc_translate_path
else:
    import xbmc
    import xbmcgui
    import xbmcaddon
    import xbmcvfs
    from xbmcvfs import translatePath as xbmc_translate_path
    

ADDON = xbmcaddon.Addon('script.reliableresume')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_USER_PATH = os.path.join(xbmc_translate_path('special://userdata'), 'addon_data', ADDON_ID)
ADDON_ICON = os.path.join(ADDON_PATH, 'icon.png')

DATAFILE = os.path.join(ADDON_USER_PATH, 'ResumeSaverA.m3u')
DATAFILE2 = os.path.join(ADDON_USER_PATH, 'ResumeSaverB.m3u')

if PY2:
    XBMC_LOG_LEVEL = xbmc.LOGNOTICE
else:
    XBMC_LOG_LEVEL = xbmc.LOGINFO


def get_addon_setting(id):
    setting = xbmcaddon.Addon(ADDON_ID).getSetting(id)
    if setting.lower() == 'true': return True
    if setting.lower() == 'false': return False
    return str(setting)


class ResumePlayer:
    rewind_before_play = {'0': 0.0, '1': 5.0, '2': 15.0, '3': 60.0, '4': 180.0, '5': 300.0}

    rewind_s = rewind_before_play[get_addon_setting('rewind_before_play')]

    def main(self):
        if os.path.exists(DATAFILE) or os.path.exists(DATAFILE2):
            if not self.opendata():
                return note("""Can't resume corrupt file""")
        else:
            return note('''Can't resume''', 'No File exist')

        if self.plsize == False:  # there is no playlist
            xbmc.Player().play(self.playing)
            self.seekTime(self.time)

        if get_addon_setting('volume') and self.volume is not False:
            volume_set(self.volume)

        if self.media == 'audio':
            self.plist = xbmc.PlayList(0)
        elif self.media == 'video':
            self.plist = xbmc.PlayList(1)
        else:
            self.plist = xbmc.PlayList(0)

        self.plist.clear()

        self.plist.load(self.datafile)
        # log(self.plist.size())
        if self.plsize < 1:
            return

        # xbmc.Player().play(item=self.datafile, startpos=self.plpos)


        '''
        

        for i in range(0, self.plsize):
            #log(self.plist[i].getfilename())            

            if int(self.plist[i].getduration()) > 0:
                self.can_play = True
                break

        if not self.can_play:
            xbmc.Player().stop()
            return note("Can't resume", 'File from Playlist is not available')
        '''

        if self.playing:
            #xbmc.Player().play(self.playing)    #.playselected(self.plpos)
            xbmc.Player().play(item=self.plist, windowed=False, startpos=self.plpos)
            #xbmc.Player().playselected(self.plpos)
            #self.plist.clear()
            #self.plist.load(self.datafile)

        self.can_play = False
        from threading import Thread
        self.can_play_thread = Thread(target=self.player_has_started)
        self.can_play_thread.daemon = True
        self.can_play_thread.start()

        self.can_play_thread.join()

        if not self.can_play:
            xbmc.Player().stop()
            return note('''Can't resume''', 'File from Playlist is not available')


        self.seekTime(self.time)

        if get_addon_setting('pause_on_startup') and xbmc.Player().isPlaying():
            xbmc.Player().pause()

    def seekTime(self, seekTo):
        xbmc.sleep(1000)  # wait 'a bit'. if doing seek directly it does not work when we just started playing
        if xbmc.Player().isPlaying(): xbmc.Player().seekTime(seekTo)

    def player_has_started(self):
        for counter in range(5000, 0, -1):
            if xbmc.Player().isPlaying():
                if xbmc.Player().getTime() > 0.0:
                    self.can_play = True
                    return
            xbmc.sleep(1)
        self.can_play = False

    def opendata(self):
        firstFile = DATAFILE
        secondFile = DATAFILE2

        if (os.access(firstFile, os.F_OK) and os.access(secondFile, os.F_OK)):
            log('Both files existing. checking which is newer')
            if (os.path.getctime(secondFile) > os.path.getctime(firstFile)):
                firstFile = DATAFILE2
                secondFile = DATAFILE
                log('swapping files')

        try:
            return self.opendataex(firstFile)
        except:
            return self.opendataex(secondFile)

    def opendataex(self, datafile):
        self.playlist = []
        self.datafile = datafile
        log(self.datafile)
        # self.plsize = False
        # tag = ["<window>", "<volume>", "<time>", "<plspos>", "<plsize>", "<playing>", "<media>"]

        #fh = open(file=datafile, mode='r')
        with open(datafile, mode='r') as fh:
            fh_str = fh.read()

            if fh_str.find('#STORE::DONE') < 0:
                return False

            self.volume = False
            for line in fh_str.splitlines():
                debug('line: [%s]' % line)
                theLine = line.strip()
                if theLine.startswith('#WINDOW::'):
                    self.window = theLine[9:]
                if theLine.startswith('#VOLUME::'):
                    self.volume = theLine[9:]
                if theLine.startswith('#TIME::'):
                    self.time = theLine[7:]
                    if self.time == '-':
                        self.time = False
                    else:
                        self.time = float(self.time)
                    self.time = max(0.0, self.time - self.rewind_s)
                if theLine.startswith('#PLPOS::'):
                    self.plpos = theLine[8:]
                    if self.plpos == "-":
                        self.plpos = False
                    else:
                        self.plpos = int(self.plpos)
                if theLine.startswith('#PLSIZE::'):
                    self.plsize = theLine[9:]
                    if self.plsize == '-':
                        self.plsize = False
                    else:
                        self.plsize = int(self.plsize)
                if theLine.startswith('#PLAYING::'):
                    self.playing = theLine[10:]
                    if self.playing == '-':
                        self.playing = False
                if theLine.startswith('#MEDIA::'):
                    self.media = theLine[8:]
                    if self.media == '-':
                        self.media = False
        #fh.close()
        return True

    def checkme(self):
        self.plist = xbmc.PlayList(0)
        self.plsize = self.plist.size()
        if self.plsize != 0:
            self.media = 'audio'
            for i in range(0, self.plsize):
                temp = self.plist[i]
                self.playlist.append(xbmc.PlayListItem.getfilename(temp))
            return
        else:
            pass
        self.plist = xbmc.PlayList(1)
        self.plsize = self.plist.size()
        if self.plsize != 0:
            self.media = 'video'
            for i in range(0, self.plsize):
                temp = self.plist[i]
                self.playlist.append(xbmc.PlayListItem.getfilename(temp))
            return
        else:
            self.media = '-'
            self.plsize = '-'
            self.playlist = '-'
            return


def volume_set(volume):
    # xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Application.SetVolume", "params": {"volume": %s}, "id": 1}' % volume)

    xbmc.executebuiltin('SetVolume(%s, False)' % volume)
    log('VOLUME: Set = %s' % volume)


def open_settings():
    # log('Window: %s' % xbmcgui.getCurrentWindowId())
    # log('Dialog: %s' % xbmcgui.getCurrentWindowDialogId())
    if xbmcgui.getCurrentWindowDialogId() == 10140:
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Back", "id": 1 }')
    else:
        xbmcaddon.Addon().openSettings()


def log(msg):
    xbmc.log('%s: LDR: %s' % (ADDON_ID, msg), XBMC_LOG_LEVEL)


def note(heading, message=None, time=-1, icon=None):
    if time == -1:
        xbmcgui.Dialog().notification(heading='%s' % heading, message='%s' % message if message else ' ', icon='%s' % (icon if icon else ADDON_ICON))
    else:
        xbmcgui.Dialog().notification(heading='%s' % heading, message='%s' % message if message else ' ', icon='%s' % (icon if icon else ADDON_ICON), time=time)
    log('NOTIFICATION: "%s%s"' % (heading, ' - %s' % message if message else ''))


def dialog_yesno(label1, label2=None, label3=None, nolabel='', yeslabel='', autoclose=0):
    if PY2:
        return xbmcgui.Dialog().yesno(ADDON_NAME, line1=label1, line2=label2, line3=label3, nolabel=nolabel, yeslabel=yeslabel, autoclose=autoclose)
    else:
        return xbmcgui.Dialog().yesno(ADDON_NAME, message='%s%s%s' % (label1, ' - %s' % label2 if label2 else '', ' - %s' % label3 if label3 else ''), nolabel='Cancel', yeslabel='Delete', autoclose=autoclose)


def debug(string):
    if not get_addon_setting('debug'):
        return
    log('DEBUG: %s' % string)


def delete_m3u():
    if not dialog_yesno('Sure to delete M3u Files?'):
        return
    os.remove(DATAFILE)
    os.remove(DATAFILE2)
    note('M3U Files deleted!')

def main():
    count = len(sys.argv) - 1
    if count > 0:
        log(sys.argv[1])
        given_args = sys.argv[1].split(';')
        if str(given_args[0]) == "delete_m3u":
            delete_m3u()
        elif str(given_args[0]) == "settings":
            open_settings()
        elif str(given_args[0]) == 'update':
            update()
        else:
            note('Unknown Arguments given!', '%s' % given_args)
    else:
        m = ResumePlayer()
        m.main()
        del m


if __name__ == '__main__':
    main()
