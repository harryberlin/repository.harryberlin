#!/usr/bin/env python
# -*- coding: utf-8 -*-


__author__ = 'devkid/stanley87/harryberlin'

import sys


__all__ = ['PY2', 'py2_encode', 'py2_decode']

PY2 = sys.version_info[0] == 2

import os
import json
import time
import xbmc
import xbmcgui
import xbmcaddon
import datetime

if PY2:
    import xbmc
    import xbmcgui
    import xbmcaddon
    import xbmcvfs
    from xbmc import translatePath as xbmc_translate_path
else:
    import xbmc
    import xbmcgui
    import xbmcaddon
    import xbmcvfs
    from xbmcvfs import translatePath as xbmc_translate_path

ADDON = xbmcaddon.Addon('script.reliableresume')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_USER_PATH = os.path.join(xbmc_translate_path('special://userdata'), 'addon_data', ADDON_ID)
ADDON_ICON = os.path.join(ADDON_PATH, 'icon.png')
MONITOR = xbmc.Monitor()

DATAFILE = os.path.join(ADDON_USER_PATH, 'ResumeSaverA.m3u')
DATAFILE2 = os.path.join(ADDON_USER_PATH, 'ResumeSaverB.m3u')

if PY2:
    XBMC_LOG_LEVEL = xbmc.LOGNOTICE
else:
    XBMC_LOG_LEVEL = xbmc.LOGINFO


class ResumeSaver(object):
    currentFile = 0

    if PY2:
        lastExecutionTime = time.clock()
    else:
        lastExecutionTime = datetime.datetime.now().timestamp() #time.clock()
    lastConfigReadTime = 0

    timer_amounts = {'0': 5, '1': 30, '2': 120, '3': 300, '4': 600}

    videoEnable = False
    audioEnable = False
    executeInterval = 60

    def shouldExecute(self):
        if PY2:
            now = time.clock()
        else:
            now = datetime.datetime.now().timestamp() #time.clock()
        if (now - self.lastExecutionTime) >= self.executeInterval:
            self.lastExecutionTime = now
            return True
        return False

    def shouldReadConfig(self):
        if PY2:
            now = time.clock()
        else:
            now = datetime.datetime.now().timestamp()  # time.clock()
        if (now - self.lastConfigReadTime) >= 5:
            self.lastConfigReadTime = now
            return True
        return False

    def reloadConfigIfNeeded(self):
        if self.shouldReadConfig():
            self.videoEnable = get_addon_setting('observe_video')
            self.videoExcludeLiveTV = get_addon_setting('ExcludeLiveTV')
            self.videoExcludeHTTP = get_addon_setting('ExcludeHTTP')
            self.audioEnable = get_addon_setting('observe_audio')
            self.all_to_music = get_addon_setting('all_to_music')
            self.executeInterval = self.timer_amounts[get_addon_setting('timer_amount')]

    def loader(self):
        while not MONITOR.abortRequested():
            xbmc.sleep(2000)

            self.reloadConfigIfNeeded()

            if not self.shouldExecute():
                continue

            self.playlist = []
            if xbmc.Player().isPlayingAudio() and self.audioEnable:
                self.media = 'audio'
                self.time = xbmc.Player().getTime()
                self.plist = xbmc.PlayList(0)
                self.plsize = self.plist.size()
                self.playing = xbmc.Player().getPlayingFile()
                # for i in range(0, self.plsize):
                #    self.playlist.append(self.plist[i].getfilename()+'|'+self.plist[i].getLabel()+'|'+self.plist[i].getArt('thumb')+'|'+self.plist[i].getMusicInfoTag().getArtist()+'|'+self.plist[i].getMusicInfoTag().getTitle()+'|'+self.plist[i].getMusicInfoTag().getAlbum()+'|'+self.plist[i].getMusicInfoTag().getReleaseDate())
                self.plpos = self.plist.getposition()
                if xbmc.Player().getTime() > 0:
                    self.writedata()
            elif xbmc.Player().isPlayingVideo() and self.all_to_music:
                self.media = 'audio'
                self.time = xbmc.Player().getTime()
                self.plist = xbmc.PlayList(0)
                self.plsize = self.plist.size()
                self.playing = xbmc.Player().getPlayingFile()
                # for i in range(0, self.plsize):
                #    self.playlist.append(self.plist[i].getfilename())
                self.plpos = self.plist.getposition()
                if xbmc.Player().getTime() > 0:
                    self.writedata()
                if (self.playing.find("pvr://") > -1) and self.videoExcludeLiveTV:
                    log('Video is PVR (Live TV), which is currently set as an excluded source.')
                    continue
            elif xbmc.Player().isPlayingVideo() and self.videoEnable:
                self.media = 'video'
                self.time = xbmc.Player().getTime()
                self.plist = xbmc.PlayList(1)
                self.plsize = self.plist.size()
                self.playing = xbmc.Player().getPlayingFile()
                # for i in range(0, self.plsize):
                #    self.playlist.append(self.plist[i].getfilename())
                self.plpos = self.plist.getposition()
                if xbmc.Player().getTime() > 0:
                    self.writedata()
                if (self.playing.find("pvr://") > -1) and self.videoExcludeLiveTV:
                    log('Video is PVR (Live TV), which is currently set as an excluded source.')
                    continue
            else:
                continue

            if (self.playing.find("http://") > -1 or self.playing.find("https://") > -1) and self.videoExcludeHTTP:
                log("Media is from an HTTP/S source, which is currently set as an excluded source.")
                continue

    def writedata(self):
        if self.currentFile == 0:
            self.writedataex(DATAFILE)
            self.currentFile = 1
        else:
            self.writedataex(DATAFILE2)
            self.currentFile = 0

    def writedataex(self, datafile):
        with open(datafile, 'w') as f:
            f.write('#EXTCPlayListM3U::M3U\n')
            debug('writing m3u tracks started')
            if self.plsize != '-':
                for i in range(0, self.plsize):
                    if PY2:
                        f.write('#EXTINF:0,%s\n' % (os.path.split(self.plist[i].getfilename())[1]))
                        f.write('%s\n' % self.plist[i].getfilename())
                    else:
                        f.write('#EXTINF:0,%s\n' % (os.path.split(self.plist[i].getPath())[1]))
                        f.write('%s\n' % self.plist[i].getPath())
            debug('writing m3u tracks finished')
            
            debug('writing extra tags started')
            f.write('#MEDIA::%s\n' % self.media)
            debug('#MEDIA::%s\n' % self.media)
            
            f.write('#TIME::%s\n' % self.time)
            debug('#TIME::%s\n' % self.time)
            
            f.write('#PLPOS::%s\n' % self.plpos)
            debug('#PLPOS::%s\n' % self.plpos)
            
            f.write('#PLSIZE::%s\n' % self.plsize)
            debug('#PLSIZE::%s\n' % self.plsize)
            
            f.write('#PLAYING::%s\n' % self.playing)
            debug('#PLAYING::%s\n' % self.playing)
            
            f.write('#WINDOW::%s\n' % xbmcgui.getCurrentWindowId())
            debug('#WINDOW::%s\n' % xbmcgui.getCurrentWindowId())
            
            f.write('#VOLUME::%s\n' % volume_get())
            debug('#VOLUME::%s\n' % volume_get())
            
            f.write('#STORE::DONE\n')
            debug('#STORE::DONE\n')

            debug('writing extra tags finished')


def volume_get():
    request = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Application.GetProperties", "params": { "properties": [ "volume" ] }, "id": 1}')
    volume = json.loads(u'%s' % request)['result']['volume']
    log('VOLUME: Get %s' % volume)
    return volume


def log(msg):
    xbmc.log('%s: SRV: %s' % (ADDON_ID, msg), XBMC_LOG_LEVEL)


def note(heading, message=None, time=-1, icon=None):
    if time == -1:
        xbmcgui.Dialog().notification(heading='%s' % heading, message='%s' % message if message else ' ', icon='%s' % (icon if icon else ADDON_ICON))
    else:
        xbmcgui.Dialog().notification(heading='%s' % heading, message='%s' % message if message else ' ', icon='%s' % (icon if icon else ADDON_ICON), time=time)
    log('NOTIFICATION: "%s%s"' % (heading, ' - %s' % message if message else ''))


def get_addon_setting(id):
    setting = xbmcaddon.Addon(ADDON_ID).getSetting(id)
    if setting.lower() == 'true': return True
    if setting.lower() == 'false': return False
    return str(setting)

def str_to_bstr(s):
    if not PY2 and isinstance(s, str):
        #s = b'%s' % s
        #return s.encode('utf-8')
        #if PLATFORM_WINDOWS:
        #    return bytes(s, 'cp1252')
        #else:
        s = bytes(s, 'utf-8')
    return s


def debug(string):
    if not get_addon_setting('debug'):
        return
    log('DEBUG: %s' % string)
    

def main():
    if os.access(ADDON_USER_PATH, os.F_OK) == 0:
        os.mkdir(ADDON_USER_PATH)
    if get_addon_setting('autorun'):
        xbmc.executescript('special://home/addons/script.reliableresume/default.py')
    m = ResumeSaver()
    m.loader()
    del m


if __name__ == '__main__':
    main()
