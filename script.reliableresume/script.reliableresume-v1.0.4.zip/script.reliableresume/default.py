#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'devkid/stanley87/harryberlin'

import os
import time
import xbmc
import xbmcgui
import xbmcaddon

ADDON = xbmcaddon.Addon('script.reliableresume')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_USER_PATH = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data', ADDON_ID)
ADDON_ICON = os.path.join(ADDON_PATH, 'icon.png')

DATAFILE = os.path.join(ADDON_USER_PATH, 'ResumeSaverA.m3u')
DATAFILE2 = os.path.join(ADDON_USER_PATH, 'ResumeSaverB.m3u')


def get_addon_setting(id):
    setting = xbmcaddon.Addon(ADDON_ID).getSetting(id)
    if setting.lower() == 'true': return True
    if setting.lower() == 'false': return False
    return str(setting)


class ResumePlayer:
    rewind_before_play = {'0': 0.0, '1': 5.0, '2': 15.0, '3': 60.0, '4': 180.0, '5': 300.0}

    rewind_s = rewind_before_play[get_addon_setting('rewind_before_play')]

    def main(self):
        if os.path.exists(DATAFILE) or os.path.exists(DATAFILE2):
            self.opendata()
        else:
            return note('''Can't resume''', 'No File exist')

        if self.plsize == False:  # there is no playlist
            xbmc.Player().play(self.playing)
            self.seekTime(self.time)

        if self.media == 'audio':
            self.plist = xbmc.PlayList(0)
        elif self.media == 'video':
            self.plist = xbmc.PlayList(1)
        else:
            self.plist = xbmc.PlayList(0)

        self.plist.clear()

        self.plist.load(self.datafile)
        # log(self.plist.size())
        if self.plsize < 1:
            return

        # xbmc.Player().play(item=self.datafile, startpos=self.plpos)
        if get_addon_setting('volume') and self.volume is not False:
            volume_set(self.volume)

        xbmc.Player().playselected(self.plpos)

        self.seekTime(self.time)
        if get_addon_setting('pause_on_startup') and xbmc.Player().isPlaying():
            xbmc.Player().pause()

    def seekTime(self, seekTo):
        time.sleep(1)  # wait 'a bit'. if doing seek directly it does not work when we just started playing
        if xbmc.Player().isPlaying(): xbmc.Player().seekTime(seekTo)

    def opendata(self):
        firstFile = DATAFILE
        secondFile = DATAFILE2

        if (os.access(firstFile, os.F_OK) and os.access(secondFile, os.F_OK)):
            log('Both files existing. checking which is newer')
            if (os.path.getctime(secondFile) > os.path.getctime(firstFile)):
                firstFile = DATAFILE2
                secondFile = DATAFILE
                log('swapping files')

        try:
            self.opendataex(firstFile)
        except:
            self.opendataex(secondFile)

    def opendataex(self, datafile):
        self.playlist = []
        self.datafile = datafile
        log(self.datafile)
        # tag = ["<window>", "<volume>", "<time>", "<plspos>", "<plsize>", "<playing>", "<media>"]
        fh = open(name=datafile, mode='r')
        count = 0
        self.volume = False
        for line in fh.readlines():
            theLine = line.strip()
            if theLine.startswith('#WINDOW::'):
                self.window = theLine[9:]
            if theLine.startswith('#VOLUME::'):
                self.volume = theLine[9:]
            if theLine.startswith('#TIME::'):
                self.time = theLine[7:]
                if self.time == '-':
                    self.time = False
                else:
                    self.time = float(self.time)
                self.time = max(0.0, self.time - self.rewind_s)
            if theLine.startswith('#PLPOS::'):
                self.plpos = theLine[8:]
                if self.plpos == "-":
                    self.plpos = False
                else:
                    self.plpos = int(self.plpos)
            if theLine.startswith('#PLSIZE::'):
                self.plsize = theLine[9:]
                if self.plsize == '-':
                    self.plsize = False
                else:
                    self.plsize = int(self.plsize)
            if theLine.startswith('#PLAYING::'):
                self.playing = theLine[10:]
                if self.playing == '-':
                    self.playing = False
            if theLine.startswith('#MEDIA::'):
                self.media = theLine[8:]
                if self.media == '-':
                    self.media = False
        fh.close()

    def checkme(self):
        self.plist = xbmc.PlayList(0)
        self.plsize = self.plist.size()
        if self.plsize != 0:
            self.media = 'audio'
            for i in range(0, self.plsize):
                temp = self.plist[i]
                self.playlist.append(xbmc.PlayListItem.getfilename(temp))
            return
        else:
            pass
        self.plist = xbmc.PlayList(1)
        self.plsize = self.plist.size()
        if self.plsize != 0:
            self.media = 'video'
            for i in range(0, self.plsize):
                temp = self.plist[i]
                self.playlist.append(xbmc.PlayListItem.getfilename(temp))
            return
        else:
            self.media = '-'
            self.plsize = '-'
            self.playlist = '-'
            return





def volume_set(volume):
    # xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Application.SetVolume", "params": {"volume": %s}, "id": 1}' % volume)

    xbmc.executebuiltin('SetVolume(%s, False)' % volume)
    log('VOLUME: Set = %s' % volume)


def log(msg):
    xbmc.log('%s: LDR: %s' % (ADDON_ID, msg), xbmc.LOGNOTICE)


def note(heading, message=None, time=-1, icon=None):
    if time == -1:
        xbmcgui.Dialog().notification(heading='%s' % heading, message='%s' % message if message else ' ', icon='%s' % (icon if icon else ADDON_ICON))
    else:
        xbmcgui.Dialog().notification(heading='%s' % heading, message='%s' % message if message else ' ', icon='%s' % (icon if icon else ADDON_ICON), time=time)
    log('NOTIFICATION: "%s%s"' % (heading, ' - %s' % message if message else ''))





def main():
    m = ResumePlayer()
    m.main()
    del m


if __name__ == '__main__':
    main()
