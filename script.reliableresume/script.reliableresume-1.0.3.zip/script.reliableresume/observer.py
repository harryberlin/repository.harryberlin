#!/usr/bin/env python
# -*- coding: utf-8 -*-


import time, os
import xbmcaddon, xbmcgui, xbmc

__addonID__ = "script.reliableresume"
DATADIR = xbmc.translatePath("special://profile/addon_data/" + __addonID__ + "/")

DATAFILE = os.path.join(DATADIR, "ResumeSaverA.m3u")
DATAFILE2 = os.path.join(DATADIR, "ResumeSaverB.m3u")

if os.access(DATADIR, os.F_OK) == 0:
    os.mkdir(DATADIR)


class ResumeSaver(object):
    currentFile = 0

    lastExecutionTime = time.clock()
    lastConfigReadTime = 0

    timer_amounts = {}
    timer_amounts['0'] = 5
    timer_amounts['1'] = 30
    timer_amounts['2'] = 120
    timer_amounts['3'] = 300
    timer_amounts['4'] = 600

    videoEnable = False
    audioEnable = False
    executeInterval = 60

    def shouldExecute(self):
        now = time.clock()
        if ((now - self.lastExecutionTime) >= self.executeInterval):
            self.lastExecutionTime = now
            return True
        return False

    def shouldReadConfig(self):
        now = time.clock()
        if ((now - self.lastConfigReadTime) >= 5):
            self.lastConfigReadTime = now
            return True
        return False

    def reloadConfigIfNeeded(self):
        if (self.shouldReadConfig()):
            Addon = xbmcaddon.Addon(__addonID__)
            self.videoEnable = (Addon.getSetting('observe_video') == 'true')
            self.audioEnable = (Addon.getSetting('observe_audio') == 'true')
            self.all_to_music = (Addon.getSetting('all_to_music') == 'true')
            self.executeInterval = self.timer_amounts[Addon.getSetting('timer_amount')]

    def loader(self):
        while (not xbmc.abortRequested):
            time.sleep(2)

            self.reloadConfigIfNeeded()

            if not self.shouldExecute():
                continue

            self.playlist = []
            if xbmc.Player().isPlayingAudio() and self.audioEnable:
                self.media = "audio"
                self.time = xbmc.Player().getTime()
                self.plist = xbmc.PlayList(0)
                self.plsize = self.plist.size()
                self.playing = xbmc.Player().getPlayingFile()
                #for i in range(0, self.plsize):
                #    self.playlist.append(self.plist[i].getfilename()+'|'+self.plist[i].getLabel()+'|'+self.plist[i].getArt('thumb')+'|'+self.plist[i].getMusicInfoTag().getArtist()+'|'+self.plist[i].getMusicInfoTag().getTitle()+'|'+self.plist[i].getMusicInfoTag().getAlbum()+'|'+self.plist[i].getMusicInfoTag().getReleaseDate())
                self.plpos = self.plist.getposition()
                self.writedata()
            elif xbmc.Player().isPlayingVideo() and self.all_to_music:
                self.media = "audio"
                self.time = xbmc.Player().getTime()
                self.plist = xbmc.PlayList(0)
                self.plsize = self.plist.size()
                self.playing = xbmc.Player().getPlayingFile()
                #for i in range(0, self.plsize):
                #    self.playlist.append(self.plist[i].getfilename())
                self.plpos = self.plist.getposition()
                self.writedata()
            elif xbmc.Player().isPlayingVideo() and self.videoEnable:
                self.media = "video"
                self.time = xbmc.Player().getTime()
                self.plist = xbmc.PlayList(1)
                self.plsize = self.plist.size()
                self.playing = xbmc.Player().getPlayingFile()
                #for i in range(0, self.plsize):
                #    self.playlist.append(self.plist[i].getfilename())
                self.plpos = self.plist.getposition()
                self.writedata()

    def writedata(self):
        if (self.currentFile == 0):
            self.writedataex(DATAFILE)
            self.currentFile = 1
        else:
            self.writedataex(DATAFILE2)
            self.currentFile = 0

    def writedataex(self, datafile):
        f = open(name=datafile, mode="wb")
        f.write("#EXTCPlayListM3U::M3U\n")
        if self.plsize != "-":
            for i in range(0, self.plsize):
                f.write("#EXTINF:0,%s\n" % (os.path.split(self.plist[i].getfilename())[1]))
                f.write("%s\n" % self.plist[i].getfilename())
        f.write("#MEDIA::%s\n" % self.media)
        f.write("#TIME::%s\n" % self.time)
        f.write("#PLPOS::%s\n" % self.plpos)
        f.write("#PLSIZE::%s\n" % self.plsize)
        f.write("#PLAYING::%s\n" % self.playing)
        f.write("#WINDOW::%s\n" % xbmcgui.getCurrentWindowId())
        f.close()


def log(msg):
    xbmc.log("%s: %s" % (__addonID__, msg), xbmc.LOGNOTICE)


def getAddonSetting(id):
    setting = xbmcaddon.Addon().getSetting(id)
    if setting == 'true': return True
    if setting == 'false': return False
    return str(setting)


def main():
    #if getAddonSetting('autorun'):
    xbmc.executescript('special://home/addons/script.reliableresume/default.py')
    m = ResumeSaver()
    m.loader()
    del m


if __name__ == '__main__':
    main()
