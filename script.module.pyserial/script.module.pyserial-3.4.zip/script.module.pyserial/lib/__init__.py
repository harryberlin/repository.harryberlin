#!/usr/bin/env python
#
# This module for kodi implementation
#
# This owner of pySerial is.
# Chris Liechti <cliechti@gmx.net>
# https://github.com/pyserial/pyserial

