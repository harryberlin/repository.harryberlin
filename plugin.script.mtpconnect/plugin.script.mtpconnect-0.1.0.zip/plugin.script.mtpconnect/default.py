#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
import time
import xbmc
import xbmcgui
import xbmcaddon
from threading import Thread

__author__ = 'harryberlin'

DEVICE_NAMES = ['Android', 'userdefined']
ANDROID_PATH = home = os.path.expanduser("~") + "/Android"


def ok(message1, message2=" ", message3=" "):
    xbmcgui.Dialog().ok(heading="MTP Connect", line1=message1, line2=message2, line3=message3)


def note(header, message=" ", time=3000):
    __icon__ = xbmcaddon.Addon().getAddonInfo('path') + '/icon.png'
    xbmcgui.Dialog().notification(heading=' %s' % header, message=' %s' % message, icon=__icon__, time=time)
    log('NOTIFICATION: ' + header + ' - ' + message)


def log(message):
    xbmc.log('plugin.script.mtpconnect: %s' % message)


def busy_show():
    xbmc.executebuiltin("ActivateWindow(busydialog)")


def busy_close():
    xbmc.executebuiltin("Dialog.Close(busydialog)")


def run_command(command):
    import subprocess
    f = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    return f.stdout.read()


def open_settings():
    xbmcaddon.Addon().openSettings()


def install():
    busy_show()
    log('update package libary')
    command = 'sudo apt-get update'
    f = run_command(command)

    log('install package and add mount-path')
    command = 'sudo apt-get install -y jmtpfs'
    f = run_command(command)
    log(f)

    command = 'sudo mkdir %s' % ANDROID_PATH
    f = run_command(command)
    log(f)
    busy_close()
    note("Package installed","Path %s created" % ANDROID_PATH)


def deinstall():
    busy_show()
    log('delete directory')
    command = 'sudo apt-get remove -y jmtpfs'
    f = run_command(command)
    log(f)

    log('delete directory')
    command = 'sudo rmdir %s' % ANDROID_PATH
    f = run_command(command)
    log(f)
    busy_close()
    note("Package deinstalled","Path %s removed" % ANDROID_PATH)


def connect():
    ### Select and Set
    '''
    selected = xbmcgui.Dialog().select("Set Device Name", DEVICE_NAMES)
    if selected != -1:
        if DEVICE_NAMES[selected] == DEVICE_NAMES[0]:
            device_name = DEVICE_NAMES[0]

        elif DEVICE_NAMES[selected] == DEVICE_NAMES[1]:
            response = xbmcgui.Dialog().input("Set Custom Device Name")
            if response == '': return
            device_name = response

    log(device_name)

    command = 'sudo apt-get update'
    f = run_command(command)
    log(f)
    '''
    disconnect(False)

    ok('Some Devices only share their Folders,', 'when Screen is unlocked.','UNLOCK YOUR DISPLAY')

    command = 'sudo mkdir %s' % ANDROID_PATH
    f = run_command(command)
    log(f)

    log('try to mount')
    command = 'sudo jmtpfs -o allow_other %s' % ANDROID_PATH
    f = run_command(command)
    log(f)

    if f.find('No mtp devices found') > 0 or f.find('bad mount point') > 0 or f.find('jmtpfs: command not found') > 0:
        note("CAN'T CONNECT DEVICE")

    elif f.find('Device 0') > 0 or f.find('Device 1') > 0 or f.find('Device 2') > 0 or f.find('Device 3') > 0:
        note("Android Device connected",time=800)
        DIR_CHECKER.start()

    else:
        pass


def disconnect(shownotification=True):
    log('try to unmount')
    command = 'sudo umount %s' % ANDROID_PATH
    f = run_command(command)
    log(f)
    #if f.find('not mounted') > 0: note("Android Device already unmounted")
    if shownotification: note("Android Device disconnected")


def is_device_on():
    counter = 0
    while counter < 1:
        #log("check path %s" % counter)
        try:
            if os.listdir(ANDROID_PATH) == []:
                pass
            else:
                counter = -1
            time.sleep(1)
            counter += 1
        except:
            break
    disconnect()


def main():
    count = len(sys.argv) - 1
    if count > 0:
        given_args = sys.argv[1].split(';')
        if str(given_args[0]) == "install":
            install()
        elif str(given_args[0]) == "deinstall":
            deinstall()
        elif str(given_args[0]) == "connect":
            connect()
        elif str(given_args[0]) == "disconnect":
            disconnect(False)
        elif str(given_args[0]) == "settings":
            open_settings()
        else:
            note(header='Unknown Arguments given!', message='install, connect, disconnect are available', time=5000)

    else:
        open_settings()


DIR_CHECKER = Thread(name="dirchecker", target=is_device_on)
DIR_CHECKER.setDaemon(True)

if __name__ == '__main__':
    main()
