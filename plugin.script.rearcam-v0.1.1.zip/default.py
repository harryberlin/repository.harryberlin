#!/usr/bin/python
# -*- coding: utf-8 -*-

'''

This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0) License.



To view a copy of this license, visit

German version:  http://creativecommons.org/licenses/by-nc-sa/4.0/deed.de

English version: http://creativecommons.org/licenses/by-nc-sa/4.0/



or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.

'''

import os
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import os.path
from threading import Thread

###### intall these pakets #####
# sudo apt-get install python-opencv
import cv2

addon = xbmcaddon.Addon()
addonid = addon.getAddonInfo('id')
addonname = addon.getAddonInfo('name')
path = ('/tmp/ramdisk'.encode("utf-8")).decode("utf-8")

ACTION_PREVIOUS_MENU = 10
ACTION_STOP = 13
ACTION_NAV_BACK = 92
ACTION_BACKSPACE = 110

PIC_X = int(xbmcaddon.Addon().getSetting('pic_x'))
PIC_Y = int(xbmcaddon.Addon().getSetting('pic_y'))
PIC_W = int(xbmcaddon.Addon().getSetting('pic_w'))
PIC_H = int(xbmcaddon.Addon().getSetting('pic_h'))
MIRROR_VERTICAL = True if (xbmcaddon.Addon().getSetting('mirror_v') == 'true') else False
CAMERA_PORT = 0


class CamWindow(xbmcgui.WindowDialog):
    def __init__(self):
        # path = xbmc.translatePath('special://profile/addon_data/%s' %addonid )
        loader = xbmc.translatePath('special://home/addons/%s/resources/loader.gif' % addonid)

        ##### Create RAM Drive #####
        # RAM_DRIVE	= xbmcaddon.Addon().getAddonInfo('path') + '/ramdrive.sh'
        # f=os.popen('sudo -s bash ' + RAM_DRIVE)
        if not xbmcvfs.exists(path):
            f = os.popen('sudo -s mkdir /tmp/ramdisk')
            f = os.popen('sudo -s chmod 777 /tmp/ramdisk')
            f = os.popen('sudo -s mount -t tmpfs -o size=16M tmpfs /tmp/ramdisk/')
            #f = os.popen('mkfifo /tmp/ramdisk/image.jpg')

        if not xbmcvfs.exists(path):
            xbmcvfs.mkdir(path)

        self.camera = cv2.VideoCapture(CAMERA_PORT)
        self.camera.set(3, 640)
        self.camera.set(4, 480)

        # Define the codec and create VideoWriter object
        #fourcc = cv2.cv.CV_FOURCC(*'MJPG')
        #self.stream = cv2.VideoWriter(os.path.join(path, 'stream.gif'), fourcc, 20.0, (640, 480))

        urls = [
            # addon.getSetting('URL1'),
            # addon.getSetting('URL2'),
            # addon.getSetting('URL3'),
            # addon.getSetting('URL4'),
            # addon.getSetting('URL5'),
            # addon.getSetting('URL6')

            # Test URLs with Webcams
            # 'http://webcams.passau.de/cam-rathaus-huge-aktuell.jpg',
            ##'http://www.mediac2.de/projekte/webcam/wallstrasse/aktuell/aktuell.jpg',
            # 'http://64.251.85.30/jpg/image.jpg?time=1458071906862&dummy=image.jpg',
            # 'http://www.cityscope.de/bmw/current_pano.jpg',
            ##'http://www.goldbeck.de/uploads/webcam/df0691/current.jpg',
            'http://205.157.152.230/jpg/image.jpg?time=1458072061233&dummy=image.jpg',
            # 'http://62.157.185.131/record/current.jpg',
            # 'http://webcams.passau.de/cam-rathaus-huge-aktuell.jpg'
        ]

        files = [
            os.path.join(path, '1.0.jpg'),
            # os.path.join(path, '2.0.jpg'),
            # os.path.join(path, '3.0.jpg'),
            # os.path.join(path, '4.0.jpg'),
            # os.path.join(path, '5.0.jpg'),
            # os.path.join(path, '6.0.jpg')
        ]

        # coords = (
        #    (12, 360, 205, 160),
        #    (222, 360, 205, 160),
        #    (432, 360, 205, 160),
        #    (642, 360, 205, 160),
        #    (852, 360, 205, 160),
        #    (1062, 360, 205, 160),
        # )

        coords = (
            (PIC_X, PIC_Y, PIC_W, PIC_H),
            # (000, 000, 426, 360),
            # (427, 000, 426, 360),
            # (854, 000, 426, 360),
            # (000, 361, 426, 360),
            # (427, 361, 426, 360),
            # (854, 361, 426, 360),
        )

        imgs = []
        for c, f in zip(coords, files):
            # aspectRatio: integer - (values 0 = stretch (default), 1 = scale up (crops), 2 = scale down (black bars)
            img = xbmcgui.ControlImage(*c, filename=loader, aspectRatio=0)
            self.addControl(img)
            imgs.append(img)

        # workaround - superimposed image controls to prevent flicker
        imgs2 = []
        for c, f in zip(coords, files):
            img = xbmcgui.ControlImage(*c, filename='', aspectRatio=0)
            self.addControl(img)
            imgs2.append(img)

        cams = [list(l) for l in zip(urls, files, imgs, imgs2)]

        self.show()
        # self.isRunning = True
        set_kodi_prop('rearcam', '1')

        for i, c in enumerate(cams):
            t = Thread(target=self.getImages, args=(i, c, path))
            t.start()

        while (not xbmc.abortRequested) and get_kodi_prop('rearcam') == '1':
            xbmc.sleep(1000)

        for i in xbmcvfs.listdir(path)[1]:
            if i <> "settings.xml":
                xbmcvfs.delete(os.path.join(path, i))

        self.closeWindow()

    def getImages(self, i, c, path):
        x = 0
        error = True
        while (not xbmc.abortRequested) and get_kodi_prop('rearcam') == '1':
            try:
                x += 1
                c[1] = os.path.join(path, '%d.%d.jpg') % (i, x)
                # c[1] = '/tmp/ramdisk/image.jpg'
                xbmcvfs.delete(os.path.join(path, '%d.%d.jpg') % (i, x - 2))

                retval, frame = self.camera.read()

                if MIRROR_VERTICAL:
                    frame = cv2.flip(frame, 1)

                cv2.imwrite(c[1], frame) # image
                # urlretrieve(c[0], c[1])
                if error:
                    error = False
                    c[2].setColorDiffuse('0xFFFFFFFF')
                    c[3].setColorDiffuse('0xFFFFFFFF')
                c[2].setImage(c[1], useCache=False)

                c[3].setImage(c[1], useCache=False)
            except Exception, e:
                error = True
                xbmc.log(str(e))
                # error = xbmc.translatePath('special://home/addons/%s/resources/error.png' %addonid )
                # c[2].setImage(error, useCache=False)
                c[2].setColorDiffuse('0xC0FF0000')
                c[3].setColorDiffuse('0xC0FF0000')

        self.camera.release()

    def onAction(self, action):
        # xbmc.log(str(action))
        if action in (ACTION_PREVIOUS_MENU, ACTION_STOP, ACTION_NAV_BACK, ACTION_BACKSPACE):
            set_kodi_prop('rearcam', '0')
            self.closeWindow()

    def closeWindow(self):
        # self.isRunning = False
        self.close()


def set_kodi_prop(property, value):
    # xbmc.log('set prop')
    xbmcgui.Window(10000).setProperty(property, '%s' % value)


def get_kodi_prop(property):
    value = xbmcgui.Window(10000).getProperty(property)
    # xbmc.log('get prop - %s : %s' % (property,value))
    return '%s' % value


CW = CamWindow()
del CW
